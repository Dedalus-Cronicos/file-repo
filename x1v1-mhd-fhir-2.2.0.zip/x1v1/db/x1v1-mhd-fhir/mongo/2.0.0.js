load("util/definition/def_configuration.js");
load("util/2.0.0-configuration.js");

load("util/2.0.0-resource_mapping.js");
