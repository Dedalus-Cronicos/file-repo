load("util/definition/def_configuration.js");
load("util/1.5.0-configuration.js");
load("util/1.5.0-resource_mapping.js");
