load("util/definition/def_configuration.js");
load("util/1.6.0-configuration.js");
