db.configuration.remove({ key: "default210"});
db.configuration.insert(defaultConfiguration210);