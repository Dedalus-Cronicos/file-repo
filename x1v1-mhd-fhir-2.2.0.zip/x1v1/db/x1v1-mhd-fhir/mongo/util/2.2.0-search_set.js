db.search_set.ensureIndex({ expirationTime: 1});
db.search_set.ensureIndex({ key: 1});