db.resource_mapping.dropIndex("resourceType_1_id_1");
db.resource_mapping.dropIndex("resourceType_1_xdsUniqueId_1");

db.resource_mapping.ensureIndex({ xdsObjectType: 1 , id: 1});
db.resource_mapping.ensureIndex({ xdsObjectType: 1 , xdsUniqueId: 1});
