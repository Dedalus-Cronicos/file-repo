load("util/definition/deprecated_def_configuration.js");

var defaultConfiguration220 = {
    "key": "default220",
    "commons": {
		"paging": {
			"searchDefaultPageSize": 10,
			"searchMaximumPageSize": 100,
			"searchExpirationTimeout": 300
		},
        "hideDeprecatedDocument": false,
		"searchPatientWithOrWithoutSystemPrefix": "BOTH",
        "showRelatedDataWithIti66": false,
		"validator": {
			"profilePath": "@x1v1.mhd.fhir.validation.profiles.path@",
			"profilesJobEnabled": "@x1v1.mhd.fhir.validation.update.profiles.enabled@",
			"profilesJobFixedDelay": "@x1v1.mhd.fhir.validation.update.profiles.delay@",
			"codeSystemPath": "@x1v1.mhd.fhir.validation.codesystems.path@",
			"codesystemsJobEnabled": false,
			"codesystemsJobFixedDelay": 0,
			"valueSetPath": "@x1v1.mhd.fhir.validation.valuesets.path@",
			"valuesetsJobEnabled": false,
			"valuesetsJobFixedDelay": 0,
			"discoveryServiceInfo": {
				"url": "@x1v1.mhd.fhir.validation.discovery.url@",
				"headers": "@x1v1.mhd.fhir.validation.discovery.headers@",
				"username": "@x1v1.mhd.fhir.validation.discovery.username@",
				"password": "@x1v1.mhd.fhir.validation.discovery.password@",
				"clientId": "@x1v1.mhd.fhir.validation.discovery.clientId@",
				"leeway": "@x1v1.mhd.fhir.validation.discovery.leeway@"
			}
		}
    },
    "fhir": [{
            "version": "DSTU3",
            "fhirRepositories": [{
                    "name": "PEOPLE",
                    "publicEndpoint": "@domain.public.protocol@://@mpi@@domain.public@/people.fhir/fhir",
                    "internalEndpoint": "http://@mpi@@domain.internal.mpi@/people.fhir/fhir",
                    "useAuthToken": true,
                    "relativeReferenceEnabled": false,
                    "resources": ["Patient"],
					"customHeaders": {
					}
                }, {
                    "name": "HPDX",
                    "publicEndpoint": "@domain.public.protocol@://@hpdx@@domain.public@/hpdx/fhir/dstu3",
                    "internalEndpoint": "http://@hpdx@@domain.internal.hpdx@/hpdx/fhir/dstu3",
                    "useAuthToken": true,
                    "relativeReferenceEnabled": false,
                    "resources": ["Practitioner", "Organization"],
					"customHeaders": {
					}
                }, {
                    "name": "CLINICAL",
                    "publicEndpoint": "@domain.public.protocol@://@fhir.clinical@@domain.public@/x1v1-fhir-clinical/STU3",
                    "internalEndpoint": "http://@fhir.clinical@@domain.internal.xds@/x1v1-fhir-clinical/STU3",
                    "useAuthToken": true,
                    "relativeReferenceEnabled": false,
                    "resources": ["*"],
					"customHeaders": {
					}
                }, {
                    "name": "MHD",
                    "publicEndpoint": "@domain.public.protocol@://@mhd@@domain.public@/x1v1-mhd-fhir/STU3",
                    "internalEndpoint": "http://@mhd@@domain.internal.xds@/x1v1-mhd-fhir/STU3",
                    "useAuthToken": true,
                    "relativeReferenceEnabled": false,
                    "resources": ["DocumentReference", "Binary", "DocumentManifest", "List"],
					"customHeaders": {
					}
                }, {
                    "name": "TERMINOLOGY",
                    "publicEndpoint": "@domain.public.protocol@://@fhir.terminology@@domain.public@/x1v1-fhir-terminology/STU3",
                    "internalEndpoint": "http://@fhir.terminology@@domain.internal.xds@/x1v1-fhir-terminology/STU3",
                    "useAuthToken": false,
                    "relativeReferenceEnabled": false,
                    "resources": ["CodeSystem", "ValueSet"],
					"customHeaders": {
					}
                }
            ],
            "identifierResolvers": [{
                    "resource": "Patient",
                    "priority": [{
                            "type": "system",
                            "value": "urn:oid:2.16.840.1.113883.2.9.3.12.4.1"
                        }
                    ],
                    "returnFirstWhenPriorityNotFound": false
                }, {
                    "resource": "Practitioner",
                    "priority": [{
                            "type": "system",
                            "value": "urn:oid:2.16.840.1.113883.2.9.3.12.4.1"
                        },{
                            "type": "system",
                            "value": "http://xvalue.dedalus.eu/auth/users"
                        }
                    ],
                    "returnFirstWhenPriorityNotFound": false
                }, {
                    "resource": "Organization",
                    "priority": [{
                            "type": "system",
                            "value": "http://xvalue.dedalus.eu/fhir/organization/id"
                        }
                    ],
                    "returnFirstWhenPriorityNotFound": false
                }, {
                    "resource": "Encounter",
                    "priority": [{
                            "type": "system",
                            "value": "http://xvalue.dedalus.eu/fhir/encounter/id"
                        }
                    ],
                    "returnFirstWhenPriorityNotFound": false
                }, {
                    "resource": "DiagnosticReport",
                    "priority": [{
                            "type": "system",
                            "value": "http://xvalue.dedalus.eu/fhir/labresults/id"
                        }
                    ],
                    "returnFirstWhenPriorityNotFound": false
                }
            ],
            "validation": {
                "active": "@x1v1.mhd.fhir.validation.active@",
                "enableCodesValidation": "@x1v1.mhd.fhir.validation.codes.enabled@",
				"useRemoteTerminology": "@x1v1.mhd.fhir.validation.remote.terminology.enabled@"
            },
            "ftl": {
				"EXTRINSICOBJECT": "DocumentReferenceTemplateDSTU3.ftl",
				"DOCUMENT": "BinaryTemplateDSTU3.ftl",
				"SUBMISSIONSET": "DocumentManifestTemplateDSTU3.ftl",
				"FOLDER": "ListTemplateDSTU3.ftl",
				"ITI65": "ITI65TemplateDSTU3.ftl",
				"RPT003": "RPTTemplateDSTU3.ftl",
				"RPT007": "RPTTemplateDSTU3.ftl",
				"RPT008": "RPTTemplateDSTU3.ftl",
				"RPT011": "RPTTemplateDSTU3.ftl"
            }
        },{
            "version": "R4",
            "fhirRepositories": [{
                    "name": "PEOPLE",
                    "publicEndpoint": "@domain.public.protocol@://@mpi@@domain.public@/people.fhir/R4",
                    "internalEndpoint": "http://@mpi@@domain.internal.mpi@/people.fhir/R4",
                    "useAuthToken": true,
                    "relativeReferenceEnabled": false,
                    "resources": ["Patient"],
					"customHeaders": {
					}
                }, {
                    "name": "HPDX",
                    "publicEndpoint": "@domain.public.protocol@://@hpdx@@domain.public@/hpdx/fhir/r4",
                    "internalEndpoint": "http://@hpdx@@domain.internal.hpdx@/hpdx/fhir/r4",
                    "useAuthToken": true,
                    "relativeReferenceEnabled": false,
                    "resources": ["Practitioner", "Organization"],
					"customHeaders": {
					}
                }, {
                    "name": "CLINICAL",
                    "publicEndpoint": "@domain.public.protocol@://@fhir.clinical@@domain.public@/x1v1-fhir-clinical/R4",
                    "internalEndpoint": "http://@fhir.clinical@@domain.internal.xds@/x1v1-fhir-clinical/R4",
                    "useAuthToken": true,
                    "relativeReferenceEnabled": false,
                    "resources": ["*"],
					"customHeaders": {
					}
                }, {
                    "name": "MHD",
                    "publicEndpoint": "@domain.public.protocol@://@mhd@@domain.public@/x1v1-mhd-fhir/R4",
                    "internalEndpoint": "http://@mhd@@domain.internal.xds@/x1v1-mhd-fhir/R4",
                    "useAuthToken": true,
                    "relativeReferenceEnabled": false,
                    "resources": ["DocumentReference", "Binary", "List"],
					"customHeaders": {
					}
                }, {
                    "name": "TERMINOLOGY",
                    "publicEndpoint": "@domain.public.protocol@://@fhir.terminology@@domain.public@/x1v1-fhir-terminology/R4",
                    "internalEndpoint": "http://@fhir.terminology@@domain.internal.xds@/x1v1-fhir-terminology/R4",
                    "useAuthToken": false,
                    "relativeReferenceEnabled": false,
                    "resources": ["CodeSystem", "ValueSet"],
					"customHeaders": {
					}
                }
            ],
            "identifierResolvers": [{
                    "resource": "Patient",
                    "priority": [{
                            "type": "system",
                            "value": "urn:oid:2.16.840.1.113883.2.9.3.12.4.1"
                        }
                    ],
                    "returnFirstWhenPriorityNotFound": false
                }, {
                    "resource": "Practitioner",
                    "priority": [{
                            "type": "system",
                            "value": "urn:oid:2.16.840.1.113883.2.9.3.12.4.1"
                        },{
                            "type": "system",
                            "value": "http://xvalue.dedalus.eu/auth/users"
                        }
                    ],
                    "returnFirstWhenPriorityNotFound": false
                }, {
                    "resource": "Organization",
                    "priority": [{
                            "type": "system",
                            "value": "http://xvalue.dedalus.eu/fhir/organization/id"
                        }
                    ],
                    "returnFirstWhenPriorityNotFound": false
                }, {
                    "resource": "Encounter",
                    "priority": [{
                            "type": "system",
                            "value": "http://xvalue.dedalus.eu/fhir/encounter/id"
                        }
                    ],
                    "returnFirstWhenPriorityNotFound": false
                }, {
                    "resource": "DiagnosticReport",
                    "priority": [{
                            "type": "system",
                            "value": "http://xvalue.dedalus.eu/fhir/labresults/id"
                        }
                    ],
                    "returnFirstWhenPriorityNotFound": false
                }
            ],
            "validation": {
                "active": "@x1v1.mhd.fhir.validation.active@",
                "enableCodesValidation": "@x1v1.mhd.fhir.validation.codes.enabled@",
				"useRemoteTerminology": "@x1v1.mhd.fhir.validation.remote.terminology.enabled@"
            },
            "ftl": {
				"EXTRINSICOBJECT": "DocumentReferenceTemplateR4.ftl",
				"DOCUMENT": "BinaryTemplateR4.ftl",
				"SUBMISSIONSET": "ListTemplateR4.ftl",
				"FOLDER": "ListTemplateR4.ftl",
				"ITI65": "ITI65TemplateR4.ftl",
				"RPT003": "RPTTemplateR4.ftl",
				"RPT007": "RPTTemplateR4.ftl",
				"RPT008": "RPTTemplateR4.ftl",
				"RPT011": "RPTTemplateR4.ftl"
            }
        }
    ],
    "policyEngine": {
        "endpoint": "http://@pm@@domain.internal.xds@/policy-engine-web/pep/service/fhirResourceRead",
        "filterExtrinsicObject": true,
        "filterSubmissionSet": true,
        "filterFolder": true,
        "extrinsicObjectCustomFields": {
            "customFields": {
                "patientIdentifier": {
                    "hasMultipleResults": true,
                    "discoveries": [{
                            "mainExpression": "//ExternalIdentifier[@identificationScheme='urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427']/@value"
                        }
                    ]
                },
                "eventIdentifier": {
                    "hasMultipleResults": true,
                    "discoveries": [{
                            "mainExpression": "//Slot[@name='urn:ihe:iti:xds:2013:referenceIdList']/ValueList/Value/text()"
                        }
                    ]
                },
                "documentId": {
                    "hasMultipleResults": false,
                    "discoveries": [{
                            "mainExpression": "//ExternalIdentifier[@identificationScheme='urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab']/@value"
                        }
                    ]
                },
                "wardId": {
                    "hasMultipleResults": true,
                    "discoveries": [{
                            "mainExpression": "//Classification[@classificationScheme='urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d']/Slot[@name='authorInstitution']/ValueList/Value/text()",
							"conversionType": "FROM_XON_TO_CODE"
                        }
                    ]
                },
                "authorId": {
                    "hasMultipleResults": true,
                    "discoveries": [{
                            "mainExpression": "//Classification[@classificationScheme='urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d']/Slot[@name='authorPerson']/ValueList/Value/text()",
							"conversionType": "FROM_XCN_TO_CX"
                        }
                    ]
                },
                "creationDate": {
                    "hasMultipleResults": false,
                    "discoveries": [{
                            "mainExpression": "//Slot[@name='creationTime']/ValueList/Value/text()"
                        }
                    ]
                },
                "confidentialityCode": {
                    "hasMultipleResults": true,
                    "discoveries": [{
                            "groupingExpression": "//Classification[@classificationScheme='urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f']/@id",
                            "mainExpressionHasFunction": true,
                            "mainExpressionFunctionType": "STRING",
                            "mainExpression": "concat(//Classification[@id='{GROUPING_VALUE}']/Slot/ValueList/Value/text(),'|',//Classification[@id='{GROUPING_VALUE}']/@nodeRepresentation)"
                        }
                    ]
                },
                "typeCode": {
                    "hasMultipleResults": false,
                    "discoveries": [{
                            "mainExpressionHasFunction": true,
                            "mainExpressionFunctionType": "STRING",
                            "mainExpression": "concat(//Classification[@classificationScheme='urn:uuid:f0306f51-975f-434e-a61c-c59651d33983']/Slot/ValueList/Value/text(),'|',//Classification[@classificationScheme='urn:uuid:f0306f51-975f-434e-a61c-c59651d33983']/@nodeRepresentation)"
                        }
                    ]
                }
            }
        },
        "submissionSetCustomFields": {
            "customFields": {
                "patientIdentifier": {
                    "hasMultipleResults": true,
                    "discoveries": [{
                            "mainExpression": "//ExternalIdentifier[@identificationScheme='urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446']/@value"
                        }
                    ]
                },
                "wardId": {
                    "hasMultipleResults": true,
                    "discoveries": [{
                            "mainExpression": "//Classification[@classificationScheme='urn:uuid:a7058bb9-b4e4-4307-ba5b-e3f0ab85e12d']/Slot[@name='authorInstitution']/ValueList/Value/text()",
							"conversionType": "FROM_XON_TO_CODE"
                        }
                    ]
                },
                "authorId": {
                    "hasMultipleResults": true,
                    "discoveries": [{
                            "mainExpression": "//Classification[@classificationScheme='urn:uuid:a7058bb9-b4e4-4307-ba5b-e3f0ab85e12d']/Slot[@name='authorPerson']/ValueList/Value/text()",
							"conversionType": "FROM_XCN_TO_CX"
                        }
                    ]
                },
                "creationDate": {
                    "hasMultipleResults": false,
                    "discoveries": [{
                            "mainExpression": "//Slot[@name='submissionTime']/ValueList/Value/text()"
                        }
                    ]
                }
            }
        },
        "folderCustomFields": {
            "customFields": {
                "patientIdentifier": {
                    "hasMultipleResults": true,
                    "discoveries": [{
                            "mainExpression": "//ExternalIdentifier[@identificationScheme='urn:uuid:f64ffdf0-4b97-4e06-b79f-a52b38ec2f8a']/@value"
                        }
                    ]
                },
                "creationDate": {
                    "hasMultipleResults": false,
                    "discoveries": [{
                            "mainExpression": "//Slot[@name='lastUpdateTime']/ValueList/Value/text()"
                        }
                    ]
                }
            }
        },
		"connectionTimeout": 30000,
		"socketTimeout": 60000,
		"connectionRequestTimeout": 30000,
        "customHeaders": {
        }
    },
    "xds": {
        "xdsRegistry": {
            "iti18Endpoint": "http://@xds@@domain.internal.xds@/arriettywebservice/arrietty/query",
            "iti57Endpoint": "http://@xds@@domain.internal.xds@/arriettywebservice/arrietty/update",
            "iti62Endpoint": "http://@xds@@domain.internal.xds@/arriettywebservice/arrietty/delete",
            "folderSupported": true,
            "relatedAppendsSupported": true,
            "relatedReplacesSupported": true,
            "relatedTransformsSupported": true,
            "sortParameterSupported": true,
            "tlsEnabled": false,
            "tlsProtocol": "",
            "tlsCipher": "",
            "keyPwd": "",
            "keystorePath": "",
            "keystorePwd": "",
            "keystoreType": "",
            "useCustomTruststore": false,
            "truststoreType": "",
            "truststorePath": "",
            "truststorePwd": "",
            "connectionTimeout": 30000,
            "socketTimeout": 60000,
            "connectionRequestTimeout": 30000,
			"customHeaders": {
			}
        },
        "xdsRepositories": [{
                "oid": "@repository.oid@",
                "iti41Endpoint": "http://@xds@@domain.internal.xds@/x1v1-repositoryb/services/repositoryb",
                "iti43Endpoint": "http://@xds@@domain.internal.xds@/x1v1-repositoryb/services/repositoryb",
                "mtomEnabled": false,
                "mtomOptimized": false,
                "tlsEnabled": false,
                "tlsProtocol": "",
                "tlsCipher": "",
                "keyPwd": "",
                "keystorePath": "",
                "keystorePwd": "",
                "keystoreType": "",
                "useCustomTruststore": false,
                "truststoreType": "",
                "truststorePath": "",
                "truststorePwd": "",
				"connectionTimeout": 30000,
				"socketTimeout": 60000,
				"connectionRequestTimeout": 30000,
				"customHeaders": {
				}
            }
        ],
        "ftl": {
			"ITI18": "ITI18TemplateHTTP.ftl",
			"ITI41": "ITI41TemplateHTTP.ftl",
			"ITI43": "ITI43TemplateHTTP.ftl",
			"ITI57": "ITI57TemplateHTTP.ftl",
			"ITI62": "ITI62TemplateHTTP.ftl"
        },
        "codes": {
            "localPath": "@affinitydomainpath@/codes.xml",
            "publicUrl": "@x1v1.mhd.fhir.remote.codes.url@",
			"customHeaders": {
			}
        },
        "defaultRepositoryOid": "@repository.oid@"
    },
	"audit": {
		"readExtrinsicObjectActive": true,
		"readSubmissionSetActive": true,
		"readFolderActive": true,
		"iti65Active": true,
		"iti66Active": true,
		"iti67Active": true,
		"iti68Active": true,
		"rpt003Active": true,
		"rpt004Active": true,
		"rpt007Active": true,
		"rpt008Active": true,
		"rpt011Active": true
	}
};