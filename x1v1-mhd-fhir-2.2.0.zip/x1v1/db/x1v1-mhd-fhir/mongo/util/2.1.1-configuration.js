db.configuration.remove({ key: "default211"});
db.configuration.insert(defaultConfiguration211);