db.configuration.remove({ key: "default200"});
db.configuration.insert(defaultConfiguration200);