db.configuration.remove({ key: "default220"});
db.configuration.insert(defaultConfiguration220);