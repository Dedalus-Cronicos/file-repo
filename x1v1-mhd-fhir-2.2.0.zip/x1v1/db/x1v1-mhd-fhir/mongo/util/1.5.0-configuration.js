db.configuration.ensureIndex({ key: 1 });
db.configuration.remove({ key: "default"});
db.configuration.insert(defaultConfiguration);