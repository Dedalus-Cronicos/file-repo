//mongo 127.0.0.1:27017/x1v1-mhd-fhir -u x1v1-mhd-fhir -p x1v1-mhd-fhir < 1.2.0.js
load("util/definition/def_configuration.js");
load("util/1.3.0-configuration.js");

db.script_version.remove({ key: "x1v1-mhd-fhir"});
db.script_version.insert({ key: "x1v1-mhd-fhir", version : "1.3.0", date: new Date() });
