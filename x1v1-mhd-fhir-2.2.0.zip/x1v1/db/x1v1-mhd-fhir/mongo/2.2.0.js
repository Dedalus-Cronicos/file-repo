load("util/definition/def_configuration.js");
load("util/2.2.0-configuration.js");

load("util/2.2.0-healthcheck.js");

load("util/2.2.0-resource_mapping.js");

load("util/2.2.0-search_set.js");

load("util/2.2.0-upload_codesystems.js");

load("util/2.2.0-upload_profiles.js");

load("util/2.2.0-upload_valuesets.js");

db.sequence.drop()