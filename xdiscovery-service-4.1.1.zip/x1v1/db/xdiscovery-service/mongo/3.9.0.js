
db.createCollection("schema_version");

db.getCollection("schema_version").insert(
    {
        "major" : "3",
        "minor" : "9",
        "patch" : "0",
        "tag" : "xdiscovery-service",
        "revision" : 0,
        "last_change" : ISODate("2020-10-09T16:53:27.604+02:00"),
        "description" : ""
    }
);

db.createCollection("DS_PassCode");
db.DS_PassCode.createIndex( {"identifier":1}, {"name":"passcode_pk_idx", unique: true } )
db.DS_PassCode.createIndex( {"passCode":1}, {"name":"passcode_pasc_idx", unique: false } )
db.DS_PassCode.createIndex( {"createdOn":1},{"name":"passcode_cron_idx", unique: false} );


db.getCollection('DS_RegisteredClient').update({"clientId":"ODufuxmcA5ECdcMF"},{$set:{"serverLocationUri" : "https://@mpi@@domain.web@","userRoleProvisioningURL":"https://@mpi@@domain.app@/people-auth/rest/Profile"}});

db.getCollection('DS_RegisteredClient').update({"clientId":"wByuGJB1ZrymbFlU"},{$set:{"serverLocationUri" : "https://@mpi@@domain.web@","userRoleProvisioningURL":"https://@mpi@@domain.app@/people-auth/rest/Profile"}});

db.getCollection('DS_RegisteredClient').update({"clientId":"MLnUN1cQOICT5773"},{$set:{"serverLocationUri" : "https://@mpi@@domain.web@","userRoleProvisioningURL":"https://@mpi@@domain.app@/people-auth/rest/Profile"}});


