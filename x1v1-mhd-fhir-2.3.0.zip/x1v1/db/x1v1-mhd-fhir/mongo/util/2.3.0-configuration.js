db.configuration.remove({ key: "default230"});
db.configuration.insert(defaultConfiguration230);