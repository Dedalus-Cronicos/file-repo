db.resource_mapping.ensureIndex({ resourceType: 1 , id: 1});
db.resource_mapping.ensureIndex({ resourceType: 1 , xdsUniqueId: 1});