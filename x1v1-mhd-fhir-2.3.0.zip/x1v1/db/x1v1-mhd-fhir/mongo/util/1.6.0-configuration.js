db.configuration.remove({ key: "default"});
db.configuration.insert(defaultConfiguration);