db.resource_mapping.find({resourceType: "DocumentReference"}).forEach(function(doc) {
	doc.xdsObjectType = "ExtrinsicObject";
	db.resource_mapping.save(doc);
});

db.resource_mapping.find({resourceType: "DocumentManifest"}).forEach(function(doc) {
	doc.xdsObjectType = "SubmissionSet";
	db.resource_mapping.save(doc);
});

db.resource_mapping.find({resourceType: "List"}).forEach(function(doc) {
	doc.xdsObjectType = "Folder";
	db.resource_mapping.save(doc);
});