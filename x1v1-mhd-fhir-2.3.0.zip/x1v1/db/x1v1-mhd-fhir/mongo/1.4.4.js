//mongo 127.0.0.1:27017/x1v1-mhd-fhir -u x1v1-mhd-fhir -p x1v1-mhd-fhir < 1.4.0.js
load("util/definition/def_configuration.js");
load("util/1.4.4-configuration.js");
