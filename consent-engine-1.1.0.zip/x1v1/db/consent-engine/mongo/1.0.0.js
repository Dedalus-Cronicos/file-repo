load("util/definition/def_include_all.js");

load("util/1.0.0-configuration.js");
load("util/1.0.0-consent_historical.js");
load("util/1.0.0-consent_registry.js");
load("util/1.0.0-consent.js");
load("util/1.0.0-information_registry.js");
load("util/1.0.0-message_patient_historical.js");
load("util/1.0.0-message_patient.js");
load("util/1.0.0-message.js");
load("util/1.0.0-model_registry.js");
load("util/1.0.0-patient_consent_updater.js");
load("util/1.0.0-pdf_id_card.js");
load("util/1.0.0-pdf_bundle_document.js");
load("util/1.0.0-tutor_consent.js");
load("util/1.0.0-tutor_historical.js");
load("util/1.0.0-tutor.js");