load("util/definition/def_include_all.js");

load("util/1.1.0-information_registry.js");
load("util/1.1.0-configuration_market.js");
load("util/1.1.0-configuration_function.js");
load("util/1.1.0-consent_registry.js");
load("util/1.1.0-model_registry.js");
load("util/1.1.0-configuration.js");

