db.message.ensureIndex({ code : 1 });

db.message.remove({code : "empty"});
db.message.insert(empty);