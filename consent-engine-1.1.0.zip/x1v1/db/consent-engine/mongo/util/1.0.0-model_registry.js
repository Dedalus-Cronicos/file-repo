db.model_registry.ensureIndex({ code : 1 });

db.model_registry.update(
   {'code':'defModel'},
   { $setOnInsert: defModel },
   { upsert: true }
);

db.model_registry.update(
   {'code':'1'},
   { $setOnInsert: KPrivacy },
   { upsert: true }
);

db.model_registry.update(
   {'code':'2'},
   { $setOnInsert: completeModel },
   { upsert: true }
);

db.model_registry.update(
   {'code':'3'},
   { $setOnInsert: eventModel },
   { upsert: true }
);

db.model_registry.update(
   {'code':'4'},
   { $setOnInsert: documentModel },
   { upsert: true }
);

db.model_registry.update(
   {'code':'INI'},
   { $setOnInsert: INI },
   { upsert: true }
);