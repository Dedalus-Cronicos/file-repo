db.configuration.remove({key : "personInfo"});
db.configuration.insert(personInfo);
