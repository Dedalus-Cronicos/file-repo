db.configuration_market.ensureIndex({ key: 1});
db.configuration_market.remove({key : "italy"});
db.configuration_market.insert(italy);