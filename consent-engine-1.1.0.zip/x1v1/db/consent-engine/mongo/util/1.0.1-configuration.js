db.configuration.remove({key : "infocertIntegration"});
db.configuration.insert(infocertIntegration);
