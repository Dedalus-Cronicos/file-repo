db.consent_registry.remove({code : "DLGS196-03"});
db.consent_registry.remove({code : "FS-1"});
db.consent_registry.remove({code : "DS-1"});
db.consent_registry.remove({code : "P4"});
db.consent_registry.remove({code : "P24"});
db.consent_registry.remove({code : "P25"});
db.consent_registry.remove({code : "P26"});
db.consent_registry.remove({code : "P35"});

db.consent_registry.update(
   {'code':'P100'},
   { $setOnInsert: P100 },
   { upsert: true }
);


db.consent_registry.update(
   {'code':'P4'},
   { $setOnInsert: P4 },
   { upsert: true }
);
