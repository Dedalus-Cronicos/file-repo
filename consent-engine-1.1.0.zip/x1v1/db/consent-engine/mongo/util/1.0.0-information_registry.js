db.information_registry.ensureIndex({ code : 1 });

db.information_registry.update(
   {'code':'1'},
   { $setOnInsert: INF1 },
   { upsert: true }
);

db.information_registry.update(
   {'code':'2'},
   { $setOnInsert: INF2 },
   { upsert: true }
);