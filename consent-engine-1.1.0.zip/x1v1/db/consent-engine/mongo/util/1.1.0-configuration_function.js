
db.configuration_function.ensureIndex({ key: 1});
db.configuration_function.remove({key : "forms"});
db.configuration_function.insert(forms);
db.configuration_function.remove({key : "patient"});
db.configuration_function.insert(patient);
db.configuration_function.remove({key : "menu"});
db.configuration_function.insert(menu);
db.configuration_function.remove({key : "admin"});
db.configuration_function.insert(admin);
db.configuration_function.remove({key : "documentConsultationColumns"});
db.configuration_function.insert(documentConsultationColumns);
db.configuration_function.remove({key : "eventConsultationColumns"});
db.configuration_function.insert(eventConsultationColumns);
db.configuration_function.remove({key : "requestgroupconsultationcolumns"});
db.configuration_function.insert(requestgroupconsultationcolumns);