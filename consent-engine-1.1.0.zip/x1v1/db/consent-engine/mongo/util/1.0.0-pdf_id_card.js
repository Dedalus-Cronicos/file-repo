db.pdf_id_card.ensureIndex({ documentKey : 1 });
db.pdf_id_card.ensureIndex({ documentKey : 1, patientId : 1, documentType : 1, endDate : 1 });