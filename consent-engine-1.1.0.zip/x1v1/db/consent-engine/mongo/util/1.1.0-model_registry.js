db.model_registry.remove({code : "1"});
db.model_registry.remove({code : "2"});
db.model_registry.remove({code : "3"});


db.model_registry.update(
   {'code':'3'},
   { $setOnInsert: eventModel },
   { upsert: true }
);

db.model_registry.update(
   {'code':'5'},
   { $setOnInsert: requestGroupModel },
   { upsert: true }
);

db.model_registry.update(
   {'code':'6'},
   { $setOnInsert: confidentialityModel },
   { upsert: true }
);

