db.consent_registry.ensureIndex({ code : 1 });

db.consent_registry.update(
   {'code':'DLGS196-03'},
   { $setOnInsert: DLGS19603 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'FS-1'},
   { $setOnInsert: FS1 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'DS-1'},
   { $setOnInsert: DS1 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'C1'},
   { $setOnInsert: C1 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'C2'},
   { $setOnInsert: C2 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'C3'},
   { $setOnInsert: C3 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P1'},
   { $setOnInsert: P1 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P2'},
   { $setOnInsert: P2 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P3'},
   { $setOnInsert: P3 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P4'},
   { $setOnInsert: P4 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P24'},
   { $setOnInsert: P24 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P25'},
   { $setOnInsert: P25 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P26'},
   { $setOnInsert: P26 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P35'},
   { $setOnInsert: P35 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P80'},
   { $setOnInsert: P80 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P95'},
   { $setOnInsert: P95 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P96'},
   { $setOnInsert: P96 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P97'},
   { $setOnInsert: P97 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P98'},
   { $setOnInsert: P98 },
   { upsert: true }
);

db.consent_registry.update(
   {'code':'P99'},
   { $setOnInsert: P99 },
   { upsert: true }
);