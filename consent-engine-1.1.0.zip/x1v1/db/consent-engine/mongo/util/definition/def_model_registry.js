
var eventModel={    
    "code" : "3", 
    "description" : [ {
        "language" : "it-IT",
        "text" : "Modello evento"
    }, {
        "language" : "en-GB",
        "text" : "Event Model"
    },
    {
        "language" : "de-DE",
        "text" : "Event Model" 
    } ],
    "author" : "Rossi Mario", 
    "standalone" : false, 
    "creationDate" : ISODate("2018-04-18T00:00:00.000+0000"), 
    "consentType" : [
        "privacy"
    ], 
    "status" : "current", 
    "bundles" : [
        {
            "informationRegistryCode" : "1",
            "informationRegistryVersion" : NumberLong(1), 
            "itemsConsent" : [
                {
                    "consentRegistryVersion" : NumberLong(1), 
                    "consentRegistryCode" : "P96",
                    "signatures" : [
                        {
                            "type" : "graphometric", 
                            "who" : [
                                {
                                    "language" : "it-IT", 
                                    "text" : "Paziente"
                                }, 
                                {
                                    "language" : "en-GB", 
                                    "text" : "Patient"
                                }
                            ], 
                            "why" : [
                                {
                                    "language" : "it-IT", 
                                    "text" : "Firma del paziente al consenso per il Fascicolo Sanitario Elettronico"
                                }, 
                                {
                                    "language" : "en-GB", 
                                    "text" : "Acceptance"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
};

var documentModel={    
    "code" : "4", 
    "description" : [ {
        "language" : "it-IT",
        "text" : "Modello documento"
    }, {
        "language" : "en-GB",
        "text" : "Document Model"
    },
    {
        "language" : "de-DE",
        "text" : "Document Model" 
    } ],
    "author" : "Rossi Mario", 
    "standalone" : false, 
    "creationDate" : ISODate("2018-04-18T00:00:00.000+0000"), 
    "consentType" : [
        "privacy"
    ], 
    "status" : "current", 
    "bundles" : [
        {
            "informationRegistryCode" : "2",
            "informationRegistryVersion" : NumberLong(1), 
            "itemsConsent" : [
                {
                    "consentRegistryVersion" : NumberLong(1), 
                    "consentRegistryCode" : "P99",
                    "signatures" : [
                        {
                            "type" : "graphometric", 
                            "who" : [
                                {
                                    "language" : "it-IT", 
                                    "text" : "Paziente"
                                }, 
                                {
                                    "language" : "en-GB", 
                                    "text" : "Patient"
                                }
                            ], 
                            "why" : [
                                {
                                    "language" : "it-IT", 
                                    "text" : "Firma del paziente al consenso per il Fascicolo Sanitario Elettronico"
                                }, 
                                {
                                    "language" : "en-GB", 
                                    "text" : "Acceptance"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
};

var requestGroupModel={    
    "code" : "5", 
    "description" : [ {
        "language" : "it-IT",
        "text" : "Modello request group"
    }, {
        "language" : "en-GB",
        "text" : "Request group Model"
    },
    {
        "language" : "de-DE",
        "text" : "Request group Model" 
    } ],
    "author" : "Rossi Mario", 
    "standalone" : false, 
    "creationDate" : ISODate("2021-10-25T00:00:00.000+0000"), 
    "consentType" : [
        "privacy"
    ], 
    "status" : "current", 
    "bundles" : [
        {
            "informationRegistryCode" : "1",
            "informationRegistryVersion" : NumberLong(1), 
            "itemsConsent" : [
                {
                    "consentRegistryVersion" : NumberLong(1), 
                    "consentRegistryCode" : "P100",
                    "signatures" : [
                        {
                            "type" : "graphometric", 
                            "who" : [
                                {
                                    "language" : "it-IT", 
                                    "text" : "Paziente"
                                }, 
                                {
                                    "language" : "en-GB", 
                                    "text" : "Patient"
                                }
                            ], 
                            "why" : [
                                {
                                    "language" : "it-IT", 
                                    "text" : "Firma del paziente al consenso per il Fascicolo Sanitario Elettronico"
                                }, 
                                {
                                    "language" : "en-GB", 
                                    "text" : "Acceptance"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
};


var INI = {
    "code" : "INI",
    "description" : [ {
        "language" : "it-IT",
        "text" : "Modello INI"
    }, {
        "language" : "en-GB",
        "text" : "INI Model"
    } ,
    {
        "language" : "de-DE",
        "text" : "EGA Einverständnis" 
    }],
    "author" : "Rossi Mario",
    "standalone" : false,
    "creationDate" : ISODate("2018-04-18T00:00:00.000+0000"),
    "consentType" : [ "privacy" ],
    "status" : "current",
    "bundles" : [ {
        "informationRegistryCode" : "1",
        "informationRegistryVersion" : NumberLong(1),
        "itemsConsent" : [ {
            "consentRegistryCode" : "C1",
            "consentRegistryVersion" : NumberLong(1)
        }, {
            "consentRegistryCode" : "C2",
            "consentRegistryVersion" : NumberLong(1)
        }
        , {
            "consentRegistryCode" : "C3",
            "consentRegistryVersion" : NumberLong(1),
            "signatures" : [
                {
                    "type" : "graphometric", 
                    "who" : [
                        {
                            "language" : "it-IT", 
                            "text" : "Paziente"
                        }, 
                        {
                            "language" : "en-GB", 
                            "text" : "Patient"
                        }
                    ], 
                    "why" : [
                        {
                            "language" : "it-IT", 
                            "text" : "Firma del paziente al consenso per il Fascicolo Sanitario Elettronico"
                        }, 
                        {
                            "language" : "en-GB", 
                            "text" : "Acceptance"
                        }
                    ]
                }
            ]
        }
        ]
    } 
    ]
};

var defModel = {
    "code": "defModel",
    "description": [{
            "language": "it-IT",
            "text": "Modello Default"
        }, {
            "language": "en-GB",
            "text": "Default Model"
        }, {
            "language": "de-DE",
            "text": "EGA Einverständnis"
        }
    ],
    "author": "Rossi Mario",
    "standalone": false,
    "creationDate" : ISODate("2018-04-18T00:00:00.000+0000"),
    "consentType": ["privacy"],
    "status": "current",
    "bundles": [{
            "informationRegistryCode": "1",
            "informationRegistryVersion": NumberLong(1),
            "itemsConsent": [{
                    "consentRegistryCode": "P1",
                    "consentRegistryVersion": NumberLong(1)
                }, {
                    "consentRegistryCode": "P2",
                    "consentRegistryVersion": NumberLong(1)
                }, {
                    "consentRegistryCode": "P3",
                    "consentRegistryVersion": NumberLong(1),
                    "signatures": [{
                            "type": "graphometric",
                            "who": [{
                                    "language": "it-IT",
                                    "text": "Paziente"
                                }, {
                                    "language": "en-GB",
                                    "text": "Patient"
                                }
                            ],
                            "why": [{
                                    "language": "it-IT",
                                    "text": "Firma del paziente al consenso per il Fascicolo Sanitario Elettronico"
                                }, {
                                    "language": "en-GB",
                                    "text": "Acceptance"
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    ]
};


var confidentialityModel={    
	    "code" : "6", 
	    "description" : [ {
	        "language" : "it-IT",
	        "text" : "Modello Confidenzialità"
	    }, {
	        "language" : "en-GB",
	        "text" : "Confidentiality Model"
	    },
	    {
	        "language" : "de-DE",
	        "text" : "Confidentiality Model" 
	    } ],
	    "author" : "Rossi Mario", 
	    "standalone" : false, 
	    "creationDate" : ISODate("2018-04-18T00:00:00.000+0000"), 
	    "consentType" : [
	        "privacy"
	    ], 
	    "status" : "current", 
	    "bundles" : [
	        {
	            "informationRegistryCode" : "2",
	            "informationRegistryVersion" : NumberLong(1), 
	            "itemsConsent" : [
	                {
	                    "consentRegistryVersion" : NumberLong(1), 
	                    "consentRegistryCode" : "P4",
	                    "signatures" : [
	                        {
	                            "type" : "graphometric", 
	                            "who" : [
	                                {
	                                    "language" : "it-IT", 
	                                    "text" : "Paziente"
	                                }, 
	                                {
	                                    "language" : "en-GB", 
	                                    "text" : "Patient"
	                                }
	                            ], 
	                            "why" : [
	                                {
	                                    "language" : "it-IT", 
	                                    "text" : "Firma del paziente al consenso per il Fascicolo Sanitario Elettronico"
	                                }, 
	                                {
	                                    "language" : "en-GB", 
	                                    "text" : "Acceptance"
	                                }
	                            ]
	                        }
	                    ]
	                }
	            ]
	        }
	    ]
	}
;

