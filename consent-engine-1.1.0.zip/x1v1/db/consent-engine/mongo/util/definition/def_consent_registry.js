var C1 = {
    "code": "C1",
    "ini": false,
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "CONSENSO ALL'ALIMENTAZIONE DEL FASCICOLO SANITARIO ELETTRONICO(FSE)"
        }, {
            "language": "en-GB",
            "text": "CONSENT TO COLLECT INFORMATION(FSE)"
        }, {
            "language": "de-DE",
            "text": "Einverständnis zur Einspeisung der Daten in die Elektronische Gesundheitsakte (EGA)"
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        },
        {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var C2 = {
    "code": "C2",
    "ini": false,
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "CONSENSO ALLA CONSULTAZIONE DEI DATI E DEI DOCUMENTI DI NATURA CLINICA CONTENUTI NEL FASCICOLO SANITARIO ELETTRONICO (FSE) DA PARTE DEI SOGGETTI AUTORIZZATI DEL SSN"
        }, {
            "language": "en-GB",
            "text": "CONSENT TO THE CONSULTATION OF DATA AND CLINICAL DOCUMENTS BY AUTHORIZED PARTNERS OF THE SSN"
        }, {
            "language": "de-DE",
            "text": "Einverständnis zur Konsultation der Daten und der klinischen Dokumente, welche in der Elektronischen Gesundheitsakte (EGA) enthalten sind, durch autorisierte Personen des NGD"
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        },
        {
            "language": "en-GB",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var C3 = {
    "code": "C3",
    "ini": false,
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "CONSENSO ALLA CONSULTAZIONE DEI DATI E DEI DOCUMENTI CLINICI PREGRESSI"
        }, {
            "language": "en-GB",
            "text": "CONSENT TO CONSULTATION OF PREVIOUS DATA AND CLINICAL DOCUMENTS"
        }, {
            "language": "de-DE",
            "text": "Einverständnis zur Konsultation früherer Daten und klinischer Dokumente"
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        },
        {
            "language": "en-GB",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P1 = {
    "code": "P1",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Consenso"
        }, {
            "language": "en-GB",
            "text": "Consent"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        },
        {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P2 = {
    "code": "P2",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Consenso"
        }, {
            "language": "en-GB",
            "text": "Consent"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        },
        {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P3 = {
    "code": "P3",
    "ini": false,
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "CONSENSO ALLA CONSULTAZIONE DEI DATI E DEI DOCUMENTI CLINICI PREGRESSI"
        }, {
            "language": "en-GB",
            "text": "CONSENT TO CONSULTATION OF PREVIOUS DATA AND CLINICAL DOCUMENTS"
        }, {
            "language": "de-DE",
            "text": "Einverständnis zur Konsultation früherer Daten und klinischer Dokumente"
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        },
        {
            "language": "en-GB",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P80 = {
    "code": "P80",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Consenso alla consultazione di documenti prodotti negli ultimi 45 giorni"
        }, {
            "language": "en-GB",
            "text": "Consent to consult documents produced in the last 45 days"
        }, {
            "language": "de-DE",
            "text": "Zustimmung zur Konsultation der in den letzten 45 Tagen erstellten Dokumente"
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        },
        {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "D",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P95 = {
    "code": "P95",
    "version": 1,
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Oscuramento dei dati relativi al paziente"
        }, {
            "language": "en-GB",
            "text": "Obscuring of the data related to the patient"
        }, {
            "language": "de-DE",
            "text": "Verschleierung der Patientendaten"
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": 0,
    "creationDate": ISODate("2018-04-18T02:00:00.000+02:00"),
    "hideFromDate": false
};

var P96 = {
    "code": "P96",
    "version": 1,
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Oscuramento dei dati relativi all'episodio indicato"
        }, {
            "language": "en-GB",
            "text": "Obscuring of the data related to the episode indicated"
        }, {
            "language": "de-DE",
            "text": "Verschleierung der Daten in Bezug auf die angegebene Episode"
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "E",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": 0,
    "creationDate": ISODate("2018-04-18T02:00:00.000+02:00"),
    "hideFromDate": false
};

var P97 = {
    "code": "P97",
    "version": 1,
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Oscuramento dei dati relativi al documento per tutore (documenti a maggior tutela)"
        }, {
            "language": "en-GB",
            "text": "Obscuring of the data related to the indicated document for the tutor (very restricted documents)"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "D",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": 0,
    "creationDate": ISODate("2018-04-18T02:00:00.000+02:00"),
    "hideFromDate": false
};

var P98 = {
    "code": "P98",
    "version": 1,
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Oscuramento dei dati relativi al documento per paziente e tutore"
        }, {
            "language": "en-GB",
            "text": "Obscuring of the data related to the indicated document for the patient and the tutor"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "D",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": 0,
    "creationDate": ISODate("2018-04-18T02:00:00.000+02:00"),
    "hideFromDate": false
};

var P99 = {
    "code": "P99",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Oscuramento dei dati relativi al documento indicato"
        }, {
            "language": "en-GB",
            "text": "Obscuring of the data related to the indicated document"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        },
        {
            "language": "en-GB",
            "text": ""
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "D",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P100 = {  
    "code" : "P100", 
    "activeLabel" : [
        {
            "language" : "it-IT", 
            "text" : "Autorizzo"
        }, 
        {
            "language" : "en-GB", 
            "text" : "Authorize"
        }, 
        {
            "language" : "de-DE", 
            "text" : "Zugestimmt"
        }
    ], 
    "codingScheme" : "AffinityDomainItaliaV1.0", 
    "consentKind" : "A", 
    "consentType" : "privacy", 
    "creationDate" : ISODate("2021-10-25T00:00:00.000+0000"), 
    "display" : [
        {
            "language" : "it-IT", 
            "text" : "Oscuramento dei dati relativi all'ordine indicato"
        }, 
        {
            "language" : "en-GB", 
            "text" : "Obscuring of the data related to the order indicated"
        }, 
        {
            "language" : "de-DE", 
            "text" : "Verschleierung der Daten in Bezug auf die angegebene Order"
        }
    ], 
    "expiration" : false, 
    "footer" : [
        {
            "language" : "it-IT", 
            "text" : ""
        }, 
        {
            "language" : "en-GB", 
            "text" : ""
        }, 
        {
            "language" : "de-DE", 
            "text" : ""
        }
    ], 
    "header" : [
        {
            "language" : "it-IT", 
            "text" : ""
        }, 
        {
            "language" : "en-GB", 
            "text" : ""
        }, 
        {
            "language" : "de-DE", 
            "text" : ""
        }
    ], 
    "hideFromDate" : false, 
    "rejectedLabel" : [
        {
            "language" : "it-IT", 
            "text" : "Non Autorizzo"
        }, 
        {
            "language" : "en-GB", 
            "text" : "I do not authorize"
        }, 
        {
            "language" : "de-DE", 
            "text" : "Abgelehnt"
        }
    ], 
    "required" : true, 
    "status" : "current", 
    "typescope" : "RG", 
    "validityPeriod" : 0.0, 
    "version" : 1.0
};


var P4 = {
	    "code": "P4",
	    "version": NumberLong(1),
	    "status": "current",
	    "display": [{
	            "language": "it-IT",
	            "text": "Confidenzialità"
	        }, {
	            "language": "en-GB",
	            "text": "Confidentiality"
	        }, {
	            "language": "de-DE",
	            "text": ""
	        }
	    ],
	    "footer": [{
	            "language": "it-IT",
	            "text": ""
	        }, {
	            "language": "en-GB",
	            "text": ""
	        }, {
	            "language": "de-DE",
	            "text": ""
	        }
	    ],
	    "header": [{
	            "language": "it-IT",
	            "text": ""
	        },
	        {
	            "language": "en-GB",
	            "text": ""
	        }, {
	            "language": "de-DE",
	            "text": ""
	        }
	    ],
	    "codingScheme": "AffinityDomainItaliaV1.0",
	    "typescope": "D",
	    "required": true,
	    "consentType": "privacy",
	    "activeLabel": [{
	            "language": "it-IT",
	            "text": "Autorizzo"
	        },
	        {
	            "language": "en-GB",
	            "text": "Authorize"
	        }, {
	            "language": "de-DE",
	            "text": "Zugestimmt"
	        }
	    ],
	    "rejectedLabel": [{
	            "language": "it-IT",
	            "text": "Non Autorizzo"
	        }, {
	            "language": "en-GB",
	            "text": "I do not authorize"
	        }, {
	            "language": "de-DE",
	            "text": "Abgelehnt"
	        }
	    ],
	    "consentKind": "A",
	    "expiration": false,
	    "validityPeriod": NumberInt(0),
	    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
	    "hideFromDate": false
	};
