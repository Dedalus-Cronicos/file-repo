load("util/definition/commons.js");

load("util/definition/deprecated.js");
load("util/definition/def_configuration.js");
load("util/definition/def_consent_registry.js");
load("util/definition/def_information_registry.js");
load("util/definition/def_model_registry.js");
load("util/definition/def_message.js");
load("util/definition/def_configuration_market.js");
load("util/definition/def_configuration_function.js");