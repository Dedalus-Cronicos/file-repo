var INF1 = {
    "code": "1",
    "version" : NumberLong(1),
    "status" : "current",
    "description" : "Informativa di Test",
    "display" : [ {
        "language" : "it-IT",
        "text" : "Gestione del trattamento dei dati personali"
    }, {
        "language" : "en-GB",
        "text" : "Management of the processing of personal data"
    } , 
    {
        "language" : "de-DE",
        "text" : ""
    }],
    "footer" : [],
    "header" : [],
    "document" : [ {
        "language" : "it-IT",
        "uri" : "../consent-engine/information-folder/Information_1_it-IT.pdf"
    }, {
        "language" : "en-GB",
        "uri" : "../consent-engine/information-folder/Information_1_en-GB.pdf"
    }, 
    {
        "language" : "de-DE",
        "uri" : "../consent-engine/information-folder/Information_1_de-DE.pdf"
    } ],
    "creationDate" : ISODate("2018-04-18T00:00:00.000+0000")
};

var INF2 = {
    "code": "2",
    "version" : NumberLong(1),
    "status" : "current",
    "description" : "Informativa di Test Oscuramento",
    "display" : [ {
        "language" : "it-IT",
        "text" : "Richiesta oscuramento dati (referti/episodi di cura) nel Dossier Sanitario Elettronico"
    }, {
        "language" : "en-GB",
        "text" : "Request to obscure data (reports / episodes of treatment) in the Electronic Health Dossier"
    }, 
    {
        "language" : "de-DE",
        "text" : ""
    } ],
    "footer" : [],
    "header" : [],
    "document" : [ {
        "language" : "it-IT",
        "uri" : "../consent-engine/information-folder/Information_2_it-IT.pdf"
    }, {
        "language" : "en-GB",
        "uri" : "../consent-engine/information-folder/Information_2_en-GB.pdf"
    }, 
    {
        "language" : "de-DE",
        "uri" : "../consent-engine/information-folder/Information_2_de-DE.pdf"
    } ],
    "creationDate" : ISODate("2018-04-18T00:00:00.000+0000")
};