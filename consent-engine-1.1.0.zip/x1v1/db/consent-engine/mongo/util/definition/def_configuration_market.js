var italy = {
		"market": "ITALY",
		"inUse": true,
		"frontEnd" : "consent-collector",
		"environment": "prod",
		"data": {
			"consent-collector": {
				"proxy" : {
					"status" : true, 
					"endpoint" : "/consent-engine/"
				}, 
				"commonEndpoints":{
					"mhd": "@x1v1-mhd-fhir@",
					"patient": "@people-fhir@",
					"patientRest" : "@people-rest@", 
					"practitioner": "@people-fhir@",
					"clinical": "@x1v1-fhir-clinical@",
					"terminology": "@x1v1-fhir-terminology@",
					"consentEngine": "/consent-engine/",
					"apiGateway" : ""
				}, 
				"customEndpoints" : {

				},
				"user": {				
					"recent": {
						"show": false,
						"system": "http://apiframework.dedalus.eu/fhir/CodeSystem/ListCodes",
						"code": "recents-patient",
						"display": "List of a practitioner's recent patients",
						"listLimit": "10"
					},
					"favourite": {
						"show": false,
						"system": "",
						"code": "",
						"display": "List of a practitioner's favourite patients",
						"listLimit": "10"
					}
				},
				"header": {
					"hideLogo": false,
					"showDarkMode": false
				},
				"consent": {					
					"identifierSystemCode": "urn:oid:2.16.840.1.113883.2.9.3.12.4.1",
					"identifierValueJpath": "$.identifier[?(@.system == \"urn:oid:2.16.840.1.113883.2.9.3.12.4.1\")].value",
					"openingInTabOrWindow": "window",
					"embedded": false,
					"showConsents4PatientList": false,
					"showModels4PatientList": false,
					"showConsents4DocumentList": false,
					"showModels4DocumentList": false,
					"showConsents4PatientBanner": false,
					"showModels4PatientBanner": false,
					"showConsents4Timeline": false,
					"showModels4Timeline": false,
					"accessToPatientAfterCheckOnConsent": false,
					"consentToAccessToPatient": "P2",
					"consentStatusToAccess": "active"
				},
				"patientBannerConfiguration": {
					"showAllergies": false,
					"showProcedures": false,
					"showAuthorities": false,
					"showFamilyMemberHistories": false,
					"showPhoto" : true, 
				},
				"environmentLinks": {
					"backUrl": "",
					"profile": "",
					"civicNetwork": "",
					"logoutRedirectUrl": ""
				},
				"resourceConsultation": {
					"classToIdentifierTypeCodeMapping": [
						{
							"class": "IMP",
							"identifierTypeCode": "urn:rve:2016:admissionNumber"
						},
						{
							"class": "EMER",
							"identifierTypeCode": "urn:ihe:iti:xds:2013:accession"
						},
						{
							"class": "AMB",
							"identifierTypeCode": "urn:eu:dedalus:xvalue:2020:sessionId"
						}
					],
					"hideAttachmentViewerBrowsing": true,
					"D": {
						"resourceType" : "DocumentReference",
						"columnsConfigurations" : "documentconsultationcolumns", 
						"identifierFieldName": "documentid",
						"formType": "advancedSearchDocumentForm",
						"rowsToFetch": 50,
						"rowsPerPage": 10
					},
					"E": {
						"resourceType" : "Encounter",
						"columnsConfigurations": "eventconsultationcolumns",
						"identifierFieldName": "eventid",
						"emittedFieldName": "identifier",
						"defaultDateFhirField": "date",
						"formType": "advancedSearchEventForm",
						"rowsToFetch": 50,
						"rowsPerPage": 10
					},
					"RG": {
						"resourceType" : "RequestGroup", 
						"columnsConfigurations" : "requestgroupconsultationcolumns", 
						"identifierFieldName": "requestGroupId",
						"emittedFieldName": "identifier",
						"defaultDateFhirField": "authored",
						"formType": "advancedSearchRequestGroupForm",
						"rowsToFetch": 50,
						"rowsPerPage": 10
					},
					"allowOpeningDocument": true
				},
				"advancedPatientSearchDefault": false,
				"patientSearchEnabledIfPatientNotFound": false,
				"tutorVisibilityFlag": true,
				"guardianVisibilityFlag": true,
				"showHistory": true,
				"showHistorySearch": false,
				"hidedHistoricalConsents": "",
				"showEventConsent": true,
				"showDocumentConsent": true,
				"showPrintBundle": true,
				"toolbarPosition": "bottom",
				"periodEndDate": "2099-12-31",
				"graphometricIntegration": false,
				"switchableGraphometric": false,
				"idCardRequired": false,
				"clientPollingInterval": 6000,
				"mode": "standalone",
				"allergyAvailable": true,
				"taxcodeSystemCode": "urn:oid:2.16.840.1.113883.2.9.4.3.2",
				"identifierSystemCode": "urn:oid:2.16.840.1.113883.2.9.3.12.4.1",
				"birthplaceSystemCode": "http://hl7.org/fhir/structuredefinition/birthplace",
				"addressCitySystemCode": "http://xvalue.dedalus.eu/dm/Address#city-code",
				"telecomSystemCode": "phone",
				"patientPhotoUrl": null,
				"downloadFile": true,
				"fhirPatientService": "/patientFhir",
				"guardianRolesKey": "enumGuardianRole",
				"consentOpenedOnInit": false,
				"checkIfTokenPatientExists": false,
				"hideEventOrDocumentOnCollectConsent": false,
				"advancedSearch": {
					"endpoints": [
						{
							"key": "dictionaryEndpoint",
							"value": "/xvalue-patsyn/dictionary/AffinityDomainTypeCodes-MHD"
						}
					],
					"range": [
						{
							"label": "s4h.advanced-search.today",
							"offset": 1,
							"disabled": false
						},
						{
							"label": "s4h.advanced-search.week",
							"offset": 7,
							"disabled": false
						},
						{
							"label": "s4h.advanced-search.month",
							"offset": 1,
							"unit": "months",
							"disabled": false,
							"active": true
						},
						{
							"label": "s4h.advanced-search.2months",
							"offset": 2,
							"unit": "months",
							"disabled": true
						},
						{
							"label": "s4h.advanced-search.3months",
							"offset": 3,
							"unit": "months",
							"disabled": true
						},
						{
							"label": "s4h.advanced-search.4months",
							"offset": 4,
							"unit": "months",
							"disabled": true
						},
						{
							"label": "s4h.advanced-search.6months",
							"offset": 6,
							"unit": "months",
							"disabled": true
						},
						{
							"label": "s4h.advanced-search.year",
							"offset": 1,
							"unit": "year",
							"disabled": true
						},
						{
							"label": "s4h.advanced-search.2years",
							"offset": 2,
							"unit": "year",
							"disabled": true
						},
						{
							"label": "s4h.advanced-search.3years",
							"offset": 3,
							"unit": "year",
							"disabled": true
						},
						{
							"label": "s4h.advanced-search.demo",
							"offset": 6,
							"unit": "year",
							"disabled": true
						}
					]
				},
				"timeline": {
					"styles": {
						"default": {
							"bgColor": "#0861c7d2",
							"color": "#ffffff",
							"icon": "fa fa-circle"
						},
						"IMP": {
							"bgColor": "#11a189",
							"color": "#ffffff",
							"icon": "fa fa-hospital-o"
						},
						"urneudedalusx1v12015nosological": {
							"bgColor": "#11a189",
							"color": "#ffffff",
							"icon": "fa fa-hospital-o"
						},
						"httpwwwbmcnlzorgportalidentifiersencounters": {
							"bgColor": "#11a189",
							"color": "#ffffff",
							"icon": "fa fa-hospital-o"
						},
						"AMB": {
							"bgColor": "#b0cc8b",
							"color": "#ffffff",
							"icon": "fa fa-stethoscope"
						},
						"EMER": {
							"bgColor": "#e66e0b",
							"color": "#ffffff",
							"icon": "fa fa-ambulance"
						},
						"urniheitixds2013referral": {
							"bgColor": "#e66e0b",
							"color": "#ffffff",
							"icon": "fa fa-ambulance"
						},
						"SS": {
							"bgColor": "#aeaeae",
							"color": "#ffffff",
							"icon": "fa fa-stethoscope"
						},
						"PHYRHB": {
							"bgColor": "#1e90ff",
							"color": "#ffffff",
							"icon": "fa fa-heart-o"
						},
						"HH": {
							"bgColor": "#f55753",
							"color": "#ffffff",
							"icon": "fa fa-home"
						},
						"urniheitixdw2013workflowId": {
							"bgColor": "#f55753",
							"color": "#ffffff",
							"icon": "fa fa-home"
						},
						"urniheitixds2013order": {
							"bgColor": "#a5bde2",
							"color": "#ffffff"
						},
						"urniheitixds2013accession": {
							"bgColor": "#186d03",
							"color": "#ffffff"
						},
						"urneudedalusx1v12015encounterId": {
							"bgColor": "#b0cc8b",
							"color": "#ffffff",
							"icon": "fa fa-stethoscope"
						},
						"urniheitixds2015encounterId": {
							"bgColor": "#b0cc8b",
							"color": "#ffffff",
							"icon": "fa fa-stethoscope"
						},
						"urniheitixds2013uniqueId": {
							"bgColor": "#aeaeae",
							"color": "#ffffff",
							"icon": "fa fa-stethoscope"
						}
					}
				}
			}
		}
	};
