var admin = {
	"key" : "admin",
	"data" : {
		"admin" : true,
		"config_key" : "consent-collector"
	},
	"frontEnd" : "consent-collector"
};
var forms = {
		   "key":"forms",
		   "data":{
		      "patientForm":{
		         "jsonPathOptionLabel":"$.components.*.cols.*.components.*.data.values[?(@.value=='VALUE_OPTION')].label['CURRENT_LANG']",
		         "jsonPathLabel":"$.components.*.cols.*.components[?(@.key=='KEY')].label['CURRENT_LANG']",
		         "model":{
		            "type":"form",
		            "key":"form",
		            "components":[
		               {
		                  "cols":[
		                     {
		                        "components":[
		                           {
		                              "label":{
		                                 "it-IT":"Cognome",
		                                 "en-GB":"Surname",
		                                 "en-US":"Last Name",
		                                 "fr-FR":"Nom de famille",
		                                 "zh-CN":"姓",
		                                 "de-DE":"Nachname"
		                              },
		                              "key":"family",
		                              "type":"textfield"
		                           }
		                        ],
		                        "width":6
		                     },
		                     {
		                        "components":[
		                           {
		                              "label":{
		                                 "it-IT":"Nome",
		                                 "en-GB":"Name",
		                                 "en-US":"First Name",
		                                 "fr-FR":"Prénom",
		                                 "zh-CN":"名",
		                                 "de-DE":"Name"
		                              },
		                              "key":"given",
		                              "type":"textfield"
		                           }
		                        ],
		                        "width":6
		                     }
		                  ],
		                  "key":"columns1",
		                  "type":"columns"
		               },
		               {
		                  "cols":[
		                     {
		                        "components":[
		                           {
		                              "label":{
		                                 "it-IT":"Data nascita",
		                                 "en-GB":"Birthdate",
		                                 "en-US":"Birthdate",
		                                 "fr-FR":"Date de naissance",
		                                 "zh-CN":"出生日期",
		                                 "de-DE":"Geburtstag"
		                              },
		                              "key":"birthdate",
		                              "type":"datetime",
		                              "enabledMask":false,
		                              "suffix":"fa fa-calendar",
		                              "datePicker":{
		                                 "showYearNavigator":true
		                              },
		                              "calculateProperty":{
		                                 "yearRange.start":{
		                                    "var":"param.startYear"
		                                 },
		                                 "yearRange.end":{
		                                    "var":"param.endYear"
		                                 }
		                              }
		                           }
		                        ],
		                        "width":6
		                     },
		                     {
		                        "components":[
		                           {
		                              "label":{
		                                 "it-IT":"Sesso",
		                                 "en-GB":"Gender",
		                                 "en-US":"Gender",
		                                 "fr-FR":"Le sexe",
		                                 "zh-CN":"性别",
		                                 "de-DE":"Geschlecht"
		                              },
		                              "multiple":false,
		                              "data":{
		                                 "values":[
		                                    {
		                                       "label":{
		                                          "it-IT":"Femminile",
		                                          "en-GB":"Female",
		                                          "en-US":"Female",
		                                          "fr-FR":"Femme",
		                                          "zh-CN":"女",
		                                          "de-DE":"Weiblich"
		                                       },
		                                       "value":"female"
		                                    },
		                                    {
		                                       "label":{
		                                          "it-IT":"Maschile",
		                                          "en-GB":"Male",
		                                          "en-US":"Male",
		                                          "fr-FR":"Homme",
		                                          "zh-CN":"男",
		                                          "de-DE":"Männlich"
		                                       },
		                                       "value":"male"
		                                    },
		                                    {
		                                       "label":{
		                                          "it-IT":"Altro",
		                                          "en-GB":"Other",
		                                          "en-US":"Other",
		                                          "fr-FR":"Autres",
		                                          "zh-CN":"其他",
		                                          "de-DE":"Andere"
		                                       },
		                                       "value":"other"
		                                    }
		                                 ]
		                              },
		                              "key":"gender",
		                              "type":"select"
		                           }
		                        ],
		                        "width":6
		                     }
		                  ],
		                  "key":"columns2",
		                  "type":"columns"
		               },
		               {
		                  "cols":[
		                     {
		                        "components":[
		                           {
		                              "label":{
		                                 "it-IT":"Identificativo",
		                                 "en-GB":"Identifier",
		                                 "en-US":"Identifier",
		                                 "fr-FR":"Identifiant",
		                                 "zh-CN":"标识",
		                                 "de-DE":"Identifier"
		                              },
		                              "tooltip":{
		                                 "it-IT":""
		                              },
		                              "key":"id",
		                              "type":"textfield"
		                           }
		                        ],
		                        "width":6
		                     },
		                     {
		                        "components":[
		                           {
		                              "multiple":false,
		                              "key":"authority",
		                              "type":"select",
		                              "data":{
		                                 "values":[
		                                    {
		                                       "label":{
		                                          "it-IT":"Master patient identifier",
		                                          "en-GB":"Master patient identifier",
		                                          "en-US":"Master patient identifier",
		                                          "fr-FR":"Master patient identifier",
		                                          "zh-CN":"Master patient identifier",
		                                          "de-DE":"Master patient identifier"
		                                       },
		                                       "value":"http://xvalue.dedalus.eu/dm/person/master_key"
		                                    },
		                                    {
		                                       "label":{
		                                          "it-IT":"Patient identifier",
		                                          "en-GB":"Patient identifier",
		                                          "en-US":"Patient identifier",
		                                          "fr-FR":"Patient identifier",
		                                          "zh-CN":"Patient identifier",
		                                          "de-DE":"Patient identifier"
		                                       },
		                                       "value":"2.16.840.1.113883.2.9.3.12.4.1"
		                                    },
		                                    {
		                                       "label":{
		                                          "it-IT":"Codice fiscale",
		                                          "en-GB":"National Insurance Number",
		                                          "en-US":"SSN",
		                                          "fr-FR":"NIR-INS",
		                                          "zh-CN":"居民身份证号",
		                                          "de-DE":"Nationalversicherungsnummer"
		                                       },
		                                       "value":"urn:oid:2.16.840.1.113883.2.9.4.3.2",
		                                       "checked":true
		                                    }
		                                 ]
		                              },
		                              "label":{
		                                 "it-IT":"Autorità",
		                                 "en-GB":"Authority",
		                                 "en-US":"Authority",
		                                 "fr-FR":"Autorité",
		                                 "zh-CN":"Authority",
		                                 "de-DE":"Authority"
		                              }
		                           }
		                        ],
		                        "width":6
		                     }
		                  ],
		                  "key":"columns1",
		                  "type":"columns"
		               },
		               {
		                  "label":{
		                     "it-IT":"Reset",
		                     "en-GB":"Reset",
		                     "en-US":"Reset",
		                     "fr-FR":"Remettre",
		                     "zh-CN":"重置",
		                     "de-DE":"Zurücksetzen"
		                  },
		                  "action":"event",
		                  "key":"submit1",
		                  "type":"button",
		                  "theme":"default",
		                  "eventName":"reset",
		                  "layout":{
		                     "halign":"hr",
		                     "width":"unset",
		                     "margin":{
		                        "marginTop":3
		                     }
		                  }
		               },
		               {
		                  "label":{
		                     "it-IT":"Ricerca",
		                     "en-GB":"Search",
		                     "en-US":"Search",
		                     "de-DE":"Suche",
		                     "fr-FR":"Recherche",
		                     "zh-CN":"搜索"
		                  },
		                  "key":"search",
		                  "type":"button",
		                  "layout":{
		                     "width":"unset",
		                     "margin":{
		                        "marginTop":3
		                     }
		                  },
		                  "conditional":{
		                     "json":{
		                        "or":[
		                           {
		                              "!!":[
		                                 {
		                                    "var":"data.given"
		                                 }
		                              ]
		                           },
		                           {
		                              "!!":[
		                                 {
		                                    "var":"data.family"
		                                 }
		                              ]
		                           },
		                           {
		                              "!=":[
		                                 {
		                                    "var":"data.birthdate"
		                                 }
		                              ]
		                           },
		                           {
		                              "!!":[
		                                 {
		                                    "var":"data.id"
		                                 }
		                              ]
		                           }
		                        ]
		                     }
		                  }
		               }
		            ],
		            "langs":"it-IT,en-GB,en-US,de-DE,fr-FR,zh-CN",
		            "defaultLang":"it-IT"
		         }
		      },
		      "advancedSearchDocumentForm":{
		         "jsonPathOptionLabel":"$.components.*.cols.*.components.*.data.values[?(@.value=='VALUE_OPTION')].label['CURRENT_LANG']",
		         "jsonPathLabel":"$.components.*.cols.*.components[?(@.key=='KEY')].label['CURRENT_LANG']",
		         "model":{
		            "type":"form",
		            "components":[
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Data da",
		                           "en-GB":"Date from",
		                           "en-US":"Date from",
		                           "fr-FR":"Date from",
		                           "zh-CN":"从",
		                           "de-DE":"Date from"
		                        },
		                        "key":"dateFrom",
		                        "type":"datetime",
		                        "suffix":"fa fa-calendar",
		                        "validate":{
		                           "required":true
		                        },
		                        "datePicker":{
		                           "showYearNavigator":true
		                        },
		                        "calculateProperty":{
		                           "yearRange.start":{
		                              "var":"param.startYear"
		                           },
		                           "yearRange.end":{
		                              "var":"param.endYear"
		                           }
		                        }
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Data a",
		                           "en-GB":"Date to",
		                           "en-US":"Date to",
		                           "fr-FR":"Date to",
		                           "zh-CN":"至",
		                           "de-DE":"Date to"
		                        },
		                        "suffix":"fa fa-calendar",
		                        "key":"dateTo",
		                        "type":"datetime",
		                        "validate":{
		                           "required":true
		                        },
		                        "datePicker":{
		                           "showYearNavigator":true
		                        },
		                        "calculateProperty":{
		                           "yearRange.start":{
		                              "var":"param.startYear"
		                           },
		                           "yearRange.end":{
		                              "var":"param.endYear"
		                           }
		                        }
		                     }
		                  ]
		               },
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Identificativo dell'evento",
		                           "en-GB":"Event identifier",
		                           "en-US":"Event identifier",
		                           "fr-FR":"Identifiant d'événement",
		                           "zh-CN":"事件",
		                           "de-DE":"Ereigniskennung"
		                        },
		                        "key":"searchDocumentEventCode",
		                        "type":"textfield",
		                        "dataSource":"calculate",
		                        "calculateProperty":{
		                           "disabled":{
		                              "if":[
		                                 {
		                                    "!!":[
		                                       {
		                                          "var":"data.searchDocumentDocumentCode"
		                                       }
		                                    ]
		                                 },
		                                 true,
		                                 false
		                              ]
		                           }
		                        }
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Identificativo del documento",
		                           "en-GB":"Document identifier",
		                           "en-US":"Document identifier",
		                           "fr-FR":"Identifiant du document",
		                           "zh-CN":"Document identifier",
		                           "de-DE":"Dokumentkennung"
		                        },
		                        "key":"searchDocumentDocumentCode",
		                        "type":"textfield",
		                        "dataSource":"calculate",
		                        "calculateProperty":{
		                           "disabled":{
		                              "if":[
		                                 {
		                                    "!!":[
		                                       {
		                                          "var":"data.searchDocumentEventCode"
		                                       }
		                                    ]
		                                 },
		                                 true,
		                                 false
		                              ]
		                           }
		                        }
		                     }
		                  ]
		               },
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Reset",
		                           "en-GB":"Reset",
		                           "en-US":"Reset",
		                           "de-DE":"Zurücksetzen",
		                           "fr-FR":"Remettre",
		                           "zh-CN":"重置"
		                        },
		                        "action":"event",
		                        "eventName":"reset",
		                        "key":"submit1",
		                        "type":"button",
		                        "layout":{
		                           "valign":"vb",
		                           "halign":"right",
		                           "width":"unset"
		                        },
		                        "theme":"default"
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Ricerca",
		                           "en-GB":"Search",
		                           "en-US":"Search",
		                           "de-DE":"Suche",
		                           "fr-FR":"Recherche",
		                           "zh-CN":"搜索"
		                        },
		                        "key":"submit2",
		                        "type":"button",
		                        "layout":{
		                           "valign":"vb",
		                           "halign":"hr",
		                           "width":"unset"
		                        },
		                        "conditional":{
		                           "json":{
		                              "or":[
		                                 {
		                                    "!=":[
		                                       {
		                                          "var":"data.dateFrom"
		                                       }
		                                    ]
		                                 },
		                                 {
		                                    "!=":[
		                                       {
		                                          "var":"data.dateTo"
		                                       }
		                                    ]
		                                 },
		                                 {
		                                    "!!":[
		                                       {
		                                          "var":"data.searchDocumentDocumentTypeCode"
		                                       }
		                                    ]
		                                 },
		                                 {
		                                    "!!":[
		                                       {
		                                          "var":"data.searchDocumentEventCode"
		                                       }
		                                    ]
		                                 },
		                                 {
		                                    "!!":[
		                                       {
		                                          "var":"data.searchDocumentDocumentCode"
		                                       }
		                                    ]
		                                 }
		                              ]
		                           }
		                        }
		                     }
		                  ]
		               }
		            ],
		            "langs":"it-IT,en-GB,en-US,de-DE,fr-FR,zh-CN",
		            "defaultLang":"it-IT",
		            "key":"form"
		         }
		      },
		      "advancedSearchEventForm":{
		         "jsonPathOptionLabel":"$.components.*.cols.*.components.*.data.values[?(@.value=='VALUE_OPTION')].label['CURRENT_LANG']",
		         "jsonPathLabel":"$.components.*.cols.*.components[?(@.key=='KEY')].label['CURRENT_LANG']",
		         "model":{
		            "type":"form",
		            "components":[
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Data da",
		                           "en-GB":"Date from",
		                           "en-US":"Date from",
		                           "fr-FR":"Date from",
		                           "zh-CN":"从",
		                           "de-DE":"Date from"
		                        },
		                        "key":"date@ge",
		                        "type":"datetime",
		                        "suffix":"fa fa-calendar",
		                        "validate":{
		                           "required":true
		                        },
		                        "datePicker":{
		                           "showYearNavigator":true
		                        },
		                        "calculateProperty":{
		                           "yearRange.start":{
		                              "var":"param.startYear"
		                           },
		                           "yearRange.end":{
		                              "var":"param.endYear"
		                           }
		                        }
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Data a",
		                           "en-GB":"Date to",
		                           "en-US":"Date to",
		                           "fr-FR":"Date to",
		                           "zh-CN":"至",
		                           "de-DE":"Date to"
		                        },
		                        "suffix":"fa fa-calendar",
		                        "key":"date@le",
		                        "type":"datetime",
		                        "validate":{
		                           "required":true
		                        },
		                        "datePicker":{
		                           "showYearNavigator":true
		                        },
		                        "calculateProperty":{
		                           "yearRange.start":{
		                              "var":"param.startYear"
		                           },
		                           "yearRange.end":{
		                              "var":"param.endYear"
		                           }
		                        }
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Identificativo dell'evento",
		                           "en-GB":"Event identifier",
		                           "en-US":"Event identifier",
		                           "fr-FR":"Identifiant d'événement",
		                           "zh-CN":"事件",
		                           "de-DE":"Ereigniskennung"
		                        },
		                        "key":"identifier",
		                        "type":"textfield",
		                        "dataSource":"calculate"
		                     }
		                  ]
		               },
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Reset",
		                           "en-GB":"Reset",
		                           "en-US":"Reset",
		                           "de-DE":"Zurücksetzen",
		                           "fr-FR":"Remettre",
		                           "zh-CN":"重置"
		                        },
		                        "action":"event",
		                        "eventName":"reset",
		                        "key":"submit1",
		                        "type":"button",
		                        "layout":{
		                           "valign":"vb",
		                           "halign":"right",
		                           "width":"unset"
		                        },
		                        "theme":"default"
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Ricerca",
		                           "en-GB":"Search",
		                           "en-US":"Search",
		                           "de-DE":"Suche",
		                           "fr-FR":"Recherche",
		                           "zh-CN":"搜索"
		                        },
		                        "key":"submit2",
		                        "type":"button",
		                        "layout":{
		                           "valign":"vb",
		                           "halign":"hr",
		                           "width":"unset"
		                        },
		                        "conditional":{
		                           "json":{
		                              "or":[
		                                 {
		                                    "!=":[
		                                       {
		                                          "var":"data.date@ge"
		                                       }
		                                    ]
		                                 },
		                                 {
		                                    "!=":[
		                                       {
		                                          "var":"data.date@le"
		                                       }
		                                    ]
		                                 },
		                                 {
		                                    "!!":[
		                                       {
		                                          "var":"data.identifier"
		                                       }
		                                    ]
		                                 }
		                              ]
		                           }
		                        }
		                     }
		                  ]
		               }
		            ],
		            "langs":"it-IT,en-GB,en-US,de-DE,fr-FR,zh-CN",
		            "defaultLang":"it-IT",
		            "key":"form"
		         }
		      },
		      "advancedSearchRequestGroupForm":{
		         "jsonPathOptionLabel":"$.components.*.cols.*.components.*.data.values[?(@.value=='VALUE_OPTION')].label['CURRENT_LANG']",
		         "jsonPathLabel":"$.components.*.cols.*.components[?(@.key=='KEY')].label['CURRENT_LANG']",
		         "model":{
		            "type":"form",
		            "components":[
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Data da",
		                           "en-GB":"Date from",
		                           "en-US":"Date from",
		                           "fr-FR":"Date from",
		                           "zh-CN":"从",
		                           "de-DE":"Date from"
		                        },
		                        "key":"authored@ge",
		                        "type":"datetime",
		                        "suffix":"fa fa-calendar",
		                        "validate":{
		                           "required":true
		                        },
		                        "datePicker":{
		                           "showYearNavigator":true
		                        },
		                        "calculateProperty":{
		                           "yearRange.start":{
		                              "var":"param.startYear"
		                           },
		                           "yearRange.end":{
		                              "var":"param.endYear"
		                           }
		                        }
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Data a",
		                           "en-GB":"Date to",
		                           "en-US":"Date to",
		                           "fr-FR":"Date to",
		                           "zh-CN":"至",
		                           "de-DE":"Date to"
		                        },
		                        "suffix":"fa fa-calendar",
		                        "key":"authored@le",
		                        "type":"datetime",
		                        "validate":{
		                           "required":true
		                        },
		                        "datePicker":{
		                           "showYearNavigator":true
		                        },
		                        "calculateProperty":{
		                           "yearRange.start":{
		                              "var":"param.startYear"
		                           },
		                           "yearRange.end":{
		                              "var":"param.endYear"
		                           }
		                        }
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Identificativo della Request Group",
		                           "en-GB":"Request Group identifier",
		                           "en-US":"Request Group identifier",
		                           "fr-FR":"Identifiant du groupe de demandes",
		                           "zh-CN":"请求组标识符",
		                           "de-DE":"Gruppenkennung anfordern"
		                        },
		                        "key":"identifier",
		                        "type":"textfield",
		                        "dataSource":"calculate"
		                     }
		                  ]
		               },
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Reset",
		                           "en-GB":"Reset",
		                           "en-US":"Reset",
		                           "de-DE":"Zurücksetzen",
		                           "fr-FR":"Remettre",
		                           "zh-CN":"重置"
		                        },
		                        "action":"event",
		                        "eventName":"reset",
		                        "key":"submit1",
		                        "type":"button",
		                        "layout":{
		                           "valign":"vb",
		                           "halign":"right",
		                           "width":"unset"
		                        },
		                        "theme":"default"
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Ricerca",
		                           "en-GB":"Search",
		                           "en-US":"Search",
		                           "de-DE":"Suche",
		                           "fr-FR":"Recherche",
		                           "zh-CN":"搜索"
		                        },
		                        "key":"submit2",
		                        "type":"button",
		                        "layout":{
		                           "valign":"vb",
		                           "halign":"hr",
		                           "width":"unset"
		                        },
		                        "conditional":{
		                           "json":{
		                              "or":[
		                                 {
		                                    "!=":[
		                                       {
		                                          "var":"data.authored@ge"
		                                       }
		                                    ]
		                                 },
		                                 {
		                                    "!=":[
		                                       {
		                                          "var":"data.authored@le"
		                                       }
		                                    ]
		                                 },
		                                 {
		                                    "!!":[
		                                       {
		                                          "var":"data.identifier"
		                                       }
		                                    ]
		                                 }
		                              ]
		                           }
		                        }
		                     }
		                  ]
		               }
		            ],
		            "langs":"it-IT,en-GB,en-US,de-DE,fr-FR,zh-CN",
		            "defaultLang":"it-IT",
		            "key":"form"
		         }
		      },
		      "idCardUploadForm":{
		         "model":{
		            "type":"form",
		            "components":[
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "value":"Drop files here or click to upload",
		                        "label":{
		                           "it-IT":"Trascina il file qui o fai clic per caricare il Documento",
		                           "en-GB":"Drop file here or click to upload Document",
		                           "de-DE":"Legen Sie die Datei hier ab oder klicken Sie, um das Dokument hochzuladen"
		                        },
		                        "dropZone":true,
		                        "mimeType":"image/jpeg,application/pdf",
		                        "validate":{
		                           "required":true
		                        },
		                        "key":"idCardFile",
		                        "type":"file"
		                     }
		                  ]
		               },
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Tipo di documento",
		                           "en-GB":"Document type",
		                           "de-DE":"Art des Dokuments"
		                        },
		                        "multiple":false,
		                        "data":{
		                           "values":[
		                              {
		                                 "label":{
		                                    "it-IT":"Carta d'identità",
		                                    "en-GB":"ID",
		                                    "de-DE":"Personalausweis"
		                                 },
		                                 "value":"identity"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Patente di guida",
		                                    "en-GB":"Driving license",
		                                    "de-DE":"Fahrerlaubnis"
		                                 },
		                                 "value":"drivelicense"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Altro",
		                                    "en-GB":"Other",
		                                    "de-DE":"Andere"
		                                 },
		                                 "value":"other"
		                              }
		                           ]
		                        },
		                        "validate":{
		                           "required":true
		                        },
		                        "key":"idCardType",
		                        "type":"select"
		                     }
		                  ]
		               },
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Codice documento",
		                           "en-GB":"Document code",
		                           "de-DE":"Dokumentcode"
		                        },
		                        "tooltip":{
		                           "it-IT":""
		                        },
		                        "validate":{
		                           "required":false
		                        },
		                        "key":"idCardCode",
		                        "type":"textfield"
		                     }
		                  ]
		               },
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Data di scadenza",
		                           "en-GB":"Expiration date",
		                           "de-DE":"Haltbarkeitsdatum"
		                        },
		                        "suffix":"fa fa-calendar",
		                        "datePicker":{
		                           "showYearNavigator":true
		                        },
		                        "validate":{
		                           "required":true
		                        },
		                        "calculateProperty":{
		                           "yearRange.start":{
		                              "var":"param.startYear"
		                           },
		                           "yearRange.end":{
		                              "var":"param.endYear"
		                           }
		                        },
		                        "key":"idCardEndDate",
		                        "type":"datetime"
		                     }
		                  ]
		               },
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Reset",
		                           "en-GB":"Reset",
		                           "de-DE":"Zurücksetzen"
		                        },
		                        "layout":{
		                           "valign":"vb",
		                           "halign":"right",
		                           "width":"unset"
		                        },
		                        "theme":"secondary",
		                        "action":"event",
		                        "eventName":"reset",
		                        "key":"reset",
		                        "type":"button"
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Carica",
		                           "en-GB":"Upload",
		                           "de-DE":"Hochladen"
		                        },
		                        "layout":{
		                           "valign":"vb",
		                           "halign":"hr",
		                           "width":"unset"
		                        },
		                        "key":"submit",
		                        "type":"button"
		                     }
		                  ]
		               }
		            ],
		            "langs":"it-IT,en-GB,de-DE",
		            "defaultLang":"it-IT",
		            "key":"form"
		         }
		      },
		      "guardianForm":{
		         "model":{
		            "type":"form",
		            "components":[
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Ruolo",
		                           "en-GB":"Role",
		                           "de-DE":"Rolle"
		                        },
		                        "multiple":false,
		                        "data":{
		                           "values":[
		                              {
		                                 "label":{
		                                    "it-IT":"Tutore legale",
		                                    "en-GB":"Tutor",
		                                    "de-DE":"Tutor"
		                                 },
		                                 "value":"GUARD"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Genitore",
		                                    "en-GB":"Parent",
		                                    "de-DE":"Elternteil"
		                                 },
		                                 "value":"PRN"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Padre",
		                                    "en-GB":"Father",
		                                    "de-DE":"Vater"
		                                 },
		                                 "value":"FTH"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Madre",
		                                    "en-GB":"Mother",
		                                    "de-DE":"Mutter"
		                                 },
		                                 "value":"MTH"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Delegato",
		                                    "en-GB":"Responsible party",
		                                    "de-DE":"Delegierte"
		                                 },
		                                 "value":"RESPRSN"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Figlio/a",
		                                    "en-GB":"Child",
		                                    "de-DE":"Sohn/Tochter"
		                                 },
		                                 "value":"CHILD"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Convivente",
		                                    "en-GB":"Domestic partner",
		                                    "de-DE":"Lebenspartner"
		                                 },
		                                 "value":"DOMPART"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Familiare",
		                                    "en-GB":"Family member",
		                                    "de-DE":"Familienmitglied"
		                                 },
		                                 "value":"FAMMEMB"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Prossimo congiunto",
		                                    "en-GB":"Next of kin",
		                                    "de-DE":"Nächste Verwandte"
		                                 },
		                                 "value":"NOK"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Interessato",
		                                    "en-GB":"Interested party",
		                                    "de-DE":"Interessent"
		                                 },
		                                 "value":"DICH"
		                              }
		                           ]
		                        },
		                        "validate":{
		                           "required":true
		                        },
		                        "key":"role",
		                        "type":"select"
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Cognome",
		                           "en-GB":"Last Name",
		                           "de-DE":"Nachname"
		                        },
		                        "validate":{
		                           "required":true
		                        },
		                        "key":"lastname",
		                        "type":"textfield"
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Nome",
		                           "en-GB":"Name",
		                           "de-DE":"Name"
		                        },
		                        "validate":{
		                           "required":true
		                        },
		                        "key":"name",
		                        "type":"textfield"
		                     }
		                  ]
		               },
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Data di nascita",
		                           "en-GB":"Birth date",
		                           "de-DE":"Geburtsdatum"
		                        },
		                        "suffix":"fa fa-calendar",
		                        "datePicker":{
		                           "showYearNavigator":true
		                        },
		                        "validate":{
		                           "required":true
		                        },
		                        "calculateProperty":{
		                           "yearRange.start":{
		                              "var":"param.startYear"
		                           },
		                           "yearRange.end":{
		                              "var":"param.endYear"
		                           }
		                        },
		                        "key":"birthdate",
		                        "type":"datetime"
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Codice Fiscale",
		                           "en-GB":"Taxcode",
		                           "de-DE":"Steuernummer"
		                        },
		                        "validate":{
		                           "required":true
		                        },
		                        "key":"taxcode",
		                        "type":"textfield"
		                     },
		                     {
		                        "label":{
		                           "it-IT":"Sesso",
		                           "en-GB":"Gender",
		                           "de-DE":"Geschlecht"
		                        },
		                        "multiple":false,
		                        "data":{
		                           "values":[
		                              {
		                                 "label":{
		                                    "it-IT":"Maschio",
		                                    "en-GB":"Male",
		                                    "de-DE":"Männlich"
		                                 },
		                                 "value":"male"
		                              },
		                              {
		                                 "label":{
		                                    "it-IT":"Femmina",
		                                    "en-GB":"Female",
		                                    "de-DE":"Weiblich"
		                                 },
		                                 "value":"female"
		                              }
		                           ]
		                        },
		                        "validate":{
		                           "required":true
		                        },
		                        "key":"gender",
		                        "type":"select"
		                     }
		                  ]
		               },
		               {
		                  "type":"row",
		                  "components":[
		                     {
		                        "label":{
		                           "it-IT":"Salva",
		                           "en-GB":"Save",
		                           "de-DE":"Speichern"
		                        },
		                        "layout":{
		                           "valign":"vb",
		                           "halign":"hr",
		                           "width":"unset"
		                        },
		                        "key":"submit",
		                        "type":"button"
		                     }
		                  ]
		               }
		            ],
		            "langs":"it-IT,en-GB,de-DE",
		            "defaultLang":"it-IT",
		            "key":"form"
		         }
		      }
		   },
		   "frontEnd":"consent-collector"
		};

var patient = {
		   "key":"patient",
		   "data":{
			  "rowsToFetch" : NumberInt(100), 
			  "rowsPerPage" : NumberInt(10), 
		      "columns":[
		         {
		            "type":"Image",
		            "field":"s4h.patient-search.photo",
		            "jpath":"$.resource.photo[0].url",
		            "hide":false,
		            "imageSecured":true
		         },
		         {
		            "type":"String",
		            "field":"s4h.patient-search.fullname",
		            "jpath":"$.resource.name[0].text",
		            "hide":false
		         },
		         {
		            "type":"String",
		            "field":"s4h.patient-search.taxcode",
		            "jpath":"$.resource.identifier[?(@.system == \"urn:oid:2.16.840.1.113883.2.9.4.3.2\")].value",
		            "hide":false
		         },
		         {
		            "type":"String",
		            "field":"s4h.patient-search.gender",
		            "jpath":"$.resource.gender",
		            "isTranslatable":true,
		            "toUpperCase":true,
		            "hide":false
		         },
		         {
		            "type":"Date",
		            "field":"s4h.patient-search.birthdate",
		            "jpath":"$.resource.birthDate",
		            "hide":false
		         },
		         {
		            "type":"String",
		            "field":"s4h.patient-search.BirthPlace",
		            "jpath":"$.resource.extension[?(@.url==\"http://hl7.org/fhir/StructureDefinition/birthPlace\")].valueAddress.city",
		            "hide":false
		         },
		         {
		            "type":"Actions",
		            "field":"s4h.patient-search.authorities",
		            "actions":[
		               {
		                  "icon":"fa fa-users",
		                  "eventKey":"showAuthorities",
		                  "jpath":"$.resource.identifier"
		               }
		            ],
		            "hide":false
		         },
		         {
		            "type":"Actions",
		            "field":"s4h.patient-search.consent",
		            "actions":[
		               {
		                  "icon":"fa fa-unlock-alt",
		                  "eventKey":"consentPatient",
		                  "jpath":"$.resource.identifier"
		               }
		            ],
		            "hide":true
		         },
		         {
		            "type":"Actions",
		            "field":"s4h.patient-search.urgentAccess",
		            "actions":[
		               {
		                  "icon":"fa fa-exclamation-triangle",
		                  "eventKey":"urgentAccess",
		                  "jpath":"$.resource"
		               }
		            ],
		            "hide":true
		         }
		      ],
		      "banner":{
		         "jsonExpressions":[
		            {
		               "key":"photo",
		               "type":"Image",
		               "field":"s4h.patient-banner.photo",
		               "jpath":"$.photo[0].url",
		               "imageSecured":true
		            },
		            {
		               "key":"familyName",
		               "type":"String",
		               "field":"",
		               "jpath":"$.name[0].family"
		            },
		            {
		               "key":"givenName",
		               "type":"String",
		               "field":"",
		               "jpath":"$.name[0].given"
		            },
		            {
		               "key":"identifier",
		               "type":"String",
		               "field":"",
		               "jpath":"$.identifier[?(@.system == \"urn:oid:2.16.840.1.113883.2.9.4.3.2\")].value"
		            },
		            {
		               "key":"taxcode",
		               "type":"String",
		               "field":"",
		               "jpath":"$.identifier[?(@.system == \"urn:oid:2.16.840.1.113883.2.9.4.3.2\")].value"
		            },
		            {
		               "key":"gender",
		               "type":"String",
		               "field":"s4h.patient-banner.gender",
		               "jpath":"$.gender",
		               "isTranslatable":true,
		               "toUpperCase":true
		            },
		            {
		               "key":"birthDate",
		               "type":"Date",
		               "field":"s4h.patient-banner.birthdate",
		               "jpath":"$.birthDate"
		            },
		            {
		               "key":"phoneNumber",
		               "type":"String",
		               "field":"s4h.patient-banner.phonenumber",
		               "jpath":"$.telecom[?(@.system==\"phone\")].value"
		            },
		            {
		               "key":"mail",
		               "type":"String",
		               "field":"s4h.patient-banner.mail",
		               "jpath":"$.telecom[?(@.system==\"mail\")].value"
		            },
		            {
		               "key":"residenceAddress",
		               "type":"String",
		               "field":"s4h.patient-banner.residenceAddress",
		               "jpath":"$.address.extension[?(@.valueCode=\"H\")].valueAddress.city"
		            },
		            {
		               "key":"knownAddress",
		               "type":"String",
		               "field":"s4h.patient-banner.knownAddress",
		               "jpath":"$.extension[?(@.url==\"http://hl7.org/fhir/structuredefinition/birthplace\")].valueAddress.city"
		            },
		            {
		               "key":"id",
		               "type":"String",
		               "field":"s4h.patient-banner.id",
		               "jpath":"$.id"
		            },
		            {
		               "key":"generalPractitioner",
		               "type":"String",
		               "field":"s4h.patient-banner.practitioner",
		               "jpath":"$.generalPractitioner.*.display"
		            },
		            {
		               "key":"managingOrganization",
		               "type":"String",
		               "field":"s4h.patient-banner.organization",
		               "jpath":"$.managingOrganization.display"
		            },
		            {
		               "key":"birthPlace",
		               "type":"String",
		               "field":"s4h.patient-banner.residenceAddress",
		               "jpath":"$.extension[?(@.url==\"http://hl7.org/fhir/StructureDefinition/birthPlace\")].valueAddress.city"
		            },
		            {
		               "key":"photo",
		               "type":"Image",
		               "field":"s4h.patient-banner.photo",
		               "jpath":"$.photo[0].url"
		            },
		            {
		               "key":"identifiers",
		               "type":"String",
		               "field":"s4h.patient-banner.AssigningAuthorities",
		               "jpath":"$.identifier"
		            }
		         ],
		         "system":"urn:oid:2.16.840.1.113883.2.9.4.3.2",
		         "urlAddressQualifier":"http://apiframework.dedalus.eu/fhir/StructureDefinition/address-qualifier",
		         "residenceQualifier":"HP",
		         "domicileQualifier":"H"
		      },
		      "allergy":[
		         {
		            "key":"clinicalStatus",
		            "type":"String",
		            "field":"s4h.patient-banner.allergyintolerance.clinicalstatus",
		            "jpath":"$.resource.clinicalStatus",
		            "simpleJPath":"s4hpatientbannerallergyintoleranceclinicalstatus"
		         },
		         {
		            "key":"verificationStatus",
		            "type":"String",
		            "field":"s4h.patient-banner.allergyintolerance.verificationstatus",
		            "jpath":"$.resource.verificationStatus",
		            "simpleJPath":"s4hpatientbannerallergyintoleranceverificationstatus"
		         },
		         {
		            "key":"type",
		            "type":"String",
		            "field":"s4h.patient-banner.allergyintolerance.type",
		            "jpath":"$.resource.type",
		            "simpleJPath":"s4hpatientbannerallergyintolerancetype"
		         },
		         {
		            "key":"category",
		            "type":"String",
		            "field":"s4h.patient-banner.allergyintolerance.category",
		            "jpath":"$.resource.category.*",
		            "simpleJPath":"s4hpatientbannerallergyintolerancecategory"
		         },
		         {
		            "key":"criticality",
		            "type":"String",
		            "field":"s4h.patient-banner.allergyintolerance.criticality",
		            "jpath":"$.resource.criticality",
		            "simpleJPath":"s4hpatientbannerallergyintolerancecriticality"
		         },
		         {
		            "key":"allergy",
		            "type":"String",
		            "field":"s4h.patient-banner.allergyintolerance.allergies",
		            "jpath":"$.resource.code.coding.*.display",
		            "simpleJPath":"s4hpatientbannerallergyintoleranceallergies"
		         },
		         {
		            "key":"reaction",
		            "type":"String",
		            "field":"s4h.patient-banner.allergyintolerance.reaction",
		            "jpath":"$.resource.reaction.*.manifestation.*.coding.*.display",
		            "simpleJPath":"s4hpatientbannerallergyintolerancereaction"
		         },
		         {
		            "key":"severity",
		            "type":"String",
		            "field":"s4h.patient-banner.allergyintolerance.severity",
		            "jpath":"$.resource.reaction.*.severity",
		            "simpleJPath":"s4hpatientbannerallergyintoleranceseverity"
		         },
		         {
		            "key":"asserteddate",
		            "type":"Date",
		            "field":"s4h.patient-banner.allergyintolerance.asserteddate",
		            "jpath":"$.resource.assertedDate",
		            "simpleJPath":"s4hpatientbannerallergyintoleranceasserteddate"
		         }
		      ],
		      "procedure":[
		         {
		            "key":"task",
		            "type":"String",
		            "field":"s4h.patient-banner.procedure.task",
		            "jpath":"$.resource.code.coding[*].display",
		            "simpleJPath":"s4hpatientbannerproceduretask"
		         },
		         {
		            "key":"status",
		            "type":"String",
		            "field":"s4h.patient-banner.procedure.status",
		            "jpath":"$.resource.status",
		            "simpleJPath":"s4hpatientbannerprocedurestatus"
		         },
		         {
		            "key":"start",
		            "type":"Date",
		            "field":"s4h.patient-banner.procedure.start",
		            "jpath":"$.resource.performedPeriod.start",
		            "simpleJPath":"s4hpatientbannerprocedurestart"
		         },
		         {
		            "key":"end",
		            "type":"Date",
		            "field":"s4h.patient-banner.procedure.end",
		            "jpath":"$.resource.performedPeriod.end",
		            "simpleJPath":"s4hpatientbannerprocedureend"
		         }
		      ],
		      "authority":[
		         {
		            "key":"assingingauthorities",
		            "type":"String",
		            "field":"s4h.patient-banner.assigningauthorities.assingingauthority",
		            "jpath":"system",
		            "simpleJPath":"s4hpatientbannerassigningauthoritiesassigningauthority"
		         },
		         {
		            "key":"assingingauthoritiesdisplay",
		            "type":"String",
		            "field":"s4h.patient-banner.assigningauthorities.assigningauthoritydisplay",
		            "jpath":"type.coding.display",
		            "simpleJPath":"s4hpatientbannerassigningauthorityassigningauthorities"
		         },
		         {
		            "key":"assingingauthoritiesvalue",
		            "type":"String",
		            "field":"s4h.patient-banner.assigningauthorities.assigningauthorityvalue",
		            "jpath":"value",
		            "simpleJPath":"s4hpatientbannerassigningauthoritiesesassigningauthorityvalue"
		         }
		      ],
	            "familyMemberHistory": [
	                {
	                    "key": "status",
	                    "type": "String",
	                    "field": "s4h.patient-banner.familymemberhistory.status",
	                    "jpath": "$.resource.status",
	                    "simpleJPath": "s4hpatientbannerfamilymemberhistorystatus",
	                    "hide": false
	                },
	                {
	                    "key": "name",
	                    "type": "String",
	                    "field": "s4h.patient-banner.familymemberhistory.name",
	                    "jpath": "$.resource.name",
	                    "simpleJPath": "s4hpatientbannerfamilymemberhistoryname",
	                    "hide": true
	                },
	                {
	                    "key": "relationship",
	                    "type": "String",
	                    "field": "s4h.patient-banner.familymemberhistory.relationship",
	                    "jpath": "$.resource.relationship.coding[*].display",
	                    "simpleJPath": "s4hpatientbannerfamilymemberhistoryrelationship",
	                    "hide": false
	                },
	                {
	                    "key": "gender",
	                    "type": "String",
	                    "field": "s4h.patient-banner.familymemberhistory.gender",
	                    "jpath": "$.resource.gender",
	                    "simpleJPath": "s4hpatientbannerfamilymemberhistorygender",
	                    "hide": false
	                },
	                {
	                    "key": "condition",
	                    "type": "String",
	                    "field": "s4h.patient-banner.familymemberhistory.condition",
	                    "jpath": "$.resource.condition[*].code.coding[*].display",
	                    "simpleJPath": "s4hpatientbannerfamilymemberhistorycondition",
	                    "hide": false
	                },
	                {
	                    "key": "date",
	                    "type": "Date",
	                    "field": "s4h.patient-banner.familymemberhistory.date",
	                    "jpath": "$.resource.date",
	                    "simpleJPath": "s4hpatientbannerfamilymemberhistorydate",
	                    "hide": false
	                }
	            ]
		   },
		   "frontEnd":"consent-collector"
		};

var menu = {
		   "key":"menu",
		   "data":{
				"default" : "search-patient-bundle",
				"list" : [
					{
						"title" : "searchPatient",
						"label" : "searchPatient",
						"icon" : "fa fa-h-square fa-lg",
						"routerLink" : [
							"search-patient/search"
						],
						"visible" : true,
						"mode" : [
							"standalone"
						]
					},
					{
						"title" : "collectConsent",
						"label" : "collectConsent",
						"icon" : "fa fa-user fa-lg",
						"routerLink" : [
							"search-patient-bundle/detail/patient-details/search-bundle"
						],
						"visible" : true,
						"mode" : [
							"standalone",
							"context"
						]
					},
					{
						"title" : "collectConsentEvent@E",
						"label" : "collectConsentEvent@E",
						"icon" : "fa fa-calendar fa-lg",
						"routerLink" : [
							"search-patient-event/detail/patient-details/search-event"
						],
						"visible" : true,
						"mode" : [
							"standalone",
							"context"
						]
					},
					{
						"title" : "collectConsentRequestGroup@RG",
						"label" : "collectConsentRequestGroup@RG",
						"icon" : "fa fa-clipboard fa-lg",
						"routerLink" : [
							"search-patient-request-group/detail/patient-details/search-request-group"
						],
						"visible" : true,
						"mode" : [
							"standalone",
							"context"
						]
					},
					{
						"title" : "collectConsentDocument@D",
						"label" : "collectConsentDocument@D",
						"icon" : "fa fa-file-text-o fa-lg",
						"routerLink" : [
							"search-patient-document/detail/patient-details/search-document"
						],
						"visible" : true,
						"mode" : [
							"standalone",
							"context"
						]
					},
					{
						"title" : "historicalConsent",
						"label" : "historicalConsent",
						"icon" : "fa fa-hospital-o fa-lg",
						"routerLink" : [
							"history/detail/patient-details/list"
						],
						"visible" : true,
						"mode" : [
							"standalone",
							"context"
						]
					}
				]
			},
		   "frontEnd":"consent-collector"
		};

var documentConsultationColumns ={
   "key":"documentconsultationcolumns",
   "data":{
      "columns": [
          {
              "jpath": "$.resource.indexed",
              "name": "indexed",
              "columnTitle": "s4h.document-list.columnTitle.indexed",
              "type": "Date",
              "infoFormat": "date+time",
              "ignore": false,
              "display": true
          },
          {
              "jpath": "$.resource.meta.versionId",
              "name": "version",
              "columnTitle": "s4h.document-list.columnTitle.version",
              "type": "String",
              "ignore": false,
              "display": true
          },
          {
              "jpath": "$.resource.context.related[?(@.identifier.type.coding[0].code)].identifier",
              "name": "o3Identifier",
              "columnTitle": "s4h.document-list.columnTitle.o3",
              "type": "Identifier",
              "ignore": true,
              "display": true
          },
          {
              "jpath": "$.resource.context.related[?(@.identifier.type.coding[0].code)].identifier",
              "name": "externalAppIdentifier",
              "columnTitle": "s4h.document-list.columnTitle.externalApp",
              "type": "Identifier",
              "ignore": true,
              "display": true
          },
          {
              "jpath": "$.resource.context.encounter.reference_MULTI_PATH_$.resource.context.related[0].ref.reference_ENCOUNTER_PATH_$.resource.context.related.*.identifier.value_VAL_SYS_CODE_$.resource.context.related.*.identifier.system_VAL_SYS_CODE_$.resource.context.related.*.identifier.type.coding[0].code_IDENTIFIER_$.resource.context.related.*.identifier",
              "name": "encounter",
              "columnTitle": "s4h.document-list.columnTitle.encounter",
              "type": "EncounterString",
              "ignore": false,
              "display": true
          },
          {
              "jpath": "$.resource.type.coding.*.display_DISPLAY_OR_$.resource.type.coding.*.code",
              "name": "typeDisplayORCode",
              "columnTitle": "s4h.document-list.columnTitle.typeDisplayORCode",
              "type": "String",
              "ignore": false,
              "display": true
          },
          {
              "jpath": "$.resource.author.*.reference",
              "jpathForPostProcessing": "$.resource.contained[?(@.id=='')].resourceType_RESOURCE_TYPE_$.resource.contained[?(@.id=='')].name.*.text_PRACTICTIONER_NAME_ORGANIZATION_$.resource.contained[?(@.id=='')].name_NAMES_$.resource.contained[?(@.id=='')].qualification.*.code.text_SPECIALIZATION_INSTITUTION_$.resource.contained[?(@.id=='')].qualification.*.issuer.display",
              "isAReference": true,
              "postProcessing": true,
              "name": "author",
              "columnTitle": "s4h.document-list.columnTitle.author",
              "type": "ArrayString",
              "ignore": false,
              "display": true
          },
          {
              "jpath": "$.resource.securityLabel.*.coding[?(@.system=='urn:oid:2.16.840.1.113883.2.9.2.50.6.34.8')].code",
              "name": "confidentialityCode",
              "postProcessing": true,
              "columnTitle": "s4h.document-list.columnTitle.confidentialityCode",
              "type": "ConfidentialityString",
              "ignore": false,
              "display": true
          },
          {
              "jpath": "$.resource.extension[?(@.valueCodeableConcept.id=='urn:uuid:22130e88-0cab-4f64-8d28-bbef1d050e32')].*.coding.*.display",
              "name": "producerWardCode",
              "columnTitle": "s4h.document-list.columnTitle.producerWardCode",
              "type": "String",
              "ignore": true,
              "display": true
          },
          {
              "jpath": "$.resource.extension[?(@.valueCodeableConcept.id=='urn:uuid:f049cac7-8a07-4980-99d2-0db29f52991e')].*.coding.*.display",
              "name": "requestingWardCode",
              "columnTitle": "s4h.document-list.columnTitle.requestingWardCode",
              "type": "String",
              "ignore": true,
              "display": true
          },
          {
              "jpath": "$.resource.masterIdentifier.value",
              "name": "open",
              "columnTitle": "s4h.document-list.columnTitle.open",
              "type": "Button",
              "ignore": false,
              "display": false
          },
          {
              "jpath": "$.resource.content.*.attachment.contentType",
              "name": "contentType",
              "columnTitle": "s4h.document-list.columnTitle.contentType",
              "type": "String",
              "ignore": false,
              "display": false
          },
          {
              "jpath": "$.resource.content.*.attachment.size",
              "name": "size",
              "columnTitle": "s4h.document-list.columnTitle.size",
              "type": "String",
              "ignore": false,
              "display": false
          }
      ]
   },
   "frontEnd":"consent-collector"
};



var eventConsultationColumns ={
   "key":"eventconsultationcolumns",
   "data":{
	   "columns" : [
		   {
				"jpath" : "$.resource.identifier[0].value",
				"name" : "eventCode",
				"columnTitle" : "s4h.resource-list.event-columnTitle.eventCode",
				"type" : "String",
				"ignore" : false,
				"display" : true
			},
			{
				"jpath" : "$.resource.identifier",
				"name" : "identifier",
				"columnTitle" : "s4h.resource-list.event-columnTitle.identifier",
				"type" : "Identifier",
				"ignore" : false,
				"display" : true
			},
			{
				"jpath" : "$.resource.class.code",
				"name" : "class",
				"columnTitle" : "s4h.resource-list.event-columnTitle.class",
				"type" : "String",
				"ignore" : false,
				"display" : true,
				"i18nKey" : "s4h.timeline."
			},
			{
				"jpath" : "$.resource.type.*.coding[?(@.system=='http://apiframework.dedalus.eu/fhir/CodeSystem/EncounterType')].code",
				"name" : "type",
				"columnTitle" : "s4h.resource-list.event-columnTitle.type",
				"type" : "String",
				"ignore" : false,
				"display" : true
			},
			{
				"jpath" : "$.resource.status",
				"name" : "status",
				"columnTitle" : "s4h.resource-list.event-columnTitle.status",
				"type" : "String",
				"ignore" : false,
				"display" : true
			}
		]
   },
   "frontEnd":"consent-collector"
};




var requestgroupconsultationcolumns ={
	"key" : "requestgroupconsultationcolumns",
	"data" : {
		"columns" : [
			{
				"jpath" : "$.resource.identifier[0].value",
				"name" : "requestGroupCode",
				"columnTitle" : "s4h.resource-list.requestGroup-columnTitle.requestCode",
				"type" : "String",
				"ignore" : false,
				"display" : true
			},
			{
				"jpath" : "$.resource.identifier",
				"name" : "identifier",
				"columnTitle" : "s4h.resource-list.requestGroup-columnTitle.identifier",
				"type" : "Identifier",
				"ignore" : false,
				"display" : true
			},
			{
				"jpath" : "$.resource.authoredOn",
				"name" : "authoredOn",
				"columnTitle" : "s4h.resource-list.requestGroup-columnTitle.authoredOn",
				"type" : "String",
				"ignore" : false,
				"display" : true
			},
			{
				"jpath" : "$.resource.priority",
				"name" : "priority",
				"columnTitle" : "s4h.resource-list.requestGroup-columnTitle.priority",
				"type" : "String",
				"ignore" : false,
				"display" : true
			}
		]
	},
	"frontEnd" : "consent-collector"
};


