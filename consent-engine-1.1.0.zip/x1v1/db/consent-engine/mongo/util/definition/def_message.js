var empty = {
	code : "empty",
	message : {
		it: "E' necessario esprimere nuovi consensi.",
        en: "You have to give new consents."
	}
};