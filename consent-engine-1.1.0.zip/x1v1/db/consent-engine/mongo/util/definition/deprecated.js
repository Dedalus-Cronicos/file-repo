var DLGS19603 = {
    "code": "DLGS196-03",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Consenso al trattamento dei dati personali"
        }, {
            "language": "en-GB",
            "text": "Consent to the processing of personal data"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": "Il Titolare al trattamento dei dati personali necessari per lo svolgimento dell'incarico conferito, anche comunicandoli a soggetti esterni alla propria struttura qualora ciò si rendesse necessario ai fini dell'adempimento di tutto o in parte dell'incarico"
        }, {
            "language": "en-GB",
            "text": "The Owner to the processing of personal data necessary for the performance of the assignment, also communicating it to third parties outside the structure if this becomes necessary for the fulfillment of all or part of the assignment"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": "Ai fini dell'espressione del consenso al trattameno dei dati personali e sensibili (art.23 e art.81 del d.lgs.196/2003)"
        },
        {
            "language": "en-GB",
            "text": "For the purpose of expressing consent to the processing of personal and sensitive data (art.23 and art.81 of Legislative Decree 196/2003)"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var DS1 = {
    "code": "DS-1",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Costituzione del dossier sanitario elettronico (DSE)"
        }, {
            "language": "en-GB",
            "text": "Establishment of the electronic health dossier (DSE)"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": "Il Titolare al trattamento dei dati personali necessari per lo svolgimento dell'incarico conferito, anche comunicandoli a soggetti esterni alla propria struttura qualora ciò si rendesse necessario ai fini dell'adempimento di tutto o in parte dell'incarico"
        }, {
            "language": "en-GB",
            "text": "The Owner to the processing of personal data necessary for the performance of the assignment, also communicating it to third parties outside the structure if this becomes necessary for the fulfillment of all or part of the assignment"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": "Ai fini dell'espressione del consenso al trattameno dei dati personali e sensibili (art.23 e art.81 del d.lgs.196/2003)"
        }, {
            "language": "en-GB",
            "text": "For the purpose of expressing consent to the processing of personal and sensitive data (art.23 and art.81 of Legislative Decree 196/2003)"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var FS1 = {
    "code": "FS-1",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Costituzione del fascicolo sanitario elettronico (FSE)"
        }, {
            "language": "en-GB",
            "text": "Establishment of the electronic health file (FSE)"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": "Il Titolare al trattamento dei dati personali necessari per lo svolgimento dell'incarico conferito, anche comunicandoli a soggetti esterni alla propria struttura qualora ciò si rendesse necessario ai fini dell'adempimento di tutto o in parte dell'incarico"
        }, {
            "language": "en-GB",
            "text": "The Owner to the processing of personal data necessary for the performance of the assignment, also communicating it to third parties outside the structure if this becomes necessary for the fulfillment of all or part of the assignment"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": "Ai fini dell'espressione del consenso al trattameno dei dati personali e sensibili (art.23 e art.81 del d.lgs.196/2003)"
        }, {
            "language": "en-GB",
            "text": "For the purpose of expressing consent to the processing of personal and sensitive data (art.23 and art.81 of Legislative Decree 196/2003)"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P4 = {
    "code": "P4",
    "ini": false,
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "CONSENSO ALLA CONSULTAZIONE DEI DATI SOGGETTI A MAGGIOR TUTELA DELL'ANONIMATO"
        }, {
            "language": "en-GB",
            "text": "CONSENT TO CONSULTATION OF VERY RESTRICTED DATA"
        }, {
            "language": "de-DE",
            "text": "ZUSTIMMUNG ZUR BERATUNG SEHR BESCHRÄNKTER DATEN"
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        },
        {
            "language": "en-GB",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P24 = {
    "code": "P24",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "CONSENSO ALLA CONSULTAZIONE DEI DATI E DEI DOCUMENTI DI NATURA CLINICA CONTENUTI NEL FASCICOLO SANITARIO ELETTRONICO (FSE) DA PARTE DEI SOGGETTI AUTORIZZATI DEL SSN"
        }, {
            "language": "en-GB",
            "text": "CONSENT TO THE CONSULTATION OF DATA AND CLINICAL DOCUMENTS CONTAINED IN THE ELECTRONIC HEALTH INSTRUMENT (ESF) BY AUTHORIZED PARTNERS OF THE SSN"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": "Il presente consenso al trattamento dei dati ha validità permanente salvo revoca e/o modifica e/o raggiungimento della maggiore età. In caso di delega alla consegna, presentarsi con delega e documento in corso di validità proprio e del  delegante (anche in copia) "
        }, {
            "language": "en-GB",
            "text": "The present consent to the processing of data has permanent validity unless revoked and / or modified and / or reached the age of majority. In case of delegation to the delivery, present yourself with a proxy and a valid document of your own and of the delegator (also in copy) "
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": "Ai fini dell'espressione del consenso al trattameno dei dati personali e sensibili (art.23 e art.81 del d.lgs.196/2003)"
        }, {
            "language": "en-GB",
            "text": "For the purpose of expressing consent to the processing of personal and sensitive data (art.23 and art.81 of Legislative Decree 196/2003)"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Not Authorized"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": true,
    "validityPeriod": NumberInt(3),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P25 = {
    "code": "P25",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "CONSENSO ALLA CONSULTAZIONE DEI DATI E DEI DOCUMENTI DI NATURA CLINICA CONTENUTI NEL  DOSSIER SANITARIO ELETTRONICO (DSE) DA PARTE DEI SOGGETTI AUTORIZZATI DEL SSN"
        }, {
            "language": "en-GB",
            "text": "CONSENT TO THE CONSULTATION OF DATA AND CLINICAL DOCUMENTS CONTAINED IN THE ELECTRONIC SANITARY DOSSIER (DSE) BY AUTHORIZED PARTNERS OF THE SSN"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": "Il presente consenso al trattamento dei dati ha validità permanente salvo revoca e/o modifica e/o raggiungimento della maggiore età. In caso di delega alla consegna, presentarsi con delega e documento in corso di validità proprio e del  delegante (anche in copia)"
        }, {
            "language": "en-GB",
            "text": "The present consent to the processing of data has permanent validity unless revoked and / or modified and / or reached the age of majority. In case of delegation to the delivery, present yourself with a proxy and a valid document of your own and of the delegator (also in copy)"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": "Ai fini dell'espressione del consenso al trattameno dei dati personali e sensibili (art.23 e art.81 del d.lgs.196/2003)"
        }, {
            "language": "en-GB",
            "text": "For the purpose of expressing consent to the processing of personal and sensitive data (art.23 and art.81 of Legislative Decree 196/2003)"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Authorized"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Not Authorized"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P26 = {
    "code": "P26",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "Oscuramento all'interno del Dossier Sanitario Elettronico dei dati relativi all'episodio indicato"
        }, {
            "language": "en-GB",
            "text": "Obscuring within the Electronic Health Dossier of the data related to the episode indicated"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": "Il presente consenso al trattamento dei dati ha validità permanente salvo revoca e/o modifica e/o raggiungimento della maggiore età. In caso di delega alla consegna, presentarsi con delega e documento in corso di validità proprio e del  delegante (anche in copia)"
        }, {
            "language": "en-GB",
            "text": "The present consent to the processing of data has permanent validity unless revoked and / or modified and / or reached the age of majority. In case of delegation to the delivery, present yourself with a proxy and a document of valid validity and of the delegator (also in copy)"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": "Con la procedura di oscuramento i referti/episodi indicati non saranno più consultabili attraverso lo strumento del Dossier Sanitario Elettronico e pertanto i clinici non avranno la possibilità di visionarli, nemmeno in caso di emergenza/urgenza"
        }, {
            "language": "en-GB",
            "text": "With the procedure of obscuring the reported reports / episodes will no longer be available through the Electronic Health Dossier and therefore clinicians will not be able to view them, not even in case of emergency / urgency"
        }, {
            "language": "de-DE",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "P",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Authorized"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "Not Authorized"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};

var P35 = {
    "code": "P35",
    "version": NumberLong(1),
    "status": "current",
    "display": [{
            "language": "it-IT",
            "text": "CONSENSO ALLA CONSULTAZIONE DEI DATI E DEI DOCUMENTI DI NATURA CLINICA CONTENUTI NEL FASCICOLO SANITARIO ELETTRONICO (FSE) DA PARTE DEI SOGGETTI AUTORIZZATI DEL SSN RELATIVAMENTE ALL'EVENTO INDICATO"
        }, {
            "language": "en-GB",
            "text": "CONSENT TO THE CONSULTATION OF DATA AND DOCUMENTS OF CLINICAL NATURE CONTAINED IN THE ELECTRONIC HEALTH INSTRUMENT (ESF) BY AUTHORIZED PARTNERS OF THE SSN RELATIVE TO THE EVENT"
        }
    ],
    "footer": [{
            "language": "it-IT",
            "text": ""
        }, {
            "language": "en-GB",
            "text": ""
        }
    ],
    "header": [{
            "language": "it-IT",
            "text": ""
        },
        {
            "language": "en-GB",
            "text": ""
        }
    ],
    "codingScheme": "AffinityDomainItaliaV1.0",
    "typescope": "E",
    "required": true,
    "consentType": "privacy",
    "activeLabel": [{
            "language": "it-IT",
            "text": "Autorizzo"
        },
        {
            "language": "en-GB",
            "text": "Authorize"
        }, {
            "language": "de-DE",
            "text": "Zugestimmt"
        }
    ],
    "rejectedLabel": [{
            "language": "it-IT",
            "text": "Non Autorizzo"
        }, {
            "language": "en-GB",
            "text": "I do not authorize"
        }, {
            "language": "de-DE",
            "text": "Abgelehnt"
        }
    ],
    "consentKind": "A",
    "expiration": false,
    "validityPeriod": NumberInt(0),
    "creationDate": ISODate("2018-04-18T00:00:00.000+0000"),
    "hideFromDate": false
};


var KPrivacy = {
    "code" : "1",
    "description" : [ {
        "language" : "it-IT",
        "text" : "Modello KPrivacy"
    }, {
        "language" : "en-GB",
        "text" : "Model KPrivacy"
    },
    {
        "language" : "de-DE",
        "text" : "Model KPrivacy" 
    } ],
    "author" : "Rossi Mario",
    "standalone" : false,
    "creationDate" : ISODate("2018-04-18T00:00:00.000+0000"),
    "consentType" : [ "privacy" ],
    "status" : "current",
    "bundles" : [ {
        "informationRegistryCode" : "1",
        "informationRegistryVersion" : NumberLong(1),
        "itemsConsent" : [ {
            "consentRegistryVersion" : NumberLong(1),
            "consentRegistryCode" : "DLGS196-03"
        }, {
            "consentRegistryCode" : "DS-1",
            "consentRegistryVersion" : NumberLong(1)
        }, {
            "consentRegistryCode" : "FS-1",
            "consentRegistryVersion" : NumberLong(1),
            "signatures" : [
                {
                    "type" : "graphometric", 
                    "who" : [
                        {
                            "language" : "it-IT", 
                            "text" : "Paziente"
                        }, 
                        {
                            "language" : "en-GB", 
                            "text" : "Patient"
                        }
                    ], 
                    "why" : [
                        {
                            "language" : "it-IT", 
                            "text" : "Firma del paziente al consenso per il Fascicolo Sanitario Elettronico"
                        }, 
                        {
                            "language" : "en-GB", 
                            "text" : "Acceptance"
                        }
                    ]
                }
            ]
        } ]
        
    } ]
};

var completeModel = {
    "code" : "2",
    "description" : [ {
        "language" : "it-IT",
        "text" : "Modello completo"
    }, {
        "language" : "en-GB",
        "text" : "Complete Model"
    },
    {
        "language" : "de-DE",
        "text" : "Complete Model" 
    } ],
    "author" : "Rossi Mario",
    "standalone" : false,
    "creationDate" : ISODate("2018-04-18T00:00:00.000+0000"),
    "consentType" : [ "privacy" ],
    "status" : "current",
    "bundles" : [ {
        "informationRegistryCode" : "1",
        "informationRegistryVersion" : NumberLong(1),
        "itemsConsent" : [ {
            "consentRegistryCode" : "P24",
            "consentRegistryVersion" : NumberLong(1)
        }, {
            "consentRegistryCode" : "P25",
            "consentRegistryVersion" : NumberLong(1),
            "signatures" : [
                {
                    "type" : "graphometric", 
                    "who" : [
                        {
                            "language" : "it-IT", 
                            "text" : "Paziente"
                        }, 
                        {
                            "language" : "en-GB", 
                            "text" : "Patient"
                        }
                    ], 
                    "why" : [
                        {
                            "language" : "it-IT", 
                            "text" : "Firma del paziente al consenso per il Fascicolo Sanitario Elettronico"
                        }, 
                        {
                            "language" : "en-GB", 
                            "text" : "Acceptance"
                        }
                    ]
                }
            ]
        } ]
    }, {
        "informationRegistryCode" : "2",
        "informationRegistrVersion" : NumberLong(1),
        "itemsConsent" : [ {
            "consentRegistryCode" : "P26",
            "consentRegistryVersion" : NumberLong(1),
            "signatures" : [
                {
                    "type" : "graphometric", 
                    "who" : [
                        {
                            "language" : "it-IT", 
                            "text" : "Paziente"
                        }, 
                        {
                            "language" : "en-GB", 
                            "text" : "Patient"
                        }
                    ], 
                    "why" : [
                        {
                            "language" : "it-IT", 
                            "text" : "Firma del paziente al consenso per il Fascicolo Sanitario Elettronico"
                        }, 
                        {
                            "language" : "en-GB", 
                            "text" : "Acceptance"
                        }
                    ]
                }
            ]
        } ],
        
    } ]
};
