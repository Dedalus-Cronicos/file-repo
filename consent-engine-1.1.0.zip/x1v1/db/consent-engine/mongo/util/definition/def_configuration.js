var consentTypeCode = {
    key : "consentTypeCode",
    value : "59284-0"
};

var eventConsentTypeCode = {
    key : "eventConsentTypeCode",
    value : "consent002"
};

var supplyConsent = {
    key : "supplyConsent",
    value : "P1"
};

var dateFormat = {
    key : "dateFormat",
    value : "yyyy-MM-dd"
};

var message4EmptyValueCode = {
    key : "message4EmptyValueCode",
    value : "empty"
};

var periodEndDate = {
    key : "periodEndDate",
    value : new Date('2099-12-31T22:59:59.000Z')
};

var consentModelDefault = {
    key : "consentModelDefault",
    value : "1"
};

var affinityDomainFileUrl = {
    key : "affinityDomainFileUrl",
    value : "file://@affinitydomainpath@codes.xml"
};

var peopleIntegration = {
    key : "peopleIntegration",
    value : {
        "status" : false,
        "url" : "http://@mpi@@domain.internal.mpi@@mpi_context@"
    }
};

var domainIdentifier = {
    key : "domainIdentifier",
    value : "2.16.840.1.113883.2.9.3.12.4.1"
};

var informationDefault = {
    key : "informationDefault",
    value : "1"
};

var jmsConfig = {
    key : "jmsConfig",
    value : {
        "JMSSessionCacheSize" : "10",
        "JMSBrokerURL" : "@activemq.broker.url@",
        "destinations" : "consentQueue",
        "jmsEnabled" : true
    }
};

var roleDefault = {
    key : "roleDefault",
    value : "X1V1_MEDICO"
};

var registryDatasourceConfiguration = {
    key : "registryDatasourceConfiguration",
    value : {
        "driver-url" : "@mpi.oradb.conn.string@",
        "driver-class" : "@mpi.oradb.driver@",
        "user" : "@mpi.oradb.user@",
        "password" : "@mpi.oradb.password@",
        "active" : false
    }
};

var registryPatientCountQuery = {
    key : "registryPatientCountQuery",
    value : "SELECT COUNT(*) FROM MPI_CODE WHERE ID_PATIENT = ? AND REPLACE(NAMESPACE, 'urn:oid:', '') = REPLACE(?, 'urn:oid:', '')"
};

var iniIntegration = { 
    "key" : "iniIntegration", 
    "value" : {
        "url": "@domain.public.esb.protocol@://@esb@@domain.public.esb@@esb.context@@picasso.channel.read.ini.information@/DisclosureManager_Service/",
        "regionId" : ""
    }
};

var installedLangs = {
    key : "installedLangs",
    value : [ "en-GB", "it-IT" ,"de-DE"]
};

var defaultLang = {
	    key : "defaultLang",
	    value : "it-IT"
	};

var enumCXiTypeLabel = { 
    "key" : "enumCXiTypeLabel", 
    "value" : {
        "items" : {
            "urn:eu:dedalus:x1v1:2015:nosological" : [
                {
                    "language" : "it-IT", 
                    "text" : "Nosologico"
                }, 
                {
                    "language" : "en-GB", 
                    "text" : "Nosological"
                }, 
                {
                    "language" : "de-DE", 
                    "text" : "Nosologische nummer"
                }
            ], 
            "urn:eu:dedalus:x1v1:2015:emergency" : [
                {
                    "language" : "it-IT", 
                    "text" : "Pronto Soccorso"
                }, 
                {
                    "language" : "en-GB", 
                    "text" : "Emergency"
                }, 
                {
                    "language" : "de-DE", 
                    "text" : "Notfall"
                }
            ], 
            "urn:eu:dedalus:x1v1:2015:uniqueId" : [
                {
                    "language" : "it-IT", 
                    "text" : "ID Univoco"
                }, 
                {
                    "language" : "en-GB", 
                    "text" : "Unique ID"
                }, 
                {
                    "language" : "de-DE", 
                    "text" : "Kennung"
                }
            ], 
            "urn:eu:dedalus:x1v1:2015:workflowId" : [
                {
                    "language" : "it-IT", 
                    "text" : "ID Workflow"
                }, 
                {
                    "language" : "en-GB", 
                    "text" : "Workflow ID"
                }, 
                {
                    "language" : "de-DE", 
                    "text" : "Workflow-ID"
                }
            ], 
            "urn:eu:dedalus:x1v1:2015:order" : [
                {
                    "language" : "it-IT", 
                    "text" : "Order"
                }, 
                {
                    "language" : "en-GB", 
                    "text" : "Order"
                }, 
                {
                    "language" : "de-DE", 
                    "text" : "Order"
                }
            ], 
            "urn:eu:dedalus:x1v1:2015:accession" : [
                {
                    "language" : "it-IT", 
                    "text" : "Accession"
                }, 
                {
                    "language" : "en-GB", 
                    "text" : "Accession"
                }, 
                {
                    "language" : "de-DE", 
                    "text" : "Accession"
                }
            ], 
            "urn:eu:dedalus:x1v1:2015:referral" : [
                {
                    "language" : "it-IT", 
                    "text" : "Referral"
                }, 
                {
                    "language" : "en-GB", 
                    "text" : "Referral"
                }, 
                {
                    "language" : "de-DE", 
                    "text" : "Referral"
                }
            ], 
            "urn:eu:dedalus:x1v1:2015:encounterId" : [
                {
                    "language" : "it-IT", 
                    "text" : "ID Visita"
                }, 
                {
                    "language" : "en-GB", 
                    "text" : "Encounter ID"
                }, 
                {
                    "language" : "de-DE", 
                    "text" : "Besuchs-ID"
                }
            ]
        }
    }
};

var enumPdfTranslations = {
    key : "enumPdfTranslations",
    value : {
        "items" : {
            "UNDERSIGNED_TEXT" : [
                    {
                        "language" : "it-IT",
                        "text" : "Io sottoscritto (nome e cognome) ............................................................................................................................"
                    },
                    {
                        "language" : "en-GB",
                        "text" : "I, the undersigned, (fullname) .............................................................................................................................."
                    } ,
                    {
                        "language" : "de-DE",
                        "text" : "Ich, der Unterzeichnete, (vollständiger Name) ..............................................................................................................."
                    }],
            "BIRTHDATE_TEXT" : [
                    {
                        "language" : "it-IT",
                        "text" : "nato il ..............................  con codice fiscale ............................................................................................................"
                    },
                    {
                        "language" : "en-GB",
                        "text" : "born on ..............................  with tax code ................................................................................................................."
                    } ,
                    {
                        "language" : "de-DE",
                        "text" : "geboren am ............................ mit Steuernummer ..............................................................................................................."
                    } ],
            "GUARDIAN_TEXT" : [
                    {
                        "language" : "it-IT",
                        "text" : "in qualita' di ............................................................................................................................................................."
                    },
                    {
                        "language" : "en-GB",
                        "text" : "as ........................................................................................................................................................................."
                    } ,
                    {
                        "language" : "de-DE",
                        "text" : "in Qualität von ............................................................................................................................................................"
                    } ],
            "GUARDIAN_PATIENT_TEXT" : [
                    {
                        "language" : "it-IT",
                        "text" : "di (nome e cognome) .............................................................................................................................................."
                    },
                    {
                        "language" : "en-GB",
                        "text" : "of (fullname) ...................................................................................................................................................."
                    }  ,
                    {
                        "language" : "de-DE",
                        "text" : "von (vollständiger Name).........................................................................................................................................."
                    }],
            "MYSELF_TEXT" : [ {
                "language" : "it-IT",
                "text" : "per me:"
            }, {
                "language" : "en-GB",
                "text" : "for myself:"
            } ,
            {
                "language" : "de-DE",
                "text" : "für mich"
            } ],
            "SIGNATURE_TEXT" : [ {
                "language" : "it-IT",
                "text" : "Data: ........................      Firma: ...................................................................."
            }, {
                "language" : "en-GB",
                "text" : "Date: ........................  Signature: ...................................................................."
            },
            {
                "language" : "de-DE",
                "text" : "Datum:.......................Unterschrift: ...................................................................."
            }  ],
            "PAGEOF_TEXT" : [ {
                "language" : "it-IT",
                "text" : "Pagine %s di %s"
            }, {
                "language" : "en-GB",
                "text" : "Page %s of %s"
            },
            {
                "language" : "de-DE",
                "text" : "Seite %s von %s"
            }  ],
            "EVENT_TEXT" : [ {
                "language" : "it-IT",
                "text" : "Relativo all'evento"
            }, {
                "language" : "en-GB",
                "text" : "Related event"
            },
            {
                "language" : "de-DE",
                "text" : "Zugehöriges Ereignis"
            }  ],
            "DOCUMENT_TEXT" : [ {
                "language" : "it-IT",
                "text" : "Relativo al documento"
            }, {
                "language" : "en-GB",
                "text" : "Related document"
            } ,
            {
                "language" : "de-DE",
                "text" : "Zugehöriges Dokument"
            } ],
            "DATEFROM_TEXT" : [ {
                "language" : "it-IT",
                "text" : "Valido dal %s"
            }, {
                "language" : "en-GB",
                "text" : "Valid from %s"
            },
            {
                "language" : "de-DE",
                "text" : "Gültig von %s"
            }  ],
            "DATEFROMTO_TEXT" : [ {
                "language" : "it-IT",
                "text" : "Valido dal %s al %s"
            }, {
                "language" : "en-GB",
                "text" : "Valid from %s to %s"
            },
            {
                "language" : "de-DE",
                "text" : "Gültig von %s bis %s"
            }  ]
        }
    }
};

var enumGuardianRole = {
    key : "enumGuardianRole",
    value : {
        "items" : {
            "GUARD" : [ {
                "language" : "it-IT",
                "text" : "Tutore legale"
            }, {
                "language" : "en-GB",
                "text" : "Tutor"
            }, {
                "language" : "de-DE",
                "text" : "Tutor"
            } ],
            "PRN" : [ {
                "language" : "it-IT",
                "text" : "Genitore"
            }, {
                "language" : "en-GB",
                "text" : "Parent"
            }, {
                "language" : "de-DE",
                "text" : "Elternteil"
            } ],
            "FTH" : [ {
                "language" : "it-IT",
                "text" : "Padre"
            }, {
                "language" : "en-GB",
                "text" : "Father"
            }, {
                "language" : "de-DE",
                "text" : "Vater"
            } ],
            "MTH" : [ {
                "language" : "it-IT",
                "text" : "Madre"
            }, {
                "language" : "en-GB",
                "text" : "Mother"
            }, {
                "language" : "de-DE",
                "text" : "Mutter"
            } ],
            "RESPRSN" : [ {
                "language" : "it-IT",
                "text" : "Delegato"
            }, {
                "language" : "en-GB",
                "text" : "Responsible party"
            }, {
                "language" : "de-DE",
                "text" : "Delegierte"
            } ],
            "CHILD" : [ {
                "language" : "it-IT",
                "text" : "Figlio/a"
            }, {
                "language" : "en-GB",
                "text" : "Child"
            }, {
                "language" : "de-DE",
                "text" : "Sohn/Tochter"
            } ],
            "DOMPART" : [ {
                "language" : "it-IT",
                "text" : "Convivente"
            }, {
                "language" : "en-GB",
                "text" : "Domestic partner"
            }, {
                "language" : "de-DE",
                "text" : "Lebenspartner"
            } ],
            "FAMMEMB" : [ {
                "language" : "it-IT",
                "text" : "Familiare"
            }, {
                "language" : "en-GB",
                "text" : "Family member"
            }, {
                "language" : "de-DE",
                "text" : "Familienmitglied"
            }],
            "NOK" : [ {
                "language" : "it-IT",
                "text" : "Prossimo congiunto"
            }, {
                "language" : "en-GB",
                "text" : "Next of kin"
            }, {
                "language" : "de-DE",
                "text" : "Nächste Verwandte"
            } ],
            "DICH" : [ {
                "language" : "it-IT",
                "text" : "Interessato"
            }, {
                "language" : "en-GB",
                "text" : "Interested party"
            }, {
                "language" : "de-DE",
                "text" : "Interessent"
            } ]
        }
    }
};

var processingHandler = {
    key : "processingHandler",
    value : {
        "readProcessHandler" : {
            "preprocess" : {
                "enabled" : false,
                "implementationClasses" : [],
                "cuncurrentexecution" : true,
                "coreThreadNumber" : 1,
                "maxThreadNumber" : 1
            },
            "postprocess" : {
                "enabled" : false,
                "implementationClasses" : [],
                "cuncurrentexecution" : true,
                "coreThreadNumber" : 1,
                "maxThreadNumber" : 1
            }
        },
        "writeBundleProcessHandler" : {
            "postprocess" : {
                "enabled" : true,
                "implementationClasses" : [ "eu.dedalus.xvalue.consentengine.process.post.impl.registry.RegistryUpdater" ],
                "cuncurrentexecution" : false
            }
        },
        "writeProcessHandler" : {
            "postprocess" : {
                "enabled" : false,
                "implementationClasses" : [ "eu.dedalus.xvalue.consentengine.process.post.impl.QueuingConsents" ],
                "cuncurrentexecution" : false
            }
        },
        "infocertStartWorkflowProcessHandler" : {
            "postprocess" : {
                "enabled" : false,
                "implementationClasses" : [ "eu.dedalus.xvalue.consentengine.process.post.impl.InfocertStartWorkflowProcess" ],
                "cuncurrentexecution" : false
            }
        },
        "infocertGetFileWorkflowProcessHandler" : {
            "postprocess" : {
                "enabled" : false,
                "implementationClasses" : [ "eu.dedalus.xvalue.consentengine.process.post.impl.InfocertGetFileWorkflowProcess" ],
                "cuncurrentexecution" : false
            }
        },
        "jobHandler" : {
            "enabled" : false,
            "jobsDetail" : [ {
                "enabled" : false,
                "implementationClass" : "",
                "threadNumber" : 1,
                "startDelayInMillis" : 60000,
                "repeatIntervalInMillis" : 60000,
                "configuration" : {
                    "method" : "POST",
                    "url" : ""
                }
            } ]
        }
    }
};

var defaultTemplates = {
	    key : "defaultTemplates",
	    value : [
	    	{
	    		"language": "en-GB",
	    		"bundleTemplatePathname": "/Bundle_en-GB.jrxml",
	    		"blockTemplatePathname": "/Block_en-GB.jrxml"
	    	},
	    	{
	    		"language": "it-IT",
	    		"bundleTemplatePathname": "/Bundle_it-IT.jrxml",
	    		"blockTemplatePathname": "/Block_it-IT.jrxml"
	    	},
	    	{
	    		"language": "de-DE",
	    		"bundleTemplatePathname": "/Bundle_de-DE.jrxml",
	    		"blockTemplatePathname": "/Block_de-DE.jrxml"
	    	}
	    ]
	};

var autoSignatureType = {
		key: 'autoSignatureType',
		value: 'consent'
};


var internalConsentPath = {
		key: 'internalConsentPath',
		value: 'http://@consent@@domain.internal.xds@/consent-engine/consent/100'
};


var consentCollectorConfig = {
    key : "consentCollectorConfig",
    value : {
        "storage" : "session",
        "auth" : {
            "method" : "ds",
            "url" : "@domain.public.protocol@://@ds@@domain.public@/xdiscovery-service"

        },
        "tutorVisibilityFlag" : "false",
        "guardianVisibilityFlag" : "false",
        "consent100Web" : "http://@consent@@domain.internal.xds@",
        "consent100Public" : "@domain.public.protocol@://@consent@@domain.public@",
        "consent100SubPath":"/consent-engine/consent/100",
        "showHistory": "true",
        "showPrintBundle": "false",
        "toolbarPosition": "bottom",
        "downloadFile":"true",
        "environmentLinks" : {
            "backUrl" : "",
            "profile" : "",
            "civicNetwork" : ""
        }
    }
};

var pathFhirConsentSaving = {
        key: 'pathFhirConsentSaving',
        value: '/home/xds/temp/consentFhir/'
};


var fseTemplateConfig = { 
    "key" : "fseTemplateConfig", 
    "value" : {
        "custodianRoot": "2.16.840.1.113883.2.9.4.1.1",
        "custodianCode" : "100902",
        "custodianDisplay" : "Ministero della Salute",
        "uriXsl" : "https://localhost/xsl/prescrizione_v1.xsl"
    }
};

var tutorPeriodEndDate = {
	key : "tutorPeriodEndDate",
	value : new Date('2099-12-31T22:59:59.000Z')
}

var externalConsentManagerConfiguration = { 
    "key" : "externalConsentManagerConfiguration", 
    "value": {
        "consentManagerEndpoint": "https://hostname/raccoltaConsensiCall/verificaConsensi",
        "authorizationEndpoint": "http://hostname/TokenService/Handler",
        "appID": "urn:uuid:9d6481ac-ec29-4767-a53d-58a9abde1583"
    }
};

var taxCodeIdentifier = {
    key : "taxCodeIdentifier",
    value : "2.16.840.1.113883.2.9.4.3.2"
};

var infocertIntegration = { 
       
        "key" : "infocertIntegration", 
        "value" : {
            "active" : false, 
            "endpoint": "https://testdev.proxysign.it/",
            "graphometric": "grapho/",
            "startWorkflow": "rest/request/startworkflow",
            "statusWorkflow": "rest/request/status/",
            "getFile": "rest/request/getpdffile/",
            "stopWorkflow": "rest/request/stopworkflow/",
            "username" : "koelid", 
            "password" : "koelidpwd",
            "timeout": NumberInt(600000), 
            "clientPollingInterval" : NumberInt(6000),
            "patientSignLabel" : [
                {
                    "language" : "it-IT", 
                    "text" : "Paziente"
                }, 
                {
                    "language" : "en-GB", 
                    "text" : "Patient"
                }, 
                {
                    "language" : "de-DE", 
                    "text" : "Patient"
                }
            ]
        }
    };

var reportDataConfiguration = { 
    "key": "reportDataConfiguration",
    "value": {
        "active": false,
        "url": "http://sample.com",
        "throwErrors": true,
        "connectionTimeout": 30000,
        "requestTimeout": 30000,
        "socketTimeout": 60000
    }
};

var applications = {
    key : "applications",
    value : [
            {
                name : "default",
                enableConsentDomain : false,
                consentsDomain : [ "P1", "P2", "P3", "P4", "P5", "P6", "P7", "P8", "P9", "P10", "P11", "P12", "P13", "P14", "P15", "P16", "P17", "P20", "P21", "P22", "P23", "P24",
                        "P25", "P26", "P27", "P28", "P29", "P30", "P31", "P32", "P33", "P34", "P35", "P80", "P95", "P96", "P97", "P98", "P99", "2.16.840.1.113883.2.9.10.2.4.13.1",
                        "2.16.840.1.113883.2.9.10.2.4.13.2", "2.16.840.1.113883.2.9.10.2.4.13.3", "2.16.840.1.113883.2.9.10.2.4.13.4", "2.16.840.1.113883.2.9.10.2.4.13.5",
                        "2.16.840.1.113883.2.9.10.2.4.13.8", "2.16.840.1.113883.2.9.10.2.4.13.9", "2.16.840.1.113883.2.9.10.2.4.13.10", "2.16.840.1.113883.2.9.10.2.4.13.11",
                        "2.16.840.1.113883.2.9.10.2.4.13.12", "2.16.840.1.113883.2.9.10.2.4.13.99", "2.16.840.1.113883.2.9.2.100.RAMO_OID_CODIFICHE_PRIVACY.0",
                        "2.16.840.1.113883.2.9.2.100.RAMO_OID_CODIFICHE_PRIVACY.98", "2.16.840.1.113883.2.9.2.100.RAMO_OID_CODIFICHE_FLUSSO.0", "DLGS196-03", "FS-1", "DS-1", "B1",
                        "A1", "A2", "C1", "C2", "C3" ]
            }, {
                name : "viewer",
                enableConsentDomain : false
            }, {
                name : "guest",
                enableConsentDomain : false
            } ]
};

var quartzConfig = { 
    "key" : "quartzConfig", 
    "value" : {       
        "InfocertJob" : {
            "active" : false, 
            "startDelay" : NumberInt(3000), 
            "repeatInterval" : NumberInt(3000), 
            "redeliveryInterval" : NumberInt(600000), 
            "maxRedeliveries" : NumberInt(5)
        }
    }
};

var subscriberCodes = {
	    key : "subscriberCodes",
	    value : ["consentAudit", "consentPeople", "consentSTU3"]
	};


var personInfo = { 

    "key" : "personInfo", 
    "value" : {
        "name" : {
            "visible" : true, 
            "mandatory" : true
        }, 
        "lastname" : {
            "visible" : true, 
            "mandatory" : true
        }, 
        "gender" : {
            "visible" : true, 
            "mandatory" : true
        }, 
        "birthDate" : {
            "visible" : true, 
            "mandatory" : true
        }, 
        "taxcode" : {
            "visible" : true, 
            "mandatory" : false
        }
    }
};

var gatewayActive = {
        "key": "gatewayActive",
        "value": false
};
var proxyConfig = {
    "key" : "proxyConfig", 
    "value" : {
		 "proxyConfigurationMapper" : {
	       "people-fhir" : {
	    	   "url" : "@domain.public.protocol@://@mpi@@domain.public@@mpi.context@",
	           "urlApiGateway" : "@domain.public.protocol@://@mpi@@domain.public@/dc4h/people.fhir/fhir/", 
	          
	           "clientType" : "fhir", 
	           "useToken" : true, 
	           "headers" : {
	               "headersDefault" : {
	
	               }, 
	               "headersGet" : {
	
	               }, 
	               "headersPost" : {
	
	               }, 
	               "headersPut" : {
	
	               }, 
	               "headersDelete" : {
	
	               }
	           }
	       }, 
	       "people-rest" : {
	           "url" : "@domain.public.protocol@://@mpi@@domain.public@/people.fhir/rest/", 
	           "urlApiGateway" : "@domain.public.protocol@://@mpi@@domain.public@/dc4h/people.fhir/rest/", 
	           "clientType" : "fhir", 
	           "useToken" : true, 
	           "headers" : {
	               "headersDefault" : {
	
	               }, 
	               "headersGet" : {
	
	               }, 
	               "headersPost" : {
	
	               }, 
	               "headersPut" : {
	
	               }, 
	               "headersDelete" : {
	
	               }
	           }
	       }, 
	       "x1v1-fhir-clinical" : {
	           "url" : "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/", 
	           "urlApiGateway" : "@domain.public.protocol@://@fhir@@domain.public@/dc4h/x1v1-fhir-clinical/fhir/", 
	           "responseType" : "fhir", 
	           "useToken" : true, 
	           "headers" : {
	               "headersDefault" : {
	                   "Content-Type" : "application/json"
	               }, 
	               "headersGet" : {
	
	               }, 
	               "headersPost" : {
	
	               }, 
	               "headersPut" : {
	
	               }, 
	               "headersDelete" : {
	
	               }
	           }
	       }, 
	       "x1v1-mhd-fhir" : {
	           "url" : "@domain.public.protocol@://@xds@@domain.public@/x1v1-mhd-fhir/", 
	           "urlApiGateway" : "@domain.public.protocol@://@xds@@domain.public@/dc4h/x1v1-mhd-fhir/", 
	           "clientType" : "fhir", 
	           "useToken" : true, 
	           "headers" : {
	               "headersDefault" : {
	                   "Cache-Control" : "no-cache", 
	                   "Pragma" : "no-cache", 
	                   "Expires" : "0"
	               }, 
	               "headersGet" : {
	
	               }, 
	               "headersPost" : {
	
	               }, 
	               "headersPut" : {
	
	               }, 
	               "headersDelete" : {
	
	               }
	           }
	       }, 
	       "x1v1-fhir-terminology" : {
	           "url" : "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/", 
	           "urlApiGateway" : "@domain.public.protocol@://@fhir@@domain.public@/dc4h/x1v1-fhir-clinical/fhir/", 
	           "clientType" : "fhir", 
	           "useToken" : true, 
	           "headers" : {
	               "headersDefault" : {
	
	               }, 
	               "headersGet" : {
	
	               }, 
	               "headersPost" : {
	
	               }, 
	               "headersPut" : {
	
	               }, 
	               "headersDelete" : {
	
	               }
	           }
	       }
	   }
   }
}




