db.configuration.insert(proxyConfig);
db.configuration.insert(gatewayActive);
db.configuration.remove({key : "registryDatasourceConfiguration"});
db.configuration.insert(registryDatasourceConfiguration);