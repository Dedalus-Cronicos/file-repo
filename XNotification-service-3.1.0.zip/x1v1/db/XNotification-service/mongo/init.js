//mongo admin -u admin -p x1v1mdb --authenticationDatabase admin;

db = db.getSiblingDB("@arr.fhir.mongodb.name@");
db.createUser({ user: "@arr.fhir.mongodb.user@",
  pwd: "@arr.fhir.mongodb.password@",
  roles: [
    { role: "readWrite", db: "@arr.fhir.mongodb.name@"}
  ]
});