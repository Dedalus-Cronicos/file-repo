db.createCollection('notifications');

db.notifications.createIndex( { 'user' : 1, 'notificType': 1 } , { sparse: true, name: 'notifTypeIndex'});


var templateFiles = listFiles('templates')
var seq, id, tot;
var insertDateString;
var dateString;
var longDateString;
for (var index = 0; index < templateFiles.length; index++ ) {
    var template = cat(templateFiles[index].name);
    var templateJson = JSON.parse(template)
    var templateType = templateJson.templateType;
    
	var currentDate = new Date();
    print(currentDate);
    
	var month = currentDate.getMonth() + 1;
	var monthString = month.toString();
	if (monthString.length == 1) {
		monthString =  '0' + monthString;
	}
	
	var day = currentDate.getDate();
	var dayString = day.toString();
	if (dayString.length == 1) {
		dayString =  '0' + dayString;
	}
	
	
	
	var hour = currentDate.getHours();
	var hourString = hour.toString();
	if (hourString.length == 1) {
		hourString =  '0' + hourString;
	}
	
	var minutes = currentDate.getMinutes();
	var minutesString = minutes.toString();
	if (minutesString.length == 1) {
		minutesString = '0' + minutesString;
	}
	
	var seconds = currentDate.getSeconds();
	var secondsString = seconds.toString();
	if (secondsString.length == 1) {
		secondsString = '0' + secondsString;
	}
	
	
	var millesString = '00' + index; 
	
	insertDateString =  currentDate.getFullYear()  + monthString+ dayString + hourString + minutesString + secondsString+ millesString;
	print('insertDateString: ' + insertDateString);
    longDateString = currentDate.getFullYear() + '' + monthString+ dayString + '000000';
	print('longDateString: ' + longDateString);
	dateString = currentDate.getFullYear() + '-'+ monthString + '-' + dayString ;
	print('dateString: ' + dateString);
    
	id = insertDateString;
	templateJson._id = id;
	templateJson.id = id;
	
	templateJson.insertDateLong = NumberLong (longDateString);
	templateJson.insertDate = dateString;
	
	db.getCollection('templates').remove({'templateType': templateType});
	
    db.templates.insert(templateJson)
    
}
  
    
    
