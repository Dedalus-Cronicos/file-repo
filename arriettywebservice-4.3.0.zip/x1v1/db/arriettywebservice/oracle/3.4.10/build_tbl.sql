-- &1 USER 
-- &2 TABLES' TABLESPACE 
-- &3 INDEXES' TABLESPACE 
-- &4 LOBS' TABLESPACE 
 
spool build_tbl.log 
 
prompt Creating Tables... 
@tables/tables.sql &1 &2 &3 &4; 
 
spool off 
 
quit 
