-- &1 USER 
-- &2 TABLES' TABLESPACE 
-- &3 INDEXES' TABLESPACE 
-- &4 LOBS' TABLESPACE 

spool build_rem.log 

prompt Creating Constraints Not Foreign Key...
@constraints/constraints_nofk.sql &1 &2 &3 &4;

--prompt Creating Constraints Foreign Key...
--@constraints/constraints_fk.sql &1 &2 &3 &4;

--prompt Creating Indexes...
--@indexes/indexes.sql &1 &2 &3 &4;

--prompt Creating Sequences...
--@sequences/sequences.sql &1 &2 &3 &4;

--prompt Creating Views...
--@views/views.sql &1 &2 &3 &4;

--prompt Creating Triggers...
--@triggers/triggers.sql &1 &2 &3 &4;

spool off 

quit 
