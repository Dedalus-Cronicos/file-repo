//mongo admin -u admin -p x1v1mdb --authenticationDatabase admin;

db = db.getSiblingDB("@arrietty.mongodb.name@");
db.createUser({ user: "@arrietty.mongodb.user@",
  pwd: "@arrietty.mongodb.password@",
  roles: [
    { role: "readWrite", db: "@arrietty.mongodb.name@"}
  ]
});
