//COLLECTION
db.createCollection('documentRead');

//INDICI 
db.documentRead.ensureIndex({'username': 1, 'uniqueId': 1}, { sparse: false,  name: 'documentReadIndex'});