db.createCollection('arrietty_docsyn');
db.arrietty_docsyn.ensureIndex({'entryUUID': 1 }, { sparse: true,  name: 'docSynEntryUUIDIndex'});

