db.arrietty_dwh_notify.drop();

db.createCollection('arrietty_notify');
db.arrietty_notify.ensureIndex({'name': 1, 'state': 1, 'retryCount': 1, 'insertDate': 1 }, { sparse: true,  name: 'notifyIndex'});

db.createCollection('mongo2oracle');
db.mongo2oracle.ensureIndex({'elaborato': 1}, {name: 'orIndex'});
db.mongo2oracle.ensureIndex({'dataInserimento': 1 , 'elaborato': 1}, {name: 'orDtIndex'});