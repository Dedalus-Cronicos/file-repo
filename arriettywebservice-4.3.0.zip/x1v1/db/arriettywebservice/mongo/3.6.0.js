
var submissions = db.submission.find({'RegistryObjectList.ExtrinsicObject.status': 'urn:oasis:names:tc:ebxml-regrep:StatusType:Deprecated'});
var currDoc;
var tmp;
var countUpdate = 0;
var sub_id;
var uuid;
var eos;
var eo;
var ownerSub;
print("begin MetadataLevel conversion");
while (submissions.hasNext()) {
	currDoc = submissions.next();
	
	if ( currDoc.RegistryObjectList) {
		eos = currDoc.RegistryObjectList.ExtrinsicObject;
		sub_id = currDoc._id;
		for (var i = 0; i < eos.length; i++) {
			eo = eos[i];
			ownerSub = db.submission.find({'RegistryObjectList.ExtrinsicObject': {$elemMatch: {'lid': eo.id,
			    'id': {$ne: eo.id}
		    }}});
			if (ownerSub.hasNext()) {
				if (countUpdate == 0) {
					subBulk = db.submission.initializeUnorderedBulkOp();
				}
				print('UPDATE EO ID: ' + eo.id);
				subBulk.find({
					'RegistryObjectList.ExtrinsicObject.id': eo.id
				}).update({
					$set : {
						'RegistryObjectList.ExtrinsicObject.$.deprecatedByMU' : true
					}
				});
				countUpdate = countUpdate + 1;
				if (countUpdate >= 500) {
					subBulk.execute();
					countUpdate = 0;
				}
			}
		}
	}
}
if (countUpdate > 0) {
	subBulk.execute();
	countUpdate = 0;
}

print("end MetadataLevel conversion");