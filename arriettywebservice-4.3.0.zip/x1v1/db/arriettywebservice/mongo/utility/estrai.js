
var submissions = db.submission.find({});
var currDoc;
var sub_id;
var dwhDoc;
print("begin");
while (submissions.hasNext()) {
	currDoc = submissions.next();
	sub_id = currDoc._id;
	dwhDoc = {
			  idSub : sub_id,
			  name : "DatawareHouse",
			  insertDate : new Date(),
			  status : 0,
			  error : "",
			  retryCount : 0,
			  operationType : "INSERT"
			
	};
	
	db.arrietty_notify.insert(dwhDoc); 

}
print("end ");
