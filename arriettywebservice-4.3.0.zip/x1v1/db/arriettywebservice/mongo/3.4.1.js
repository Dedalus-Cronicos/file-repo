//COLLECTION
db.createCollection('submission');
db.createCollection('patients');
db.createCollection('notifiers');
db.createCollection('arrietty_dwh_notify');
db.createCollection('arrietty_dwh');
db.createCollection('ARRIETTY_TRANSACTION');

//SOLO PER LO SHARDING
//db.submission.ensureIndex({'patId' : 'hashed'}, {name: 'patIdIndex'});
//sh.shardCollection("arrietty.submission", {'patId': 'hashed'});


//db.createCollection('submissionUUIDS');
//INDICI 

db.ARRIETTY_TRANSACTION.ensureIndex({'transLock': 1 }, { sparse: false,  name: 'transactionLockIndex'});

//arrietty_dwh_notify
db.arrietty_dwh_notify.ensureIndex({'state': 1, 'retryCount': 1, 'insertDate': 1 }, { sparse: true,  name: 'dwhNotifyIndex'});
db.arrietty_dwh.ensureIndex({'entryUUID': 1 }, { sparse: true,  name: 'dwhEntryUUIDIndex'});

//PATIENTS
db.patients.ensureIndex({'patId' : 1}, {name: 'PatientPatIDIndex'});
//NOTIFIERS
db.notifiers.ensureIndex({'error': 1, 'attemptNum' : 1}, { sparse: true,  name: 'notifiersErrorIndex'});
//SUBMISSION

// Eliminata l'univocita' per lo sharding
//db.submission.ensureIndex({'RegistryObjectList.ExtrinsicObject.id' : 1},{sparse: true, 'unique': true, name : 'ExtrinsicObjectidIndex'});
//db.submission.ensureIndex({'RegistryObjectList.RegistryPackage.id' : 1},{'unique': true, name: 'RegistryPackageidIndex'});
db.submission.ensureIndex({'RegistryObjectList.ExtrinsicObject.id' : 1},{sparse: true, name : 'ExtrinsicObjectidIndex'});
db.submission.ensureIndex({'RegistryObjectList.RegistryPackage.id' : 1},{name: 'RegistryPackageidIndex'});
db.submission.ensureIndex({'RegistryObjectList.RegistryPackage.ExternalIdentifier.value': 1,
'RegistryObjectList.RegistryPackage.ExternalIdentifier.identificationScheme': 1}, {name: 'RegistryPackageExtidIndex'});
db.submission.ensureIndex({'RegistryObjectList.Association.targetObject': 1}, {sparse: true, name : 'AssociationTargetIndex'});
db.submission.ensureIndex({'RegistryObjectList.Association.sourceObject': 1}, {sparse: true, name : 'AssociationSourceIndex'});
db.submission.ensureIndex({'RegistryObjectList.Classification.classificationNode': 1, 'RegistryObjectList.Classification.classifiedObject': 1}, {sparse: true, name : 'ClassificationIndex'});
db.submission.ensureIndex({'uuids': 1}, {sparse: true, name : 'UUIDSIndex'});
db.submission.ensureIndex({'RegistryObjectList.ExtrinsicObject.ExternalIdentifier.value' : 1,'RegistryObjectList.ExtrinsicObject.ExternalIdentifier.identificationScheme': 1}, { sparse: true, name: 'ExtrinsicObjectExtIdIndex'});
db.submission.ensureIndex({'RegistryObjectList.insertTime': 1}, { name: 'insertDtIndex'});
db.submission.ensureIndex({'pendingTransactions': 1}, { sparse: true,  name: 'pendingTransactionsIndex'});
db.submission.ensureIndex({'patId': 1,'referenceIdList.refIds':1}, {sparse: true, name : 'refIdsIndex'});
db.submission.ensureIndex({'RegistryObjectList.Association.id': 1}, {sparse: true, name : 'AssociationIdIndex'});
db.submission.ensureIndex({'RegistryObjectList.ExtrinsicObject.lid' : 1},{sparse: true, 'unique': false, name : 'ExtrinsicObjectLidIndex'});
db.submission.ensureIndex({'RegistryObjectList.RegistryPackage.lid' : 1},{'unique': false, name: 'RegistryPackageLidIndex'}); 