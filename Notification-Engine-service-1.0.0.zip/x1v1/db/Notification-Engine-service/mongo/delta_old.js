//mongo 127.0.0.1:27017/pm-web -u pm-web -p pm-web < delta.js
var tag = "x1v1-arr";

function compareVersions(v1, v2, options) {
    var lexicographical = options && options.lexicographical,
        zeroExtend = options && options.zeroExtend,
        v1parts = v1.split('.'),
        v2parts = v2.split('.');
    function isValidPart(x) {
        return (lexicographical ? /^\d+[A-Za-z]*$/ : /^\d+$/).test(x);
    }
    if (!v1parts.every(isValidPart) || !v2parts.every(isValidPart)) {
        return NaN;
    }
    if (zeroExtend) {
        while (v1parts.length < v2parts.length) v1parts.push("0");
        while (v2parts.length < v1parts.length) v2parts.push("0");
    }
    if (!lexicographical) {
        v1parts = v1parts.map(Number);
        v2parts = v2parts.map(Number);
    }
    for (var i = 0; i < v1parts.length; ++i) {
        if (v2parts.length == i) {
            return 1;
        }
        if (v1parts[i] == v2parts[i]) {
            continue;
        }
        else if (v1parts[i] > v2parts[i]) {
            return 1;
        }
        else {
            return -1;
        }
    }
    if (v1parts.length != v2parts.length) {
        return -1;
    }
    return 0;
}

function compareFiles(v1, v2) {
	return compareVersions(v1.replace("./","").replace(".js",""), v2.replace("./","").replace(".js",""));
}

var installedVersion = db.schema_version.aggregate({$match: {tag: tag}}, {$project: { installedVersion : { $concat : ["$major", ".", "$minor", ".", "$patch"]}}}) || '0.0.0';
if (installedVersion && installedVersion.hasNext()) {
	installedVersion = installedVersion.next().installedVersion || '0.0.0';
} else {
	installedVersion = '0.0.0';
}
var files = ls();
if (files) {
	files.sort(compareFiles);
	print("START UPDATE FROM '"+installedVersion+"' VERSION");
	for (var i = 0; i < files.length; i++) {
		if (/^(\.\/){0,1}[0-9]+\.[0-9]+\.[0-9]+\.js$/.test(files[i])) {
			var scriptVersion = files[i].replace("./","").replace(".js","");
			var scriptMajor = scriptVersion.split(".")[0];
			var scriptMinor = scriptVersion.split(".")[1];
			var scriptPatch = scriptVersion.split(".")[2];
			if (compareVersions(scriptVersion, installedVersion) > 0) {
				print("install > " + scriptVersion);
				load(files[i]);
				db.schema_version.remove({tag: tag});
				db.schema_version.insert({major: scriptMajor, minor: scriptMinor, patch: scriptPatch, tag: tag, revision:0, last_change: new Date(), description: ""});
			}
		}
	}
	print("END UPDATE FROM '"+installedVersion+"' VERSION");
}