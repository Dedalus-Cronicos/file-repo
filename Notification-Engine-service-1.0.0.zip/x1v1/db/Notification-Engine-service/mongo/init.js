//mongo admin -u admin -p x1v1mdb --authenticationDatabase admin;

db = db.getSiblingDB("@platform.notifier.mongodb.name@");
db.createUser({ user: "@platform.notifier.mongodb.user@",
  pwd: "@platform.notifier.mongodb.password@",
  roles: [
    { role: "readWrite", db: "@platform.notifier.mongodb.name@"}
  ],
  mechanisms:[  
	  "SCRAM-SHA-1"
	 ]
});