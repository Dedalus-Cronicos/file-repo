db.configuration.ensureIndex({ property : 1 });

db.configuration.remove({property: "cache.timeout.in.millis"});
db.configuration.insert(cacheTimeoutInMillis);