db.api_mapping.ensureIndex({ apis : 1 });

db.api_mapping.remove({apis : "agmatrix"});
db.api_mapping.insert(agmatrix);

db.api_mapping.remove({apis : "consent"});
db.api_mapping.insert(consent);

db.api_mapping.remove({apis : "sampleapi1"});
db.api_mapping.insert(sample);