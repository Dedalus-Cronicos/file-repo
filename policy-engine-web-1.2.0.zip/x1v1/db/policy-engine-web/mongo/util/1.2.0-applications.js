db.applications.remove({_id : "mci_service"});
db.applications.remove({_id : "fhir_clinical_1_6_0"});
db.applications.remove({_id : "mci_service_1_6_0"});

db.applications.remove({_id : "fhir_clinical"});
db.applications.insert(fhir_clinical);

db.applications.remove({_id : "fhir_terminology"});
db.applications.insert(fhir_terminology);