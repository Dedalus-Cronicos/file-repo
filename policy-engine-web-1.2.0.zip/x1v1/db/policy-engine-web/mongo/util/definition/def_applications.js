var dsub = {
    _id: 'dsub',
    value: 'http://@xds@@domain.internal.xds@/broker'
};

var test = {
    _id: 'test',
    value: 'http://@pm@@domain.internal.xds@/policy-engine-web/proxy_test/test'
};

var fhir_clinical = {
    _id: "fhir_clinical",
    value: "http://@fhir.clinical@@domain.internal.xds@/x1v1-fhir-clinical"
};

var mci_service = {
    _id: "mci_service",
    value: "http://@fhir@@domain.internal.xds@/x1v1-mci-service"
};

var fhir_clinical_1_6_0 = {
    _id: "fhir_clinical_1_6_0",
    value: "http://@fhir@@domain.internal.xds@/x1v1-fhir-clinical-STU3-1.6/fhir"
};

var mci_service_1_6_0 = {
    _id: "mci_service_1_6_0",
    value: "http://@fhir@@domain.internal.xds@/x1v1-mci-service-STU3-1.6"
};

var rest = {
    _id: "rest",
    value: 'http://@pm@@domain.internal.xds@/policy-engine-web/proxy_test/test'
};

var ce_base = {
    _id: 'ce_base',
    value: 'http://@consent@@domain.internal.xds@/consent-engine'
};

var pmce_consents = {
    _id: 'pmce_consents',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/consent'
};

var pmce_bundleconsents = {
    _id: 'pmce_bundleconsents',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/consent/100/bundle'
};

var pmce_bundlepdf = {
    _id: 'pmce_bundlepdf',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/pdf/bundles'
};

var pmce_consentengine = {
    _id: 'pmce_consentengine',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/consentengine'
};

var pmce_messages = {
    _id: 'pmce_messages',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/message'
};

var pmce_messagepatients = {
    _id: 'pmce_messagepatients',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/message/patient'
};

var pmce_tutors = {
    _id: 'pmce_tutors',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/tutor'
};

var pmce_tutors_rollback = {
    _id: 'pmce_tutors_rollback',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/tutorRollback'
};

var pmce_patients = {
    _id: 'pmce_patients',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/patient'
};

var pmce_consentcollector = {
    _id: 'pmce_consentcollector',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/consentCollector'
};

var pmce_registrymodel = {
    _id: 'pmce_registrymodel',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/registry/model'
};
var pmce_registryinformation = {
    _id: 'pmce_registryinformation',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/registry/information'
};

var pmce_registryconsent = {
    _id: 'pmce_registryconsent',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/registry/consent'
};

var pmce_graphometric = {
    _id: 'pmce_graphometric',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/graphometric'
};

var pmce_configurationbykey = {
    _id: 'pmce_configurationbykey',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/configurationbykey'
};

var pmce_consentcollector_standalone = {
    _id: 'pmce_consentcollector_standalone',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/consentCollector/standalone'
};

var pmce_consentcollector_patients_bundles = {
    _id: 'pmce_consentcollector_patients_bundles',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/consentCollector/patients/bundles'
};

var pmce_tutors_onlytutor = {
    _id: 'pmce_tutors_onlytutor',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/tutor/onlytutor'
};

var pmce_consentcollector_externalconsentmanager = {
    _id: 'c',
    value: 'http://@consent@@domain.internal.xds@/consent-engine/consentCollector/externalConsentManager'
};

var people_fhir = {
    _id: "people_fhir",
    value: "http://@mpi@@domain.internal.mpi@/people.fhir"
};

var x1v1_mhd = {
    "_id": "x1v1_mhd",
    "value": "http://@mhd@@domain.internal.xds@/x1v1-mhd-fhir"
};

var xvalue_patsyn = {
    _id: "xvalue_patsyn",
    value: "http://@patsyn@@domain.internal.xds@/xvalue-patsyn"
};

var arr_fhir = {
    _id: "arr_fhir",
    value: "http://@audit@@domain.internal.xds@/x1v1-arr-service"
};

var fhir_terminology = {
    _id: "fhir_terminology",
    value: "http://@fhir.terminology@@domain.internal.xds@/x1v1-fhir-terminology"
};

var x1v1_configurator = {
    _id: "x1v1_configurator",
    value: "http://@config@@domain.internal.xds@/x1v1-configurator-service"
};

var pwp_backend = {
    _id: 'pwp_backend',
    value: 'http://@mpi@@domain.internal.mpi@/people.pwp.backend'
};
