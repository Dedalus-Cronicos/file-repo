var mci_service = {
    _id: "mci_service",
    value: "http://@fhir.terminology@@domain.internal.xds@/x1v1-mci-service"
};

var fhir_clinical_1_6_0 = {
    _id: "fhir_clinical_1_6_0",
    value: "http://@fhir@@domain.internal.xds@/x1v1-fhir-clinical-STU3-1.6/fhir"
};

var mci_service_1_6_0 = {
    _id: "mci_service_1_6_0",
    value: "http://@fhir@@domain.internal.xds@/x1v1-mci-service-STU3-1.6"
};