var agmatrix = {
    apis: [ "agmatrix"],
    mapping: {
        c: XACML_PREFIX + "xacml:3.0:environment:confidentiality",
        roles: XACML_PREFIX + "xacml:3.0:subject:subject-role",
        uId: XACML_PREFIX + "xacml:3.0:environment:uniqueId",
        tc: XACML_PREFIX + "xacml:3.0:environment:type-code"
    },
    remove: [ XACML_PREFIX + "xacml:3.0:policy:policyId" ]
};

var consent = {
    apis: [ "consent"],
    mapping: {
        c: XACML_PREFIX + "xacml:3.0:environment:confidentiality",
        roles: XACML_PREFIX + "xacml:3.0:subject:subject-role",
        uId: XACML_PREFIX + "xacml:3.0:environment:uniqueId",
        tc: XACML_PREFIX + "xacml:3.0:environment:type-code"
    },
    remove: [ XACML_PREFIX + "xacml:3.0:policy:policyId" ]
};

var sample = {
    apis: [ "sampleapi1", "api2" ],
    mapping: {
        c: "urn:ihe:tf:sample:attribute",
        tc: XACML_PREFIX + "xacml:3.0:environment:type-code"
    },
    remove: [ XACML_PREFIX + "xacml:3.0:policy:policyId" , "urn:ihe:tf:sample:attribute" ]
};