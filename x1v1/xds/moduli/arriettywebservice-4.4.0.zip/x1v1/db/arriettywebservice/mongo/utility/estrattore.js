function estrai(patId, author, typeCode, status, from, to) {
  query = {
    'RegistryObjectList.insertTime': { $gt: from, $lt: to }};
  if (patId != null) {
    query['patId'] = patId;
  }
  if (typeCode != null && status != null) {
    typeCodeQry = {$elemMatch: {
            'Classification.nodeRepresentation': typeCode, 
            'status': status}};
    query['RegistryObjectList.ExtrinsicObject'] = typeCodeQry;
  } else if (typeCode != null && status == null) {
    query['RegistryObjectList.ExtrinsicObject.Classification.nodeRepresentation'] = typeCode;
  } else if (typeCode == null && status != null) {
    query['RegistryObjectList.ExtrinsicObject.status'] = status;
  }
  authorQuery = {};
  authorQueryUnwind = {};
  if (author != null) {
    authorQueryUnwind = {$and: [{'RegistryObjectList.ExtrinsicObject.Classification.classificationScheme':'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d'}, 
        {'RegistryObjectList.ExtrinsicObject.Classification.Slot': 
            {$elemMatch: {'name' : 'authorPerson', 'ValueList.Value': author}}}]};
    authorQuery = {$elemMatch: {'classificationScheme':'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d', 
                          'Slot.name' : 'authorPerson', 'Slot.ValueList.Value': author}};
    query['RegistryObjectList.ExtrinsicObject.Classification'] = authorQuery;
  } else {
    authorQueryUnwind = {$and: [{'RegistryObjectList.ExtrinsicObject.Classification.classificationScheme':'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d'}, 
        {'RegistryObjectList.ExtrinsicObject.Classification.Slot.name' : 'authorPerson'}]};
    authorQuery = {$elemMatch: {'classificationScheme':'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d', 
                          'Slot.name' : 'authorPerson'}};
    query['RegistryObjectList.ExtrinsicObject.Classification'] = authorQuery;
  }
    
  submissions = db.submission.aggregate([{$match: query},
      {$unwind: '$RegistryObjectList.ExtrinsicObject'},
      {$unwind: '$RegistryObjectList.ExtrinsicObject.Classification'},
      {$match: authorQueryUnwind},
      {$unwind: '$RegistryObjectList.ExtrinsicObject.Classification.Slot'},
      {$unwind: '$RegistryObjectList.ExtrinsicObject.Classification.Slot.ValueList.Value'},
      {$project: {'_id': '$_id', 
        'authorName': '$RegistryObjectList.ExtrinsicObject.Classification.Slot.ValueList.Value.content'}}
      ]);

  saveToFile(submissions);
  
}

function saveToFile(submissions) {
  while (submissions.hasNext()) {
     currDoc = submissions.next();
     _id = currDoc._id;
     authorName = currDoc.authorName;
       altreInfo = db.submission.findOne({'_id': currDoc._id});
       //altreInfo = altreInfos.next();

    for (i=0; i < altreInfo.RegistryObjectList.ExtrinsicObject.length; i++) {
      extrinsicObject = altreInfo.RegistryObjectList.ExtrinsicObject[i];
      docType = null;
      for (idx = 0; (idx < extrinsicObject.Classification.length && docType == null); idx++) {
        classification = extrinsicObject.Classification[idx];
        if (classification.classificationScheme == 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983') {
          docType = classification.nodeRepresentation;
        }
      }
      uniqueId = null;
      for (idx = 0; (idx < extrinsicObject.ExternalIdentifier.length && uniqueId == null); idx++) {
        extId = extrinsicObject.ExternalIdentifier[idx];
        if (extId.identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab') {
          uniqueId = extId.value;
        }
      }
      print('"'+ _id + '","' + authorName + '","' + docType + '","' + extrinsicObject.status 
        + '","' + uniqueId + '","' + altreInfo.patId + '","' + altreInfo.RegistryObjectList.insertTime + '"');
    }
  }
}

patId = null;//'122478^^^&2.16.840.1.113883.2.9.2.20&ISO';
author = null;
typeCode = '60592-3';
status = 'urn:oasis:names:tc:ebxml-regrep:StatusType:Approved';
from = 20150101000000;
to = 20161231000000;

estrai(patId, author, typeCode, status, from, to);
