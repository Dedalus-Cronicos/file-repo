db.arrietty_dwh.ensureIndex({'typeCode': 1 , 'status' : 1, 'attempsNumber': 1}, { sparse: true,  name: 'dwhTpCodeIndex'});
