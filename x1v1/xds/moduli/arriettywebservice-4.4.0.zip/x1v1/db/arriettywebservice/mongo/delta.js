//eg. mongo 127.0.0.1:27017/dbname -u dbuser -p dbpass delta.js
//eg. mongo 127.0.0.1:27017/dbname -u dbuser -p dbpass --eval "var defaultStartingVersion='0.0.0';" delta.js
//eg. mongo 127.0.0.1:27017/dbname -u dbuser -p dbpass --eval "var startingVersion='0.0.0';" delta.js

var tag = "arrietty";

function getStartingVersionParam() {
    var checkedParamVersion = null;
    try {
        checkedParamVersion = startingVersion;
    } catch (e){
        checkedParamVersion = null;
    }
    if (checkedParamVersion!==null && (/^[0-9]+\.[0-9]+\.[0-9]+$/).test(checkedParamVersion)) {
        return checkedParamVersion;
    } else {
        return null;
    }
}

function getDefaultStartingVersionParam() {
    var checkedParamVersion = null;
    try {
        checkedParamVersion = defaultStartingVersion;
    } catch (e){
        checkedParamVersion = null;
    }
    if (checkedParamVersion!==null && (/^[0-9]+\.[0-9]+\.[0-9]+$/).test(checkedParamVersion)) {
        return checkedParamVersion;
    } else {
        return null;
    }
}

function getVersionToStart() {
    var versionToStart = null;
    var paramVersion = getStartingVersionParam();
    if (paramVersion!==null && (/^[0-9]+\.[0-9]+\.[0-9]+$/).test(paramVersion)) {
        versionToStart = paramVersion;
    } else {
        var installedVersion = db.schema_version.aggregate({$match: {tag: tag}}, {$project: { installedVersion : { $concat : ["$major", ".", "$minor", ".", "$patch"]}}}) || '0.0.0';
        if (installedVersion && installedVersion.hasNext()) {
            versionToStart = installedVersion.next().installedVersion || '0.0.0';
        } else {
            versionToStart = 'NO-VERSION';
        }
    }
    if (versionToStart === 'NO-VERSION') {
        var paramDefaultVersion = getDefaultStartingVersionParam();
        if (paramDefaultVersion!==null && (/^[0-9]+\.[0-9]+\.[0-9]+$/).test(paramDefaultVersion)) {
            versionToStart = paramDefaultVersion;
        }
    }
    return versionToStart;
}

function compareVersions(v1, v2) {
  var v1parts = v1.split('.'),
      v2parts = v2.split('.');
  function isValidPart(x) {
      return (/^\d+$/).test(x);
  }
  if (!v1parts.every(isValidPart) || !v2parts.every(isValidPart)) {
      return NaN;
  }
  for (var i = 0; i < v1parts.length; i++) {

      if (Number(v1parts[i]) == Number(v2parts[i])) {
          continue;
      }
      else if (Number(v1parts[i]) > Number(v2parts[i])) {
          return 1;
      }
      else {
          return -1;
      }
  }
  return 0;
}

function executeScript(major, minor, patch, applicationTag) {
    var fileVersionedName = major+"."+minor+"."+patch;
    print(getInfo("install > " + pwd()+"/"+fileVersionedName+".js"));
    load(pwd()+"/"+fileVersionedName+".js");
    db.schema_version.remove({tag: applicationTag});
    db.schema_version.insert({major: major, minor: minor, patch: patch, tag: tag, revision:0, last_change: new Date(), description: ""});
    print(getInfo("installed > " + pwd()+"/"+fileVersionedName+".js"));
}

function getError(message) {
    return '{"level":"ERROR","@timestamp":"'+getNowAsString()+'","message":"'+message+'","logger_name":"MONGO_SCRIPT"}';
}

function getInfo(message) {
    return '{"level":"INFO","@timestamp":"'+getNowAsString()+'","message":"'+message+'","logger_name":"MONGO_SCRIPT"}';
}

function getNowAsString(){
    var d = new Date();
    var tzo = -d.getTimezoneOffset(),
    dif = tzo >= 0 ? '+' : '-',
    pad = function(x, n) {
        while (x.toString().length < n) {
            x = "0" + x;
      }
      return x;
    };
return d.getFullYear() +
    '-' + pad(d.getMonth() + 1,2) +
    '-' + pad(d.getDate(),2) +
    'T' + pad(d.getHours(),2) +
    ':' + pad(d.getMinutes(),2) +
    ':' + pad(d.getSeconds(),2) +
    ':' + pad(d.getMilliseconds(), 3)+
    dif + pad(tzo / 60, 2) +
    ':' + pad(tzo % 60, 2);
}

var versionToStart = getVersionToStart();
if (versionToStart === 'NO-VERSION') {
    print(getError("ERROR: 'schema_version' collection, 'startingVersion' param or 'defaultStartingVersion' param are required."));
} else {
    var files = ls();
    if (files) {
        files = files.map(function(fileName, index) {
            return fileName.replace("./","").replace(".js","");
        });
        files = files.filter(function(fileName) {
            return (/^[0-9]+\.[0-9]+\.[0-9]+$/).test(fileName);
        });
        files.sort(function compareFileVersions(v1, v2) {
            return compareVersions(v1, v2);
        });
        print(getInfo("START UPDATE FROM '"+versionToStart+"' VERSION"));
        var _scriptConfigurations = [];
        for (var i = 0; i < files.length; i++) {
            var scriptMajor = files[i].split(".")[0];
            var scriptMinor = files[i].split(".")[1];
            var scriptPatch = files[i].split(".")[2];
            if (compareVersions(files[i], versionToStart) > 0) {
                _scriptConfigurations.push({major: scriptMajor, minor: scriptMinor, patch: scriptPatch, applicationTag: tag});
            }
        }
        for (var j = 0; j < _scriptConfigurations.length; j++) {
            executeScript(_scriptConfigurations[j].major, _scriptConfigurations[j].minor, _scriptConfigurations[j].patch, _scriptConfigurations[j].applicationTag);
        }
        print(getInfo("END UPDATE FROM '"+versionToStart+"' VERSION"));
    }
}
