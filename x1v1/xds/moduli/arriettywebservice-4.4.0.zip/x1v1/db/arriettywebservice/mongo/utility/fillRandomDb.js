//IMPORT da https://github.com/mongodb/mongo-csharp-driver/blob/master/uuidhelpers.js

function HexToBase64(hex) {
    var base64Digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    var base64 = "";
    var group;
    for (var i = 0; i < 30; i += 6) {
        group = parseInt(hex.substr(i, 6), 16);
        base64 += base64Digits[(group >> 18) & 0x3f];
        base64 += base64Digits[(group >> 12) & 0x3f];
        base64 += base64Digits[(group >> 6) & 0x3f];
        base64 += base64Digits[group & 0x3f];
    }
    group = parseInt(hex.substr(30, 2), 16);
    base64 += base64Digits[(group >> 2) & 0x3f];
    base64 += base64Digits[(group << 4) & 0x3f];
    base64 += "==";
    return base64;
}

function Base64ToHex(base64) {
    var base64Digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var hexDigits = "0123456789abcdef";
    var hex = "";
    for (var i = 0; i < 24; ) {
        var e1 = base64Digits.indexOf(base64[i++]);
        var e2 = base64Digits.indexOf(base64[i++]);
        var e3 = base64Digits.indexOf(base64[i++]);
        var e4 = base64Digits.indexOf(base64[i++]);
        var c1 = (e1 << 2) | (e2 >> 4);
        var c2 = ((e2 & 15) << 4) | (e3 >> 2);
        var c3 = ((e3 & 3) << 6) | e4;
        hex += hexDigits[c1 >> 4];
        hex += hexDigits[c1 & 15];
        if (e3 != 64) {
            hex += hexDigits[c2 >> 4];
            hex += hexDigits[c2 & 15];
        }
        if (e4 != 64) {
            hex += hexDigits[c3 >> 4];
            hex += hexDigits[c3 & 15];
        }
    }
    return hex;
}

function UUID(uuid) {
    var hex = uuid.replace(/[{}-]/g, ""); // remove extra characters
    var base64 = HexToBase64(hex);
    //print(uuid + ' = ' + base64);
    return new BinData(4, base64); // new subtype 4
}

function JUUID(uuid) {
    var hex = uuid.replace(/[{}-]/g, ""); // remove extra characters
    var msb = hex.substr(0, 16);
    var lsb = hex.substr(16, 16);
    msb = msb.substr(14, 2) + msb.substr(12, 2) + msb.substr(10, 2) + msb.substr(8, 2) + msb.substr(6, 2) + msb.substr(4, 2) + msb.substr(2, 2) + msb.substr(0, 2);
    lsb = lsb.substr(14, 2) + lsb.substr(12, 2) + lsb.substr(10, 2) + lsb.substr(8, 2) + lsb.substr(6, 2) + lsb.substr(4, 2) + lsb.substr(2, 2) + lsb.substr(0, 2);
    hex = msb + lsb;
    var base64 = HexToBase64(hex);
    return new BinData(4, base64);
}

function CSUUID(uuid) {
    var hex = uuid.replace(/[{}-]/g, ""); // remove extra characters
    var a = hex.substr(6, 2) + hex.substr(4, 2) + hex.substr(2, 2) + hex.substr(0, 2);
    var b = hex.substr(10, 2) + hex.substr(8, 2);
    var c = hex.substr(14, 2) + hex.substr(12, 2);
    var d = hex.substr(16, 16);
    hex = a + b + c + d;
    var base64 = HexToBase64(hex);
    return new BinData(3, base64);
}

function PYUUID(uuid) {
    var hex = uuid.replace(/[{}-]/g, ""); // remove extra characters
    var base64 = HexToBase64(hex);
    return new BinData(3, base64);
}

BinData.prototype.toUUID = function () {
    var hex = Base64ToHex(this.base64()); // don't use BinData's hex function because it has bugs in older versions of the shell
    var uuid = hex.substr(0, 8) + '-' + hex.substr(8, 4) + '-' + hex.substr(12, 4) + '-' + hex.substr(16, 4) + '-' + hex.substr(20, 12);
    return 'UUID("' + uuid + '")';
}

BinData.prototype.toJUUID = function () {
    var hex = Base64ToHex(this.base64()); // don't use BinData's hex function because it has bugs in older versions of the shell
    var msb = hex.substr(0, 16);
    var lsb = hex.substr(16, 16);
    msb = msb.substr(14, 2) + msb.substr(12, 2) + msb.substr(10, 2) + msb.substr(8, 2) + msb.substr(6, 2) + msb.substr(4, 2) + msb.substr(2, 2) + msb.substr(0, 2);
    lsb = lsb.substr(14, 2) + lsb.substr(12, 2) + lsb.substr(10, 2) + lsb.substr(8, 2) + lsb.substr(6, 2) + lsb.substr(4, 2) + lsb.substr(2, 2) + lsb.substr(0, 2);
    hex = msb + lsb;
    var uuid = hex.substr(0, 8) + '-' + hex.substr(8, 4) + '-' + hex.substr(12, 4) + '-' + hex.substr(16, 4) + '-' + hex.substr(20, 12);
    return 'JUUID("' + uuid + '")';
}

BinData.prototype.toCSUUID = function () {
    var hex = Base64ToHex(this.base64()); // don't use BinData's hex function because it has bugs in older versions of the shell
    var a = hex.substr(6, 2) + hex.substr(4, 2) + hex.substr(2, 2) + hex.substr(0, 2);
    var b = hex.substr(10, 2) + hex.substr(8, 2);
    var c = hex.substr(14, 2) + hex.substr(12, 2);
    var d = hex.substr(16, 16);
    hex = a + b + c + d;
    var uuid = hex.substr(0, 8) + '-' + hex.substr(8, 4) + '-' + hex.substr(12, 4) + '-' + hex.substr(16, 4) + '-' + hex.substr(20, 12);
    return 'CSUUID("' + uuid + '")';
}

BinData.prototype.toPYUUID = function () {
    var hex = Base64ToHex(this.base64()); // don't use BinData's hex function because it has bugs
    var uuid = hex.substr(0, 8) + '-' + hex.substr(8, 4) + '-' + hex.substr(12, 4) + '-' + hex.substr(16, 4) + '-' + hex.substr(20, 12);
    return 'PYUUID("' + uuid + '")';
}


BinData.prototype.toHexUUID = function () {
    var hex = Base64ToHex(this.base64()); // don't use BinData's hex function because it has bugs
    var uuid = hex.substr(0, 8) + '-' + hex.substr(8, 4) + '-' + hex.substr(12, 4) + '-' + hex.substr(16, 4) + '-' + hex.substr(20, 12);
    return 'HexData(' + this.subtype() + ', "' + uuid + '")';
}

function TestUUIDHelperFunctions() {
    var s = "{12711e6d-6166-326b-90bc-c694017f6922}";
    var uuid = UUID(s);
    var juuid = JUUID(s);
    var csuuid = CSUUID(s);
    var pyuuid = PYUUID(s);
    print(uuid.toUUID());
    print(juuid.toJUUID());
    print(csuuid.toCSUUID());
    print(pyuuid.toPYUUID());
    print(uuid.toHexUUID());
    print(juuid.toHexUUID());
    print(csuuid.toHexUUID());
    print(pyuuid.toHexUUID());
}

//----------------------------------


function guid() {
  function s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }
  return s4() + s4() + '-' + s4() + '-' + s4() + '-' +
    s4() + '-' + s4() + s4() + s4();
}

function guidToBinData(guid) {
    var guid = guid.replace(/[{}-]/g, ""); 
    guid = guid.replace(/-/g, '');
    var field1 = guid.substr(0, 8);
    var field2 = guid.substr(8, 4);
    var field3 = guid.substr(12, 4);
    var field4 = guid.substr(16, 4);
    var field5 = guid.substr(20, 12);
    field1 = field1.substr(6, 2) + field1.substr(4, 2) + field1.substr(2, 2) + field1.substr(0, 2)
    field2 = field2.substr(2, 2) + field2.substr(0, 2)
    field3 = field3.substr(2, 2) + field3.substr(0, 2)
    var hex = field1 + field2 + field3 + field4 + field5
    var base64Digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    var base64 = "";
    var group;
    for (var i = 0; i < 30; i += 6) {
        group = parseInt(hex.substr(i, 6), 16);
        base64 += base64Digits[(group >> 18) & 0x3f];
        base64 += base64Digits[(group >> 12) & 0x3f];
        base64 += base64Digits[(group >> 6) & 0x3f];
        base64 += base64Digits[group & 0x3f];
    }
    group = parseInt(hex.substr(30, 2), 16);
    base64 += base64Digits[(group >> 2) & 0x3f];
    base64 += base64Digits[(group << 4) & 0x3f];
    base64 += "==";
    return new BinData(4, base64);
}


//pat=db.patients.initializeOrderedBulkOp();


sub=db.submission.initializeUnorderedBulkOp();
jsonTemplate = { 
    
    "uuids" : [
        "@id1@" , 
        "@id2@" , 
        "@id3@" , 
        "@id4@" , 
        "@id5@" , 
        "@id6@" , 
        "@id7@" , 
        "@id8@" , 
        "@id9@" , 
        "@id10@" , 
        "@id11@" , 
        "@id12@" , 
        "@id13@" , 
        "@id14@" , 
        "@id15@" , 
        "@id16@" , 
        "@id17@" , 
        "@id18@" , 
        "@id19@" 
    ], 
    "patId" : "@patId@" ,
    "insertTime" : 111222333, 
    "RegistryObjectList" : {
        
        
        "Association" : [
            {
                "id" : "@id1@" , 
                "targetObject" : "@id2@" , 
                "lid" : "@id1@" , 
                "sourceObject" : "@id13@" , 
                "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                "associationType" : "urn:oasis:names:tc:ebxml-regrep:AssociationType:HasMember", 
                "versionName" : NumberInt(1)
            }
        ], 
        "lastUpdateTime" : 111222333, 
        "ExtrinsicObject" : [
            {
                "id" : "@id2@" , 
                "home" : "", 
                "lid" : "@id2@" , 
                "Classification" : [
                    {
                        "id" : "@id3@" , 
                        "lid" : "@id3@" , 
                        "classifiedObject" : "@id2@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "", 
                        "Slot" : [
                            {
                                "name" : "authorPerson", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "GRNMRZ52B24L856R^GUARNIERI^MAURIZIO^^^^^^&2.16.840.1.113883.2.9.4.3.2&ISO"
                                        }
                                    ]
                                }
                            }, 
                            {
                                "name" : "authorInstitution", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "ULSS 8 - ASOLO^^^^^^^^^2.16.840.1.113883.2.9.2.50.2.050108"
                                        }
                                    ]
                                }
                            }, 
                            {
                                "name" : "authorSpecialty", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "MEDICO DI MEDICINA GENERALE"
                                        }
                                    ]
                                }
                            }
                        ], 
                        "classificationScheme" : "urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d", 
                        "versionName" : NumberInt(1)
                    }, 
                    {
                        "id" : "@id4@" , 
                        "lid" : "@id4@" , 
                        "classifiedObject" : "@id2@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "rv_cc_0101", 
                        "Slot" : [
                            {
                                "name" : "codingScheme", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "regioneveneto classCodes v1"
                                        }
                                    ]
                                }
                            }
                        ], 
                        "classificationScheme" : "urn:uuid:41a5887f-8865-4c09-adf7-e362475b143a", 
                        "versionName" : NumberInt(1)
                    }, 
                    {
                        "id" : "@id5@" , 
                        "lid" : "@id5@" , 
                        "classifiedObject" : "@id2@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "N", 
                        "Slot" : [
                            {
                                "name" : "codingScheme", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "HL7 Confidentiality"
                                        }
                                    ]
                                }
                            }
                        ], 
                        "classificationScheme" : "urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f", 
                        "versionName" : NumberInt(1)
                    }, 
                    {
                        "id" : "@id6@" , 
                        "lid" : "@id6@" , 
                        "classifiedObject" : "@id2@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "urn:rve:mef:preMEF:2013:ePrescription", 
                        "Slot" : [
                            {
                                "name" : "codingScheme", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "regioneveneto formatCodes v1"
                                        }
                                    ]
                                }
                            }
                        ], 
                        "classificationScheme" : "urn:uuid:a09d5840-386c-46f2-b5ad-9c3699a4309d", 
                        "versionName" : NumberInt(1)
                    }, 
                    {
                        "id" : "@id7@" , 
                        "lid" : "@id7@" , 
                        "classifiedObject" : "@id2@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "doge_hftc008", 
                        "Slot" : [
                            {
                                "name" : "codingScheme", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "DOGE healthcareFacilityTypeCodes"
                                        }
                                    ]
                                }
                            }
                        ], 
                        "classificationScheme" : "urn:uuid:f33fb8ac-18af-42cc-ae0e-ed0b0bdb91e1", 
                        "versionName" : NumberInt(1)
                    }, 
                    {
                        "id" : "@id8@" , 
                        "lid" : "@id8@" , 
                        "classifiedObject" : "@id2@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "doge_psc010", 
                        "Slot" : [
                            {
                                "name" : "codingScheme", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "DOGE practiceSettingCodes"
                                        }
                                    ]
                                }
                            }
                        ], 
                        "classificationScheme" : "urn:uuid:cccf5598-8b07-4b77-a05e-ae952c785ead", 
                        "versionName" : NumberInt(1)
                    }, 
                    {
                        "id" : "@id9@" , 
                        "lid" : "@id9@" , 
                        "classifiedObject" : "@id2@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "57833-6", 
                        "Slot" : [
                            {
                                "name" : "codingScheme", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "2.16.840.1.113883.6.1"
                                        }
                                    ]
                                }
                            }
                        ], 
                        "classificationScheme" : "urn:uuid:f0306f51-975f-434e-a61c-c59651d33983", 
                        "versionName" : NumberInt(1)
                    }, 
                    {
                        "id" : "@id10@" , 
                        "lid" : "@id10@" , 
                        "classifiedObject" : "@id2@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "DISPONIBILE", 
                        "Slot" : [
                            {
                                "name" : "codingScheme", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "regioneveneto eventCodeList v1"
                                        }
                                    ]
                                }
                            }
                        ], 
                        "classificationScheme" : "urn:uuid:2c6b8cb7-8b2a-4051-b291-b1ae6a575ef4", 
                        "versionName" : NumberInt(1)
                    }
                ], 
                "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                "ExternalIdentifier" : [
                    {
                        "id" : "@id11@" , 
                        "Name" : {
                            "LocalizedString" : {
                                "value" : "XDSDocumentEntry.patientId"
                            }
                        }, 
                        "lid" : "@id11@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "value" : "@patId@" , 
                        "identificationScheme" : "urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427", 
                        "versionName" : NumberInt(1), 
                        "registryObject" : "@id2@" 
                    }, 
                    {
                        "id" : "@id12@" , 
                        "Name" : {
                            "LocalizedString" : {
                                "value" : "XDSDocumentEntry.uniqueId"
                            }
                        }, 
                        "lid" : "@id12@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "value" : "@ExtId2@", 
                        "identificationScheme" : "urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab", 
                        "versionName" : NumberInt(1), 
                        "registryObject" : "@id2@" 
                    }
                ], 
                "Slot" : [
                    {
                        "name" : "hash", 
                        "ValueList" : {
                            "Value" : [
                                {
                                    "content" : "b73ae5d63e78bfdcfa5d507685d7eaae9cb472c2"
                                }
                            ]
                        }
                    }, 
                    {
                        "name" : "size", 
                        "ValueList" : {
                            "Value" : [
                                {
                                    "content" : NumberInt(5685)
                                }
                            ]
                        }
                    }, 
                    {
                        "name" : "repositoryUniqueId", 
                        "ValueList" : {
                            "Value" : [
                                {
                                    "content" : "2.16.840.1.113883.2.9.50.4.5.108.20801.3.1"
                                }
                            ]
                        }
                    }, 
                    {
                        "name" : "creationTime", 
                        "ValueList" : {
                            "Value" : [
                                {
                                    "content" : "201408260813"
                                }
                            ]
                        }
                    }, 
                    {
                        "name" : "languageCode", 
                        "ValueList" : {
                            "Value" : [
                                {
                                    "content" : "it"
                                }
                            ]
                        }
                    }, 
                    {
                        "name" : "serviceStartTime", 
                        "ValueList" : {
                            "Value" : [
                                {
                                    "content" : "201408260813"
                                }
                            ]
                        }
                    }, 
                    {
                        "name" : "sourcePatientId", 
                        "ValueList" : {
                            "Value" : [
                                {
                                    "content" : "@patId@" 
                                }
                            ]
                        }
                    }, 
                    {
                        "name" : "sourcePatientInfo", 
                        "ValueList" : {
                            "Value" : [
                                {
                                    "content" : "PID-3|FRRLBA31S68L856O^^^&2.16.840.1.113883.2.9.4.3.2&ISO"
                                }, 
                                {
                                    "content" : "PID-5|FERRACIN^ALBA^^^"
                                }, 
                                {
                                    "content" : "PID-7|19311128"
                                }, 
                                {
                                    "content" : "PID-8|F"
                                }, 
                                {
                                    "content" : "PID-11|VIA ROVEDE              9 ^^VIDOR^^31020^ITA"
                                }
                            ]
                        }
                    }
                ], 
                "creationTime" : NumberLong(20140826081300), 
                "versionName" : NumberInt(1), 
                "documentAvailability" : "urn:ihe:iti:2010:DocumentAvailability:Online", 
                "serviceStartTime" : NumberLong(20140826081300), 
                "objectType" : "urn:uuid:7edca82f-054d-47f2-a032-9b2a5b5186c1", 
                "mimeType" : "text/x-cda-r2+xml"
            }
        ], 
        "RegistryPackage" : [
            {
                "id" : "@id13@" , 
                "lid" : "@id13@" , 
                "Classification" : [
                    {
                        "id" : "@id14@" , 
                        "lid" : "@id14@" , 
                        "classifiedObject" : "@id13@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "", 
                        "Slot" : [
                            {
                                "name" : "authorPerson", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "GRNMRZ52B24L856R^GUARNIERI^MAURIZIO^^^^^^&2.16.840.1.113883.2.9.4.3.2&ISO"
                                        }
                                    ]
                                }
                            }, 
                            {
                                "name" : "authorInstitution", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "ULSS 8 - ASOLO^^^^^^^^^2.16.840.1.113883.2.9.2.50.2.050108"
                                        }
                                    ]
                                }
                            }, 
                            {
                                "name" : "authorSpecialty", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "MEDICO DI MEDICINA GENERALE"
                                        }
                                    ]
                                }
                            }
                        ], 
                        "classificationScheme" : "urn:uuid:a7058bb9-b4e4-4307-ba5b-e3f0ab85e12d", 
                        "versionName" : NumberInt(1)
                    }, 
                    {
                        "id" : "@id15@" , 
                        "lid" : "@id15@" , 
                        "classifiedObject" : "@id13@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "doge_ctc003", 
                        "Slot" : [
                            {
                                "name" : "codingScheme", 
                                "ValueList" : {
                                    "Value" : [
                                        {
                                            "content" : "DOGE contentTypeCodes"
                                        }
                                    ]
                                }
                            }
                        ], 
                        "classificationScheme" : "urn:uuid:aa543740-bdda-424e-8c96-df4873be8500", 
                        "versionName" : NumberInt(1)
                    }, 
                    {
                        "id" : "@id16@" , 
                        "lid" : "@id16@" , 
                        "classifiedObject" : "@id13@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "nodeRepresentation" : "", 
                        "classificationNode" : "urn:uuid:a54d6aa5-d40d-43f9-88c5-b4633d873bdd", 
                        "classificationScheme" : "", 
                        "versionName" : NumberInt(1)
                    }
                ], 
                "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                "ExternalIdentifier" : [
                    {
                        "id" : "@id17@" , 
                        "Name" : {
                            "LocalizedString" : {
                                "value" : "XDSSubmissionSet.uniqueId"
                            }
                        }, 
                        "lid" : "@id17@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "value" : "@ExtId1@", 
                        "identificationScheme" : "urn:uuid:96fdda7c-d067-4183-912e-bf5ee74998a8", 
                        "versionName" : NumberInt(1), 
                        "registryObject" : "@id13@" 
                    }, 
                    {
                        "id" : "@id18@" , 
                        "Name" : {
                            "LocalizedString" : {
                                "value" : "XDSSubmissionSet.sourceId"
                            }
                        }, 
                        "lid" : "@id18@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "value" : "@ExtId3@" , 
                        "identificationScheme" : "urn:uuid:554ac39e-e3fe-47fe-b233-965d2a147832", 
                        "versionName" : NumberInt(1), 
                        "registryObject" : "@id13@" 
                    }, 
                    {
                        "id" : "@id19@" , 
                        "Name" : {
                            "LocalizedString" : {
                                "value" : "XDSSubmissionSet.patientId"
                            }
                        }, 
                        "lid" : "@id19@" , 
                        "status" : "urn:oasis:names:tc:ebxml-regrep:StatusType:Approved", 
                        "value" : "@patId@" , 
                        "identificationScheme" : "urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446", 
                        "versionName" : NumberInt(1), 
                        "registryObject" : "@id13@" 
                    }
                ], 
                "Slot" : [
                    {
                        "name" : "submissionTime", 
                        "ValueList" : {
                            "Value" : [
                                {
                                    "content" : "201408260813"
                                }
                            ]
                        }
                    }
                ], 
                "submissionTime" : NumberLong(20140826081300), 
                "versionName" : NumberInt(1), 
                "objectType" : "urn:oasis:names:tc:ebxml-regrep:ObjectType:RegistryObject:RegistryPackage"
            }
        ]
    }
};
str = JSON.stringify(jsonTemplate);
var submission, uuids, newUuids;
for (j=0;j<1000;j++)  {
    sub=db.submission.initializeUnorderedBulkOp();
    for (i=0;i<300;i++)  {
        patId = 'pat' + Math.floor(Math.random()*1000000);
        //pat = pat.find({'patId' : patId });
        //pat.insert({'patId': patId});
        id = guid();
        json = str.replace(/@id1@/g, id);
        id = guid();
        json = json.replace(/@id2@/g, id);
        id = guid();
        json = json.replace(/@id3@/g, id);
        id = guid();
        json = json.replace(/@id4@/g, id);
        id = guid();
        json = json.replace(/@id5@/g, id);
        id = guid();
        json = json.replace(/@id6@/g, id);
        id = guid();
        json = json.replace(/@id7@/g, id);
        id = guid();
        json = json.replace(/@id8@/g, id);
        id = guid();
        json = json.replace(/@id9@/g, id);
        id = guid();
        json = json.replace(/@id10@/g, id);
        id = guid();
        json = json.replace(/@id11@/g, id);
        id = guid();
        json = json.replace(/@id12@/g, id);
        id = guid();
        json = json.replace(/@id13@/g, id);
        id = guid();
        json = json.replace(/@id14@/g, id);
        id = guid();
        json = json.replace(/@id15@/g, id);
        id = guid();
        json = json.replace(/@id16@/g, id);
        id = guid();
        json = json.replace(/@id17@/g, id);
        id = guid();
        json = json.replace(/@id18@/g, id);
        id = guid();
        json = json.replace(/@id19@/g, id);
    
        json = json.replace(/@ExtId1@/g, guid());
        json = json.replace(/@ExtId2@/g, guid());
        json = json.replace(/@ExtId3@/g, guid());
        json = json.replace(/@patId@/g, patId);
        dt = new Date();
        var day = dt.getDate();
        var monthIndex = dt.getMonth() + 1;
        var year = dt.getFullYear();
        var hh = dt.getHours();
        var min = dt.getMinutes();
        var sec = dt.getSeconds();
        var d = "";
        if (day < 10) {d = "0" + day;} else { d = d + day;}
        var h = "";
        if (hh < 10) {h = "0" + hh;} else { h = h + hh;}
        var mm = "";
        if (min < 10) {mm = "0" + min;} else { mm = mm + min;}
        var ss = "";
        if (sec < 10) {ss = "0" + sec;} else { ss = ss + sec;}
        var m = "";
        if (monthIndex < 10) {m = "0" + monthIndex;} else { m = m + monthIndex;}
        now = "" + year + mm + d + h + m + ss ;
        json = json.replace(/111222333/g, now);
        //print(json);
        submision = JSON.parse(json);
        //print(submision);
        uuids = submision.uuids;
        newUuids = [];
        for (var index in uuids) {
            id = uuids[index];
            newUuids.push(UUID(id));
        }
        submision.uuids = newUuids;
        sub.insert(submision);
    }
//pat.execute({j: true});
    sub.execute({j: true});
}
