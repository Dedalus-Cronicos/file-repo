db.createCollection('patient_identifiers');
db.patient_identifiers.createIndex({"patId": 1, "assignAuth": 1}, {unique: true});
db.patient_identifiers.createIndex({"deprecateIds.patId": 1, "deprecateIds.assignAuth": 1});
db.createCollection('import_patients_log');


