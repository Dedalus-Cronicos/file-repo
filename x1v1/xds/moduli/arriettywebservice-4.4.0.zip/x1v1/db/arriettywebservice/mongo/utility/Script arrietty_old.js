//COLLECTION
db.createCollection('submission');
db.createCollection('patients');
db.createCollection('notifiers');

//INDICI 
db.submission.ensureIndex({'RegistryObjectList.patientId': 1}, { sparse: true, name: 'patientIdIndex'});
db.submission.ensureIndex({'RegistryObjectList.ExtrinsicObject.id' : 1},{sparse: true, 'unique': true, name : 'ExtrinsicObjectidIndex'});

db.submission.ensureIndex({'RegistryObjectList.RegistryPackage.id' : 1},{'unique': true, name: 'RegistryPackageidIndex'});

db.submission.ensureIndex({
'RegistryObjectList.RegistryPackage.ExternalIdentifier.value': 1,
'RegistryObjectList.RegistryPackage.ExternalIdentifier.identificationScheme': 1}, {name: 'RegistryPackageExtidIndex'});

db.submission.ensureIndex({'RegistryObjectList.Association.targetObject': 1}, {sparse: true, name : 'AssociationTargetIndex'});

db.submission.ensureIndex({'RegistryObjectList.Association.sourceObject': 1}, {sparse: true, name : 'AssociationSourceIndex'});

db.submission.ensureIndex({'RegistryObjectList.Classification.classificationNode': 1, 'RegistryObjectList.Classification.classifiedObject': 1}, {sparse: true, name : 'ClassificationIndex'});

db.patients.ensureIndex({'patId' : 1}, {name: 'PatientPatIDIndex'});

db.submission.ensureIndex({'uuids': 1}, {sparse: true, name : 'UUIDSIndex'});

db.submission.ensureIndex({
'RegistryObjectList.ExtrinsicObject.ExternalIdentifier.value' : 1,
'RegistryObjectList.ExtrinsicObject.ExternalIdentifier.identificationScheme': 1}, { sparse: true, name: 'ExtrinsicObjectExtIdIndex'});
    
db.submission.ensureIndex({'RegistryObjectList.insertTime': 1}, { name: 'insertDtIndex'});
db.submission.ensureIndex({'pendingTransactions': 1}, { sparse: true,  name: 'pendingTransactionsIndex'});
db.notifiers.ensureIndex({'error': 1}, { sparse: true,  name: 'notifiersErrorIndex'});
db.submission.ensureIndex({'RegistryObjectList.patientId': 1,'referenceIdList.refIds':1}, {sparse: true, name : 'refIdsIndex'});
db.submission.ensureIndex({'RegistryObjectList.Association.id': 1}, {sparse: true, name : 'AssociationIdIndex'});
db.submission.ensureIndex({'RegistryObjectList.ExtrinsicObject.lid' : 1},{sparse: true, 'unique': false, name : 'ExtrinsicObjectLidIndex'});
db.submission.ensureIndex({'RegistryObjectList.RegistryPackage.lid' : 1},{'unique': false, name: 'RegistryPackageLidIndex'});

      
