db.ARRIETTY_TRANSACTION.drop();
db.createCollection('ARRIETTY_TRANSACTION');
db.ARRIETTY_TRANSACTION.ensureIndex({'transLock': 1 }, {  unique: true, sparse: true,  name: 'transactionLockIndex'});
