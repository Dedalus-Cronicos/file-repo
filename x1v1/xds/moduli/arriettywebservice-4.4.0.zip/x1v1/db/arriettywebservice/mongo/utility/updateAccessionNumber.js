var submissions = db.submission.find({
    $and: [
    
    {'RegistryObjectList.insertTime': {
        $gte:20180101000000,
        $lt: 20190101000000
    }},
    {'RegistryObjectList.ExtrinsicObject.Slot.name': 'accessionNumber'},
    {'RegistryObjectList.ExtrinsicObject.Slot.name': {$ne: 'referenceIdList'}}

    ]
});
var currDoc;
var tmpEo, eo = null;
var slotValue = null;
var idxEo = 0;
var idxSlot = 0;
var slot;
var slotTemplate = {
    'name': 'referenceIdList',
    'ValueList': {
        "Value" : [ 
            {
                "content" : "TEST_AO501"
            }
        ]
    }
};
print("begin conversion");
while (submissions.hasNext()) {
    currDoc = submissions.next();
    idxEo = 0;
    slotValue = null;
    eo = null;
    while (slotValue == null && eo == null && 
            idxEo < currDoc.RegistryObjectList.ExtrinsicObject.length) {
        tmpEo = currDoc.RegistryObjectList.ExtrinsicObject[idxEo];
        idxSlot = 0;
        while (slotValue == null && idxSlot < tmpEo.Slot.length) {
            slot = tmpEo.Slot[idxSlot];
            if (slot.name == 'accessionNumber') {
                eo = tmpEo;
                print("slot found ");
                //currDoc.RegistryObjectList.ExtrinsicObject[idxEo]
                slotValue = slot.ValueList.Value[0].content;
                //currDoc.RegistryObjectList.ExtrinsicObject[idxEo].Slot[idxSlot].name = 'referenceIdList';
                slotTemplate.ValueList.Value[0].content = slotValue;
                currDoc.RegistryObjectList.ExtrinsicObject[idxEo].Slot.push(slotTemplate);
                var res = db.submission.replaceOne({'_id' : currDoc._id}, currDoc);
                //print(JSON.stringify(res));
            }
            idxSlot = idxSlot + 1;
        }
        idxEo = idxEo + 1;
    }
}
print("end conversion");
