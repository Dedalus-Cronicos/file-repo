db.x1v1_configuration.deleteMany({key : "ConsentCollector"});
db.x1v1_configuration.insertOne(ConsentCollector);


