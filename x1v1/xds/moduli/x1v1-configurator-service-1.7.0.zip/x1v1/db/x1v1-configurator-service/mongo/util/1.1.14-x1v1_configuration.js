db.x1v1_configuration.deleteMany({key : "PatientSynoptic"});
db.x1v1_configuration.insertOne(PatientSynoptic);