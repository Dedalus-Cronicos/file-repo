db.subscriber.updateMany(
   {'name':'consentPeople'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'consentSTU3'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'consentAudit'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'AuditEventSTU3'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'sharingContextAudit'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ITI_18'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ITI_41'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ITI_42'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ITI_43'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ITI_57'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ITI_62'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'auth-003'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'auth-005'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'auth-006'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ds_login_password_expired'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ds_login_user_unknown'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ds_login_wrong_password'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ds_login'},
   { $set: { "gateway" : false}}
);

db.subscriber.updateMany(
   {'name':'ds_logout'},
   { $set: { "gateway" : false}}
);

