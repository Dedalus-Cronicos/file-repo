db.subscriber.deleteMany({name : "consentPeople"});
db.subscriber.insertOne(consentPeople);

db.subscriber.deleteMany({name : "consentSTU3"});
db.subscriber.insertOne(consentSTU3);


db.subscriber.deleteMany({name : "consentAudit"});
db.subscriber.insertOne(consentAudit);

db.subscriber.deleteMany({name : "AuditEventSTU3"});
db.subscriber.insertOne(auditEventSTU3);

db.subscriber.deleteMany({name : "sharingContextAudit"});
db.subscriber.insertOne(sharingContextAudit);

db.subscriber.deleteMany({name : "ITI_18"});
db.subscriber.insertOne(ITI_18);

db.subscriber.deleteMany({name : "ITI_41"});
db.subscriber.insertOne(ITI_41);

db.subscriber.deleteMany({name : "ITI_42"});
db.subscriber.insertOne(ITI_42);

db.subscriber.deleteMany({name : "ITI_43"});
db.subscriber.insertOne(ITI_43);

db.subscriber.deleteMany({name : "ITI_57"});
db.subscriber.insertOne(ITI_57);

db.subscriber.deleteMany({name : "ITI_62"});
db.subscriber.insertOne(ITI_62);

db.subscriber.deleteMany({name : "auth-003"});
db.subscriber.insertOne(auth_003);

db.subscriber.deleteMany({name : "auth-005"});
db.subscriber.insertOne(auth_005);

db.subscriber.deleteMany({name : "auth-006"});
db.subscriber.insertOne(auth_006);


db.subscriber.deleteMany({name : "ds_login_password_expired"});
db.subscriber.insertOne(ds_login_password_expired);

db.subscriber.deleteMany({name : "ds_login_user_unknown"});
db.subscriber.insertOne(ds_login_user_unknown);

db.subscriber.deleteMany({name : "ds_login_wrong_password"});
db.subscriber.insertOne(ds_login_wrong_password);


db.subscriber.deleteMany({name : "ds_login"});
db.subscriber.insertOne(ds_login);


db.subscriber.deleteMany({name : "ds_logout"});
db.subscriber.insertOne(ds_logout);








