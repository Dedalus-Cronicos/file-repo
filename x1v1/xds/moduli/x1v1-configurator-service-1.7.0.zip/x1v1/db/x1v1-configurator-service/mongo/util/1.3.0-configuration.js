
db.configuration.deleteMany({key : "notifyPersistenceConfig"});
db.configuration.insertOne(notifyPersistenceConfig);

db.configuration.deleteMany({key : "jmsConfig"});
db.configuration.insertOne(jmsConfig);