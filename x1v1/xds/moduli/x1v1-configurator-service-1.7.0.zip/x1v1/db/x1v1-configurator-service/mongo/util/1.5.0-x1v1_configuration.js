db.x1v1_configuration.drop()
  