db.subscriber.deleteMany({ name: "AuditEventSTU3" });


db.subscriber.insertOne(auditEventSTU3);

