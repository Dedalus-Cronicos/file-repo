load("util/definition/def-deprecated.js");
load("util/definition/def-subscriber.js");
load("util/1.6.0-subscriber.js");

db.script_version.drop();
db.script_version.insertOne({ key: "x1v1-configurator", version : "1.6.0", date: new Date() });