load("util/definition/def-deprecated.js");
load("util/definition/def-subscriber.js");
load("util/1.5.1-subscriber.js");


db.script_version.drop();
db.script_version.insertOne({ key: "x1v1-configurator", version : "1.5.1", date: new Date() });