var consentPeople_file = fs.readFileSync('util/ftl/consentPeople.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var consentSTU3_file = fs.readFileSync('util/ftl/consentSTU3.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var consentAudit_file = fs.readFileSync('util/ftl/consentAudit.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var sharingContextAudit_file = fs.readFileSync('util/ftl/sharingContextAudit.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var auditEventSTU3_file = fs.readFileSync('util/ftl/auditEventSTU3.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ITI_18_file = fs.readFileSync('util/ftl/AuditEvent-ITI_18.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ITI_41_file = fs.readFileSync('util/ftl/AuditEvent-ITI_41.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ITI_42_file = fs.readFileSync('util/ftl/AuditEvent-ITI_42.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ITI_43_file = fs.readFileSync('util/ftl/AuditEvent-ITI_43.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ITI_57_file = fs.readFileSync('util/ftl/AuditEvent-ITI_57.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ITI_62_file = fs.readFileSync('util/ftl/AuditEvent-ITI_62.ftl', 'utf8' ).replace( /\r\n/g, '\n' );


var auth_003_file = fs.readFileSync('util/ftl/auth-003.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var auth_005_file = fs.readFileSync('util/ftl/auth-005.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var auth_006_file = fs.readFileSync('util/ftl/auth-006.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ds_login_password_expired_file = fs.readFileSync('util/ftl/ds_login_password_expired.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ds_login_user_unknown_file = fs.readFileSync('util/ftl/ds_login_user_unknown.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ds_login_wrong_password_file = fs.readFileSync('util/ftl/ds_login_wrong_password.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ds_login_file = fs.readFileSync('util/ftl/ds_login.ftl', 'utf8' ).replace( /\r\n/g, '\n' );
var ds_logout_file = fs.readFileSync('util/ftl/ds_logout.ftl', 'utf8' ).replace( /\r\n/g, '\n' );


var consentPeople = {
    "name": "consentPeople",
    "contentType": "application/json",
    "url": "http://@mpi@@domain.internal.mpi@@mpi.context@/Consent",
    "status": true,
    "value": consentPeople_file,
    "gateway": false
};

var consentSTU3 = {
    "name": "consentSTU3",
    "contentType": "application/json",
    "url": "http://@fhir@@domain.internal.xds@/x1v1-fhir-clinical/fhir/Consent",
    "status": true,
    "value": consentSTU3_file,
    "gateway": false
};

var consentAudit = {
    "name": "consentAudit",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": consentAudit_file,
    "gateway": false
};

var auditEventSTU3 = {
    "name": "AuditEventSTU3",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": auditEventSTU3_file,
    "gateway": false
};

var sharingContextAudit = {
    "name": "sharingContextAudit",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": sharingContextAudit_file,
    "gateway": false
};

var ITI_18 = {
    "name": "ITI_18",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_18_file,
    "gateway": false
};

var ITI_41 = {
    "name": "ITI_41",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_41_file,
    "gateway": false
};

var ITI_42 = {
    "name": "ITI_42",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_42_file,
    "gateway": false
};

var ITI_43 = {
    "name": "ITI_43",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_43_file,
    "gateway": false
};

var ITI_57 = {
    "name": "ITI_57",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_57_file,
    "gateway": false
};

var ITI_62 = {
    "name": "ITI_62",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_62_file,
    "gateway": false
};

var auth_003 = {
    "name": "auth-003",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": auth_003_file,
    "gateway": false
};

var auth_005 = {
    "name": "auth-005",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": auth_005_file,
    "gateway": false
};

var auth_006 = {
    "name": "auth-006",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": auth_006_file,
    "gateway": false
};

var ds_login_password_expired = {
    "name": "ds_login_password_expired",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ds_login_password_expired_file,
    "gateway": false
};

var ds_login_user_unknown = {
    "name": "ds_login_user_unknown",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ds_login_user_unknown_file,
    "gateway": false
};

var ds_login_wrong_password = {
    "name": "ds_login_wrong_password",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ds_login_wrong_password_file,
    "gateway": false
};

var ds_login = {
    "name": "ds_login",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ds_login_file,
    "gateway": false
};

var ds_logout = {
    "name": "ds_logout",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ds_logout_file,
    "gateway": false
};



