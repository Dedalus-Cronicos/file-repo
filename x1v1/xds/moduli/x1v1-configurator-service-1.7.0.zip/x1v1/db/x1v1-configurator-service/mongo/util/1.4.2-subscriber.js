db.subscriber.deleteMany({ name: "AuditEventSTU3" });
db.subscriber.deleteMany({ name: "auth-003" });
db.subscriber.deleteMany({ name: "auth-005" });
db.subscriber.deleteMany({ name: "auth-006" });
db.subscriber.deleteMany({ name: "ds_login_password_expired" });
db.subscriber.deleteMany({ name: "ds_login_user_unknown" });
db.subscriber.deleteMany({ name: "ds_login_wrong_password" });
db.subscriber.deleteMany({ name: "ds_login" });
db.subscriber.deleteMany({ name: "ds_logout" });

db.subscriber.insertOne(auditEventSTU3);
db.subscriber.insertOne(auth_003);
db.subscriber.insertOne(auth_005);
db.subscriber.insertOne(auth_006);
db.subscriber.insertOne(ds_login_password_expired);
db.subscriber.insertOne(ds_login_user_unknown);
db.subscriber.insertOne(ds_login_wrong_password);
db.subscriber.insertOne(ds_login);
db.subscriber.insertOne(ds_logout);
