db.subscriber.deleteMany({ name: "consentPeople" });
db.subscriber.deleteMany({ name: "consentSTU3" });
db.subscriber.deleteMany({ name: "consentAudit" });
db.subscriber.deleteMany({ name: "sharingContextAudit" });
db.subscriber.deleteMany({ name: "AuditEventSTU3" });
db.subscriber.deleteMany({ name: "ITI_18" });
db.subscriber.deleteMany({ name: "ITI_41" });
db.subscriber.deleteMany({ name: "ITI_42" });
db.subscriber.deleteMany({ name: "ITI_43" });
db.subscriber.deleteMany({ name: "ITI_57" });
db.subscriber.deleteMany({ name: "ITI_62" });

db.subscriber.insertOne(consentPeople);
db.subscriber.insertOne(consentSTU3);
db.subscriber.insertOne(consentAudit);
db.subscriber.insertOne(sharingContextAudit);
db.subscriber.insertOne(auditEventSTU3);
db.subscriber.insertOne(ITI_18);
db.subscriber.insertOne(ITI_41);
db.subscriber.insertOne(ITI_42);
db.subscriber.insertOne(ITI_43);
db.subscriber.insertOne(ITI_57);
db.subscriber.insertOne(ITI_62);
  