db.x1v1_configuration.createIndex({ key: 1 });
db.x1v1_configuration.drop();
db.x1v1_configuration.insertOne(xvalue_task_manager);
db.x1v1_configuration.insertOne(ConsentCollector);
  