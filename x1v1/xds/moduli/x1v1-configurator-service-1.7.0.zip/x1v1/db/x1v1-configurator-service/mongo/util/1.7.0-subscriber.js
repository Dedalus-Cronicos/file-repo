db.subscriber.deleteMany({name : "consentSTU3"});
db.subscriber.insertOne(consentSTU3);

