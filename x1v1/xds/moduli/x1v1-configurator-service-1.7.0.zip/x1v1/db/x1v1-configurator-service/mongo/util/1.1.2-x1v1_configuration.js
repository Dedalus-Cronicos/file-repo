db.x1v1_configuration.deleteMany({key : "ConsentCollector"});
db.x1v1_configuration.deleteMany({key : "xvalue-task-manager"});
db.x1v1_configuration.insertOne(ConsentCollector);
db.x1v1_configuration.insertOne(xvalue_task_manager);
  