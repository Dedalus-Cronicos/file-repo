db.createCollection("DS_Access");
db.DS_Access.createIndex( {"code":1,"clientId":1}, {"name":"pk_idx", unique: true } )
db.DS_Access.createIndex( {"sid":1},{"name":"sid_idx", unique: true} );
db.DS_Access.createIndex( {"createdOn":1},{"name":"createdon_idx", unique: false} );
db.DS_Access.createIndex( {"modifiedOn":1},{"name":"modifiedon_idx", unique: false} );

db.createCollection("DS_RegisteredClient");
db.DS_RegisteredClient.createIndex( {"clientId":1}, {"name":"clientid_idx", unique: true } );

db.createCollection("DS_Kid");
db.DS_Kid.createIndex( {"kid":1}, {"name":"kid_idx", unique: true } );

// insert default
db.getCollection('DS_RegisteredClient').insert(
    {
         "clientId" : "123456",
         "nameIdentifier" : "CodicesTest",
         "secret" : "FoqZ1Ju4GS2u$iNC",
         "userRoleProvisioningURL" : "http://dd-xvaluedev.dedalus.lan:58080/people.auth/rest/Profile",
         "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
         "serverLocationUri" : "http://192.168.215.134:8080",
         "queryBy" : "username",
         "subjectAA" : "CF"
    }
);

// insert default
db.getCollection('DS_RegisteredClient').insert(
    {
         "clientId" : "7777777",
         "nameIdentifier" : "C7Test",
         "secret" : "CdRHjXD7J$M8s2xN",
         "userRoleProvisioningURL" : "http://hpdx-8080-tcp-@domain.app@/hpdx/api/auth/Profile",
         "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
         "serverLocationUri" : "http://hpdx-8080-tcp-@domain.app@",
         "queryBy" : "username",
         "subjectAA" : "CF"
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
         "clientId" : "ODufuxmcA5ECdcMF",
         "nameIdentifier" : "Consent-collector",
         "secret" : "9$APrIT04w8GtZM7",
         "userRoleProvisioningURL" : "http://ax1v1.localdomain:8080/people-auth/rest/Profile",
         "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
         "serverLocationUri" : "https://ax1v1.localdomain",
         "queryBy" : "username",
         "subjectAA" : "CF"
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
         "clientId" : "wByuGJB1ZrymbFlU",
         "nameIdentifier" : "PATSYN",
         "secret" : "AF6gmAN3$6zhdISh",
         "userRoleProvisioningURL" : "http://ax1v1.localdomain:8080/people-auth/rest/Profile",
         "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
         "serverLocationUri" : "https://ax1v1.localdomain",
         "queryBy" : "username",
         "subjectAA" : "CF"
    }
);



// insert kid (lecce)
db.getCollection('DS_Kid').insert(
   {
       kid : "YTViMzE=",
       owner : "lecce_pkcs8_key",
       filename : "lecce_pkcs8_key",
       key : BinData(0,"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCl5gH8oxkwgDK/4jdisw1p0/L9RiR1uOzWXVtN+qdWCUTVgOeIp2GgCYi3E0i9nAN4tuOEA0DBSMxRSJ6UXjKfefB7ECL9jbvfdP4ripBG4/2KvVRkfF+CyrzMw672KC4j9DekL8sfl3lUhYo5BWPrG1itLWNSgtrdw24IFOMUHQIDAQAB")
   }
);

// insert kid (WSO2)
db.getCollection('DS_Kid').insert(
    {
        kid : "YWFjYjU=",
        owner : "WSO2.public.pkcs8",
        filename : "WSO2.public.pkcs8",
        key : BinData(0,"MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQAB")
    }
);
