
db.createCollection("schema_version");

db.getCollection("schema_version").insert(
    {
        "major" : "3",
        "minor" : "8",
        "patch" : "0",
        "tag" : "xdiscovery-service",
        "revision" : 0,
        "last_change" : ISODate("2020-07-02T16:53:27.604+02:00"),
        "description" : ""
    }
);

db.getCollection('DS_RegisteredClient').update({"clientId":"ODufuxmcA5ECdcMF"},{$set:{"userRoleProvisioningURL":"https://@mpi@@domain.app@/people-auth/rest/Profile"}});

db.getCollection('DS_RegisteredClient').update({"clientId":"wByuGJB1ZrymbFlU"},{$set:{"userRoleProvisioningURL":"https://@mpi@@domain.app@/people-auth/rest/Profile"}});

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "MLnUN1cQOICT5773",
          "secret" : "578zpibbWkn$qXF1",
          "serverLocationUri" : "https://@mpi@@domain.web@",
          "owner" : "PWP",
          "nameIdentifier" : "PWP",
          "userRoleProvisioningURL" : "https://@mpi@@domain.app@/people-auth/rest/Profile",
          "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
          "queryBy" : "username",
          "subjectAA" : "CF"
    }
);
