
db.createCollection("schema_version");

db.getCollection("schema_version").insert(
    {
        "major" : "4",
        "minor" : "1",
        "patch" : "2",
        "tag" : "xdiscovery-service",
        "revision" : 0,
        "last_change" : ISODate("2022-07-28T12:24:27.604+02:00"),
        "description" : ""
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "WegNtRbb3GyhAQEY",
          "secret" : "hL6wwad39O3huQl5",
          "serverLocationUri" : "http://garsia-gateway-8443-tcp-@domain.app@",
          "owner" : "garsia-gateway",
          "nameIdentifier" : "garsia-gateway"
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "iRRh5d745NalXOW8",
          "secret" : "jq9t2ZsgNoalmTfg",
          "serverLocationUri" : "https://gateway-@domain.app@/dc4h/",
          "owner" : "gravitee",
          "nameIdentifier" : "gravitee",
		  "userRoleProvisioningURL" : "http://gateway-@domain.app@/dc4h/hpdx/api/auth/Profile",
          "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
          "queryBy" : "username",
          "subjectAA" : "CF"
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "X1jH0jAPj7SITeDN",
          "secret" : "wnTTSRz7ToHum0Sk",
          "serverLocationUri" : "http://hpdx-8080-tcp-@domain.app@/hpdx",
          "owner" : "HPDx",
          "nameIdentifier" : "HPDx",
		  "userRoleProvisioningURL" : "http://hpdx-8080-tcp-@domain.app@/hpdx/api/auth/Profile",
          "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
          "queryBy" : "username",
          "subjectAA" : "HPDX"
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "amGjnx2kqSB3X6LR",
          "secret" : "elCuxdT0sCP2Fb4L",
          "serverLocationUri" : "https://audit-8080-tcp-@domain.app@/X4H-arr-web/",
          "owner" : "audit",
          "nameIdentifier" : "audit",
		  "userRoleProvisioningURL" : "http://hpdx-8080-tcp-@domain.app@/hpdx/api/auth/Profile",
          "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
          "queryBy" : "username",
          "subjectAA" : "CF"
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "F5BFYCSMd4b1pQCW",
          "secret" : "YN2IOdbgnTqkDb7M",
          "serverLocationUri" : "https://mci-manager-8080-tcp-@domain.app@/mci-manager/",
          "owner" : "mci-manager",
          "nameIdentifier" : "mci-manager",
		  "userRoleProvisioningURL" : "http://hpdx-8080-tcp-@domain.app@/hpdx/api/auth/Profile",
          "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
          "queryBy" : "username",
          "subjectAA" : "CF"
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "fLdkGn7cD3HEkfMu",
          "secret" : "2coFjtQFSCiaQDzX",
          "serverLocationUri" : "http://notification-engine-8080-tcp-@domain.app@",
          "owner" : "NotEn",
          "nameIdentifier" : "NotEn",
		  "userRoleProvisioningURL" : "http://hpdx-8080-tcp-@domain.app@/hpdx/api/auth/Profile",
          "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
          "queryBy" : "username",
          "subjectAA" : "CF"
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "qwaL8jKWeDE1AXlY",
          "secret" : "NBe$3NPM47DCrnO8",
          "serverLocationUri" : "http://consent-8080-tcp-@domain.app@",
          "owner" : "consent",
          "nameIdentifier" : "consent",
		  "userRoleProvisioningURL" : "http://hpdx-8080-tcp-@domain.app@/hpdx/api/auth/Profile",
          "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
          "queryBy" : "username",
          "subjectAA" : "CF"
    }
);


db.getCollection('DS_Template').drop();
