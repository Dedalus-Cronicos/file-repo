
db.createCollection("schema_version");

db.getCollection("schema_version").insert(
    {
        "major" : "4",
        "minor" : "1",
        "patch" : "2",
        "tag" : "xdiscovery-service",
        "revision" : 0,
        "last_change" : ISODate("2022-07-28T12:24:27.604+02:00"),
        "description" : ""
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "WegNtRbb3GyhAQEY",
          "secret" : "hL6wwad39O3huQl5",
          "serverLocationUri" : "https://garsia-gateway-8443-tcp-cronicos-desa.apps.lab.okd4.local",
          "owner" : "garsia-gateway",
          "nameIdentifier" : "garsia-gateway"
    }
);

db.getCollection('DS_Template').drop();
