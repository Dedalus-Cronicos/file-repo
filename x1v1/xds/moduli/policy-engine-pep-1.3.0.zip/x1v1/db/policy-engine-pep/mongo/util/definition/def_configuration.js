var jwtAdditionalJPathAttributes = {
    "property": "jwtAdditionalJPathAttributes",
    "value": {
        "enable": true,
        "attributes": [{
                "key": "jwtPurposeOfUse",
                "jpath": "$.purposeOfUse"
            }
        ]
    }
};

var registryResponseConfig = {
    "property": "registry.response.config",
    "value": {
        "showFilteredInfo": true,
        "useSingleEntry": true
    }
};

var XacmlResponseProcessorAttributeDefinition = {
    property: "XacmlResponseProcessorAttributeDefinition",
    value: [{
            attribute_environment: ENVIRONMENT_XACML
        }, {
            attribute_uniqueid: ID_ATTRIBUTO_UNIQUEID
        }, {
            attribute_policy_id: ID_ATTRIBUTO_POLICY
        }
    ]
};

var language = {
    property: "language",
    value: "it"
};

var samlConditionGraceTime = {
    property: "saml.condition.grace.time",
    value: "2000"
};

var cacheTimeoutInMillis = {
    property: "cache.timeout.in.millis",
    value: "3600000"
};

var roleCitizen = {
    property: "role.citizen",
    value: "X1V1_ASSISTITO"
};

var documentUniqueIdDiscoveryName = {
    property: "document.unique.id.discovery",
    value: "documentUniqueIdDiscovery"
};

var documentConsentInsertInvalidConditionName = {
    property: "document.consent.insert.invalid.condition",
    value: "documentConsentInsertInvalidCondition"
};

var roleAttributeIdentifier = {
    property: "role.xacml.atribute.identifier",
    value: XACML_PREFIX + "xacml:3.0:subject:subject-role"
};

var policyAttributeIdentifier = {
    property: "policy.xacml.atribute.identifier",
    value: XACML_PREFIX + "xacml:3.0:policy:policyId"
};

var documentPatientIdDiscoveryName = {
    property: "document.patient.id.discovery",
    value: "documentPatientId"
};

var userIdDiscoveryName = {
    property: "user.id.discovery",
    value: "userIdDiscovery"
};

var userHealthcareStructureDiscoveryName = {
    property: "user.healthcare.structure.discovery",
    value: "userHealthcareStructureDiscovery"
};

var samlConfig = {
    property: "saml.config",
    value: {
        issuers: [{
                name: "x1v1-sts",
                roleAttributeName: "urn:deda-sso:attribute/role",
                roleMultipleAttributeValue: true,
                roleAttributeNameQualifier: "AttributeNamespace",
                roleSeparator: null,
                fiscalCodeAttributeName: "urn:deda-sso:attribute/codiceFiscale",
                fiscalCodeAttributeNameQualifier: "AttributeNamespace"
            }, {
                name: "x1v1-sts-2.0",
                roleAttributeName: "http://wso2.org/claims/role",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "http://wso2.org/claims/codiceFiscale",
                fiscalCodeAttributeNameQualifier: "Name",
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "sp-fse-2",
                roleAttributeName: "ruoli",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "uid",
                fiscalCodeAttributeNameQualifier: "Name",
                base64Certificate: "MIIDdTCCAl2gAwIBAgIEe3+AkDANBgkqhkiG9w0BAQsFADBrMQswCQYDVQQGEwJDVDELMAkGA1UECBMCQ1QxEDAOBgNVBAcTB0NhdGFuaWExEDAOBgNVBAoTB0RlZGFsdXMxEDAOBgNVBAsTB0RlZGFsdXMxGTAXBgNVBAMTEEZhYmlvIEJhcmJhZ2FsbG8wHhcNMTYwMjEwMTAxNTM3WhcNMTcwMjA0MTAxNTM3WjBrMQswCQYDVQQGEwJDVDELMAkGA1UECBMCQ1QxEDAOBgNVBAcTB0NhdGFuaWExEDAOBgNVBAoTB0RlZGFsdXMxEDAOBgNVBAsTB0RlZGFsdXMxGTAXBgNVBAMTEEZhYmlvIEJhcmJhZ2FsbG8wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQCRrayEMbsEJgpiuTFEMjRMdZGn1/9k5/9tK7sg+4HgNX5aB84FuKX15JxHxgQ+Gr4YH3/N+N5maOfj6vBgVWOvfabicXxxwt72Hb04KaAF7sIwB6J6DKFW9YhOs6ouGFcyUiaqADgSrzlAp3d+B/1AGwyeF9XcaCL1nBzmbcYeyF7bfi0izPzVEpYSm0VjUxrZZdteUTbQSRbNd2g+0eT04SHIkWztcKqJFiuAfasPc311QAhQWS8V6JxOoovYtezWb6kB9ByBeGQ3S/ULtuPNk80SEhSKOuP76oEoy+RNtyyATtvOZXiIg8YcytCrHW1f6fbYsekSYRCh3dU3r9HvAgMBAAGjITAfMB0GA1UdDgQWBBTcG2So8XSXkLrdWY2iWPINWniYjDANBgkqhkiG9w0BAQsFAAOCAQEAVKFwuewm5tdwasVw2wfxU6/qoJP9B1yhRLPvCORFVn0vSzn7LnCginaNKV7G9MRtB7/ByrRIoYpOnLyldiHauAikcJ/M/QAIk3L1U6BH44FnPotpx2hRox3m5N1iBe0BX9JPNxH5zQYRnsZ/79Irmf9FdxlOzV2H7zcw9SjiSVBltBqV8AEPgvk6mQVabISOSGm/4gtSBjE1A1AkVekgFLALj1g2JrdDKicnmiT3Ggq/Kc3lliuJR1zZ0tKqMcpxUZoVSAPL2rUNRj+Vyg9kDitRtXrrWVA8l8TrTBMc0VG/OB8AmTKlmJ53VIfqsCzSUGUE0yUfjmbyAF+LdZGz6Q=="
            }, {
                name: "sp-fse",
                roleAttributeName: "ruoli",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "uid",
                fiscalCodeAttributeNameQualifier: "Name"
            }, {
                name: "sp-fse-dema",
                roleAttributeName: "ruoli",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "uid",
                fiscalCodeAttributeNameQualifier: "Name"
            }, {
                name: "x1v1-valve",
                roleAttributeName: "http://wso2.org/claims/role",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "http://wso2.org/claims/codiceFiscale",
                fiscalCodeAttributeNameQualifier: "Name",
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "context-sharing",
                roleAttributeName: "http://wso2.org/claims/role",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "http://wso2.org/claims/codiceFiscale",
                fiscalCodeAttributeNameQualifier: "Name",
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "https://localhost:9443",
                roleAttributeName: "http://wso2.org/claims/role",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "http://wso2.org/claims/codiceFiscale",
                fiscalCodeAttributeNameQualifier: "Name",
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "https://localhost:9443/samlsso",
                roleAttributeName: "http://wso2.org/claims/role",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "http://wso2.org/claims/codiceFiscale",
                fiscalCodeAttributeNameQualifier: "Name",
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "https://loginspid.aruba.it",
                roleMultipleAttributeValue: false,
                fiscalCodeAttributeName: "fiscalNumber",
                fiscalCodeAttributeNameQualifier: "Name",
                validityGraceTimeInMillis: 3600000,
                spidProvided: true
            }, {
                name: "https://spid.intesa.it",
                roleMultipleAttributeValue: false,
                fiscalCodeAttributeName: "fiscalNumber",
                fiscalCodeAttributeNameQualifier: "Name",
                validityGraceTimeInMillis: 3600000,
                spidProvided: true
            }, {
                name: "https://identity.infocert.it",
                roleMultipleAttributeValue: false,
                fiscalCodeAttributeName: "fiscalNumber",
                fiscalCodeAttributeNameQualifier: "Name",
                validityGraceTimeInMillis: 3600000,
                spidProvided: true
            }, {
                name: "https://idp.namirialtsp.com/idp",
                roleMultipleAttributeValue: false,
                fiscalCodeAttributeName: "fiscalNumber",
                fiscalCodeAttributeNameQualifier: "Name",
                validityGraceTimeInMillis: 3600000,
                spidProvided: true
            }, {
                name: "https://idp.namirialtsp.com/idp",
                roleMultipleAttributeValue: false,
                fiscalCodeAttributeName: "fiscalNumber",
                fiscalCodeAttributeNameQualifier: "Name",
                validityGraceTimeInMillis: 3600000,
                spidProvided: true
            }, {
                name: "https://posteid.poste.it",
                roleMultipleAttributeValue: false,
                fiscalCodeAttributeName: "fiscalNumber",
                fiscalCodeAttributeNameQualifier: "Name",
                validityGraceTimeInMillis: 3600000,
                spidProvided: true
            }, {
                name: "https://spid.register.it",
                roleMultipleAttributeValue: false,
                fiscalCodeAttributeName: "fiscalNumber",
                fiscalCodeAttributeNameQualifier: "Name",
                validityGraceTimeInMillis: 3600000,
                spidProvided: true
            }, {
                name: "https://identity.sieltecloud.it",
                roleMultipleAttributeValue: false,
                fiscalCodeAttributeName: "fiscalNumber",
                fiscalCodeAttributeNameQualifier: "Name",
                validityGraceTimeInMillis: 3600000,
                spidProvided: true
            }, {
                name: "https://login.id.tim.it/affwebservices/public/saml2sso",
                roleMultipleAttributeValue: false,
                fiscalCodeAttributeName: "fiscalNumber",
                fiscalCodeAttributeNameQualifier: "Name",
                validityGraceTimeInMillis: 3600000,
                spidProvided: true
            }, {
                name: "https://identitycl.infocert.it",
                roleMultipleAttributeValue: false,
                fiscalCodeAttributeName: "fiscalNumber",
                fiscalCodeAttributeNameQualifier: "Name",
                validityGraceTimeInMillis: 3600000,
                spidProvided: true,
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "x1v1-discovery-jwt",
                roleAttributeName: "http://wso2.org/claims/role",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "identifier",
                fiscalCodeAttributeNameQualifier: "Name",
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "document-viewer-fb",
                roleAttributeName: "http://wso2.org/claims/role",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "http://wso2.org/claims/codiceFiscale",
                fiscalCodeAttributeNameQualifier: "Name"
            }, {
                name: "attribute-authority",
                roleAttributeName: "urn:dedalus:aa:claim:subject:role",
                roleMultipleAttributeValue: false,
                roleAttributeNameQualifier: "Name",
                roleSeparator: ",",
                fiscalCodeAttributeName: "http://wso2.org/claims/codiceFiscale",
                fiscalCodeAttributeNameQualifier: "Name"
            }
        ]
    }
};

var jwtConfig = {
    property: "jwt.config",
    value: {
        issuers: [{
                name: "x1v1-jwt",
                roleAttributeName: "role",
                roleMultipleAttributeValue: true,
                roleSeparator: null,
                fiscalCodeAttributeName: "codiceFiscale",
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "x1v1-jwt-2.0",
                roleAttributeName: "roles",
                roleMultipleAttributeValue: true,
                roleSeparator: null,
                fiscalCodeAttributeName: "sub",
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "x1v1-valve",
                roleAttributeName: "http://wso2.org/claims/role",
                roleMultipleAttributeValue: true,
                roleSeparator: null,
                fiscalCodeAttributeName: "http://wso2.org/claims/codiceFiscale",
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "x1v1-discovery-jwt",
                roleAttributeName: "roles",
                roleMultipleAttributeValue: true,
                roleSeparator: null,
                fiscalCodeAttributeName: "sub",
                base64Certificate: "MIICsDCCAhmgAwIBAgICEB0wDQYJKoZIhvcNAQEFBQAwZzELMAkGA1UEBhMCSVQxEDAOBgNVBAgTB0ZpcmVuemUxEDAOBgNVBAcTB0ZpcmVuemUxFDASBgNVBAoTC0RlZGFsdXMgU3BhMQ0wCwYDVQQLEwRYMVYxMQ8wDQYDVQQDEwZjYXgxdjEwHhcNMTQwMjE0MTUzMDMxWhcNMjQwMjEyMTUzMDMxWjBXMQswCQYDVQQGEwJJVDEQMA4GA1UECBMHRmlyZW56ZTEUMBIGA1UEChMLRGVkYWx1cyBTcGExDTALBgNVBAsTBFgxVjExETAPBgNVBAMTCEVTQi1YMVYxMIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC4BngOxvMmvj28E+vaqrJHnkk0MXbq3Xbxgks0UvNFCiO0xWeESM0Oudop0lMQh9eAO9xhQlcKzk4zEd3goLkhv8w7Gp8D6NMiWc7X4aWioQrJ5nKs6k4GimtTd+bqC+DlE928+6hNep368B6Tlnd57/PsoW1jlyuEIBI7x0ktuQIDAQABo3sweTAJBgNVHRMEAjAAMCwGCWCGSAGG+EIBDQQfFh1PcGVuU1NMIEdlbmVyYXRlZCBDZXJ0aWZpY2F0ZTAdBgNVHQ4EFgQUaG9fGudNSmaM6lJOk1XLFbW7SucwHwYDVR0jBBgwFoAU0524vF41DJFJJfdiHZPXSJbiMiUwDQYJKoZIhvcNAQEFBQADgYEAcfqN87LVTwVWrOyhV9Zjo5OpNhJom97ZrhWH4AokdWL3e8DFH91yrV2DmrmlLIE9xKCA7HJ9F5P6+WEG+ngiXcLcEquTCBwy3HSCCJtP9um5RVJBa8a5+Qz4mHpNa2q9QSWjek2WqPYYokOKuu/RPRpK7kMEeXMJyuC34cBoRHM="
            }, {
                name: "xaudit",
                roleAttributeName: "roles",
                roleMultipleAttributeValue: true,
                roleSeparator: null,
                fiscalCodeAttributeName: "sub",
                base64Certificate: "MIIDWTCCAkGgAwIBAgIEbkHF8TANBgkqhkiG9w0BAQsFADBdMQswCQYDVQQGEwJJVDELMAkGA1UECBMCRkkxCzAJBgNVBAcTAklUMRAwDgYDVQQKEwdEZWRhbHVzMRAwDgYDVQQLEwdEZWRhbHVzMRAwDgYDVQQDEwdEZWRhbHVzMB4XDTIxMDQxNTEwMzYxNloXDTIyMDQxMDEwMzYxNlowXTELMAkGA1UEBhMCSVQxCzAJBgNVBAgTAkZJMQswCQYDVQQHEwJJVDEQMA4GA1UEChMHRGVkYWx1czEQMA4GA1UECxMHRGVkYWx1czEQMA4GA1UEAxMHRGVkYWx1czCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAIF3twbO/OxHNvwR/yj/ZufqAx93/KNcKaHeL4yTFXb6duO6k/DGuNoV6znBfdKtydLzxw3HAYFP+OhIrhFU7bGxIZIE2vJ25PnGQ5rqKXuszLBhJEJtc244V52BnrV7LEQyJrQ1oj7jEvbk479ztjLMQNOmeh/m00do9RTG2MdfG5gHF4BJ9xLI9lx9VZN5vvT7Po7ZvDsCBGiBjVfcHnqrfoBqDkHcksVo90kocsEUcXKwS9AJ6MWVlEIBc7TPMwotmR0Ec2RTYgsJwtwHlqwlOZfu92/5kmkL8dvmtDHodcjoYKdWIp/ng9a/Y2LjM9aof4b2OtPAMEzWc/AKo38CAwEAAaMhMB8wHQYDVR0OBBYEFIHJOnreqZV8eT6tp3CWdjCmWzl2MA0GCSqGSIb3DQEBCwUAA4IBAQBLDsKaDvD9jIETzRbNvhbIWykpl1S5p/45qkBqVsWC5SdkFLiZPV9k0DSsylKIG6hZP2UQ/afUCE6iDkzQox6BKHlcw+o3EX+nGDkfvs1oTe/NKIkgmY2hiz73XVk2sGVNElZlzdIEh02sfj1gfeN5uP8UhfQ/DDNs10gOHWESgOthljhNIEmM5qH3RHSOJZV4ueqdOeFS1kffY3PZD7CwIezGoPULHGqgHetESw8/q0xOxy1rZkKPfaLUck38gP9LT9TH4fOYlJaFAv3mzy4TBfLlCI3Fa0i0P3ZAsDUM/LZGNb6k5CGB84md5HdwgSKR8XJkpEzlveZJiJQ2e4ze"
            }
        ]
    }
};

var connectionTimeout = {
    property: "connection.timeout",
    value: "10000"
};

var affinityDomainFilePath = {
    property: "affinity.domain.filepath",
    value: "file:///@affinitydomainpath@/codes.xml"
};

var jwtLeeway = {
    property: "jwt.leeway",
    value: "0"
};

var documentConsentRemoveConditionName = {
    property: "document.consent.remove.condition",
    value: "documentConsentRemoveCondition"
};