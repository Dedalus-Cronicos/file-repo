var atnaBean_ITI18 = {
    "enabled": false,
    _id: "atnaBean_ITI18",
    when: "ITI_18",
    userIdSrc: atnaBeanSubjectNameCF,
    ntAccessPointIdSrc: fromEndpoint,
    addressingTo: addressingTo,
    ntAccessPointIdDest: toEndpoint,
    evaluateParticipantObjQry: true,
    eventTypeCode: metadataTypeCode,
    eventTypeDisplay: metadataTypeDisplay,
    eventSubTypeCode: searchSubType,
    eventSubTypeDisplay: searchSubType,
    eventSource: xvalueGatewayEvent,
    purposeOfUseCode: purposeOfUseCode,
    purposeOfUseDisplay: purposeOfUseDisplay,
    participantObjDocumentIds: participantObjDocumentIds_OUT,
    participantObjSubmissionIds: participantObjSubmissionIds_OUT,
    participantObjIdPat: participantObjPatientIds_IN,
    participantObjPatientIds: participantObjPatientIds_OUT
};

var atnaBean_ITI41 = {
    "enabled": false,
    _id: "atnaBean_ITI41",
    when: "ITI_41",
    userIdSrc: atnaBeanSubjectNameCF,
    ntAccessPointIdSrc: fromEndpoint,
    addressingTo: addressingTo,
    participantObjIdPat: submissionSetPatientId,
    eventTypeCode: documentTypeCode,
    eventTypeDisplay: documentTypeDisplay,
    eventSubTypeCode: createReplaceSubType,
    eventSubTypeDisplay: createReplaceSubType,
    eventSource: xvalueGatewayEvent,
    organizationId: organizationId,
    organizationName: organizationName,
    organizationTypeCode: organizationTypeCodeHA,
    purposeOfUseCode: purposeOfUseCode,
    purposeOfUseDisplay: purposeOfUseDisplay,
    participantObjDocumentIds: participantObjDocumentIds_IN,
    participantObjSubmissionIds: participantObjSubmissionIds_IN
};

var atnaBean_ITI42 = {
    "enabled": false,
    _id: "atnaBean_ITI42",
    when: "ITI_42",
    userIdSrc: atnaBeanSubjectNameCF,
    ntAccessPointIdSrc: fromEndpoint,
    addressingTo: addressingTo,
    participantObjIdPat: submissionSetPatientId,
    eventTypeCode: metadataTypeCode,
    eventTypeDisplay: metadataTypeDisplay,
    eventSubTypeCode: createReplaceSubType,
    eventSubTypeDisplay: createReplaceSubType,
    eventSource: xvalueGatewayEvent,
    organizationId: organizationId,
    organizationName: organizationName,
    organizationTypeCode: organizationTypeCodeHA,
    purposeOfUseCode: purposeOfUseCode,
    purposeOfUseDisplay: purposeOfUseDisplay,
    participantObjDocumentIds: participantObjDocumentIds_IN,
    participantObjSubmissionIds: participantObjSubmissionIds_IN
};

var atnaBean_ITI43 = {
    "enabled": false,
    _id: "atnaBean_ITI43",
    when: "ITI_43",
    userIdSrc: atnaBeanSubjectNameCF,
    ntAccessPointIdSrc: fromEndpoint,
    addressingTo: addressingTo,
    eventTypeCode: documentTypeCode,
    eventTypeDisplay: documentTypeDisplay,
    eventSubTypeCode: readSubType,
    eventSubTypeDisplay: readSubType,
    eventSource: xvalueGatewayEvent,
    purposeOfUseCode: purposeOfUseCode,
    purposeOfUseDisplay: purposeOfUseDisplay,
    participantObjDocumentIds: participantObjDocumentIdsForRetrieve_IN
};

var atnaBean_ITI57 = {
    "enabled": false,
    _id: "atnaBean_ITI57",
    when: "ITI_57",
    userIdSrc: atnaBeanSubjectNameCF,
    ntAccessPointIdSrc: fromEndpoint,
    addressingTo: addressingTo,
    participantObjIdPat: submissionSetPatientId,
    eventTypeCode: metadataTypeCode,
    eventTypeDisplay: metadataTypeDisplay,
    eventSubTypeCode: updateSubType,
    eventSubTypeDisplay: updateSubType,
    eventSource: xvalueGatewayEvent,
    organizationId: organizationId,
    organizationName: organizationName,
    organizationTypeCode: organizationTypeCodeHA,
    purposeOfUseCode: purposeOfUseCode,
    purposeOfUseDisplay: purposeOfUseDisplay,
    participantObjDocumentIds: participantObjDocumentIds_IN,
    participantObjSubmissionIds: participantObjSubmissionIds_IN
};

var atnaBean_ITI62 = {
    "enabled": false,
    _id: "atnaBean_ITI62",
    when: "ITI_62",
    userIdSrc: atnaBeanSubjectNameCF,
    ntAccessPointIdSrc: fromEndpoint,
    addressingTo: addressingTo,
    eventTypeCode: metadataTypeCode,
    eventTypeDisplay: metadataTypeDisplay,
    eventSubTypeCode: deleteSubType,
    eventSubTypeDisplay: deleteSubType,
    eventSource: xvalueGatewayEvent,
    purposeOfUseCode: purposeOfUseCode,
    purposeOfUseDisplay: purposeOfUseDisplay,
    participantObjDocumentIds: participantObjDocumentEntryIds_IN
};

var atnaBean_ITI86 = {
    "enabled": false,
    _id: "atnaBean_ITI86",
    when: "ITI_86",
    userIdSrc: atnaBeanSubjectNameCF,
    ntAccessPointIdSrc: fromEndpoint,
    addressingTo: addressingTo,
    eventTypeCode: documentTypeCode,
    eventTypeDisplay: documentTypeDisplay,
    eventSubTypeCode: deleteSubType,
    eventSubTypeDisplay: deleteSubType,
    eventSource: xvalueGatewayEvent,
    purposeOfUseCode: purposeOfUseCode,
    purposeOfUseDisplay: purposeOfUseDisplay,
    participantObjDocumentIds: participantObjDocumentsIds_IN
};