db.mongodb_datasource.remove({alias: "ADT_DATASOURCE"});
db.mongodb_datasource.remove({alias: "ARRIETTY_DATASOURCE"});
db.mongodb_datasource.remove({alias: "PM_CONSENT_ENGINE_DATASOURCE"});

db.mongodb_datasource.insert(ADT_DATASOURCE);
db.mongodb_datasource.insert(ARRIETTY_DATASOURCE);
db.mongodb_datasource.insert(PM_CONSENT_ENGINE_DATASOURCE);