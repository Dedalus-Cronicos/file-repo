db.datasources.remove({alias: "LHA_DATASOURCE"});

db.datasources.insert(LHA_DATASOURCE);