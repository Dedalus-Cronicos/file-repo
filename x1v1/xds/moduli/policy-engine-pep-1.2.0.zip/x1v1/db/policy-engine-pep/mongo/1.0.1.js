load("util/definition/def_include_all.js");

load("util/1.0.1-attribute_discovery.js");
load("util/1.0.1-configuration.js");
load("util/1.0.1-response_handler.js");
load("util/1.0.1-to_deprecate.js");