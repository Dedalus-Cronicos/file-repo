load("util/definition/commons.js");

load("util/definition/def_atna_bean_configuration.js");
load("util/definition/def_attribute_discovery.js");
load("util/definition/def_attributes.js");
load("util/definition/def_configuration.js");
load("util/definition/def_datasources.js");
load("util/definition/def_fault_handler.js");
load("util/definition/def_mongodb_datasource.js");
load("util/definition/def_referenceid_discovery.js");
load("util/definition/def_response_handler.js");
load("util/definition/def_stored_list.js");
load("util/definition/def_transaction_dependent_attributes.js");