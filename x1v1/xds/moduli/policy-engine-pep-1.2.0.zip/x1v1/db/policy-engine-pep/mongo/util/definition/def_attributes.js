var documentUniqueIdDiscovery = {
    id: "documentUniqueIdDiscovery",
    discovery: {
        type: "jsonpath",
        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
        returnType: "single"
    }
};
var documentConsentInsertInvalidCondition = {
    id: "documentConsentInsertInvalidCondition",
    value: {
        when: "$..Classification[?(@._classificationScheme == 'urn:uuid:2c6b8cb7-8b2a-4051-b291-b1ae6a575ef4')]._nodeRepresentation",
        postProcessing: "if ($out.length > 1) {for(var index in $out) { if($out[index] == '2.16.840.1.113883.2.9.10.2.4.13.99' || $out[index] == 'P99') {$out = 'true'; break;}}};",
        postProcessingAsUniqueValue: true,
        then: "true",
        otherwise: "false"
    }
};
var healtCareProviderRoleDiscovery = {
    id: "healtCareProviderRoleDiscovery",
    value: {
        fixed: ["mmg_titolare"]
    }
};
var delegatedPatientRoleDiscovery = {
    id: "delegatedPatientRoleDiscovery",
    value: {
        fixed: ["trustee"]
    }
};
var documentPatientId = {
    id: "documentPatientId",
    discovery: xdsPatientIdDiscovery
};
var userIdDiscovery = {
    id: "userIdDiscovery",
    discovery: {
        type: "mc",
        key: "eu.dedalus.xvalue.policyengine.common.subject"
    }
};
var userHealthcareStructureDiscovery = {
    id: "userHealthcareStructureDiscovery",
    discovery: {
        type: "jsonpath",
        expression: "$..Attribute[?(@._FriendlyName == 'codiceStrutturaSanitaria')].AttributeValue.#text",
        returnType: "single",
    }
};
var patientQueryIdDiscovery = {
    "id": "patientQueryIdDiscovery",
    "discovery": {
        "type": "jsonpath",
        "expressions": ["$..Slot[?(@._name == '$XDSDocumentEntryPatientId')].ValueList.Value.#text", "$..Slot[?(@._name == '$XDSSubmissionSetPatientId')].ValueList.Value.#text", "$..Slot[?(@._name == '$XDSFolderPatientId')].ValueList.Value.#text", "$..Slot[?(@._name == '$patientId')].ValueList.Value.#text"],
        "returnType": "single",
        "postProcessingAsUniqueValue": "true",
        "postProcessing": "if($out.length>0){$out = $out[0].replaceAll('\\'','');}",
    }
};
var documentResponseUniqueIdDiscovery = {
    "id": "documentResponseUniqueIdDiscovery",
    "discovery": {
        "type": "jsonpath",
        "expression": "$..DocumentUniqueId.#text",
        "returnType": "single"
    }
};
var folderUniqueIdDiscovery = {
    "id": "folderUniqueIdDiscovery",
    "discovery": {
        "type": "jsonpath",
        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:75df8f67-9973-4fbe-a900-df66cefecc5a')]._value",
        "returnType": "single"
    }
};
var submissionUniqueIdDiscovery = {
    "id": "submissionUniqueIdDiscovery",
    "discovery": {
        "type": "jsonpath",
        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:96fdda7c-d067-4183-912e-bf5ee74998a8')]._value",
        "returnType": "single"
    }
};
var adhocQueryIdDiscovery = {
    "id": "adhocQueryIdDiscovery",
    "discovery": {
        "type": "jsonpath",
        "expression": "$..AdhocQuery._id",
        "returnType": "single"
    }
};
var documentResponseLidDiscovery = {
    "id": "documentResponseLidDiscovery",
    "discovery": {
        "type": "mongo",
        "input": [{
                "id": "documentId",
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..DocumentUniqueId.#text",
                    "returnType": "multiple",
                    "postProcessingAsUniqueValue": true,
                    "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){ret.push($out[i]);} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                }
            }
        ],
        "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:[{documentId}]},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'}, {'$group':{'_id':'$_id','value':{'$first':'$RegistryObjectList.ExtrinsicObject.lid'}}}]",
        "ref": "ARRIETTY_DATASOURCE",
        "database": "@arrietty.mongodb.name@",
        "collection": "submission",
        "returnpath": "value",
        "returnType": "multiple",
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}"
    }
};
var actionValidatorDiscovery = {
    id: "actionValidatorDiscovery",
    discovery: {
        type: "jsonpath",
        expression: "$..Header.Action.#text",
        returnType: "single"
    },
    domain: {
        value: {
            fixed: ["urn:ihe:iti:2007:ProvideAndRegisterDocumentSet-b", "urn:ihe:iti:2007:RegistryStoredQuery", "urn:ihe:iti:2007:RetrieveDocumentSet", "urn:ihe:iti:2010:UpdateDocumentSet", "urn:ihe:iti:2010:DeleteDocumentSet", "urn:ihe:iti:2017:RemoveDocuments"]
        }
    },
    includeInResult: false,
    required: true,
    faultValue: _102
};
