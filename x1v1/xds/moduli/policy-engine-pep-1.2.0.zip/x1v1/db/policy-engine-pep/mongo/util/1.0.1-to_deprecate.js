db.to_deprecate.insert({"type":"attribute_discovery", "value":IN_ARR_GET_1});
db.to_deprecate.insert({"type":"attribute_discovery", "value":IN_ARR_POST_1});
db.to_deprecate.insert({"type":"attribute_discovery", "value":IN_ARR_PUT_1});
db.to_deprecate.insert({"type":"attribute_discovery", "value":IN_ARR_HEAD_1});
db.to_deprecate.insert({"type":"attribute_discovery", "value":IN_ARR_DELETE_1});
db.to_deprecate.insert({"type":"attribute_discovery", "value":OUT_ARR_1});