
db.createCollection("schema_version");

db.getCollection("schema_version").insert(
    {
        "major" : "4",
        "minor" : "1",
        "patch" : "0",
        "tag" : "xdiscovery-service",
        "revision" : 0,
        "last_change" : ISODate("2020-10-09T16:53:27.604+02:00"),
        "description" : ""
    }
);



// update collection with new fields "alias" , "type" and "description"
var collection=db.getCollection('DS_Kid');
collection.find( {'alias':{ $exists: false }} )
.forEach( function(myDoc) {
    //print( "kid: " + myDoc.kid );
    collection.update({"kid":myDoc.kid},{$set:{'alias' : myDoc.kid,'type':'public', 'description':myDoc.owner}});
  }
);

// create Alias Unique Index
db.DS_Kid.createIndex( {"alias":1,"type":1}, {"name":"aliastype_unique_idx", unique: true } );




db.getCollection('DS_Kid').deleteOne({"kid":"YWFjYjU="});

db.getCollection('DS_Kid').deleteOne({"kid":"YTViMzE="});


// insert Discovery Service Private Key
db.getCollection('DS_Kid').insert(
  {
      kid : "N2JjMjg=",
      alias : "DS-Private-Key",
      type : "private",
      description : "Discovery Service Private Key",
      discoveryDefault : true,
      key : BinData (0,"LS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tCk1JSUNlQUlCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQW1Jd2dnSmVBZ0VBQW9HQkFMZ0dlQTdHOHlhK1Bid1QKNjlxcXNrZWVTVFF4ZHVyZGR2R0NTelJTODBVS0k3VEZaNFJJelE2NTJpblNVeENIMTRBNzNHRkNWd3JPVGpNUgozZUNndVNHL3pEc2Fud1BvMHlKWnp0ZmhwYUtoQ3NubWNxenFUZ2FLYTFOMzV1b0w0T1VUM2J6N3FFMTZuZnJ3CkhwT1dkM252OCt5aGJXT1hLNFFnRWp2SFNTMjVBZ01CQUFFQ2dZRUFyd2RRRjFYNG5JZmk5Y2pJMGZENm9nMlYKdUxPM1ZFbVJ3TURaUUlvSTRVaDBqNUlXRkFhZUtueHdXTWkzd29oQldyRVV1ZGk4S3dYdjhMajBuSnFobVM5UApSMkVKcUg1SlVYWmRVWVhNelJNbWwyVW1mL2hQeTRvNm1ad0VVOEM1TE40dER1SDI2bTFMaWpHaUpxTEI4Z3hjCmhVVERKMEgwR1pjZjVjdGtTbEVDUVFEbWYyWHdOTlFjNlpuZldWaHlmaFB2S3FsWVlHS09pMENnTmE1U2o1QkEKSGZPNURrMUp0aXA3NnB5M2Iwc0doY0FNSnd6YWFOU0YwbVFSN3h2OFVKTWxBa0VBekdMS011SWFvenZDaHhLSQpVanBQYzZUV0xzNTNwNi82N29SbXJpeHI2RkZNNXQ3b002dG5vQzNGTWVMZzFUT3RQVFg4UlR0SnpxeVBiVjRpCkxwSzJCUUpBUzBQZWJZbFNtZjVObUhqOFFLYWFxOFlxZGdsREpYaWpLYTFkdHVmYUdwV3RPQWhMaEg1UGNSY3oKQlZMNkZLOG4vcy9oaXBBZ2xYSVY2eVZBNWlzSllRSkJBS05sQXZNRTBYalg2SjhsVUxnMEI1cVRGK3VaZ2cwYgo0Z2JXOEdPai9heGZlcFJEZGUwQXhicEhmUk54cG42cmJuNjE3dlRGL2k1c3c4a1NiVTlBV0tVQ1FRREZENVVKCmxsVjl6eWVvUUFzcWdGR3RYdWREUHFsSHFndjJrUHBXVFJ3dkdEMjl1SkVzRG5WTWdOOUd3UFNNK3ZaU1FDeHEKbkhFV0dLSE1JVzh0WU5FQwotLS0tLUVORCBQUklWQVRFIEtFWS0tLS0tCg==")
  }
);

// insert Discovery Service Public Certificate
db.getCollection('DS_Kid').insert(
  {
      kid : "YWFjYjU=",
      alias : "DS-Public-Cert",
      type : "cert",
      description : "Discovery Service Public Certificate",
      key : BinData (0,"LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUNzRENDQWhtZ0F3SUJBZ0lDRUIwd0RRWUpLb1pJaHZjTkFRRUZCUUF3WnpFTE1Ba0dBMVVFQmhNQ1NWUXgKRURBT0JnTlZCQWdUQjBacGNtVnVlbVV4RURBT0JnTlZCQWNUQjBacGNtVnVlbVV4RkRBU0JnTlZCQW9UQzBSbApaR0ZzZFhNZ1UzQmhNUTB3Q3dZRFZRUUxFd1JZTVZZeE1ROHdEUVlEVlFRREV3WmpZWGd4ZGpFd0hoY05NVFF3Ck1qRTBNVFV6TURNeFdoY05NalF3TWpFeU1UVXpNRE14V2pCWE1Rc3dDUVlEVlFRR0V3SkpWREVRTUE0R0ExVUUKQ0JNSFJtbHlaVzU2WlRFVU1CSUdBMVVFQ2hNTFJHVmtZV3gxY3lCVGNHRXhEVEFMQmdOVkJBc1RCRmd4VmpFeApFVEFQQmdOVkJBTVRDRVZUUWkxWU1WWXhNSUdmTUEwR0NTcUdTSWIzRFFFQkFRVUFBNEdOQURDQmlRS0JnUUM0CkJuZ094dk1tdmoyOEUrdmFxckpIbmtrME1YYnEzWGJ4Z2tzMFV2TkZDaU8weFdlRVNNME91ZG9wMGxNUWg5ZUEKTzl4aFFsY0t6azR6RWQzZ29Ma2h2OHc3R3A4RDZOTWlXYzdYNGFXaW9Rcko1bktzNms0R2ltdFRkK2JxQytEbApFOTI4KzZoTmVwMzY4QjZUbG5kNTcvUHNvVzFqbHl1RUlCSTd4MGt0dVFJREFRQUJvM3N3ZVRBSkJnTlZIUk1FCkFqQUFNQ3dHQ1dDR1NBR0crRUlCRFFRZkZoMVBjR1Z1VTFOTUlFZGxibVZ5WVhSbFpDQkRaWEowYVdacFkyRjAKWlRBZEJnTlZIUTRFRmdRVWFHOWZHdWROU21hTTZsSk9rMVhMRmJXN1N1Y3dId1lEVlIwakJCZ3dGb0FVMDUyNAp2RjQxREpGSkpmZGlIWlBYU0piaU1pVXdEUVlKS29aSWh2Y05BUUVGQlFBRGdZRUFjZnFOODdMVlR3VldyT3loClY5WmpvNU9wTmhKb205N1pyaFdINEFva2RXTDNlOERGSDkxeXJWMkRtcm1sTElFOXhLQ0E3SEo5RjVQNitXRUcKK25naVhjTGNFcXVUQ0J3eTNIU0NDSnRQOXVtNVJWSkJhOGE1K1F6NG1IcE5hMnE5UVNXamVrMldxUFlZb2tPSwp1dS9SUFJwSzdrTUVlWE1KeXVDMzRjQm9SSE09Ci0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0K")
  }
);

// insert Lecce - Consent Engine Public Key
db.getCollection('DS_Kid').insert(
  {
      kid : "YTViMzE=",
      alias : "Lecce-Pub-Key",
      type : "public",
      description : "Lecce Public Key",
      key : BinData(0, "LS0tLS1CRUdJTiBQVUJMSUMgS0VZLS0tLS0KTUlHZk1BMEdDU3FHU0liM0RRRUJBUVVBQTRHTkFEQ0JpUUtCZ1FDbDVnSDhveGt3Z0RLLzRqZGlzdzFwMC9MOQpSaVIxdU96V1hWdE4rcWRXQ1VUVmdPZUlwMkdnQ1lpM0UwaTluQU40dHVPRUEwREJTTXhSU0o2VVhqS2ZlZkI3CkVDTDlqYnZmZFA0cmlwQkc0LzJLdlZSa2ZGK0N5cnpNdzY3MktDNGo5RGVrTDhzZmwzbFVoWW81QldQckcxaXQKTFdOU2d0cmR3MjRJRk9NVUhRSURBUUFCCi0tLS0tRU5EIFBVQkxJQyBLRVktLS0tLQo=")
  }
);
