
db.createCollection("schema_version");

db.getCollection("schema_version").insert(
    {
        "major" : "4",
        "minor" : "1",
        "patch" : "2",
        "tag" : "xdiscovery-service",
        "revision" : 0,
        "last_change" : ISODate("2022-07-28T12:24:27.604+02:00"),
        "description" : ""
    }
);

db.getCollection('DS_Template').drop();
