db.pdpconfig.createIndex({ key : 1 });

db.pdpconfig.insertOne(policyUpdaterIntervalMinutes);
db.pdpconfig.insertOne(xacmlAttributePolicyId);