
db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "ownership",
    title: "Abilitazione ownership",
    xml: ownership,
    description: "Abilitazione al titolare del documento per autorialità esterna ed estesa oltre che al paziente o suo tutore",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "context_policy",
    title: "Context Policy",
    xml: context_policy,
    description: "Verifica ruolo e azione",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
	_id: "trasferimento_indice",
	title: "Policy per il trasferimento indice.",
	xml: trasferimento_indice,
	description: "Applicata sulla GetDocument LeafClass. Restituisce PERMIT se il ruolo, INI o NOR, con purposeofuse puo' eseguire l'azione.",
	updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
	_id: "ricerca_documenti",
	title: "Policy per la ricerca dei documenti.",
	xml: ricerca_documenti,
	description: "Applicata sulla FindDocument ObjectRef. Restituisce PERMIT se il ruolo, con opportuno purposeofuse puo' eseguire l'azione.",
	updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
	_id: "recupero_riferimento_doc",
	title: "Policy per il recupero dei riferimenti del documento.",
	xml: recupero_riferimento_doc,
	description: "Applicata sulla GetDocument ObjectRef. Restituisce PERMIT se il ruolo, con purposeofuse UPDATE puo' eseguire l'azione.",
	updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
	_id: "recupero_documento",
	title: "Policy per il recupero del documento.",
	xml: recupero_documento,
	description: "Applicata sulla RetrieveDocumentSetRequest. Restituisce PERMIT se il ruolo, con opportuno purposeofuse puo' eseguire l'azione. Se eseguita dall'assistito il purposeofuse deve essere PERSONAL.",
	updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
	_id: "comunica_aggiorna_metadati",
	title: "Policy per la comunicazione di nuovi metadati o il loro aggiornamento.",
	xml: comunica_aggiorna_metadati,
	description: "Applicata sulla SubmitObjectsRequest. Restituisce PERMIT se il ruolo, con opportuno purposeofuse puo' eseguire l'azione.",
	updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
	_id: "cancella_metadati",
	title: "Policy per la cancellazione dei metadati.",
	xml: cancella_metadati,
	description: "Applicata sulla RemoveObjectsRequest. Restituisce PERMIT se il ruolo puo' esguire l'azione. In particolare INI o NOR devono avere purposeofuse SYSADMIN.",
	updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
	_id: "ini_default_policy",
	title: "Policy generica per i ruoli di AD nazionale.",
	xml: ini_default_policy,
	description: "Restituisce PERMIT se il ruolo, definito in AD nazionale, puo' eseguire l'azione sul documento.",
	updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "registry_policy",
    title: "Policy Anagrafiche (IIA, PRPA, DOGE)",
    xml: registry_policy,
    description: "Restituisce PERMIT se il ruolo e' X1V1_MEDICO",
    updatable: true
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "C1",
    title: "Consenso ad alimentazione",
    xml: c1,
    description: "Consenso ad alimentazione",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "C2",
    title: "Consenso alla consultazione",
    xml: c2,
    description: "Consenso alla consultazione",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "C3",
    title: "Consenso al pregresso",
    xml: c3,
    description: "Consenso al pregresso",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "P1",
    title: "Consenso alla alimentazione del FSE",
    xml: p1,
    description: "Code: P1\nCodingScheme 2.16.840.1.113883.2.9.3.3.6.1.3\nDisplayName Consenso alla alimentazione del FSE\nRuoli abilitati in interoperabilità  -",
    updatable : true
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "P2",
    title: "Consenso alla consultazione del FSE",
    xml: p2,
    description: "Code P2\nCodingScheme 2.16.840.1.113883.2.9.3.3.6.1.3\nDisplayName Consenso alla consultazione del FSE\nRuoli abilitati in interoperabilità -",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "P24",
    title: "Consenso alla consultazione",
    xml: p24,
    description: "Consenso alla consultazione",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "P25",
    title: "Consenso alla consultazione",
    xml: p25,
    description: "Consenso alla consultazione",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "P26",
    title: "Oscuramento",
    xml: p26,
    description: "Oscuramento",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "P35",
    title: "Consenso alla consultazione",
    xml: p35,
    description: "Consenso al pregresso",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "P99",
    title: "Oscuramento del documento",
    xml: p99,
    description: "Code P99\nCodingScheme 2.16.840.1.113883.2.9.3.3.6.1.3\nDisplayName Oscuramento del documento\nRuoli abilitati in interoperabilità -",
    updatable: true
}});


db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "DS-1",
    title: "Consenso all'alimentazione",
    xml: ds1,
    description: "Consenso all'alimentazione",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "FS-1",
    title: "Consenso all'alimentazione",
    xml: fs1,
    description: "Consenso alla consultazione",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "DLGS196-03",
    title: "Consenso all'alimentazione",
    xml: dlgs19603,
    description: "Consenso alla consultazione",
    updatable: false
}});

db.to_deprecate.insertOne({"type":"policy", "value":{
    _id: "FHIRVisibility",
    title: "Abilitazione visibility per risorse FHIR",
    xml: fhir_visibility,
    description: "Abilitazione alla visualizzazione di risorse FHIR al paziente, al tutore, all'autore (stesso reparto) e ad altri in assenza di oscuramento.",
    updatable: false
}});