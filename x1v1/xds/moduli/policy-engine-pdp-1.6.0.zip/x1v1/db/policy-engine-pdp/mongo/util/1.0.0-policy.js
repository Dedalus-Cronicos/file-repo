db.policy.insertOne({
    _id: "rest_policy",
    title: "REST Policy",
    xml: rest_policy,
    description: "Verifica ruolo e Metodo HTTP",
    updatable: false
});

db.policy.insertOne({
    _id: "X1V1_ASSISTITO",
    title: "Abilitazione visibility per X1V1_ASSISTITO",
    xml: x1v1_assistito,
    description: "Abilitazione alla visualizzazione di risorse all'utente con ruolo X1V1_ASSISTITO.",
    updatable: false
});

db.policy.insertOne({
    _id: "X1V1_MEDICO",
    title: "Abilitazione visibility per X1V1_MEDICO",
    xml: x1v1_medico,
    description: "Abilitazione alla visualizzazione di risorse all'utente con ruolo X1V1_MEDICO.",
    updatable: false
});

db.policy.insertOne({
    _id: "X1V1_MMG",
    title: "Abilitazione visibility per X1V1_MMG",
    xml: x1v1_mmg,
    description: "Abilitazione alla visualizzazione di risorse all'utente con ruolo X1V1_MMG.",
    updatable: false
});

db.policy.insertOne({
    _id: "X1V1_AMMINISTRATIVO",
    title: "Abilitazione visibility per X1V1_AMMINISTRATIVO",
    xml: x1v1_amministrativo,
    description: "Abilitazione alla visualizzazione di risorse all'utente con ruolo X1V1_AMMINISTRATIVO.",
    updatable: false
});

db.policy.insertOne({
    _id: "X1V1_TUTORE",
    title: "Abilitazione visibility per X1V1_TUTORE",
    xml: x1v1_tutore,
    description: "Abilitazione alla visualizzazione di risorse all'utente con ruolo X1V1_TUTORE.",
    updatable: false
});

db.policy.insertOne({
    _id: "DSUB",
    title: "DSUB Policy",
    xml: dsub,
    description: "Verifica notifiche per DSUB",
    updatable: false
});