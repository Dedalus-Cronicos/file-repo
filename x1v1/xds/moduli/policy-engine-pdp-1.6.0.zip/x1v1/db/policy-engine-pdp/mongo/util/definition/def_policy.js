var registry_policy;
try {
    registry_policy = fs.readFileSync("util/definition/policy/registry_policy.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    registry_policy = cat("util/definition/policy/registry_policy.xml");
}
var ownership;
try {
    ownership = fs.readFileSync("util/definition/policy/ownership.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    ownership = cat("util/definition/policy/ownership.xml");
}
var context_policy;
try {
    context_policy = fs.readFileSync("util/definition/policy/context_policy.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    context_policy = cat("util/definition/policy/context_policy.xml");
}
var trasferimento_indice;
try {
    trasferimento_indice = fs.readFileSync("util/definition/policy/trasferimento_indice.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    trasferimento_indice = cat("util/definition/policy/trasferimento_indice.xml");
}
var ricerca_documenti;
try {
    ricerca_documenti = fs.readFileSync("util/definition/policy/ricerca_documenti.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    ricerca_documenti = cat("util/definition/policy/ricerca_documenti.xml");
}
var recupero_riferimento_doc;
try {
    recupero_riferimento_doc = fs.readFileSync("util/definition/policy/recupero_riferimento_doc.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    recupero_riferimento_doc = cat("util/definition/policy/recupero_riferimento_doc.xml");
}
var recupero_documento;
try {
    recupero_documento = fs.readFileSync("util/definition/policy/recupero_documento.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    recupero_documento = cat("util/definition/policy/recupero_documento.xml");
}
var comunica_aggiorna_metadati;
try {
    comunica_aggiorna_metadati = fs.readFileSync("util/definition/policy/comunica_aggiorna_metadati.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    comunica_aggiorna_metadati = cat("util/definition/policy/comunica_aggiorna_metadati.xml");
}
var cancella_metadati;
try {
    cancella_metadati = fs.readFileSync("util/definition/policy/cancella_metadati.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    cancella_metadati = cat("util/definition/policy/cancella_metadati.xml");
}
var ini_default_policy;
try {
    ini_default_policy = fs.readFileSync("util/definition/policy/ini_default_policy.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    ini_default_policy = cat("util/definition/policy/ini_default_policy.xml");
}
var rest_policy;
try {
    rest_policy = fs.readFileSync("util/definition/policy/rest_policy.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    rest_policy = cat("util/definition/policy/rest_policy.xml");
}
var c1;
try {
    c1 = fs.readFileSync("util/definition/policy/c1.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    c1 = cat("util/definition/policy/c1.xml");
}
var c2;
try {
    c2 = fs.readFileSync("util/definition/policy/c2.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    c2 = cat("util/definition/policy/c2.xml");
}
var c3;
try {
    c3 = fs.readFileSync("util/definition/policy/c3.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    c3 = cat("util/definition/policy/c3.xml");
}
var p1;
try {
    p1 = fs.readFileSync("util/definition/policy/p1.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    p1 = cat("util/definition/policy/p1.xml");
}
var p2;
try {
    p2 = fs.readFileSync("util/definition/policy/p2.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    p2 = cat("util/definition/policy/p2.xml");
}
var p24;
try {
    p24 = fs.readFileSync("util/definition/policy/p24.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    p24 = cat("util/definition/policy/p24.xml");
}
var p25;
try {
    p25 = fs.readFileSync("util/definition/policy/p25.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    p25 = cat("util/definition/policy/p25.xml");
}
var p26;
try {
    p26 = fs.readFileSync("util/definition/policy/p26.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    p26 = cat("util/definition/policy/p26.xml");
}
var p35;
try {
    p35 = fs.readFileSync("util/definition/policy/p35.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    p35 = cat("util/definition/policy/p35.xml");
}
var p99;
try {
    p99 = fs.readFileSync("util/definition/policy/p99.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    p99 = cat("util/definition/policy/p99.xml");
}
var ds1;
try {
    ds1 = fs.readFileSync("util/definition/policy/ds-1.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    ds1 = cat("util/definition/policy/ds-1.xml");
}
var fs1;
try {
    fs1 = fs.readFileSync("util/definition/policy/fs-1.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    fs1 = cat("util/definition/policy/fs-1.xml");
}
var dlgs19603;
try {
    dlgs19603 = fs.readFileSync("util/definition/policy/dlgs196-03.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    dlgs19603 = cat("util/definition/policy/dlgs196-03.xml");
}
var fhir_visibility;
try {
    fhir_visibility = fs.readFileSync("util/definition/policy/FHIRVisibility.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    fhir_visibility = cat("util/definition/policy/FHIRVisibility.xml");
}
var x1v1_assistito;
try {
    x1v1_assistito = fs.readFileSync("util/definition/policy/x1v1_assistito.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    x1v1_assistito = cat("util/definition/policy/x1v1_assistito.xml");
}
var x1v1_medico;
try {
    x1v1_medico = fs.readFileSync("util/definition/policy/x1v1_medico.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    x1v1_medico = cat("util/definition/policy/x1v1_medico.xml");
}
var x1v1_mmg;
try {
    x1v1_mmg = fs.readFileSync("util/definition/policy/x1v1_mmg.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    x1v1_mmg = cat("util/definition/policy/x1v1_mmg.xml");
}
var x1v1_amministrativo;
try {
    x1v1_amministrativo = fs.readFileSync("util/definition/policy/x1v1_amministrativo.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    x1v1_amministrativo = cat("util/definition/policy/x1v1_amministrativo.xml");
}
var x1v1_tutore;
try {
    x1v1_tutore = fs.readFileSync("util/definition/policy/x1v1_tutore.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    x1v1_tutore = cat("util/definition/policy/x1v1_tutore.xml");
}
var dsub;
try {
    dsub = fs.readFileSync("util/definition/policy/dsub.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    dsub = cat("util/definition/policy/dsub.xml");
}
var notifier;
try {
    notifier = fs.readFileSync("util/definition/policy/notifier.xml", "utf8");
} catch(e) {
    // mongoshell is not used. mongo used
    notifier = cat("util/definition/policy/notifier.xml");
}