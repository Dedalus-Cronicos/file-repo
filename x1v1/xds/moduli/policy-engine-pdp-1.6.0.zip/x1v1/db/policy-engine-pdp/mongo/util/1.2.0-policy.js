db.policy.deleteOne({_id: "NOTIFIER"});
db.policy.deleteOne({_id: "X1V1_ASSISTITO"});
db.policy.deleteOne({_id: "X1V1_MEDICO"});
db.policy.deleteOne({_id: "X1V1_MMG"});
db.policy.deleteOne({_id: "X1V1_TUTORE"});

db.policy.insertOne({
    _id: "NOTIFIER",
    title: "Abilitazione visibility per NOTIFIER",
    xml: notifier,
    description: "Abilitazione alla pubblicazione di risorse all'utente con ruolo NOTIFIER.",
    updatable: false
});

db.policy.insertOne({
    _id: "X1V1_ASSISTITO",
    title: "Abilitazione visibility per X1V1_ASSISTITO",
    xml: x1v1_assistito,
    description: "Abilitazione alla visualizzazione di risorse all'utente con ruolo X1V1_ASSISTITO.",
    updatable: false
});

db.policy.insertOne({
    _id: "X1V1_MEDICO",
    title: "Abilitazione visibility per X1V1_MEDICO",
    xml: x1v1_medico,
    description: "Abilitazione alla visualizzazione di risorse all'utente con ruolo X1V1_MEDICO.",
    updatable: false
});

db.policy.insertOne({
    _id: "X1V1_MMG",
    title: "Abilitazione visibility per X1V1_MMG",
    xml: x1v1_mmg,
    description: "Abilitazione alla visualizzazione di risorse all'utente con ruolo X1V1_MMG.",
    updatable: false
});

db.policy.insertOne({
    _id: "X1V1_TUTORE",
    title: "Abilitazione visibility per X1V1_TUTORE",
    xml: x1v1_tutore,
    description: "Abilitazione alla visualizzazione di risorse all'utente con ruolo X1V1_TUTORE.",
    updatable: false
});