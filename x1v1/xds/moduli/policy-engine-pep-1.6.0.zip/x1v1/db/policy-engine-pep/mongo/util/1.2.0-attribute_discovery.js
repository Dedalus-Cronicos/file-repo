db.attribute_discovery.deleteOne({when: "fhirResourceRead", endpoint: "fhirResourceRead"});
db.attribute_discovery.deleteOne({when: "AdhocQueryResponse", endpoint: "RegistryStoredQuery"});
db.attribute_discovery.deleteOne({when: "RetrieveDocumentSetResponse", endpoint: "DocumentRepository_RetrieveDocumentSet_Default"});
db.attribute_discovery.deleteOne({when: "AdhocQueryResponse", endpoint: "RegistryStoredQuery_Default"});
db.attribute_discovery.deleteOne({when: "*://*/*/xvalue_patsyn/*/*/*/*"});
db.attribute_discovery.deleteOne({when: "notifierPublish"});

db.attribute_discovery.insertOne(IN_NEW_READ_FHIRRESOURCE);
db.attribute_discovery.insertOne(OUT_AdhocQueryResponse);
db.attribute_discovery.insertOne(OUT_DocumentRepository_RetrieveDocumentSet_Default);
db.attribute_discovery.insertOne(OUT_RegistryStoredQuery_Default);
db.attribute_discovery.insertOne(IN_XVALUE_PATSYN_GET_4);
db.attribute_discovery.insertOne(OUT_XVALUE_PATSYN_4);
db.attribute_discovery.insertOne(IN_NOTIFIER_PUBLISH);