db.configuration.deleteOne({property: "jwt.config"});
db.configuration.insertOne(jwtConfig);