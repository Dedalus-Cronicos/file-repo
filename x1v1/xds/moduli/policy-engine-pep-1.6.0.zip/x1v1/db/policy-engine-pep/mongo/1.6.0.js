load("util/definition/def_include_all.js");

load("util/1.6.0-configuration.js");
load("util/1.6.0-attribute_discovery.js");