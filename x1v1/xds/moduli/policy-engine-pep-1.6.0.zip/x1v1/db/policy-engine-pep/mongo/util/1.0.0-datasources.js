db.datasources.createIndex({ alias : 1 });

db.datasources.insertOne(LHA_DATASOURCE);