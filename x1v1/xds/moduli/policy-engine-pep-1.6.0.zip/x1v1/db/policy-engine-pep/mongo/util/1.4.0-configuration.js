db.configuration.deleteOne({property: "language"});
db.configuration.insertOne(language);
db.configuration.deleteOne({property: "jwtAdditionalJPathAttributes"});
db.configuration.insertOne(jwtAdditionalJPathAttributes);
db.configuration.deleteOne({property: "saml.config"});
db.configuration.insertOne(samlConfig);