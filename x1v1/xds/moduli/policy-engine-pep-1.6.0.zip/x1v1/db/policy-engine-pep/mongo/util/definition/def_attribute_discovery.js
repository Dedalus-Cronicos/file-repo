var IN_DSUB_API_GET_1 = {
    when: "*://*/proxy/dsub/api/*",
    endpoint: "*://*/proxy/dsub/api/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_DSUB_API_GET_2 = {
    when: "*://*/proxy/dsub/api/*/*",
    endpoint: "*://*/proxy/dsub/api/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_DSUB_API_GET_3 = {
    when: "*://*/proxy/dsub/api/*/*/*",
    endpoint: "*://*/proxy/dsub/api/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_DSUB_API_POST_1 = {
    when: "*://*/proxy/dsub/api/*",
    endpoint: "*://*/proxy/dsub/api/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_DSUB_API_POST_2 = {
    when: "*://*/proxy/dsub/api/*/*",
    endpoint: "*://*/proxy/dsub/api/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_DSUB_API_POST_3 = {
    when: "*://*/proxy/dsub/api/*/*/*",
    endpoint: "*://*/proxy/dsub/api/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_DSUB_CreatePullPoint = {
    when: "CreatePullPoint",
    endpoint: "*://*/*/pullpoint/*",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    validateAction: false,
    skipEvaluationProcess: true
};

var IN_DSUB_DestroyPullPoint = {
    when: "DestroyPullPoint",
    endpoint: "*://*/*/pullpoint/*",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    validateAction: false,
    skipEvaluationProcess: true
};

var IN_DSUB_GetMessages = {
    when: "GetMessages",
    endpoint: "*://*/*/pullpointresource/*",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    validateAction: false,
    skipEvaluationProcess: true
};

var IN_DSUB_getSubscriptions = {
    when: "getSubscriptions",
    endpoint: "getSubscriptions",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    validateAction: false,
    skipEvaluationProcess: true
};

var IN_DSUB_Subscribe = {
    when: "Subscribe",
    endpoint: "subscribe",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    validateAction: false,
    skipEvaluationProcess: true
};

var IN_DSUB_Unsubscribe = {
    when: "Unsubscribe",
    endpoint: "subscribe",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    validateAction: false,
    skipEvaluationProcess: true
};

var IN_DSUB_consent = {
    when: "consent_dsub",
    endpoint: "consent_dsub",
    validateAction: false,
    validateSaml: false,
    attributes: [actionNotify, roleDSUB],
    attributebag: {
        groupBy: singleRequestConsent,
        add: [uniqueIdConsent, typeCodeConsent, getConsentsForDSUB],
        repeatOn: policyIdDSUB
    }
};

var IN_DSUB_agmatrix = {
    when : "agmatrix_dsub",
    endpoint : "agmatrix_dsub",
    phase : "IN",
    validateSaml : false,
    validateAction : false,
    attributes : [ agMatrixJSONRole, actionRead ],
    attributebag : {
        groupBy : agMatrixJSONDocument,
        add : [ agMatrixPolicyId, agMatrixJSONUniqueId, agMatrixJSONTypeCode, agMatrixJSONConfidentiality ]
    }
};

var OUT_DSUB_API_3 = {
    when: "*://*/proxy/dsub/api/*/*/*",
    endpoint: "*://*/proxy/dsub/api/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};
var OUT_DSUB_API_2 = {
    when: "*://*/proxy/dsub/api/*/*",
    endpoint: "*://*/proxy/dsub/api/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};
var OUT_DSUB_API_1 = {
    when: "*://*/proxy/dsub/api/*",
    endpoint: "*://*/proxy/dsub/api/*",
    phase: "OUT",
    skipEvaluationProcess: true
};
var OUT_DSUB_CreatePullPoint = {
    when: "CreatePullPointResponse",
    endpoint: "*://*/*/pullpoint/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_DSUB_DestroyPullPoint = {
    when: "DestroyPullPointResponse",
    endpoint: "*://*/*/pullpoint/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_DSUB_UnableToCreatePullPointFault = {
    when: "UnableToCreatePullPointFault",
    endpoint: "*://*/*/pullpoint/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_DSUB_GetMessage = {
    when: "GetMessagesResponse",
    endpoint: "*://*/*/pullpointresource/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_DSUB_ResourceUnknownFault = {
    when: "ResourceUnknownFault",
    endpoint: "*://*/*/pullpointresource/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_DSUB_UnableToGetMessagesFault = {
    when: "UnableToGetMessagesFault",
    endpoint: "*://*/*/pullpointresource/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_DSUB_getSubscriptions = {
    when: "getSubscriptionsResponse",
    endpoint: "getSubscriptions",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_DSUB_Subscribe = {
    when: "SubscribeResponse",
    endpoint: "subscribe",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_DSUB_Unsubscribe = {
    when: "UnsubscribeResponse",
    endpoint: "subscribe",
    phase: "OUT",
    skipEvaluationProcess: true
};


var OUT_CONSENTENGINE_CONSENT_BASE_6 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_CONSENTENGINE_CONSENT_BASE_5 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_CONSENTENGINE_CONSENT_BASE_4 = {
    when: "*://*/proxy/ce_base/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_CONSENTENGINE_CONSENT_BASE_3 = {
    when: "*://*/proxy/ce_base/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_CONSENTENGINE_CONSENT_BASE_2 = {
    when: "*://*/proxy/ce_base/*/*",
    endpoint: "*://*/proxy/ce_base/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_CONSENTENGINE_CONSENT_BASE_1 = {
    when: "*://*/proxy/ce_base/*",
    endpoint: "*://*/proxy/ce_base/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_BASE_GET_1 = {
    when: "*://*/proxy/ce_base/*",
    endpoint: "*://*/proxy/ce_base/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_GET_2 = {
    when: "*://*/proxy/ce_base/*/*",
    endpoint: "*://*/proxy/ce_base/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_GET_3 = {
    when: "*://*/proxy/ce_base/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_GET_4 = {
    when: "*://*/proxy/ce_base/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_GET_5 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_GET_6 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_DELETE_1 = {
    when: "*://*/proxy/ce_base/*",
    endpoint: "*://*/proxy/ce_base/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_DELETE_2 = {
    when: "*://*/proxy/ce_base/*/*",
    endpoint: "*://*/proxy/ce_base/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_DELETE_3 = {
    when: "*://*/proxy/ce_base/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_DELETE_4 = {
    when: "*://*/proxy/ce_base/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_DELETE_5 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_DELETE_6 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};


var IN_CONSENTENGINE_CONSENT_BASE_HEAD_1 = {
    when: "*://*/proxy/ce_base/*",
    endpoint: "*://*/proxy/ce_base/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_HEAD_2 = {
    when: "*://*/proxy/ce_base/*/*",
    endpoint: "*://*/proxy/ce_base/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_HEAD_3 = {
    when: "*://*/proxy/ce_base/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_HEAD_4 = {
    when: "*://*/proxy/ce_base/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_HEAD_5 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_HEAD_6 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};


var IN_CONSENTENGINE_CONSENT_BASE_PUT_1 = {
    when: "*://*/proxy/ce_base/*",
    endpoint: "*://*/proxy/ce_base/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_PUT_2 = {
    when: "*://*/proxy/ce_base/*/*",
    endpoint: "*://*/proxy/ce_base/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_PUT_3 = {
    when: "*://*/proxy/ce_base/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_PUT_4 = {
    when: "*://*/proxy/ce_base/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_PUT_5 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_PUT_6 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_POST_1 = {
    when: "*://*/proxy/ce_base/*",
    endpoint: "*://*/proxy/ce_base/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_POST_2 = {
    when: "*://*/proxy/ce_base/*/*",
    endpoint: "*://*/proxy/ce_base/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_POST_3 = {
    when: "*://*/proxy/ce_base/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_POST_4 = {
    when: "*://*/proxy/ce_base/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_POST_5 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BASE_POST_6 = {
    when: "*://*/proxy/ce_base/*/*/*/*/*/*",
    endpoint: "*://*/proxy/ce_base/*/*/*/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_000_PATIENT_DOCUMNET_GET = {
    when: "*://*/proxy/pmce_consents/*/*",
    endpoint: "*://*/proxy/pmce_consents/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_000_PATIENT_DOCUMNET_HEAD = {
    when: "*://*/proxy/pmce_consents/*/*",
    endpoint: "*://*/proxy/pmce_consents/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_000_PATIENT_DOCUMNET = {
    when: "*://*/proxy/pmce_consents/*/*",
    endpoint: "*://*/proxy/pmce_consents/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_000_PATIENT_GET = {
    when: "*://*/proxy/pmce_consents/*",
    endpoint: "*://*/proxy/pmce_consents/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_000_PATIENT_HEAD = {
    when: "*://*/proxy/pmce_consents/*",
    endpoint: "*://*/proxy/pmce_consents/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_000_PATIENT = {
    when: "*://*/proxy/pmce_consents/*",
    endpoint: "*://*/proxy/pmce_consents/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_100_APP_GET = {
    when: "*://*/proxy/pmce_consents/*/100",
    endpoint: "*://*/proxy/pmce_consents/*/100",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_APP_POST = {
    when: "*://*/proxy/pmce_consents/*/100",
    endpoint: "*://*/proxy/pmce_consents/*/100",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_APP_PUT = {
    when: "*://*/proxy/pmce_consents/*/100",
    endpoint: "*://*/proxy/pmce_consents/*/100",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_APP_HEAD = {
    when: "*://*/proxy/pmce_consents/*/100",
    endpoint: "*://*/proxy/pmce_consents/*/100",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_100_APP = {
    when: "*://*/proxy/pmce_consents/*/100",
    endpoint: "*://*/proxy/pmce_consents/*/100",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_100_APP_PARAM_GET = {
    when: "*://*/proxy/pmce_consents/*/100/*",
    endpoint: "*://*/proxy/pmce_consents/*/100/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_APP_PARAM_POST = {
    when: "*://*/proxy/pmce_consents/*/100/*",
    endpoint: "*://*/proxy/pmce_consents/*/100/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_APP_PARAM_PUT = {
    when: "*://*/proxy/pmce_consents/*/100/*",
    endpoint: "*://*/proxy/pmce_consents/*/100/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_APP_PARAM_HEAD = {
    when: "*://*/proxy/pmce_consents/*/100/*",
    endpoint: "*://*/proxy/pmce_consents/*/100/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_100_APP_PARAM = {
    when: "*://*/proxy/pmce_consents/*/100/*",
    endpoint: "*://*/proxy/pmce_consents/*/100/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_100_APP_TWO_PARAMS_HEAD = {
    when: "*://*/proxy/pmce_consents/*/100/*/*",
    endpoint: "*://*/proxy/pmce_consents/*/100/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_100_APP_TWO_PARAMS = {
    when: "*://*/proxy/pmce_consents/*/100/*/*",
    endpoint: "*://*/proxy/pmce_consents/*/100/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_100_APP_DELETE = {
    when: "*://*/proxy/pmce_consents/*/100/reset",
    endpoint: "*://*/proxy/pmce_consents/*/100/reset",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_APP_PARAM_DELETE = {
    when: "*://*/proxy/pmce_consents/*/100/reset/*",
    endpoint: "*://*/proxy/pmce_consents/*/100/reset/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_GET = {
    when: "*://*/proxy/pmce_consents/100",
    endpoint: "*://*/proxy/pmce_consents/100",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_POST = {
    when: "*://*/proxy/pmce_consents/100",
    endpoint: "*://*/proxy/pmce_consents/100",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_PUT = {
    when: "*://*/proxy/pmce_consents/100",
    endpoint: "*://*/proxy/pmce_consents/100",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_HEAD = {
    when: "*://*/proxy/pmce_consents/100",
    endpoint: "*://*/proxy/pmce_consents/100",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_100 = {
    when: "*://*/proxy/pmce_consents/100",
    endpoint: "*://*/proxy/pmce_consents/100",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_100_PARAM_GET = {
    when: "*://*/proxy/pmce_consents/100/*",
    endpoint: "*://*/proxy/pmce_consents/100/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_PARAM_POST = {
    when: "*://*/proxy/pmce_consents/100/*",
    endpoint: "*://*/proxy/pmce_consents/100/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_PARAM_PUT = {
    when: "*://*/proxy/pmce_consents/100/*",
    endpoint: "*://*/proxy/pmce_consents/100/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_PARAM_HEAD = {
    when: "*://*/proxy/pmce_consents/100/*",
    endpoint: "*://*/proxy/pmce_consents/100/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_100_PARAM = {
    when: "*://*/proxy/pmce_consents/100/*",
    endpoint: "*://*/proxy/pmce_consents/100/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_100_TWO_PARAMS_HEAD = {
    when: "*://*/proxy/pmce_consents/100/*/*",
    endpoint: "*://*/proxy/pmce_consents/100/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_100_TWO_PARAMS = {
    when: "*://*/proxy/pmce_consents/100/*/*",
    endpoint: "*://*/proxy/pmce_consents/100/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_100_DELETE = {
    when: "*://*/proxy/pmce_consents/100/reset",
    endpoint: "*://*/proxy/pmce_consents/100/reset",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_100_PARAM_DELETE = {
    when: "*://*/proxy/pmce_consents/100/reset/*",
    endpoint: "*://*/proxy/pmce_consents/100/reset/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_BUNDLE_GET = {
    when: "*://*/proxy/pmce_consents/100/bundle/*",
    endpoint: "*://*/proxy/pmce_consents/100/bundle/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_BUNDLE = {
    when: "*://*/proxy/pmce_consents/100/bundle/*",
    endpoint: "*://*/proxy/pmce_consents/100/bundle/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_BUNDLECONSENT_GET = {
    when: "*://*/proxy/pmce_bundleconsent/*",
    endpoint: "*://*/proxy/pmce_bundleconsent/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_BUNDLECONSENT = {
    when: "*://*/proxy/pmce_bundleconsent/*",
    endpoint: "*://*/proxy/pmce_bundleconsent/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_PDF_BUNDLE_GET = {
    when: "*://*/proxy/pmce_bundlepdf",
    endpoint: "*://*/proxy/pmce_bundlepdf",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_PDF_BUNDLE_POST = {
    when: "*://*/proxy/pmce_bundlepdf",
    endpoint: "*://*/proxy/pmce_bundlepdf",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_PDF_BUNDLE = {
    when: "*://*/proxy/pmce_bundlepdf",
    endpoint: "*://*/proxy/pmce_bundlepdf",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_PDF_BUNDLE_PARAM_GET = {
    when: "*://*/proxy/pmce_bundlepdf/*",
    endpoint: "*://*/proxy/pmce_bundlepdf/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_PDF_BUNDLE_PARAM = {
    when: "*://*/proxy/pmce_bundlepdf/*",
    endpoint: "*://*/proxy/pmce_bundlepdf/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_PATIENT_PARAM_GET = {
    when: "*://*/proxy/pmce_patients/*",
    endpoint: "*://*/proxy/pmce_patients/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_PATIENT_PARAM_HEAD = {
    when: "*://*/proxy/pmce_patients/*",
    endpoint: "*://*/proxy/pmce_patients/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_PATIENT_PARAM = {
    when: "*://*/proxy/pmce_patients/*",
    endpoint: "*://*/proxy/pmce_patients/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_PATIENT_GET = {
    when: "*://*/proxy/pmce_patients",
    endpoint: "*://*/proxy/pmce_patients",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_PATIENT_HEAD = {
    when: "*://*/proxy/pmce_patients",
    endpoint: "*://*/proxy/pmce_patients",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_PATIENT = {
    when: "*://*/proxy/pmce_patients",
    endpoint: "*://*/proxy/pmce_patients",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_TUTOR_PARAM_GET = {
    when: "*://*/proxy/pmce_tutors/*",
    endpoint: "*://*/proxy/pmce_tutors/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_TUTOR_PARAM_POST = {
    when: "*://*/proxy/pmce_tutors/*",
    endpoint: "*://*/proxy/pmce_tutors/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_TUTOR_PARAM_PUT = {
    when: "*://*/proxy/pmce_tutors/*",
    endpoint: "*://*/proxy/pmce_tutors/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_TUTOR_PARAM_HEAD = {
    when: "*://*/proxy/pmce_tutors/*",
    endpoint: "*://*/proxy/pmce_tutors/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_TUTOR_PARAM_DELETE = {
    when: "*://*/proxy/pmce_tutors/*",
    endpoint: "*://*/proxy/pmce_tutors/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_TUTOR_ROLLBACK_PARAM_DELETE = {
    when: "*://*/proxy/pmce_tutors_rollback/*",
    endpoint: "*://*/proxy/pmce_tutors_rollback/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_TUTOR_ROLLBACK_PARAM = {
    when: "*://*/proxy/pmce_tutors_rollback/*",
    endpoint: "*://*/proxy/pmce_tutors_rollback/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_CONSENTENGINE_TUTOR_PARAM = {
    when: "*://*/proxy/pmce_tutors/*",
    endpoint: "*://*/proxy/pmce_tutors/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_TUTOR_GET = {
    when: "*://*/proxy/pmce_tutors",
    endpoint: "*://*/proxy/pmce_tutors",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_TUTOR_POST = {
    when: "*://*/proxy/pmce_tutors",
    endpoint: "*://*/proxy/pmce_tutors",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_TUTOR_PUT = {
    when: "*://*/proxy/pmce_tutors",
    endpoint: "*://*/proxy/pmce_tutors",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_TUTOR_HEAD = {
    when: "*://*/proxy/pmce_tutors",
    endpoint: "*://*/proxy/pmce_tutors",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_TUTOR_ROLLBACK_DELETE = {
    when: "*://*/proxy/pmce_tutors_rollback",
    endpoint: "*://*/proxy/pmce_tutors_rollback",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_TUTOR_ROLLBACK = {
    when: "*://*/proxy/pmce_tutors_rollback",
    endpoint: "*://*/proxy/pmce_tutors_rollback",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_TUTOR_DELETE = {
    when: "*://*/proxy/pmce_tutors",
    endpoint: "*://*/proxy/pmce_tutors",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_TUTOR = {
    when: "*://*/proxy/pmce_tutors",
    endpoint: "*://*/proxy/pmce_tutors",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_TUTOR_ONLYTUTOR_GET = {
    when: "*://*/proxy/pmce_tutors_onlytutor",
    endpoint: "*://*/proxy/pmce_tutors_onlytutor",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_TUTOR_ONLYTUTOR_GET = {
    when: "*://*/proxy/pmce_tutors_onlytutor",
    endpoint: "*://*/proxy/pmce_tutors_onlytutor",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_TUTOR_TWO_PARAMS_DELETE = {
    when: "*://*/proxy/pmce_tutors/*/*",
    endpoint: "*://*/proxy/pmce_tutors/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_TUTOR_TWO_PARAMS = {
    when: "*://*/proxy/pmce_tutors/*/*",
    endpoint: "*://*/proxy/pmce_tutors/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_GET = {
    when: "*://*/proxy/pmce_messagepatients",
    endpoint: "*://*/proxy/pmce_messagepatients",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_PUT = {
    when: "*://*/proxy/pmce_messagepatients",
    endpoint: "*://*/proxy/pmce_messagepatients",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_HEAD = {
    when: "*://*/proxy/pmce_messagepatients",
    endpoint: "*://*/proxy/pmce_messagepatients",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_DELETE = {
    when: "*://*/proxy/pmce_messagepatients",
    endpoint: "*://*/proxy/pmce_messagepatients",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_MESSAGE_PATIENT = {
    when: "*://*/proxy/pmce_messagepatients",
    endpoint: "*://*/proxy/pmce_messagepatients",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_PARAM_GET = {
    when: "*://*/proxy/pmce_messagepatients/*",
    endpoint: "*://*/proxy/pmce_messagepatients/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_PARAM_HEAD = {
    when: "*://*/proxy/pmce_messagepatients/*",
    endpoint: "*://*/proxy/pmce_messagepatients/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_PARAM_DELETE = {
    when: "*://*/proxy/pmce_messagepatients/*",
    endpoint: "*://*/proxy/pmce_messagepatients/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_MESSAGE_PATIENT_PARAM = {
    when: "*://*/proxy/pmce_messagepatients/*",
    endpoint: "*://*/proxy/pmce_messagepatients/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_TWO_PARAMS_PUT = {
    when: "*://*/proxy/pmce_messagepatients/*/*",
    endpoint: "*://*/proxy/pmce_messagepatients/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_TWO_PARAMS_HEAD = {
    when: "*://*/proxy/pmce_messagepatients/*/*",
    endpoint: "*://*/proxy/pmce_messagepatients/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_TWO_PARAMS_DELETE = {
    when: "*://*/proxy/pmce_messagepatients/*/*",
    endpoint: "*://*/proxy/pmce_messagepatients/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_MESSAGE_PATIENT_TWO_PARAMS = {
    when: "*://*/proxy/pmce_messagepatients/*/*",
    endpoint: "*://*/proxy/pmce_messagepatients/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_MESSAGE_GET = {
    when: "*://*/proxy/pmce_messages",
    endpoint: "*://*/proxy/pmce_messages",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_MESSAGE = {
    when: "*://*/proxy/pmce_messages",
    endpoint: "*://*/proxy/pmce_messages",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_MESSAGE_PARAM_GET = {
    when: "*://*/proxy/pmce_messages/*",
    endpoint: "*://*/proxy/pmce_messages/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PARAM_POST = {
    when: "*://*/proxy/pmce_messages/*",
    endpoint: "*://*/proxy/pmce_messages/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PARAM_PUT = {
    when: "*://*/proxy/pmce_messages/*",
    endpoint: "*://*/proxy/pmce_messages/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PARAM_HEAD = {
    when: "*://*/proxy/pmce_messages/*",
    endpoint: "*://*/proxy/pmce_messages/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PARAM_DELETE = {
    when: "*://*/proxy/pmce_messages/*",
    endpoint: "*://*/proxy/pmce_messages/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_MESSAGE_PARAM = {
    when: "*://*/proxy/pmce_messages/*",
    endpoint: "*://*/proxy/pmce_messages/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_PATIENT_CODE_GET = {
    when: "*://*/proxy/pmce_messages/*/*",
    endpoint: "*://*/proxy/pmce_messages/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_PATIENT_CODE_PUT = {
    when: "*://*/proxy/pmce_messages/*/*",
    endpoint: "*://*/proxy/pmce_messages/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_PATIENT_CODE_HEAD = {
    when: "*://*/proxy/pmce_messages/*/*",
    endpoint: "*://*/proxy/pmce_messages/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_PATIENT_CODE_DELETE = {
    when: "*://*/proxy/pmce_messages/*/*",
    endpoint: "*://*/proxy/pmce_messages/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_MESSAGE_PATIENT_PATIENT_CODE = {
    when: "*://*/proxy/pmce_messages/*/*",
    endpoint: "*://*/proxy/pmce_messages/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_MESSAGE_PATIENT_ANY_CODE_PUT = {
    when: "*://*/proxy/pmce_messagepatients/any/*",
    endpoint: "*://*/proxy/pmce_messagepatients/any/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_MESSAGE_PATIENT_ANY_CODE = {
    when: "*://*/proxy/pmce_messagepatients/any/*",
    endpoint: "*://*/proxy/pmce_messagepatients/any/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENTCOLLECTOR_GET = {
    when: "*://*/proxy/pmce_consentcollector",
    endpoint: "*://*/proxy/pmce_consentcollector",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENTCOLLECTOR_GET = {
    when: "*://*/proxy/pmce_consentcollector",
    endpoint: "*://*/proxy/pmce_consentcollector",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENTCOLLECTOR__HISTORY_GET = {
    when: "*://*/proxy/pmce_consentcollector/history/100",
    endpoint: "*://*/proxy/pmce_consentcollector/history/100",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENTCOLLECTOR_HISTORY_GET = {
    when: "*://*/proxy/pmce_consentcollector/history/100",
    endpoint: "*://*/proxy/pmce_consentcollector/history/100",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENTCOLLECTOR__HISTORY_COUNT_GET = {
    when: "*://*/proxy/pmce_consentcollector/history/100/count",
    endpoint: "*://*/proxy/pmce_consentcollector/history/100/count",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENTCOLLECTOR_HISTORY_COUNT_GET = {
    when: "*://*/proxy/pmce_consentcollector/history/100/count",
    endpoint: "*://*/proxy/pmce_consentcollector/history/100/count",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_CONSENTENGINE_MODEL_REGISTRY = {
    when: "*://*/proxy/pmce_registrymodel/",
    endpoint: "*://*/proxy/pmce_registrymodel/",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_CONSENTENGINE_MODEL_REGISTRY_PARAM = {
    when: "*://*/proxy/pmce_registrymodel/*",
    endpoint: "*://*/proxy/pmce_registrymodel/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_MODEL_REGISTRY_SEARCH = {
    when: "*://*/proxy/pmce_registrymodel/",
    endpoint: "*://*/proxy/pmce_registrymodel/",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MODEL_REGISTRY_POST = {
    when: "*://*/proxy/pmce_registrymodel/",
    endpoint: "*://*/proxy/pmce_registrymodel/",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MODEL_REGISTRY_HEAD = {
    when: "*://*/proxy/pmce_registrymodel/*",
    endpoint: "*://*/proxy/pmce_registrymodel/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MODEL_REGISTRY_GET = {
    when: "*://*/proxy/pmce_registrymodel/*",
    endpoint: "*://*/proxy/pmce_registrymodel/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MODEL_REGISTRY_PUT = {
    when: "*://*/proxy/pmce_registrymodel/*",
    endpoint: "*://*/proxy/pmce_registrymodel/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_MODEL_REGISTRY_DELETE = {
    when: "*://*/proxy/pmce_registrymodel/*",
    endpoint: "*://*/proxy/pmce_registrymodel/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_INFORMATION_REGISTRY = {
    when: "*://*/proxy/pmce_registryinformation/",
    endpoint: "*://*/proxy/pmce_registryinformation/",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_CONSENTENGINE_INFORMATION_REGISTRY_PARAM = {
    when: "*://*/proxy/pmce_registryinformation/*",
    endpoint: "*://*/proxy/pmce_registryinformation/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_INFORMATION_REGISTRY_SEARCH = {
    when: "*://*/proxy/pmce_registryinformation/",
    endpoint: "*://*/proxy/pmce_registryinformation/",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_INFORMATION_REGISTRY_POST = {
    when: "*://*/proxy/pmce_registryinformation/",
    endpoint: "*://*/proxy/pmce_registryinformation/",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_INFORMATION_REGISTRY_HEAD = {
    when: "*://*/proxy/pmce_registryinformation/*",
    endpoint: "*://*/proxy/pmce_registryinformation/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_INFORMATION_REGISTRY_GET = {
    when: "*://*/proxy/pmce_registryinformation/*",
    endpoint: "*://*/proxy/pmce_registryinformation/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_INFORMATION_REGISTRY_PUT = {
    when: "*://*/proxy/pmce_registryinformation/*",
    endpoint: "*://*/proxy/pmce_registryinformation/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_INFORMATION_REGISTRY_DELETE = {
    when: "*://*/proxy/pmce_registryinformation/*",
    endpoint: "*://*/proxy/pmce_registryinformation/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENT_REGISTRY = {
    when: "*://*/proxy/pmce_registryconsent/",
    endpoint: "*://*/proxy/pmce_registryconsent/",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_CONSENTENGINE_CONSENT_REGISTRY_PARAM = {
    when: "*://*/proxy/pmce_registryconsent/*",
    endpoint: "*://*/proxy/pmce_registryconsent/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONSENT_REGISTRY_SEARCH = {
    when: "*://*/proxy/pmce_registryconsent/",
    endpoint: "*://*/proxy/pmce_registryconsent/",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_REGISTRY_POST = {
    when: "*://*/proxy/pmce_registryconsent/",
    endpoint: "*://*/proxy/pmce_registryconsent/",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_REGISTRY_HEAD = {
    when: "*://*/proxy/pmce_registryconsent/*",
    endpoint: "*://*/proxy/pmce_registryconsent/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_REGISTRY_GET = {
    when: "*://*/proxy/pmce_registryconsent/*",
    endpoint: "*://*/proxy/pmce_registryconsent/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_REGISTRY_PUT = {
    when: "*://*/proxy/pmce_registryconsent/*",
    endpoint: "*://*/proxy/pmce_registryconsent/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENT_REGISTRY_DELETE = {
    when: "*://*/proxy/pmce_registryconsent/*",
    endpoint: "*://*/proxy/pmce_registryconsent/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_GRAPHOMETRIC = {
    when: "*://*/proxy/pmce_graphometric/",
    endpoint: "*://*/proxy/pmce_graphometric/",
    phase: "OUT",
    skipEvaluationProcess: true
};
var OUT_CONSENTENGINE_GRAPHOMETRIC_PARAM = {
    when: "*://*/proxy/pmce_graphometric/*",
    endpoint: "*://*/proxy/pmce_graphometric/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_GRAPHOMETRIC_SEARCH = {
    when: "*://*/proxy/pmce_graphometric/",
    endpoint: "*://*/proxy/pmce_graphometric/",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_CONSENTENGINE_GRAPHOMETRIC_GET = {
    when: "*://*/proxy/pmce_graphometric/*",
    endpoint: "*://*/proxy/pmce_graphometric/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_GRAPHOMETRIC_POST = {
    when: "*://*/proxy/pmce_graphometric/",
    endpoint: "*://*/proxy/pmce_graphometric/",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_GRAPHOMETRIC_PUT = {
    when: "*://*/proxy/pmce_graphometric/*",
    endpoint: "*://*/proxy/pmce_graphometric/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONFIGURATIONBYKEY = {
    when: "*://*/proxy/pmce_configurationbykey/*",
    endpoint: "*://*/proxy/pmce_configurationbykey/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var OUT_CONSENTENGINE_CONFIGURATIONBYKEY = {
    when: "*://*/proxy/pmce_configurationbykey/*",
    endpoint: "*://*/proxy/pmce_configurationbykey/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_CONSENTENGINE_CONFIGURATIONBYKEY_GET = {
    when: "*://*/proxy/pmce_configurationbykey/*",
    endpoint: "*://*/proxy/pmce_configurationbykey/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_CONSENTENGINE_CONSENTCOLLECTOR_STANDALONE_POST = {
    when: "*://*/proxy/pmce_consentcollector_standalone",
    endpoint: "*://*/proxy/pmce_consentcollector_standalone",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENTCOLLECTOR_STANDALONE_POST = {
    "when": "*://*/proxy/pmce_consentcollector_standalone",
    "endpoint": "*://*/proxy/pmce_consentcollector_standalone",
    "phase": "OUT",
    "skipEvaluationProcess": true
}

var IN_CONSENTENGINE_CONSENTCOLLECTOR_PATIENTS_BUNDLES_GET = {
    when: "*://*/proxy/pmce_consentcollector_patients_bundles",
    endpoint: "*://*/proxy/pmce_consentcollector_patients_bundles",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENTCOLLECTOR_PATIENTS_BUNDLES_GET = {
    "when": "*://*/proxy/pmce_consentcollector_patients_bundles",
    "endpoint": "*://*/proxy/pmce_consentcollector_patients_bundles",
    "phase": "OUT",
    "skipEvaluationProcess": true
}

var IN_CONSENTENGINE_CONSENTCOLLECTOR_EXTERNALCONSENTMANAGER_POST = {
    when: "*://*/proxy/pmce_consentcollector_externalconsentmanager",
    endpoint: "*://*/proxy/pmce_consentcollector_externalconsentmanager",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_CONSENTENGINE_CONSENTCOLLECTOR_EXTERNALCONSENTMANAGER_POST = {
    "when": "*://*/proxy/pmce_consentcollector_externalconsentmanager",
    "endpoint": "*://*/proxy/pmce_consentcollector_externalconsentmanager",
    "phase": "OUT",
    "skipEvaluationProcess": true
};


var IN_ARR_FHIR_GET_2 = {
    when: "*://*/*/arr_fhir/*/*",
    endpoint: "*://*/*/arr_fhir/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_ARR_FHIR_POST_2 = {
    when: "*://*/*/arr_fhir/*/*",
    endpoint: "*://*/*/arr_fhir/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_ARR_FHIR_PUT_2 = {
    when: "*://*/*/arr_fhir/*/*",
    endpoint: "*://*/*/arr_fhir/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_ARR_FHIR_DELETE_2 = {
    when: "*://*/*/arr_fhir/*/*",
    endpoint: "*://*/*/arr_fhir/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_ARR_FHIR_GET_3 = {
    when: "*://*/*/arr_fhir/*/*/*",
    endpoint: "*://*/*/arr_fhir/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_ARR_FHIR_GET_4 = {
    when: "*://*/*/arr_fhir/*/*/*/*",
    endpoint: "*://*/*/arr_fhir/*/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_ARR_FHIR_POST_4 = {
    when: "*://*/*/arr_fhir/*/*/*/*",
    endpoint: "*://*/*/arr_fhir/*/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_ARR_FHIR_RESOURCE_2 = {
    when: "*://*/*/arr_fhir/*/*",
    endpoint: "*://*/*/arr_fhir/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_ARR_FHIR_RESOURCE_3 = {
    when: "*://*/*/arr_fhir/*/*/*",
    endpoint: "*://*/*/arr_fhir/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_ARR_FHIR_RESOURCE_4 = {
    when: "*://*/*/arr_fhir/*/*/*/*",
    endpoint: "*://*/*/arr_fhir/*/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_FHIR_TERMINOLOGY_GET_1 = {
    when: "*://*/*/fhir_terminology/*",
    endpoint: "*://*/*/fhir_terminology/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_FHIR_TERMINOLOGY_GET_2 = {
    when: "*://*/*/fhir_terminology/*/*",
    endpoint: "*://*/*/fhir_terminology/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_FHIR_TERMINOLOGY_GET_3 = {
    when: "*://*/*/fhir_terminology/*/*/*",
    endpoint: "*://*/*/fhir_terminology/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_TERMINOLOGY_POST_1 = {
    when: "*://*/*/fhir_terminology/*",
    endpoint: "*://*/*/fhir_terminology/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_TERMINOLOGY_POST_2 = {
    when: "*://*/*/fhir_terminology/*/*",
    endpoint: "*://*/*/fhir_terminology/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_TERMINOLOGY_POST_3 = {
    when: "*://*/*/fhir_terminology/*/*/*",
    endpoint: "*://*/*/fhir_terminology/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_TERMINOLOGY_PUT_1 = {
    when: "*://*/*/fhir_terminology/*",
    endpoint: "*://*/*/fhir_terminology/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_TERMINOLOGY_PUT_2 = {
    when: "*://*/*/fhir_terminology/*/*",
    endpoint: "*://*/*/fhir_terminology/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_TERMINOLOGY_PUT_3 = {
    when: "*://*/*/fhir_terminology/*/*/*",
    endpoint: "*://*/*/fhir_terminology/*/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_FHIR_TERMINOLOGY_RESOURCE_1 = {
    when: "*://*/*/fhir_terminology/*/*",
    endpoint: "*://*/*/fhir_terminology/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_FHIR_TERMINOLOGY_RESOURCE_2 = {
    when: "*://*/*/fhir_terminology/*/*",
    endpoint: "*://*/*/fhir_terminology/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_FHIR_TERMINOLOGY_RESOURCE_3 = {
    when: "*://*/*/fhir_terminology/*/*/*",
    endpoint: "*://*/*/fhir_terminology/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};









var IN_FHIR_CLINICAL_GET_1 = {
    when: "*://*/*/fhir_clinical/*",
    endpoint: "*://*/*/fhir_clinical/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_FHIR_CLINICAL_GET_2 = {
    when: "*://*/*/fhir_clinical/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};
var IN_FHIR_CLINICAL_GET_3 = {
    when: "*://*/*/fhir_clinical/*/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_POST_1 = {
    when: "*://*/*/fhir_clinical/*",
    endpoint: "*://*/*/fhir_clinical/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_POST_2 = {
    when: "*://*/*/fhir_clinical/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_PUT_2 = {
    when: "*://*/*/fhir_clinical/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_PUT_3 = {
    when: "*://*/*/fhir_clinical/*/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_HEAD_1 = {
    when: "*://*/*/fhir_clinical/*",
    endpoint: "*://*/*/fhir_clinical/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_HEAD_2 = {
    when: "*://*/*/fhir_clinical/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_DELETE_1 = {
    when: "*://*/*/fhir_clinical/*",
    endpoint: "*://*/*/fhir_clinical/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_DELETE_2 = {
    when: "*://*/*/fhir_clinical/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_DELETE_3 = {
    when: "*://*/*/fhir_clinical/*/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_PATCH_1 = {
    when: "*://*/*/fhir_clinical/*",
    endpoint: "*://*/*/fhir_clinical/*",
    phase: "IN",
    httpMethod: "PATCH",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, patchHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_PATCH_2 = {
    when: "*://*/*/fhir_clinical/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*",
    phase: "IN",
    httpMethod: "PATCH",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, patchHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_PATCH_3 = {
    when: "*://*/*/fhir_clinical/*/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*/*",
    phase: "IN",
    httpMethod: "PATCH",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, patchHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_FHIR_CLINICAL_RESOURCE_1 = {
    when: "*://*/*/fhir_clinical/*",
    endpoint: "*://*/*/fhir_clinical/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_FHIR_CLINICAL_RESOURCE_2 = {
    when: "*://*/*/fhir_clinical/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_FHIR_CLINICAL_RESOURCE_3 = {
    when: "*://*/*/fhir_clinical/*/*/*",
    endpoint: "*://*/*/fhir_clinical/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_FHIR_CLINICAL_160_GET_1 = {
    when: "*://*/*/fhir_clinical_1_6_0/*",
    endpoint: "*://*/*/fhir_clinical_1_6_0/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_160_POST_1 = {
    when: "*://*/*/fhir_clinical_1_6_0/*",
    endpoint: "*://*/*/fhir_clinical_1_6_0/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_160_PUT_2 = {
    when: "*://*/*/fhir_clinical_1_6_0/*/*",
    endpoint: "*://*/*/fhir_clinical_1_6_0/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_160_HEAD_1 = {
    when: "*://*/*/fhir_clinical_1_6_0/*",
    endpoint: "*://*/*/fhir_clinical_1_6_0/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_FHIR_CLINICAL_160_DELETE_1 = {
    when: "*://*/*/fhir_clinical_1_6_0/*",
    endpoint: "*://*/*/fhir_clinical_1_6_0/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_FHIR_CLINICAL_160_1 = {
    when: "*://*/*/fhir_clinical_1_6_0/*",
    endpoint: "*://*/*/fhir_clinical_1_6_0/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_FHIR_CLINICAL_160_2 = {
    when: "*://*/*/fhir_clinical_1_6_0/*/*",
    endpoint: "*://*/*/fhir_clinical_1_6_0/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_MCI_SERVICE_GET_3 = {
    when: "*://*/*/mci_service/*/*/*",
    endpoint: "*://*/*/mci_service/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_MCI_SERVICE_POST_3 = {
    when: "*://*/*/mci_service/*/*/*",
    endpoint: "*://*/*/mci_service/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_MCI_SERVICE_3 = {
    when: "*://*/*/mci_service/*/*/*",
    endpoint: "*://*/*/mci_service/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_MCI_SERVICE_160_GET_3 = {
    when: "*://*/*/mci_service_1_6_0/*/*/*",
    endpoint: "*://*/*/mci_service_1_6_0/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_MCI_SERVICE_160_POST_3 = {
    when: "*://*/*/mci_service_1_6_0/*/*/*",
    endpoint: "*://*/*/mci_service_1_6_0/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_MCI_SERVICE_160_3 = {
    when: "*://*/*/mci_service_1_6_0/*/*/*",
    endpoint: "*://*/*/mci_service_1_6_0/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_PEOPLE_FHIR_GET_1 = {
    when: "*://*/*/people_fhir/*",
    endpoint: "*://*/*/people_fhir/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_GET_2 = {
    when: "*://*/*/people_fhir/*/*",
    endpoint: "*://*/*/people_fhir/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_GET_3 = {
    when: "*://*/*/people_fhir/*/*/*",
    endpoint: "*://*/*/people_fhir/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_GET_4 = {
    when: "*://*/*/people_fhir/*/*/*/*",
    endpoint: "*://*/*/people_fhir/*/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_POST_1 = {
    when: "*://*/*/people_fhir/*",
    endpoint: "*://*/*/people_fhir/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_POST_2 = {
    when: "*://*/*/people_fhir/*/*",
    endpoint: "*://*/*/people_fhir/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_POST_3 = {
    when: "*://*/*/people_fhir/*/*/*",
    endpoint: "*://*/*/people_fhir/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_PUT_1 = {
    when: "*://*/*/people_fhir/*",
    endpoint: "*://*/*/people_fhir/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_PUT_2 = {
    when: "*://*/*/people_fhir/*/*",
    endpoint: "*://*/*/people_fhir/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_PUT_3 = {
    when: "*://*/*/people_fhir/*/*/*",
    endpoint: "*://*/*/people_fhir/*/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_DELETE_1 = {
    when: "*://*/*/people_fhir/*",
    endpoint: "*://*/*/people_fhir/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_DELETE_2 = {
    when: "*://*/*/people_fhir/*/*",
    endpoint: "*://*/*/people_fhir/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PEOPLE_FHIR_DELETE_3 = {
    when: "*://*/*/people_fhir/*/*/*",
    endpoint: "*://*/*/people_fhir/*/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_PEOPLE_FHIR_1 = {
    when: "*://*/*/people_fhir/*",
    endpoint: "*://*/*/people_fhir/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_PEOPLE_FHIR_2 = {
    when: "*://*/*/people_fhir/*/*",
    endpoint: "*://*/*/people_fhir/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_PEOPLE_FHIR_3 = {
    when: "*://*/*/people_fhir/*/*/*",
    endpoint: "*://*/*/people_fhir/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_PEOPLE_FHIR_4 = {
    when: "*://*/*/people_fhir/*/*/*/*",
    endpoint: "*://*/*/people_fhir/*/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_PWP_BACKEND_GET_1 = {
    when: "*://*/*/pwp_backend/*",
    endpoint: "*://*/*/pwp_backend/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PWP_BACKEND_GET_2 = {
    when: "*://*/*/pwp_backend/*/*",
    endpoint: "*://*/*/pwp_backend/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PWP_BACKEND_GET_3 = {
    when: "*://*/*/pwp_backend/*/*/*",
    endpoint: "*://*/*/pwp_backend/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PWP_BACKEND_POST_1 = {
    when: "*://*/*/pwp_backend/*",
    endpoint: "*://*/*/pwp_backend/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PWP_BACKEND_POST_2 = {
    when: "*://*/*/pwp_backend/*/*",
    endpoint: "*://*/*/pwp_backend/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PWP_BACKEND_POST_3 = {
    when: "*://*/*/pwp_backend/*/*/*",
    endpoint: "*://*/*/pwp_backend/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PWP_BACKEND_PUT_1 = {
    when: "*://*/*/pwp_backend/*",
    endpoint: "*://*/*/pwp_backend/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PWP_BACKEND_PUT_2 = {
    when: "*://*/*/pwp_backend/*/*",
    endpoint: "*://*/*/pwp_backend/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_PWP_BACKEND_PUT_3 = {
    when: "*://*/*/pwp_backend/*/*/*",
    endpoint: "*://*/*/pwp_backend/*/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_PWP_BACKEND_1 = {
    when: "*://*/*/pwp_backend/*",
    endpoint: "*://*/*/pwp_backend/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_PWP_BACKEND_2 = {
    when: "*://*/*/pwp_backend/*/*",
    endpoint: "*://*/*/pwp_backend/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_PWP_BACKEND_3 = {
    when: "*://*/*/pwp_backend/*/*/*",
    endpoint: "*://*/*/pwp_backend/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};



var IN_MHD_FHIR_GET_0 = {
    when: "*://*/*/x1v1_mhd/",
    endpoint: "*://*/*/x1v1_mhd/",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_MHD_FHIR_GET_1 = {
    when: "*://*/*/x1v1_mhd/*",
    endpoint: "*://*/*/x1v1_mhd/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_MHD_FHIR_GET_2 = {
    when: "*://*/*/x1v1_mhd/*/*",
    endpoint: "*://*/*/x1v1_mhd/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_MHD_FHIR_GET_3 = {
    when: "*://*/*/x1v1_mhd/*/*/*",
    endpoint: "*://*/*/x1v1_mhd/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_MHD_FHIR_POST_0 = {
    when: "*://*/*/x1v1_mhd/",
    endpoint: "*://*/*/x1v1_mhd/",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_MHD_FHIR_POST_1 = {
    when: "*://*/*/x1v1_mhd/*",
    endpoint: "*://*/*/x1v1_mhd/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_MHD_FHIR_POST_2 = {
    when: "*://*/*/x1v1_mhd/*/*",
    endpoint: "*://*/*/x1v1_mhd/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_MHD_FHIR_POST_3 = {
    when: "*://*/*/x1v1_mhd/*/*/*",
    endpoint: "*://*/*/x1v1_mhd/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_MHD_FHIR_0 = {
    when: "*://*/*/x1v1_mhd/",
    endpoint: "*://*/*/x1v1_mhd/",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_MHD_FHIR_1 = {
    when: "*://*/*/x1v1_mhd/*",
    endpoint: "*://*/*/x1v1_mhd/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_MHD_FHIR_2 = {
    when: "*://*/*/x1v1_mhd/*/*",
    endpoint: "*://*/*/x1v1_mhd/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_MHD_FHIR_3 = {
    when: "*://*/*/x1v1_mhd/*/*/*",
    endpoint: "*://*/*/x1v1_mhd/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_XVALUE_PATSYN_GET_1 = {
    when: "*://*/*/xvalue_patsyn/*",
    endpoint: "*://*/*/xvalue_patsyn/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_XVALUE_PATSYN_GET_2 = {
    when: "*://*/*/xvalue_patsyn/*/*",
    endpoint: "*://*/*/xvalue_patsyn/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_XVALUE_PATSYN_GET_3 = {
    when: "*://*/*/xvalue_patsyn/*/*/*",
    endpoint: "*://*/*/xvalue_patsyn/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_XVALUE_PATSYN_GET_4 = {
    when: "*://*/*/xvalue_patsyn/*/*/*/*",
    endpoint: "*://*/*/xvalue_patsyn/*/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_XVALUE_PATSYN_POST_1 = {
    when: "*://*/*/xvalue_patsyn/*",
    endpoint: "*://*/*/xvalue_patsyn/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_XVALUE_PATSYN_POST_2 = {
    when: "*://*/*/xvalue_patsyn/*/*",
    endpoint: "*://*/*/xvalue_patsyn/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_XVALUE_PATSYN_POST_3 = {
    when: "*://*/*/xvalue_patsyn/*/*/*",
    endpoint: "*://*/*/xvalue_patsyn/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_XVALUE_PATSYN_1 = {
    when: "*://*/*/xvalue_patsyn/*",
    endpoint: "*://*/*/xvalue_patsyn/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_XVALUE_PATSYN_2 = {
    when: "*://*/*/xvalue_patsyn/*/*",
    endpoint: "*://*/*/xvalue_patsyn/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_XVALUE_PATSYN_3 = {
    when: "*://*/*/xvalue_patsyn/*/*/*",
    endpoint: "*://*/*/xvalue_patsyn/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_XVALUE_PATSYN_4 = {
    when: "*://*/*/xvalue_patsyn/*/*/*/*",
    endpoint: "*://*/*/xvalue_patsyn/*/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};


var IN_X1V1_CONFIGURATOR_GET_1 = {
    when: "*://*/*/x1v1_configurator/*",
    endpoint: "*://*/*/x1v1_configurator/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_GET_2 = {
    when: "*://*/*/x1v1_configurator/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_GET_3 = {
    when: "*://*/*/x1v1_configurator/*/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_POST_1 = {
    when: "*://*/*/x1v1_configurator/*",
    endpoint: "*://*/*/x1v1_configurator/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_POST_2 = {
    when: "*://*/*/x1v1_configurator/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_POST_3 = {
    when: "*://*/*/x1v1_configurator/*/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_HEAD_1 = {
    when: "*://*/*/x1v1_configurator/*",
    endpoint: "*://*/*/x1v1_configurator/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_HEAD_2 = {
    when: "*://*/*/x1v1_configurator/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_HEAD_3 = {
    when: "*://*/*/x1v1_configurator/*/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_DELETE_1 = {
    when: "*://*/*/x1v1_configurator/*",
    endpoint: "*://*/*/x1v1_configurator/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_DELETE_2 = {
    when: "*://*/*/x1v1_configurator/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_DELETE_3 = {
    when: "*://*/*/x1v1_configurator/*/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_PUT_1 = {
    when: "*://*/*/x1v1_configurator/*",
    endpoint: "*://*/*/x1v1_configurator/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_PUT_2 = {
    when: "*://*/*/x1v1_configurator/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_X1V1_CONFIGURATOR_PUT_3 = {
    when: "*://*/*/x1v1_configurator/*/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_X1V1_CONFIGURATOR_1 = {
    when: "*://*/*/x1v1_configurator/*",
    endpoint: "*://*/*/x1v1_configurator/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_X1V1_CONFIGURATOR_2 = {
    when: "*://*/*/x1v1_configurator/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var OUT_X1V1_CONFIGURATOR_3 = {
    when: "*://*/*/x1v1_configurator/*/*/*",
    endpoint: "*://*/*/x1v1_configurator/*/*/*",
    phase: "OUT",
    skipEvaluationProcess: true
};


var IN_REST_GET_1 = {
    when: "*://*/*/rest/*",
    endpoint: "*://*/*/rest/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_REST_POST_1 = {
    when: "*://*/*/rest/*",
    endpoint: "*://*/*/rest/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_REST_PUT_1 = {
    when: "*://*/*/rest/*",
    endpoint: "*://*/*/rest/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_REST_HEAD_1 = {
    when: "*://*/*/rest/*",
    endpoint: "*://*/*/rest/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_REST_DELETE_1 = {
    when: "*://*/*/rest/*",
    endpoint: "*://*/*/rest/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_REST_1 = {
    when: "*://*/*/rest/*",
    endpoint: "*://*/*/rest/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_ARR_GET_1 = {
    when: "*://*/*/arr/*",
    endpoint: "*://*/*/arr/*",
    phase: "IN",
    httpMethod: "GET",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, getHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_ARR_POST_1 = {
    when: "*://*/*/arr/*",
    endpoint: "*://*/*/arr/*",
    phase: "IN",
    httpMethod: "POST",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, postHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_ARR_PUT_1 = {
    when: "*://*/*/arr/*",
    endpoint: "*://*/*/arr/*",
    phase: "IN",
    httpMethod: "PUT",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, putHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_ARR_HEAD_1 = {
    when: "*://*/*/arr/*",
    endpoint: "*://*/*/arr/*",
    phase: "IN",
    httpMethod: "HEAD",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, headHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var IN_ARR_DELETE_1 = {
    when: "*://*/*/arr/*",
    endpoint: "*://*/*/arr/*",
    phase: "IN",
    httpMethod: "DELETE",
    tokenType: "JWT",
    validateAction: false,
    attributes: [role, deleteHttpMethod],
    attributebag: {
        groupBy: fakeDocument,
        add: [restPolicy, fakeUniqueId]
    }
};

var OUT_ARR_1 = {
    when: "*://*/*/arr/*",
    endpoint: "*://*/*/arr/*",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_IIA_Search = {
    when: "serviceSearch",
    endpoint: "IIA",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_IIA_SearchResponse = {
    when: "serviceSearchResponse",
    endpoint: "IIA",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_IIA_SearchFull = {
    when: "serviceSearchFull",
    endpoint: "IIA",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_IIA_SearchFullResponse = {
    when: "serviceSearchResponseFull",
    endpoint: "IIA",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_IIA_Insert = {
    when: "serviceInsert",
    endpoint: "IIA",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionCreateUpdate],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_IIA_InsertResponse = {
    when: "serviceInsertResponse",
    endpoint: "IIA",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_IIA_Update = {
    when: "serviceUpdate",
    endpoint: "IIA",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionCreateUpdate],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_IIA_UpdateResponse = {
    when: "serviceUpdateResponse",
    endpoint: "IIA",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_IIA_Updates = {
    when: "serviceUpdates",
    endpoint: "IIA",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionCreateUpdate],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_IIA_UpdatesResponse = {
    when: "serviceUpdatesResponse",
    endpoint: "IIA",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_IIA_Merge = {
    when: "serviceMerge",
    endpoint: "IIA",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionCreateUpdate],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_IIA_MergeResponse = {
    when: "serviceMergeResponse",
    endpoint: "IIA",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_PRPA_QUQI = {
    when: "QUQI_IN000003UV01",
    endpoint: "PRPA_AR201304UV02_Service",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_PRPA_QUQI_Cancel = {
    when: "MCCI_IN000002UV01",
    endpoint: "PRPA_AR201304UV02_Service",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_PRPA_PRPA = {
    when: "PRPA_IN201305UV02",
    endpoint: "PRPA_AR201304UV02_Service",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_PRPA = {
    when: "PRPA_IN201306UV02",
    endpoint: "PRPA_AR201304UV02_Service",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_PRPA_PRPA_302 = {
    when: "PRPA_IN201302UV02",
    endpoint: "PRPA_AR201302UV02_Service",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var IN_PRPA_PRPA_301 = {
    when: "PRPA_IN201301UV02",
    endpoint: "PRPA_AR201302UV02_Service",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var IN_PRPA_PRPA_303 = {
    when: "PRPA_IN201303UV02",
    endpoint: "PRPA_AR201302UV02_Service",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var IN_PRPA_PRPA_304 = {
    when: "PRPA_IN201304UV02",
    endpoint: "PRPA_AR201302UV02_Service",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_PRPA_PRPA = {
    when: "MCCI_IN000002UV01",
    endpoint: "PRPA_AR201302UV02_Service",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_PRPA_MCCI_004 = {
    when: "MCCI_IN100004UV01",
    endpoint: "PRPA_AR201322IT01_Service",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var IN_PRPA_MCCI_001 = {
    when: "MCCI_IN100001UV01",
    endpoint: "PRPA_AR201322IT01_Service",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_PRPA_MCCI = {
    when: "PRPA_IN201321IT01",
    endpoint: "PRPA_AR201322IT01_Service",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_SND_MSG_S = {
    when: "sendMessageS",
    endpoint: "DOGE",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_SND_MSG_S = {
    when: "sendMessageSResponse",
    endpoint: "DOGE",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_SND_MSG_DOGE = {
    when: "sendMessageS",
    endpoint: "DOGE",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_SND_MSG_DOGE = {
    when: "sendMessageSResponse",
    endpoint: "DOGE",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_SND_MSG_S12 = {
    when: "sendMessageS",
    endpoint: "SendMessage12",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [registryPolicyId, fakeUniqueId]
    }
};

var OUT_SND_MSG_S12 = {
    when: "sendMessageSResponse",
    endpoint: "SendMessage12",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_pmas = {
    when: "pmas",
    endpoint: "pmas",
    phase: "IN",
    validateAction: false,
    validateSaml: false,
    attributes: [purposeOfUsePMAS, actionPMAS, userIdPMAS, userIdTaxCodePMAS, userRolePMAS, userHospitalPMAS, userFacilityPMAS, userWardPMAS, currentHospitalPMAS, currentFacilityPMAS, currentWardPMAS],
    attributebag: {
        groupBy: bundleResourcesPMAS,
        add: [typeCodePMAS, objectIdPMAS, objectCreationDatetimePMAS, patientIdPMAS, eventIdPMAS, documentIdPMAS, authorIdPMAS, authorIdTaxCodePMAS, objectHospitalPMAS, objectFacilityPMAS, objectWardPMAS, consentEndDatePMAS, consentStartDatePMAS, patientLHAHealthCareProviderIdPMAS, patientTutorsPMAS, creationPerformPMAS],
        repeatOn: policyIdPMAS
    }
};

var IN_pmasres = {
    when: "pmasres",
    endpoint: "pmasres",
    phase: "IN",
    validateAction: false,
    validateSaml: false,
    attributes: [actionPMAS, userRolePMAS],
    attributebag: {
        groupBy: bundleResourcesPMAS,
        add: [typeCodePMAS, objectIdPMAS, objectCreationDatetimePMAS, consentEndDatePMAS, consentStartDatePMAS, creationPerformPMAS],
        repeatOn: policyIdPMAS
    }
};

var IN_RemoveObjectsRequest_INI = {
    when: "RemoveObjectsRequest",
    endpoint: "DeleteDocumentSet_INI",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    attributes: [iniRoleAttribute, iniActionAttribute, iniPurposeofuseAttribute, iniConsentAttribute],
    attributebag: {
        groupBy: objectRef,
        add: [iniDeletePolicyId, fakeUniqueId]
    }
};

var OUT_RemoveObjectsResponse_INI = {
    when: "RegistryResponse",
    endpoint: "DeleteDocumentSet_INI",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_SubmitObjectsRequest_INI = {
    when: "SubmitObjectsRequest",
    endpoint: "RegisterDocumentSetb_INI",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    attributes: [iniRoleAttribute, iniActionAttribute, iniPurposeofuseAttribute, iniConsentAttribute],
    attributebag: {
        groupBy: extrinsicObject,
        add: [uniqueId, iniMetadataUpdatePolicyId]
    }
};

var OUT_SubmitObjectsResponse_INI = {
    when: "RegistryResponse",
    endpoint: "RegisterDocumentSetb_INI",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_ProvideAndRegisterDocumentSetRequest_INI = {
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB_INI",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    attributes: [role_ini, actionCreateUpdate],
    attributebag: {
        groupBy: extrinsicObject,
        add: [uniqueId, iniDefaultPolicyId]
    }
};

var OUT_RegistryResponse_INI = {
    when: "RegistryResponse",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB_INI",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_RetrieveDocumentSetRequest_INI = {
    when: "RetrieveDocumentSetRequest",
    endpoint: "DocumentRepository_RetrieveDocumentSet_INI",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    attributes: [iniRoleAttribute, iniActionAttribute, iniPurposeofuseAttribute, iniConsentAttribute],
    attributebag: {
        groupBy: extrinsicObject,
        add: [uniqueId, iniRetrieveDocPolicyId]
    }
};

var OUT_RetrieveDocumentSetResponse_INI = {
    when: "RetrieveDocumentSetResponse",
    endpoint: "DocumentRepository_RetrieveDocumentSet_INI",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_SearchDocumentRefRequest_INI = {
    when: "AdhocQueryRequest",
    endpoint: "RegistryStoredQuery_SearchDocumentRef",
    phase: "IN",
    skipEvaluationProcess: false,
    numberOfRequiredAssertion: 1,
    attributes: [iniRoleAttribute, iniActionAttribute, iniPurposeofuseAttribute, iniConsentAttribute],
    attributebag: {
        groupBy: extrinsicObject,
        add: [uniqueId, iniSearchDocumentPolicyId]
    }
};

var OUT_SearchDocumentRefResponse_INI = {
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery_SearchDocumentRef",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_SearchDocumentRequest_INI = {
    when: "AdhocQueryRequest",
    endpoint: "RegistryStoredQuery_SearchDocument",
    phase: "IN",
    skipEvaluationProcess: false,
    numberOfRequiredAssertion: 1,
    attributes: [iniRoleAttribute, iniActionAttribute, iniPurposeofuseAttribute, iniConsentAttribute],
    attributebag: {
        groupBy: extrinsicObject,
        add: [uniqueId, iniSearchDocumentPolicyId]
    }
};

var OUT_SearchDocumentResponse_INI = {
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery_SearchDocument",
    phase: "OUT",
    attributes: [iniRoleAttribute, iniActionAttribute, iniPurposeofuseAttribute, iniConsentAttribute],
    attributebag: {
        groupBy: extrinsicObject,
        add: [uniqueId, typeCode],
        repeatOn: policyIdAdhoc_INI
    }
};

var IN_RetrieveReferenceRequest_INI = {
    when: "AdhocQueryRequest",
    endpoint: "RegistryStoredQuery_RetrieveReference",
    phase: "IN",
    skipEvaluationProcess: false,
    numberOfRequiredAssertion: 1,
    attributes: [iniRoleAttribute, iniActionAttribute, iniPurposeofuseAttribute, iniConsentAttribute],
    attributebag: {
        groupBy: extrinsicObject,
        add: [uniqueId, iniRetrieveReferenceDocPolicyId]
    }
};

var OUT_RetrieveReferenceResponse_INI = {
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery_RetrieveReference",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_MoveIndexRequest_INI = {
    when: "AdhocQueryRequest",
    endpoint: "RegistryStoredQuery_MoveIndex",
    phase: "IN",
    skipEvaluationProcess: false,
    numberOfRequiredAssertion: 1,
    attributes: [iniRoleAttribute, iniActionAttribute, iniPurposeofuseAttribute, iniConsentAttribute],
    attributebag: {
        groupBy: extrinsicObject,
        add: [uniqueId, iniMoveIndexPolicyId]
    }
};

var OUT_MoveIndexResponse_INI = {
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery_MoveIndex",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_NEW_READ_FHIRRESOURCE = {
    "when": "fhirResourceRead",
    "endpoint": "fhirResourceRead",
    "phase": "IN",
    "httpMethod": "POST",
    "tokenType": "JWT",
    "validateAction": false,
    "validateSaml": true,
    "attributes": [{
            "id": "urn:oasis:names:tc:xacml:1.0:action:action-id",
            "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:action",
            "value": {
                "fixed": ["R"]
            },
            "includeInResult": false,
            "required": true
        }, {
		  "id": "urn:xacml:3.0:subject:subject-id",
		  "category": "urn:oasis:names:tc:xacml:1.0:subject-category:subject",
		  "when": {
			"discovery": {
			  "type": "mc",
			  "key": "identifier",
			  "returnType": "single"
			}
		  },
		  "then": {
			"discovery": {
			  "type": "mc",
			  "key": "identifier",
			  "returnType": "single",
			  "postProcessingAsUniqueValue": "true",
			  "postProcessing": "if ($out.length > 0) { var identifier = $out[0]; if (identifier.length > 0) { var splitted = identifier.split('^^^'); var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); if (splitted[1]) { var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); $out = value + '^^^&' + system + '&ISO'; } else { $out = value; } } }"
			}
		  },
		  "otherwise": {
			"discovery": {
			  "type": "rest",
			  "input": [
				{
				  "id": "identifiervalue",
				  "discovery": {
					"type": "mc",
					"key": "eu.dedalus.xvalue.policyengine.common.subject",
					"returnType": "single"
				  }
				}
			  ],
			  "config": {
				"method": "GET",
				"url": "@policy.fhir.practitioner.endpoint@/Practitioner?identifier=@policy.userIdentifierSystem@%7C{identifiervalue}",
				"headers": [
				  {
					"key": "accept",
					"value": "application/json"
				  },
				  {
					"key": "X-Gravitee-Api-Key",
					"value": "@policy.gravitee.apikey@"
				  }
				]
			  },
			  "returnpath": "$..entry[0].resource.identifier[?(@.system == '@policy.practitionerIdentifierSystem@')].value",
			  "postProcessing": "if ($out !== null && $out !== '') { $out = $out + '^^^&@policy.practitionerIdentifierSystem@&ISO'; } else { $out = $out; }",
			  "returnType": "single",
			  "cache": true
			}
		  },
		  "includeInResult": false,
		  "required": true,
		  "faultValue": {
			"faultCode": "subjectIdNotFound",
			"faultMessage": [
			  {
				"lang": "it",
				"message": "Id utente non trovato."
			  },
			  {
				"lang": "en",
				"message": "User id not found."
			  }
			],
			"faultDetail": ""
		  }
		}, {
            "id": "urn:xacml:3.0:subject:subject-role",
            "category": "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
            "discovery": {
                "type": "mc",
                "key": "eu.dedalus.xvalue.policyengine.common.subjectRole",
                "returnType": "single",
                "postProcessingAsUniqueValue": "true",
                "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var role = $out[i].split('@'); if (role[role.length - 1]) { ret.push(role[role.length - 1]); } } } $out = ret;",
                "postProcessingAsMappedValues": [{
                        "source": {
                            "storedListKey": "X1V1_ASSISTITO_Roles"
                        },
                        "target": {
                            "fixed": ["X1V1_ASSISTITO"]
                        }
                    }, {
                        "source": {
                            "storedListKey": "X1V1_TUTORE_Roles"
                        },
                        "target": {
                            "fixed": ["X1V1_TUTORE"]
                        }
                    }, {
                        "source": {
                            "storedListKey": "X1V1_MEDICO_Roles"
                        },
                        "target": {
                            "fixed": ["X1V1_MEDICO"]
                        }
                    }, {
                        "source": {
                            "storedListKey": "X1V1_MMG_Roles"
                        },
                        "target": {
                            "fixed": ["X1V1_MMG"]
                        }
                    }, {
                        "source": {
                            "storedListKey": "X1V1_AMMINISTRATIVO_Roles"
                        },
                        "target": {
                            "fixed": ["X1V1_AMMINISTRATIVO"]
                        }
                    }
                ]
            },
            "includeInResult": false,
            "required": true,
            "faultValue": {
                "faultCode": "subjectRoleNotFound",
                "faultMessage": [{
                        "lang": "it",
                        "message": "Ruolo utente non trovato."
                    }, {
                        "lang": "en",
                        "message": "User role not found."
                    }
                ],
                "faultDetail": ""
            }
        }, {
		  "id": "urn:xacml:3.0:subject:subject-purpose",
		  "category": "urn:oasis:names:tc:xacml:1.0:subject-category:purpose-subject",
		  "includeInResult": false,
		  "required": false,
		  "discovery": {
			"type": "mc",
			"key": "jwtPurposeOfUse",
			"returnType": "multiple",
			"whenNoResult": {
			  "value": {
				"fixed": [
				  "NO_PURPOSEOFUSE"
				]
			  }
			},
			"postProcessing": "var ret = []; if ($out !== null && $out !== '') {  var splitted=$out.split(' '); for (var k = 0; k < splitted.length; k++) { ret.push(splitted[k]); }  } else { ret.push('NO_PURPOSEOFUSE');} $out = ret;"
		  }
		}, {
            "id": "urn:xacml:3.0:subject:subject-ward",
            "category": "urn:oasis:names:tc:xacml:3.0:subject-category:ward-subject",
            "includeInResult": false,
            "required": false,
            "discovery": {
                "type": "mc",
                "key": "eu.dedalus.xvalue.policyengine.common.subjectRole",
                "returnType": "single",
                "postProcessingAsUniqueValue": "true",
                "postProcessingInput": [{
                        "name": "X1V1_ASSISTITO_Roles",
                        "storedListKey": "X1V1_ASSISTITO_Roles"
                    }, {
                        "name": "X1V1_TUTORE_Roles",
                        "storedListKey": "X1V1_TUTORE_Roles"
                    }, {
                        "name": "X1V1_MEDICO_Roles",
                        "storedListKey": "X1V1_MEDICO_Roles"
                    }, {
                        "name": "X1V1_MMG_Roles",
                        "storedListKey": "X1V1_MMG_Roles"
                    }, {
                        "name": "X1V1_AMMINISTRATIVO_Roles",
                        "storedListKey": "X1V1_AMMINISTRATIVO_Roles"
                    }
                ],
                "postProcessing": "var X1V1_ASSISTITO_Roles=[{X1V1_ASSISTITO_Roles}];var X1V1_TUTORE_Roles=[{X1V1_TUTORE_Roles}];var X1V1_MEDICO_Roles=[{X1V1_MEDICO_Roles}];var X1V1_MMG_Roles=[{X1V1_MMG_Roles}];var X1V1_AMMINISTRATIVO_Roles=[{X1V1_AMMINISTRATIVO_Roles}];var rolesToSplit=$out;$out='NO_SUBJECT_WARD';if(rolesToSplit.length>0){for(var i=0;i<rolesToSplit.length;i++){var role=rolesToSplit[i].split('@');if(role.length>1){var roleValue=role[role.length-1];var facilityValue=role[role.length-2];for(var j=0;j<X1V1_ASSISTITO_Roles.length;j++){if(roleValue==X1V1_ASSISTITO_Roles[j]){$out=facilityValue}}for(var j=0;j<X1V1_TUTORE_Roles.length;j++){if(roleValue==X1V1_TUTORE_Roles[j]){$out=facilityValue}}for(var j=0;j<X1V1_MEDICO_Roles.length;j++){if(roleValue==X1V1_MEDICO_Roles[j]){$out=facilityValue}}for(var j=0;j<X1V1_MMG_Roles.length;j++){if(roleValue==X1V1_MMG_Roles[j]){$out=facilityValue}}for(var j=0;j<X1V1_AMMINISTRATIVO_Roles.length;j++){if(roleValue==X1V1_AMMINISTRATIVO_Roles[j]){$out=facilityValue}}}}}",
                "whenNoResult": {
                    "value": {
                        "fixed": ["NO_SUBJECT_WARD"]
                    }
                }
            }
        }
    ],
    "attributebag": {
        "groupBy": {
            "id": "bundleObject",
            "discovery": {
                "type": "jsonpath",
                "expression": "$..entry",
                "returnType": "multiple"
            },
            "required": true,
            "faultValue": {
                "faultCode": "101",
                "faultMessage": [{
                        "lang": "it",
                        "message": "Formato errato della richiesta."
                    }, {
                        "lang": "en",
                        "message": "Malformed request."
                    }
                ],
                "faultDetail": ""
            }
        },
        "add": [{
                "id": "urn:xacml:3.0:environment:uniqueId",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "includeInResult": true,
                "required": true,
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..id",
                    "returnType": "single"
                },
                "faultValue": {
                    "faultCode": "101",
                    "faultMessage": [{
                            "lang": "it",
                            "message": "Id risorsa non trovato."
                        }, {
                            "lang": "en",
                            "message": "Resource id not found."
                        }
                    ],
                    "faultDetail": ""
                }
            }, {
                "id": "urn:xacml:3.0:environment:patientId",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "array": true,
                "includeInResult": true,
                "required": true,
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..patientIdentifier[*]",
                    "returnType": "multiple",
                    "postProcessingAsUniqueValue": true,
                    "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO');ret.push(value)}else{ret.push(identifier)}} $out=ret}",
					"whenNoResult": {
						"value": {
							"fixed": ["NO_PATIENT_IDENTIFIERS"]
						}
					}
                }
            }, {
                "id": "urn:xacml:3.0:environment:ward",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "array": true,
                "includeInResult": false,
                "required": false,
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..wardId[*]",
                    "returnType": "multiple",
                    "whenNoResult": {
                        "value": {
                            "fixed": ["NO_RESOURCE_WARD"]
                        }
                    }
                }
            }, {
                "id": "urn:xacml:3.0:environment:authorId",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "array": true,
                "includeInResult": false,
                "required": false,
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..authorId[*]",
                    "returnType": "multiple",
                    "postProcessingAsUniqueValue": true,
                    "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO');ret.push(value)}else{ret.push(identifier)}} $out=ret}",
                    "whenNoResult": {
                        "value": {
                            "fixed": ["NO_RESOURCE_AUTHOR"]
                        }
                    }
                }
            }, {
                "id": "urn:xacml:3.0:environment:patientTutors",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "array": true,
                "includeInResult": false,
                "required": false,
                "when": {                    
					"discovery": {
						"type": "jsonpath",
						"expression": "$..patientIdentifier[*]",
						"returnType": "multiple"
					}
                },
                "then": {
					"discovery": {
						"type": "mongo",
						"input": [{
								"id": "patientIdentifier",
								"discovery": {
									"type": "jsonpath",
									"expression": "$..patientIdentifier[*]",
									"returnType": "multiple",
									"postProcessingAsUniqueValue": true,
									"postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO');ret.push(value)}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
								}
							}
						],
						"expression": "{'patientid': { $in: [{patientIdentifier}] }}",
						"ref": "PM_CONSENT_ENGINE_DATASOURCE",
						"database": "@consent.engine.mongodb.name@",
						"collection": "tutor",
						"returnpath": "tutorid",
						"cache": true,
						"returnType": "multiple",
						"postProcessingAsUniqueValue": true,
						"postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^');if(splitted[0]&&splitted[8]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:','');var system=splitted[8].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO');ret.push(value)}else{ret.push(identifier)}}}$out=ret;",
						"whenNoResult": {
							"value": {
								"fixed": ["NO_PATIENT_TUTORS"]
							}
						}
					}
				},
                "otherwise": {
					"value": {
						"fixed": ["NO_PATIENT_TUTORS"]
					}
				}
            }, {
                "id": "urn:xacml:3.0:environment:creation-date",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "type": "integer",
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..creationDate",
                    "returnType": "single",
                    "whenNoResult": {
                        "value": {
                            "fixed": ["0"]
                        }
                    }
                },
                "includeInResult": false,
                "required": true
            }, {
                "id": "urn:xacml:3.0:environment:creation-performed",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..creationDate",
                    "postProcessing": "var year = $out.substring(0,4); var month = $out.substring(4,6); var day = $out.substring(6,8); var hours = $out.substring(8,10); var minutes = $out.substring(10,12); var seconds = $out.substring(12,14); var time = year+'-'+month+'-'+day+'T'+hours+':'+minutes+':'+seconds; var value = new Date(time).getTime(); var offset = new Date().getTime()-(45*24*60*60*1000); if(value >= offset) { $out='BEFORE_45_DAYS'; } else { $out='AFTER_45_DAYS'; }",
                    "returnType": "single",
                    "whenNoResult": {
                        "value": {
                            "fixed": ["BEFORE_45_DAYS"]
                        }
                    }
                },
                "includeInResult": false
            }, {
                "id": "urn:xacml:3.0:environment:typeCode",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "includeInResult": false,
                "required": false,
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..typeCode",
                    "returnType": "single",
                    "whenNoResult": {
                        "value": {
                            "fixed": ["NO_TYPECODE"]
                        }
                    }
                }
            }, {
                "id": "urn:xacml:3.0:environment:confidentialityCode",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "includeInResult": false,
                "required": false,
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..confidentialityCode[*]",
                    "returnType": "multiple",
                    "whenNoResult": {
                        "value": {
                            "fixed": ["NO_CONFIDENTIALITYCODE"]
                        }
                    }
                }
            }, {
                "id": "urn:xacml:3.0:environment:consents",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "array": true,
                "includeInResult": false,
                "required": false,
                "when": {                    
					"discovery": {
						"type": "jsonpath",
						"expression": "$..patientIdentifier[*]",
						"returnType": "multiple"
					}
                },
                "then": {
					"discovery": {
						"type": "mongo",
						"input": [{
								"id": "patientIdentifier",
								"discovery": {
									"type": "jsonpath",
									"expression": "$..patientIdentifier[*]",
									"returnType": "multiple",
									"postProcessingAsUniqueValue": true,
									"postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
								}
							}, {
								"id": "eventIdentifier",
								"discovery": {
									"type": "jsonpath",
									"expression": "$..eventIdentifier[*]",
									"returnType": "multiple",
									"postProcessingAsUniqueValue": true,
									"whenNoResult": {
										"value": {
											"fixed": [""]
										}
									},
									"postProcessing": "if($out&&$out.length>0){for(var ret=\"\",k=0;k<$out.length;k++){var identifier=$out[k],splittedWithoutSystem=identifier.split(\"^^^^\");if(splittedWithoutSystem[0]&&splittedWithoutSystem[1])ret+='\"'+identifier+'\"',ret+=$out.length-k>1?\",\":\"\";else{var splitted=identifier.split(\"^^^\");if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll(\"urn:oid:\",\"\"),splittedSystemAndType=splitted[1].split(\"^\"),systemAndType=\"\";splittedSystemAndType.length>1&&splittedSystemAndType[0]&&splittedSystemAndType[1]?(systemAndType=splittedSystemAndType[0].replaceAll(\"urn:oid:\",\"\")+\"^\"+splittedSystemAndType[1],splittedSystemAndType[2]&&(systemAndType+=\"^\"+splittedSystemAndType[2])):systemAndType=splitted[0].replaceAll(\"urn:oid:\",\"\"),splittedSystemAndType[0].startsWith(\"&\")?ret+='\"'+value+\"^^^\"+systemAndType+'\",\"'+value+\"^^^&urn:oid:\"+systemAndType.replace(\"&\",\"\")+'\"':ret+='\"'+value+\"^^^\"+systemAndType+'\",\"'+value+\"^^^urn:oid:\"+systemAndType+'\"',ret+=$out.length-k>1?\",\":\"\"}else ret+='\"'+identifier+'\"',ret+=$out.length-k>1?\",\":\"\"}}$out=' \"eventid\": { $in: [ '+ret+\" ] } \"}else $out=\"  $expr: { $eq: [0,1] } \";"
								}
							}, {
								"id": "documentId",
								"discovery": {
									"type": "jsonpath",
									"expression": "$..documentId",
									"returnType": "single",
									"postProcessingAsUniqueValue": true,
									"whenNoResult": {
										"value": {
											"fixed": [""]
										}
									},
									"postProcessing": "if($out && $out.length > 0){ $out = \"'documentid': { $in: [ '\" + $out[0] + \"', 'urn:oid:\" + $out[0] + \"', 'urn:uuid:\" + $out[0] + \"' ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
								}
							}, {
								"id": "requestId",
								"discovery": {
									"type": "jsonpath",
									"expression": "$..requestId",
									"returnType": "single",
									"postProcessingAsUniqueValue": true,
									"whenNoResult": {
										"value": {
											"fixed": [""]
										}
									},
									"postProcessing": "if($out && $out.length > 0) { var ret = \"\";  for(var k = 0;k < $out.length; k++) {ret += \"'\" + $out[k] + \"'\"; ret += ($out.length - k > 1) ? \",\" : \"\";} $out = \" 'requestGroupId': { $in: [ \" + ret + \" ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
								}
							}, {
								"id": "currentTime",
								"value": {
									"fixed": ["NOW"],
									"postProcessing": "var d = new Date(); $out = d.getTime() + '';"
								}
							}
						],
						"expression": "{'patientid': { $in: [{patientIdentifier}] }, 'status': 'active',  $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ], $or: [  { 'code': '@policy.authConsultation.code@' }, { 'code': '@policy.authConsultationPrevious.code@' }, { 'code': '@policy.obscuring.patient.code@' }, { 'code': '@policy.authConsultationRestricted.code@' }, { $and: [ {'code': '@policy.authConsultationLast45Days.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.forTutor.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.forTutorAndPatient.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.event.code@'}, {{eventIdentifier}} ] }, { $and: [ {'code': '@policy.obscuring.request.code@'}, {{requestId}} ] } ]}",
						"ref": "PM_CONSENT_ENGINE_DATASOURCE",
						"database": "@consent.engine.mongodb.name@",
						"collection": "consent",
						"projection": "{code : 1, status: 1}",
						"returnpath": "{code}_{status}",
						"cache": true,
						"returnType": "multiple",
						"whenNoResult": {
							"value": {
								"fixed": ["NO_CONSENTS"]
							}
						}
					}
				},
                "otherwise": {
					"value": {
						"fixed": ["NO_CONSENTS"]
					}
				}
            }, {
                "id": "urn:xacml:3.0:policy:policyId",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "includeInResult": true,
                "required": false,
                "discovery": {
                    "type": "mc",
                    "key": "eu.dedalus.xvalue.policyengine.common.subjectRole",
                    "returnType": "single",
                    "postProcessingAsUniqueValue": "true",
                    "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var role = $out[i].split('@'); if (role[role.length - 1]) { ret.push(role[role.length - 1]); } } } $out = ret;",
                    "postProcessingAsMappedValues": [{
                            "source": {
                                "storedListKey": "X1V1_ASSISTITO_Roles"
                            },
                            "target": {
                                "fixed": ["X1V1_ASSISTITO"]
                            }
                        }, {
                            "source": {
                                "storedListKey": "X1V1_TUTORE_Roles"
                            },
                            "target": {
                                "fixed": ["X1V1_TUTOR"]
                            }
                        }, {
                            "source": {
                                "storedListKey": "X1V1_MEDICO_Roles"
                            },
                            "target": {
                                "fixed": ["X1V1_MEDICO"]
                            }
                        }, {
                            "source": {
                                "storedListKey": "X1V1_MMG_Roles"
                            },
                            "target": {
                                "fixed": ["X1V1_MMG"]
                            }
                        }, {
                            "source": {
                                "storedListKey": "X1V1_AMMINISTRATIVO_Roles"
                            },
                            "target": {
                                "fixed": ["X1V1_AMMINISTRATIVO"]
                            }
                        }
                    ]
                }
            }
        ]
    }
};

var IN_READ_FHIRRESOURCE_NOAUTH = {
    when: "fhirResourceNoAuth",
    endpoint: "fhirResourceNoAuth",
    phase: "IN",
    httpMethod: "POST",
    validateAction: false,
    validateSaml: false,
    attributes: [actionRead],
    attributebag: {
        groupBy: bundleObject,
        add: [codeCoding, outcome, encounterConsent, encounterPerform, procedurePolicy, resourceId]
    }
};

var IN_READ_FHIR_PATIENTRESOURCE_NOAUTH = {
    when: "fhirPatientResourceNoAuth",
    endpoint: "fhirPatientResourceNoAuth",
    phase: "IN",
    httpMethod: "POST",
    validateAction: false,
    validateSaml: false,
    attributes: [userRoles, actionRead],
    attributebag: {
        groupBy: bundleObject,
        add: [resourceType, resourceUniqueId],
        repeatOn: customBundlePolicy
    }
};

var IN_Context_SETVALUE = {
    when: "setValueRequest",
    endpoint: "context",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionCreateUpdate],
    attributebag: {
        groupBy: document,
        add: [contextPolicyId, fakeUniqueId]
    }
};

var OUT_Context_SETVALUE = {
    when: "setValueResponse",
    endpoint: "context",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_Context_CLEARVALUE = {
    when: "clearAllValueRequest",
    endpoint: "context",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionCreateUpdate],
    attributebag: {
        groupBy: document,
        add: [contextPolicyId, fakeUniqueId]
    }
};

var OUT_Context_CLEARVALUE = {
    when: "clearAllValueResponse",
    endpoint: "context",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_Context_GETVALUE = {
    when: "getValueRequest",
    endpoint: "context",
    phase: "IN",
    numberOfRequiredAssertion: -1.0,
    validateAction: false,
    attributes: [role, actionRead],
    attributebag: {
        groupBy: document,
        add: [contextPolicyId, fakeUniqueId]
    }
};

var OUT_Context_GETVALUE = {
    when: "getValueResponse",
    endpoint: "context",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_DeleteDocumentSet_Default = {
    "when": "RemoveObjectsRequest",
    "endpoint": "DeleteDocumentSet_Default",
    "phase": "IN",
    "numberOfRequiredAssertion": 1,
    "skipXACMLProcessing": true,
    "attributes": [
        subjectIdWithPostProcessing,
        subjectRoleWithPostProcessingForAdministrativeRoles
    ]
};

var IN_UpdateDocumentSet_Default = {
    "when": "SubmitObjectsRequest",
    "endpoint": "UpdateDocumentSet_Default",
    "phase": "IN",
    "numberOfRequiredAssertion": 1,
    "skipXACMLProcessing": true,
    "attributes": [
        subjectIdWithPostProcessing,
        subjectRoleWithPostProcessingForAllRoles
    ]
};

var IN_DocumentRepository_RemoveDocumentsResponse_Default = {
    "when": "RemoveDocumentsRequest",
    "endpoint": "DocumentRepository_RemoveDocuments_Default",
    "phase": "IN",
    "numberOfRequiredAssertion": 1,
    "skipXACMLProcessing": true,
    "attributes": [
        subjectIdWithPostProcessing,
        subjectRoleWithPostProcessingForAdministrativeRoles
    ]
};

var IN_DocumentRepository_RetrieveDocumentSet_Default = {
    "when": "RetrieveDocumentSetRequest",
    "endpoint": "DocumentRepository_RetrieveDocumentSet_Default",
    "phase": "IN",
    "numberOfRequiredAssertion": 1,
    "skipXACMLProcessing": true,
    "attributes": [
        subjectIdWithPostProcessing,
        subjectRoleWithPostProcessingForAllRoles
    ]
};

var IN_DocumentRepository_ProvideAndRegisterDocumentSetB_Default = {
    "when": "ProvideAndRegisterDocumentSetRequest",
    "endpoint": "DocumentRepository_ProvideAndRegisterDocumentSetB_Default",
    "phase": "IN",
    "numberOfRequiredAssertion": 1,
    "skipXACMLProcessing": true,
    "attributes": [
        subjectIdWithPostProcessing,
        subjectRoleWithPostProcessingForAllRoles
    ]
};

var IN_RegistryStoredQuery_Default = {
    "when": "AdhocQueryRequest",
    "endpoint": "RegistryStoredQuery_Default",
    "phase": "IN",
    "numberOfRequiredAssertion": 1,
    "skipXACMLProcessing": true,
    "attributes": [
        subjectIdWithPostProcessing,
        subjectRoleWithPostProcessingForAllRoles,
        checkStoreQueryId
    ]
};

var OUT_UpdateDocumentSet_Default = {
    "when": "RegistryResponse",
    "endpoint": "UpdateDocumentSet_Default",
    "phase": "OUT",
    "skipEvaluationProcess": true
};

var OUT_DeleteDocumentSet_Default = {
    "when": "RegistryResponse",
    "endpoint": "DeleteDocumentSet_Default",
    "phase": "OUT",
    "skipEvaluationProcess": true
};

var OUT_DocumentRepository_RemoveDocumentsResponse_Default = {
    "when": "RegistryResponse",
    "endpoint": "DocumentRepository_RemoveDocuments_Default",
    "phase": "OUT",
    "skipEvaluationProcess": true
};

var OUT_DocumentRepository_ProvideAndRegisterDocumentSetB_Default = {
    "when": "RegistryResponse",
    "endpoint": "DocumentRepository_ProvideAndRegisterDocumentSetB_Default",
    "phase": "OUT",
    "skipEvaluationProcess": true
};

var OUT_DocumentRepository_RetrieveDocumentSet_Default = {
    "when": "RetrieveDocumentSetResponse",
    "endpoint": "DocumentRepository_RetrieveDocumentSet_Default",
    "phase": "OUT",
    "skipPDPWhen": discoverAdministrativeRoles,
    "attributes": [
        actionRead,
        subjectIdWithPostProcessing,
        subjectPurposeOfUse,
        subjectRoleWithPostProcessingForAllRoles,
        subjectWardWithPostProcessing,
        getPatientIdFromRetrieveDocumentSetResponse,
        getPatientTutorsFromRetrieveDocumentSetResponse,
        getPolicyBySubjectRole
    ],
    "attributebag": {
        "groupBy": groupByForRetrieveDocumentSetResponse,
        "add": [
            getUniqueIdFromRetrieveDocumentSetResponse,
            getWardFromRetrieveDocumentSetResponse,
            getAuthorFromRetrieveDocumentSetResponse,
            getCreationDateFromRetrieveDocumentSetResponse,
            getCreationPerformedFromRetrieveDocumentSetResponse,
            getConfidentialityCodeForRetrieveDocumentSetResponse,
            getTypeCodeForRetrieveDocumentSetResponse,
            getConsentsFromRetrieveDocumentSetResponse
        ]
    }
};

var OUT_RegistryStoredQuery_Default = {
    "when": "AdhocQueryResponse",
    "endpoint": "RegistryStoredQuery_Default",
    "phase": "OUT",
    "skipPDPWhen": discoverAdministrativeRoles,
    "attributes": [
        actionRead,
        subjectIdWithPostProcessing,
        subjectPurposeOfUse,
        subjectRoleWithPostProcessingForAllRoles,
        subjectWardWithPostProcessing,
        getPatientIdForAdhocQueryResponse,
        getPatientTutorsForAdhocQueryResponse,
        getPolicyBySubjectRole
    ],
    "attributebag": {
        "groupBy": getGroupByForAdhocQueryResponse,
        "add": [
            getUniqueIdForAdhocQueryResponse,
            getWardForAdhocQueryResponse,
            getAuthorForAdhocQueryResponse,
            getCreationDateForAdhocQueryResponse,
            getCreationPerformedForAdhocQueryResponse,
            getConfidentialityCodeForAdhocQueryResponse,
            getTypeCodeForAdhocQueryResponse,
            getConsentsForAdhocQueryResponse
        ]
    }
};

var IN_ProvideAndRegisterDocumentSetRequest = {
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    skipEvaluationProcess: true
};

var OUT_RegistryResponse = {
    when: "RegistryResponse",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB",
    phase: "OUT",
    skipEvaluationProcess: true
};

// deprecated
var IN_ProvideAndRegisterDocumentSetRequestBPPC = {
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetBBPPC",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    skipEvaluationProcess: true
};

//deprecated
var OUT_RegistryResponseBPPC = {
    when: "RegistryResponse",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetBBPPC",
    phase: "OUT",
    skipEvaluationProcess: true
};

//per iti-41 con ruolo applicativo MDM
var IN_ProvideAndRegisterDocumentSetRequest_lisproxy = {
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "lis-proxy",
    phase: "IN",
    validateSaml: false,
    validateAction: false,
    attributes: [mdmRole, actionCreateUpdate],
    attributebag: {
        groupBy: extrinsicObject,
        add: [uniqueId, typeCode],
        repeatOn: genericPolicyId
    }
};

var OUT_ProvideAndRegisterDocumentSetResponse_lisproxy = {
    when: "RegistryResponse",
    endpoint: "lis-proxy",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_RetrieveDocumentSetRequest = {
    when: "RetrieveDocumentSetRequest",
    endpoint: "DocumentRepository_RetrieveDocumentSet",
    phase: "IN",
    numberOfRequiredAssertion: 1,
    skipEvaluationProcess: true
};

var OUT_RetrieveDocumentSetResponse = {
    when: "RetrieveDocumentSetResponse",
    endpoint: "DocumentRepository_RetrieveDocumentSet",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_AdhocQueryRequest = {
    when: "AdhocQueryRequest",
    endpoint: "RegistryStoredQuery",
    phase: "IN",
    skipEvaluationProcess: true,
    numberOfRequiredAssertion: 1
};

var OUT_AdhocQueryResponse = {
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery",
    phase: "OUT",
    attributes: [role, actionRead],
    attributebag: {
        groupBy: extrinsicObject,
        add: [
            uniqueId,
            typeCode,
            creationPerform,
            documentCreationDate, {
                "id": "urn:xacml:3.0:environment:consent:enddate",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "type": "date",
                "when": {
                    "when": {
                        "discovery": {
                            "type": "jsonpath",
                            "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                            "returnType": "single"
                        }
                    },
                    "then": {
                        "discovery": {
                            "type": "mongo",
                            "input": [{
                                    "id": "patientIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                        "returnType": "single",
                                        "postProcessingAsUniqueValue": true,
                                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                    }
                                }, {
                                    "id": "eventIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                                        "returnType": "multiple",
                                        "postProcessingAsUniqueValue": true,
                                        "whenNoResult": {
                                            "value": {
                                                "fixed": [
                                                    ""
                                                ]
                                            }
                                        },
                                        "postProcessing": "if($out && $out.length > 0) { var ret = \"\";  for(var k = 0;k < $out.length; k++) {ret += \"'\" + $out[k] + \"'\"; ret += ($out.length - k > 1) ? \",\" : \"\";} $out = \" 'eventid': { $in: [ \" + ret + \" ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                                    }
                                }, {
                                    "id": "consentCode",
                                    "value": {
                                        "fixed": [
                                            "A1"
                                        ]
                                    }
                                }
                            ],
                            "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {{eventIdentifier}}",
                            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                            "database": "@consent.engine.mongodb.name@",
                            "collection": "consent",
                            "projection": "{code : 1}",
                            "returnpath": "code",
                            "cache": true,
                            "returnType": "single",
                            "postProcessing": "if($out == 'true') {$out = 'A1';} else {$out = ''};",
                            "whenNoResult": {
                                "discovery": {
                                    "type": "mongo",
                                    "input": [{
                                            "id": "patientIdentifier",
                                            "source": "groupBy",
                                            "discovery": {
                                                "type": "jsonpath",
                                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                "returnType": "single",
                                                "postProcessingAsUniqueValue": true,
                                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                            }
                                        }, {
                                            "id": "consentCode",
                                            "value": {
                                                "fixed": [
                                                    "A1"
                                                ]
                                            }
                                        }
                                    ],
                                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}",
                                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                    "database": "@consent.engine.mongodb.name@",
                                    "collection": "consent",
                                    "projection": "{code : 1}",
                                    "returnpath": "code",
                                    "cache": true,
                                    "returnType": "single",
                                    "postProcessing": "if($out == 'true') {$out = 'A1';} else {$out = ''};"
                                }
                            }
                        }
                    },
                    "otherwise": {
                        "discovery": {
                            "type": "mongo",
                            "input": [{
                                    "id": "patientIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                        "returnType": "single",
                                        "postProcessingAsUniqueValue": true,
                                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                    }
                                }, {
                                    "id": "consentCode",
                                    "value": {
                                        "fixed": [
                                            "A1"
                                        ]
                                    }
                                }
                            ],
                            "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}",
                            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                            "database": "@consent.engine.mongodb.name@",
                            "collection": "consent",
                            "projection": "{code : 1}",
                            "returnpath": "code",
                            "cache": true,
                            "returnType": "single",
                            "postProcessing": "if($out == 'true') {$out = 'A1';} else {$out = ''};"
                        }
                    }
                },
                "then": {
                    "when": {
                        "discovery": {
                            "type": "jsonpath",
                            "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                            "returnType": "single"
                        }
                    },
                    "then": {
                        "discovery": {
                            "type": "mongo",
                            "input": [{
                                    "id": "patientIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                        "returnType": "single",
                                        "postProcessingAsUniqueValue": true,
                                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                    }
                                }, {
                                    "id": "eventIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                                        "returnType": "multiple",
                                        "postProcessingAsUniqueValue": true,
                                        "whenNoResult": {
                                            "value": {
                                                "fixed": [
                                                    ""
                                                ]
                                            }
                                        },
                                        "postProcessing": "if($out && $out.length > 0) { var ret = \"\";  for(var k = 0;k < $out.length; k++) {ret += \"'\" + $out[k] + \"'\"; ret += ($out.length - k > 1) ? \",\" : \"\";} $out = \" 'eventid': { $in: [ \" + ret + \" ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                                    }
                                }, {
                                    "id": "consentCode",
                                    "value": {
                                        "fixed": [
                                            "A1"
                                        ]
                                    }
                                }
                            ],
                            "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {{eventIdentifier}}, {'status': 'active'}",
                            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                            "database": "@consent.engine.mongodb.name@",
                            "collection": "consent",
                            "projection": "{period.end : 1}",
                            "returnpath": "period.end",
                            "cache": true,
                            "returnType": "single",
                            "whenNoResult": {
                                "discovery": {
                                    "type": "mongo",
                                    "input": [{
                                            "id": "patientIdentifier",
                                            "source": "groupBy",
                                            "discovery": {
                                                "type": "jsonpath",
                                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                "returnType": "single",
                                                "postProcessingAsUniqueValue": true,
                                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                            }
                                        }, {
                                            "id": "consentCode",
                                            "value": {
                                                "fixed": [
                                                    "A1"
                                                ]
                                            }
                                        }
                                    ],
                                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {'status': 'active'}",
                                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                    "database": "@consent.engine.mongodb.name@",
                                    "collection": "consent",
                                    "projection": "{period.end : 1}",
                                    "returnpath": "period.end",
                                    "cache": true,
                                    "returnType": "single",
                                    "whenNoResult": {
                                        "discovery": {
                                            "type": "mongo",
                                            "input": [{
                                                    "id": "patientIdentifier",
                                                    "source": "groupBy",
                                                    "discovery": {
                                                        "type": "jsonpath",
                                                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                        "returnType": "single",
                                                        "postProcessingAsUniqueValue": true,
                                                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                                    }
                                                }, {
                                                    "id": "eventIdentifier",
                                                    "source": "groupBy",
                                                    "discovery": {
                                                        "type": "jsonpath",
                                                        "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                                                        "returnType": "multiple",
                                                        "postProcessingAsUniqueValue": true,
                                                        "whenNoResult": {
                                                            "value": {
                                                                "fixed": [
                                                                    ""
                                                                ]
                                                            }
                                                        },
                                                        "postProcessing": "if($out && $out.length > 0) { var ret = \"\";  for(var k = 0;k < $out.length; k++) {ret += \"'\" + $out[k] + \"'\"; ret += ($out.length - k > 1) ? \",\" : \"\";} $out = \" 'eventid': { $in: [ \" + ret + \" ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                                                    }
                                                }, {
                                                    "id": "consentCode",
                                                    "value": {
                                                        "fixed": [
                                                            "A1"
                                                        ]
                                                    }
                                                }
                                            ],
                                            "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {{eventIdentifier}}, {'status': 'active'}",
                                            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                            "database": "@consent.engine.mongodb.name@",
                                            "collection": "consent_historical",
                                            "projection": "{period.end : 1}",
                                            "returnpath": "period.end",
                                            "cache": true,
                                            "returnType": "single",
                                            "whenNoResult": {
                                                "discovery": {
                                                    "type": "mongo",
                                                    "input": [{
                                                            "id": "patientIdentifier",
                                                            "source": "groupBy",
                                                            "discovery": {
                                                                "type": "jsonpath",
                                                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                                "returnType": "single",
                                                                "postProcessingAsUniqueValue": true,
                                                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                                            }
                                                        }, {
                                                            "id": "consentCode",
                                                            "value": {
                                                                "fixed": [
                                                                    "A1"
                                                                ]
                                                            }
                                                        }
                                                    ],
                                                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {'status': 'active'}",
                                                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                                    "database": "@consent.engine.mongodb.name@",
                                                    "collection": "consent_historical",
                                                    "projection": "{period.end : 1}",
                                                    "returnpath": "period.end",
                                                    "cache": true,
                                                    "returnType": "single"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "otherwise": {
                        "discovery": {
                            "type": "mongo",
                            "input": [{
                                    "id": "patientIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                        "returnType": "single",
                                        "postProcessingAsUniqueValue": true,
                                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                    }
                                }, {
                                    "id": "consentCode",
                                    "value": {
                                        "fixed": [
                                            "A1"
                                        ]
                                    }
                                }
                            ],
                            "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {'status': 'active'}",
                            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                            "database": "@consent.engine.mongodb.name@",
                            "collection": "consent",
                            "projection": "{period.end : 1}",
                            "returnpath": "period.end",
                            "cache": true,
                            "returnType": "single",
                            "whenNoResult": {
                                "discovery": {
                                    "type": "mongo",
                                    "input": [{
                                            "id": "patientIdentifier",
                                            "source": "groupBy",
                                            "discovery": {
                                                "type": "jsonpath",
                                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                "returnType": "single",
                                                "postProcessingAsUniqueValue": true,
                                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                            }
                                        }, {
                                            "id": "consentCode",
                                            "value": {
                                                "fixed": [
                                                    "A1"
                                                ]
                                            }
                                        }
                                    ],
                                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {'status': 'active'}",
                                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                    "database": "@consent.engine.mongodb.name@",
                                    "collection": "consent_historical",
                                    "projection": "{period.end : 1}",
                                    "returnpath": "period.end",
                                    "cache": true,
                                    "returnType": "single"
                                }
                            }
                        }
                    }
                },
                "otherwise": {
                    "value": {
                        "fixed": []
                    }
                },
                "includeInResult": false
            }, {
                "id": "urn:xacml:3.0:environment:consent:startdate",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "type": "date",
                "when": {
                    "when": {
                        "discovery": {
                            "type": "jsonpath",
                            "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                            "returnType": "single"
                        }
                    },
                    "then": {
                        "discovery": {
                            "type": "mongo",
                            "input": [{
                                    "id": "patientIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                        "returnType": "single",
                                        "postProcessingAsUniqueValue": true,
                                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                    }
                                }, {
                                    "id": "eventIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                                        "returnType": "multiple",
                                        "postProcessingAsUniqueValue": true,
                                        "whenNoResult": {
                                            "value": {
                                                "fixed": [
                                                    ""
                                                ]
                                            }
                                        },
                                        "postProcessing": "if($out && $out.length > 0) { var ret = \"\";  for(var k = 0;k < $out.length; k++) {ret += \"'\" + $out[k] + \"'\"; ret += ($out.length - k > 1) ? \",\" : \"\";} $out = \" 'eventid': { $in: [ \" + ret + \" ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                                    }
                                }, {
                                    "id": "consentCode",
                                    "value": {
                                        "fixed": [
                                            "A1"
                                        ]
                                    }
                                }
                            ],
                            "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {{eventIdentifier}}",
                            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                            "database": "@consent.engine.mongodb.name@",
                            "collection": "consent",
                            "projection": "{code : 1}",
                            "returnpath": "code",
                            "cache": true,
                            "returnType": "single",
                            "postProcessing": "if($out == 'true') {$out = 'A1';} else {$out = ''};",
                            "whenNoResult": {
                                "discovery": {
                                    "type": "mongo",
                                    "input": [{
                                            "id": "patientIdentifier",
                                            "source": "groupBy",
                                            "discovery": {
                                                "type": "jsonpath",
                                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                "returnType": "single",
                                                "postProcessingAsUniqueValue": true,
                                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                            }
                                        }, {
                                            "id": "consentCode",
                                            "value": {
                                                "fixed": [
                                                    "A1"
                                                ]
                                            }
                                        }
                                    ],
                                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}",
                                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                    "database": "@consent.engine.mongodb.name@",
                                    "collection": "consent",
                                    "projection": "{code : 1}",
                                    "returnpath": "code",
                                    "cache": true,
                                    "returnType": "single",
                                    "postProcessing": "if($out == 'true') {$out = 'A1';} else {$out = ''};"
                                }
                            }
                        }
                    },
                    "otherwise": {
                        "discovery": {
                            "type": "mongo",
                            "input": [{
                                    "id": "patientIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                        "returnType": "single",
                                        "postProcessingAsUniqueValue": true,
                                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                    }
                                }, {
                                    "id": "consentCode",
                                    "value": {
                                        "fixed": [
                                            "A1"
                                        ]
                                    }
                                }
                            ],
                            "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}",
                            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                            "database": "@consent.engine.mongodb.name@",
                            "collection": "consent",
                            "projection": "{code : 1}",
                            "returnpath": "code",
                            "cache": true,
                            "returnType": "single",
                            "postProcessing": "if($out == 'true') {$out = 'A1';} else {$out = ''};"
                        }
                    }
                },
                "then": {
                    "when": {
                        "discovery": {
                            "type": "jsonpath",
                            "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                            "returnType": "single"
                        }
                    },
                    "then": {
                        "discovery": {
                            "type": "mongo",
                            "input": [{
                                    "id": "patientIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                        "returnType": "single",
                                        "postProcessingAsUniqueValue": true,
                                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                    }
                                }, {
                                    "id": "eventIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                                        "returnType": "multiple",
                                        "postProcessingAsUniqueValue": true,
                                        "whenNoResult": {
                                            "value": {
                                                "fixed": [
                                                    ""
                                                ]
                                            }
                                        },
                                        "postProcessing": "if($out && $out.length > 0) { var ret = \"\";  for(var k = 0;k < $out.length; k++) {ret += \"'\" + $out[k] + \"'\"; ret += ($out.length - k > 1) ? \",\" : \"\";} $out = \" 'eventid': { $in: [ \" + ret + \" ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                                    }
                                }, {
                                    "id": "consentCode",
                                    "value": {
                                        "fixed": [
                                            "A1"
                                        ]
                                    }
                                }
                            ],
                            "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {{eventIdentifier}}, {'status': 'active'}",
                            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                            "database": "@consent.engine.mongodb.name@",
                            "collection": "consent",
                            "projection": "{period.start : 1}",
                            "returnpath": "period.start",
                            "cache": true,
                            "returnType": "single",
                            "whenNoResult": {
                                "discovery": {
                                    "type": "mongo",
                                    "input": [{
                                            "id": "patientIdentifier",
                                            "source": "groupBy",
                                            "discovery": {
                                                "type": "jsonpath",
                                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                "returnType": "single",
                                                "postProcessingAsUniqueValue": true,
                                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                            }
                                        }, {
                                            "id": "consentCode",
                                            "value": {
                                                "fixed": [
                                                    "A1"
                                                ]
                                            }
                                        }
                                    ],
                                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {'status': 'active'}",
                                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                    "database": "@consent.engine.mongodb.name@",
                                    "collection": "consent",
                                    "projection": "{period.start : 1}",
                                    "returnpath": "period.start",
                                    "cache": true,
                                    "returnType": "single",
                                    "whenNoResult": {
                                        "discovery": {
                                            "type": "mongo",
                                            "input": [{
                                                    "id": "patientIdentifier",
                                                    "source": "groupBy",
                                                    "discovery": {
                                                        "type": "jsonpath",
                                                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                        "returnType": "single",
                                                        "postProcessingAsUniqueValue": true,
                                                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                                    }
                                                }, {
                                                    "id": "eventIdentifier",
                                                    "source": "groupBy",
                                                    "discovery": {
                                                        "type": "jsonpath",
                                                        "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                                                        "returnType": "multiple",
                                                        "postProcessingAsUniqueValue": true,
                                                        "whenNoResult": {
                                                            "value": {
                                                                "fixed": [
                                                                    ""
                                                                ]
                                                            }
                                                        },
                                                        "postProcessing": "if($out && $out.length > 0) { var ret = \"\";  for(var k = 0;k < $out.length; k++) {ret += \"'\" + $out[k] + \"'\"; ret += ($out.length - k > 1) ? \",\" : \"\";} $out = \" 'eventid': { $in: [ \" + ret + \" ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                                                    }
                                                }, {
                                                    "id": "consentCode",
                                                    "value": {
                                                        "fixed": [
                                                            "A1"
                                                        ]
                                                    }
                                                }
                                            ],
                                            "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {{eventIdentifier}}, {'status': 'active'}",
                                            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                            "database": "@consent.engine.mongodb.name@",
                                            "collection": "consent_historical",
                                            "projection": "{period.start : 1}",
                                            "returnpath": "period.start",
                                            "cache": true,
                                            "returnType": "single",
                                            "whenNoResult": {
                                                "discovery": {
                                                    "type": "mongo",
                                                    "input": [{
                                                            "id": "patientIdentifier",
                                                            "source": "groupBy",
                                                            "discovery": {
                                                                "type": "jsonpath",
                                                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                                "returnType": "single",
                                                                "postProcessingAsUniqueValue": true,
                                                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                                            }
                                                        }, {
                                                            "id": "consentCode",
                                                            "value": {
                                                                "fixed": [
                                                                    "A1"
                                                                ]
                                                            }
                                                        }
                                                    ],
                                                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {'status': 'active'}",
                                                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                                    "database": "@consent.engine.mongodb.name@",
                                                    "collection": "consent_historical",
                                                    "projection": "{period.start : 1}",
                                                    "returnpath": "period.start",
                                                    "cache": true,
                                                    "returnType": "single"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    },
                    "otherwise": {
                        "discovery": {
                            "type": "mongo",
                            "input": [{
                                    "id": "patientIdentifier",
                                    "source": "groupBy",
                                    "discovery": {
                                        "type": "jsonpath",
                                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                        "returnType": "single",
                                        "postProcessingAsUniqueValue": true,
                                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                    }
                                }, {
                                    "id": "consentCode",
                                    "value": {
                                        "fixed": [
                                            "A1"
                                        ]
                                    }
                                }
                            ],
                            "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {'status': 'active'}",
                            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                            "database": "@consent.engine.mongodb.name@",
                            "collection": "consent",
                            "projection": "{period.start : 1}",
                            "returnpath": "period.start",
                            "cache": true,
                            "returnType": "single",
                            "whenNoResult": {
                                "discovery": {
                                    "type": "mongo",
                                    "input": [{
                                            "id": "patientIdentifier",
                                            "source": "groupBy",
                                            "discovery": {
                                                "type": "jsonpath",
                                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                "returnType": "single",
                                                "postProcessingAsUniqueValue": true,
                                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                            }
                                        }, {
                                            "id": "consentCode",
                                            "value": {
                                                "fixed": [
                                                    "A1"
                                                ]
                                            }
                                        }
                                    ],
                                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {'status': 'active'}",
                                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                    "database": "@consent.engine.mongodb.name@",
                                    "collection": "consent_historical",
                                    "projection": "{period.start : 1}",
                                    "returnpath": "period.start",
                                    "cache": true,
                                    "returnType": "single"
                                }
                            }
                        }
                    }
                },
                "otherwise": {
                    "value": {
                        "fixed": []
                    }
                },
                "includeInResult": false
            }
        ],
        repeatOn: {
            "id": "urn:xacml:3.0:policy:policyId",
            "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
            "includeInResult": true,
            "when": {
                "discovery": {
                    "type": "mongo",
                    "input": [{
                            "id": "patientIdentifier",
                            "source": "groupBy",
                            "discovery": {
                                "type": "jsonpath",
                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                "returnType": "single",
                                "postProcessingAsUniqueValue": true,
                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                            }
                        }, {
                            "id": "documentId",
                            "discovery": {
                                "type": "jsonpath",
                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
                                "returnType": "single",
                                "postProcessingAsUniqueValue": true,
                                "postProcessing": "if($out && $out.length > 0){ $out = \"'documentid': { $in: [ '\" + $out[0] + \"' ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                            }
                        }, {
                            "id": "consentCode",
                            "value": {
                                "fixed": [
                                    "P80"
                                ]
                            }
                        }
                    ],
                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {{documentId}}, {'status': 'active'}",
                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                    "database": "@consent.engine.mongodb.name@",
                    "collection": "consent",
                    "projection": "{code : 1}",
                    "returnpath": "code",
                    "cache": true,
                    "returnType": "single"
                }
            },
            "then": {
                "discovery": {
                    "type": "mongo",
                    "input": [{
                            "id": "patientIdentifier",
                            "source": "groupBy",
                            "discovery": {
                                "type": "jsonpath",
                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                "returnType": "single",
                                "postProcessingAsUniqueValue": true,
                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                            }
                        }, {
                            "id": "documentId",
                            "discovery": {
                                "type": "jsonpath",
                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
                                "returnType": "single",
                                "postProcessingAsUniqueValue": true,
                                "postProcessing": "if($out && $out.length > 0){ $out = \"'documentid': { $in: [ '\" + $out[0] + \"' ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                            }
                        }, {
                            "id": "consentCode",
                            "value": {
                                "fixed": [
                                    "P80"
                                ]
                            }
                        }
                    ],
                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'code': '{consentCode}'}, {{documentId}}, {'status': 'active'}",
                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                    "database": "@consent.engine.mongodb.name@",
                    "collection": "consent",
                    "projection": "{code : 1}",
                    "returnpath": "code",
                    "cache": true,
                    "unionResult": {
                        "id": "urn:xacml:3.0:policy:policyId",
                        "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                        "when": {
                            "discovery": {
                                "type": "jsonpath",
                                "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                                "returnType": "multiple"
                            }
                        },
                        "then": {
                            "discovery": {
                                "type": "mongo",
                                "input": [{
                                        "id": "patientIdentifier",
                                        "source": "groupBy",
                                        "discovery": {
                                            "type": "jsonpath",
                                            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                            "returnType": "single",
                                            "postProcessingAsUniqueValue": true,
                                            "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                        }
                                    }, {
                                        "id": "eventIdentifier",
                                        "discovery": {
                                            "type": "jsonpath",
                                            "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                                            "returnType": "multiple",
                                            "postProcessingAsUniqueValue": true,
                                            "whenNoResult": {
                                                "value": {
                                                    "fixed": [
                                                        ""
                                                    ]
                                                }
                                            },
                                            "postProcessing": "if($out && $out.length > 0) { var ret = \"\";  for(var k = 0;k < $out.length; k++) {ret += \"'\" + $out[k] + \"'\"; ret += ($out.length - k > 1) ? \",\" : \"\";} $out = \" 'eventid': { $in: [ \" + ret + \" ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                                        }
                                    }
                                ],
                                "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {{eventIdentifier}}, {'status': 'active'}",
                                "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                "database": "@consent.engine.mongodb.name@",
                                "collection": "consent",
                                "projection": "{code : 1}",
                                "returnpath": "code",
                                "cache": true,
                                "whenNoResult": {
                                    "id": "urn:xacml:3.0:policy:policyId",
                                    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                                    "discovery": {
                                        "type": "mongo",
                                        "input": [{
                                                "id": "patientIdentifier",
                                                "source": "groupBy",
                                                "discovery": {
                                                    "type": "jsonpath",
                                                    "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                    "returnType": "single",
                                                    "postProcessingAsUniqueValue": true,
                                                    "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                                }
                                            }
                                        ],
                                        "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'status': 'active'}",
                                        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                        "database": "@consent.engine.mongodb.name@",
                                        "collection": "consent",
                                        "projection": "{code : 1}",
                                        "returnpath": "code",
                                        "cache": true
                                    }
                                }
                            }
                        },
                        "otherwise": {
                            "id": "urn:xacml:3.0:policy:policyId",
                            "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                            "discovery": {
                                "type": "mongo",
                                "input": [{
                                        "id": "patientIdentifier",
                                        "source": "groupBy",
                                        "discovery": {
                                            "type": "jsonpath",
                                            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                            "returnType": "single",
                                            "postProcessingAsUniqueValue": true,
                                            "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                        }
                                    }
                                ],
                                "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'status': 'active'}",
                                "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                "database": "@consent.engine.mongodb.name@",
                                "collection": "consent",
                                "projection": "{code : 1}",
                                "returnpath": "code",
                                "cache": true
                            }
                        }
                    }
                }
            },
            "otherwise": {
                "discovery": {
                    "type": "mongo",
                    "input": [{
                            "id": "patientIdentifier",
                            "source": "groupBy",
                            "discovery": {
                                "type": "jsonpath",
                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                "returnType": "single",
                                "postProcessingAsUniqueValue": true,
                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                            }
                        }, {
                            "id": "documentId",
                            "discovery": {
                                "type": "jsonpath",
                                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
                                "returnType": "single",
                                "postProcessingAsUniqueValue": true,
                                "postProcessing": "if($out && $out.length > 0){ $out = \"'documentid': { $in: [ '\" + $out[0] + \"' ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                            }
                        }
                    ],
                    "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {{documentId}}, {'status': 'active'}",
                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                    "database": "@consent.engine.mongodb.name@",
                    "collection": "consent",
                    "projection": "{code : 1}",
                    "returnpath": "code",
                    "cache": true,
                    "whenNoResult": {
                        "id": "urn:xacml:3.0:policy:policyId",
                        "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                        "when": {
                            "discovery": {
                                "type": "jsonpath",
                                "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                                "returnType": "multiple"
                            }
                        },
                        "then": {
                            "discovery": {
                                "type": "mongo",
                                "input": [{
                                        "id": "patientIdentifier",
                                        "source": "groupBy",
                                        "discovery": {
                                            "type": "jsonpath",
                                            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                            "returnType": "single",
                                            "postProcessingAsUniqueValue": true,
                                            "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                        }
                                    }, {
                                        "id": "eventIdentifier",
                                        "discovery": {
                                            "type": "jsonpath",
                                            "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                                            "returnType": "multiple",
                                            "postProcessingAsUniqueValue": true,
                                            "whenNoResult": {
                                                "value": {
                                                    "fixed": [
                                                        ""
                                                    ]
                                                }
                                            },
                                            "postProcessing": "if($out && $out.length > 0) { var ret = \"\";  for(var k = 0;k < $out.length; k++) {ret += \"'\" + $out[k] + \"'\"; ret += ($out.length - k > 1) ? \",\" : \"\";} $out = \" 'eventid': { $in: [ \" + ret + \" ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                                        }
                                    }
                                ],
                                "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {{eventIdentifier}}, {'status': 'active'}",
                                "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                "database": "@consent.engine.mongodb.name@",
                                "collection": "consent",
                                "projection": "{code : 1}",
                                "returnpath": "code",
                                "cache": true,
                                "whenNoResult": {
                                    "id": "urn:xacml:3.0:policy:policyId",
                                    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                                    "discovery": {
                                        "type": "mongo",
                                        "input": [{
                                                "id": "patientIdentifier",
                                                "source": "groupBy",
                                                "discovery": {
                                                    "type": "jsonpath",
                                                    "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                                    "returnType": "single",
                                                    "postProcessingAsUniqueValue": true,
                                                    "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                                }
                                            }
                                        ],
                                        "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'status': 'active'}",
                                        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                        "database": "@consent.engine.mongodb.name@",
                                        "collection": "consent",
                                        "projection": "{code : 1}",
                                        "returnpath": "code",
                                        "cache": true
                                    }
                                }
                            }
                        },
                        "otherwise": {
                            "id": "urn:xacml:3.0:policy:policyId",
                            "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                            "discovery": {
                                "type": "mongo",
                                "input": [{
                                        "id": "patientIdentifier",
                                        "source": "groupBy",
                                        "discovery": {
                                            "type": "jsonpath",
                                            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                                            "returnType": "single",
                                            "postProcessingAsUniqueValue": true,
                                            "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                                        }
                                    }
                                ],
                                "expression": "{'patientid': { $in: [{patientIdentifier}] }}, {'status': 'active'}",
                                "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                                "database": "@consent.engine.mongodb.name@",
                                "collection": "consent",
                                "projection": "{code : 1}",
                                "returnpath": "code",
                                "cache": true
                            }
                        }
                    }
                }
            },
            "required": true,
            "faultValue": {
                "faultCode": "missingConsent",
                "faultMessage": [{
                        "lang": "it",
                        "message": "Il paziente non ha espresso consensi"
                    }, {
                        "lang": "en",
                        "message": "The patient doesn't release consents"
                    }
                ],
                "faultDetail": ""
            }
        }
    }
};

var IN_ProxyTestParam = {
    when: "/policy-engine-web/proxy/test/param",
    endpoint: "/policy-engine-web/proxy/test/param",
    phase: "IN",
    tokenType: "JWT",
    validateAction: false,
    skipEvaluationProcess: true
};

var OUT_ProxyTestParam = {
    when: "/policy-engine-web/proxy/test/param",
    endpoint: "/policy-engine-web/proxy/test/param",
    phase: "OUT",
    skipEvaluationProcess: true
};

var IN_NOTIFIER_PUBLISH = {
    "when": "notifierPublish",
    "endpoint": "notifierPublish",
    "phase": "IN",
    "httpMethod": "POST",
    "tokenType": "JWT",
    "validateAction": false,
    "validateSaml": false,
    "attributes": [{
            "id": "urn:oasis:names:tc:xacml:1.0:action:action-id",
            "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:action",
            "value": {
                "fixed": [
                    "P"
                ]
            },
            "includeInResult": false,
            "required": true
        }, {
            "id": "urn:xacml:3.0:subject:subject-role",
            "category": "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
            "value": {
                "fixed": [
                    "NOTIFIER"
                ]
            },
            "includeInResult": false,
            "required": true
        }
    ],
    "attributebag": {
        "groupBy": {
            "id": "bundleObject",
            "discovery": {
                "type": "jsonpath",
                "expression": "$..entry",
                "returnType": "multiple"
            },
            "required": true,
            "faultValue": {
                "faultCode": "101",
                "faultMessage": [{
                        "lang": "it",
                        "message": "Formato errato della richiesta."
                    }, {
                        "lang": "en",
                        "message": "Malformed request."
                    }
                ],
                "faultDetail": ""
            }
        },
        "add": [
			{
                "id": "urn:xacml:3.0:environment:uniqueId",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "includeInResult": true,
                "required": true,
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..id",
                    "returnType": "single"
                },
                "faultValue": {
                    "faultCode": "101",
                    "faultMessage": [{
                            "lang": "it",
                            "message": "Id risorsa non trovato."
                        }, {
                            "lang": "en",
                            "message": "Resource id not found."
                        }
                    ],
                    "faultDetail": ""
                }
            }, {
                "id": "urn:xacml:3.0:environment:consents",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "array": true,
                "includeInResult": false,
                "required": false,
                "discovery": {
                    "type": "mongo",
                    "input": [{
                            "id": "patientIdentifier",
                            "discovery": {
                                "type": "jsonpath",
                                "expression": "$..patientIdentifier[*]",
                                "returnType": "multiple",
                                "postProcessingAsUniqueValue": true,
                                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                            }
                        }, {
                            "id": "documentId",
                            "discovery": {
                                "type": "jsonpath",
                                "expression": "$..documentId",
                                "returnType": "single",
                                "postProcessingAsUniqueValue": true,
                                "whenNoResult": {
                                    "value": {
                                        "fixed": [
                                            ""
                                        ]
                                    }
                                },
                                "postProcessing": "if($out && $out.length > 0){ $out = \"'documentid': { $in: [ '\" + $out[0] + \"', 'urn:oid:\" + $out[0] + \"', 'urn:uuid:\" + $out[0] + \"' ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                            }
                        }, {
                            "id": "currentTime",
                            "value": {
                                "fixed": [
                                    "NOW"
                                ],
                                "postProcessing": "var d = new Date(); $out = d.getTime() + '';"
                            }
                        }
                    ],
                    "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'status': 'active',  $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ], $or: [ { 'code': '@policy.obscuring.patient.code@' }, { $and: [ {'code': '@policy.obscuring.document.code@'}, {{documentId}} ] } ]}",
                    "ref": "PM_CONSENT_ENGINE_DATASOURCE",
                    "database": "@consent.engine.mongodb.name@",
                    "collection": "consent",
                    "projection": "{code : 1, status: 1}",
                    "returnpath": "{code}_{status}",
                    "cache": true,
                    "returnType": "multiple",
                    "whenNoResult": {
                        "value": {
                            "fixed": [
                                "NO_CONSENTS"
                            ]
                        }
                    }
                }
            }, {
                "id": "urn:xacml:3.0:policy:policyId",
                "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
                "includeInResult": true,
                "required": false,
				"value": {
					"fixed": [
						"NOTIFIER"
					]
				}
            }
        ]
    }
};


var IN_Subscribe_Default = {
  "when": "Subscribe",
  "endpoint": "Subscribe_Default",
  "phase": "IN",
  "numberOfRequiredAssertion": 1,
  "skipXACMLProcessing": true,
  "attributes": [
    {
      "id": "urn:xacml:3.0:subject:subject-role",
      "category": "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
      "description": "Retrieves the subject-roles (s) from the message-context and, if at least one of the values is mappable with the configured lists, returns the corresponding value (mapping lists: X1V1_AMMINISTRATIVO).",
      "discovery": {
        "type": "mc",
        "key": "eu.dedalus.xvalue.policyengine.common.subjectRole",
        "returnType": "single",
        "postProcessingAsUniqueValue": "true",
        "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var role = $out[i].split('@'); if (role[role.length - 1]) { ret.push(role[role.length - 1]); } } } $out = ret;",
        "postProcessingAsMappedValues": [
          {
            "source": {
              "storedListKey": "X1V1_MEDICO_Roles"
            },
            "target": {
              "fixed": [
                "X1V1_MEDICO"
              ]
            }
          }
        ]
      },
      "includeInResult": false,
      "required": true,
      "faultValue": {
        "faultCode": "subjectRoleNotFound",
        "faultMessage": [
          {
            "lang": "it",
            "message": "Ruolo utente non trovato."
          },
          {
            "lang": "en",
            "message": "User role not found."
          }
        ],
        "faultDetail": ""
      }
    }
  ],
  "validateAction": false
};


var IN_DocumentRepository_ProvideAndRegisterDocumentSetB_Multitenancy = {
    "when": "ProvideAndRegisterDocumentSetRequest",
    "endpoint": "DocumentRepository_ProvideAndRegisterDocumentSetB_Multitenancy",
    "phase": "IN",
    "numberOfRequiredAssertion": 1,
    "skipXACMLProcessing": true,
    "attributes": [
        subjectIdWithPostProcessing,
        subjectRoleWithPostProcessingForAllRoles,
        multitenancyCheckUserIntegrity
    ],
    "attributebag": {
        "groupBy": getGroupByForAdhocQueryResponse,
        "add": [
            checkMultitenancyRequestIntegritySource,
            checkMultitenancyRequestIntegrityTarget
        ]
    }
};


var IN_RegistryStoredQuery_Multitenancy = {
    "when": "AdhocQueryRequest",
    "endpoint": "RegistryStoredQuery_Multitenancy",
    "phase": "IN",
    "numberOfRequiredAssertion": 1,
    "skipXACMLProcessing": true,
    "attributes": [
        subjectIdWithPostProcessing,
        subjectRoleWithPostProcessingForAllRoles,
        multitenancyCheckCustomSlotIntegrity,
        checkStoreQueryId
	]
};