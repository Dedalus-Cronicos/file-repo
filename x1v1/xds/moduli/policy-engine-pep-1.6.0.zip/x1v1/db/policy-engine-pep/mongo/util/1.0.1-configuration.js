db.configuration.deleteOne({property: "jwtAdditionalJPathAttributes"});
db.configuration.insertOne(jwtAdditionalJPathAttributes);