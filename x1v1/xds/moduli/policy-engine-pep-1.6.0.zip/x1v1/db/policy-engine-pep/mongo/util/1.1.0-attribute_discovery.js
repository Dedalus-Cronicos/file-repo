db.attribute_discovery.deleteOne({when: "AdhocQueryResponse", endpoint: "RegistryStoredQuery_Default"});
db.attribute_discovery.deleteOne({when: "fhirResourceRead", endpoint: "fhirResourceRead"});
db.attribute_discovery.deleteOne({when: "RetrieveDocumentSetResponse", endpoint: "fhirResourceRead"});

db.attribute_discovery.insertOne(OUT_RegistryStoredQuery_Default);
db.attribute_discovery.insertOne(OUT_DocumentRepository_RetrieveDocumentSet_Default);
db.attribute_discovery.insertOne(IN_NEW_READ_FHIRRESOURCE);