var XACML_PREFIX = "urn:";
var ENVIRONMENT_XACML = "urn:oasis:names:tc:xacml:3.0:attribute-category:environment";
var ID_ATTRIBUTO_UNIQUEID = XACML_PREFIX + "xacml:3.0:environment:uniqueId";
var ID_ATTRIBUTO_POLICY = XACML_PREFIX + "xacml:3.0:policy:policyId";

var jsonAcceptHeader = {
    key: "accept",
    value: "application/json"
};

var getActiveConsentsByPatientConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?status=active",
    headers: [jsonAcceptHeader]
};

var getActiveConsentsByEventConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?eventid={eventid}&status=active",
    headers: [jsonAcceptHeader]
};

var getActiveConsentsByDocumentConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?documentid={documentid}&status=active",
    headers: [jsonAcceptHeader]
};

var headConsentsByPatientCodeActiveConfig = {
    method: "HEAD",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}/{consentcode}/?active={active}",
    headers: [jsonAcceptHeader]
};

var headConsentsByEventCodeActiveConfig = {
    method: "HEAD",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}/{consentcode}/?eventid={eventid}&active={active}",
    headers: [jsonAcceptHeader]
};

var headConsentsByDocumentCodeActiveConfig = {
    method: "HEAD",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}/{consentcode}/?documentid={documentid}&active={active}",
    headers: [jsonAcceptHeader]
};

var getConsentsByPatientCodeStatusConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?consentcode={consentcode}&status={status}",
    headers: [jsonAcceptHeader]
};

var getConsentsByEventCodeStatusConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?eventid={eventid}&consentcode={consentcode}&status={status}",
    headers: [jsonAcceptHeader]
};

var getConsentsByDocumentCodeStatusConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?documentid={documentid}&consentcode={consentcode}&status={status}",
    headers: [jsonAcceptHeader]
};

var getHistoricalConsentsByPatientCodeActiveConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/historical/100/{patientid}?consentcode={consentcode}&status=active",
    headers: [jsonAcceptHeader]
};

var getHistoricalConsentsByEventCodeActiveConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/historical/100/{patientid}?eventid={eventid}&consentcode={consentcode}&status=active",
    headers: [jsonAcceptHeader]
};

var getHistoricalConsentsByDocumentCodeActiveConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/consent-engine/consent/historical/100/{patientid}?documentid={documentid}&consentcode={consentcode}&status=active",
    headers: [jsonAcceptHeader]
};

var getTutorByPatientConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/consent-engine/tutor/{patientid}",
    headers: [jsonAcceptHeader]
};

var getA1ActiveOnPatientConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/policy-manager-consent-engine/consent/100/{patientid}?consentcode={consentcode}&status=active",
    headers: [jsonAcceptHeader]
};

var getA1ActiveOnEventConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/policy-manager-consent-engine/consent/100/{patientid}?eventid={eventid}&consentcode={consentcode}&status=active",
    headers: [jsonAcceptHeader]
};

var headA1OnPatientConfig = {
    method: "HEAD",
    url: "http://@consent@@domain.internal.xds@/policy-manager-consent-engine/consent/100/{patientid}/{consentcode}/?active=false",
    headers: [jsonAcceptHeader]
};

var headA1OnEventConfig = {
    method: "HEAD",
    url: "http://@consent@@domain.internal.xds@/policy-manager-consent-engine/consent/100/{patientid}/{consentcode}/?eventid={eventid}&active=false",
    headers: [jsonAcceptHeader]
};

var getP1ActiveOnPatientConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/policy-manager-consent-engine/consent/100/{patientid}?returntype=generic&consentcode={consentcode}&status=active",
    headers: [jsonAcceptHeader]
};

var getP1ActiveOnEventConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/policy-manager-consent-engine/consent/100/{patientid}?eventid={eventid}&consentcode={consentcode}&status=active",
    headers: [jsonAcceptHeader]
};

var getHistoricalA1ActiveOnPatientConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/policy-manager-consent-engine/consent/historical/100/{patientid}?consentcode={consentcode}&status=active",
    headers: [jsonAcceptHeader]
};

var getHistoricalA1ActiveOnEventConfig = {
    method: "GET",
    url: "http://@consent@@domain.internal.xds@/policy-manager-consent-engine/consent/historical/100/{patientid}?eventid={eventid}&consentcode={consentcode}&status=active",
    headers: [jsonAcceptHeader]
};

var _missingResourceId = {
    "faultCode": "missingResourceId",
    "faultMessage": [{
            "lang": "it",
            "message": "Identificativo della risorsa non trovato."
        }, {
            "lang": "en",
            "message": "Resource identifier not found."
        }
    ],
    "faultDetail": ""
};

var _missingPatientId = {
    "faultCode": "missingPatientId",
    "faultMessage": [{
            "lang": "it",
            "message": "Identificativo del paziente non trovato."
        }, {
            "lang": "en",
            "message": "Patient identifier not found."
        }
    ],
    "faultDetail": ""
};

var _subjectIdNotFound = {
    faultCode: "subjectIdNotFound",
    faultMessage: [{
            "lang": "it",
            "message": "Id utente non trovato."
        }, {
            "lang": "en",
            "message": "User id not found."
        }
    ],
    faultDetail: ""
};

var _subjectRoleNotFound = {
    "faultCode": "subjectRoleNotFound",
    "faultMessage": [{
            "lang": "it",
            "message": "Ruolo utente non trovato."
        }, {
            "lang": "en",
            "message": "User role not found."
        }
    ],
    "faultDetail": ""
};

var _unsupportedStoredQuery = {
    "faultCode": "unsupportedStoredQuery",
    "faultMessage": [{
            "lang": "it",
            "message": "StoredQuery non supportata"
        }, {
            "lang": "en",
            "message": "Unsupported StoredQuery"
        }
    ],
    "faultDetail": ""
};

var _missingConsent = {
    "faultCode": "missingConsent",
    "faultMessage": [{
            "lang": "it",
            "message": "Il paziente non ha espresso consensi necessari"
        }, {
            "lang": "en",
            "message": "The patient doesn't release required consents"
        }
    ],
    "faultDetail": ""
};

var _emptyConsent = {
    "faultCode": "emptyConsent",
    "faultMessage": [{
            "lang": "it",
            "message": "Il paziente non ha espresso consensi"
        }, {
            "lang": "en",
            "message": "The patient doesn't release consents"
        }
    ],
    "faultDetail": ""
};

var _101 = {
    faultCode: "101",
    faultMessage: [{
            lang: "it",
            message: "Non è possibile determinare la tipologia del documento"
        }, {
            lang: "en",
            message: "Impossible to find the document type"
        }
    ],
    faultDetail: ""
};

var _102 = {
    faultCode: "102",
    faultMessage: [{
            lang: "it",
            message: "Non è possibile determinare la tipologia di operazione"
        }, {
            lang: "en",
            message: "Impossible to find operation type"
        }
    ],
    faultDetail: ""
};

var _202 = {
    faultCode: "202",
    faultMessage: [{
            lang: "it",
            message: "Ruolo utente non trovato"
        }, {
            lang: "en",
            message: "Role or operation not found"
        }
    ],
    faultDetail: ""
};

var _203 = {
    faultCode: "203",
    faultMessage: [{
            lang: "it",
            message: "Operazione non consentita"
        }, {
            lang: "en",
            message: "Operation deny"
        }
    ],
    faultDetail: ""
};

var _205 = {
    faultCode: "205",
    faultMessage: [{
            lang: "it",
            message: "Non è possibile determinare il codice struttura"
        }, {
            lang: "en",
            message: "Impossible to find structure code"
        }
    ],
    faultDetail: ""
};

var _206 = {
    faultCode: "206",
    faultMessage: [{
            lang: "it",
            message: "Non è possibile verificare il periodo di validità"
        }, {
            lang: "en",
            message: "Impossible to verify the validity periodo"
        }
    ],
    faultDetail: ""
};

var _207 = {
    faultCode: "207",
    faultMessage: [{
            lang: "it",
            message: "Non è possibile determinare il codice struttura"
        }, {
            lang: "en",
            message: "Impossible to find structure code"
        }
    ],
    faultDetail: ""
};

var _208 = {
    faultCode: "208",
    faultMessage: [{
            lang: "it",
            message: "Identificativo risorsa non trovato"
        }, {
            lang: "en",
            message: "Resource id not found"
        }
    ],
    faultDetail: ""
};

var missingConsent = {
    faultCode: "missingConsent",
    faultMessage: [{
            lang: "it",
            message: "Il paziente non ha espresso consensi"
        }, {
            lang: "en",
            message: "The patient doesn't release consents"
        }
    ],
    faultDetail: ""
};

var customClientFault = {
    faultCode: "customClientFault",
    faultMessage: [{
            lang: "it",
            message: "La richiesta non è corretta"
        }, {
            lang: "en",
            message: "Incorrect or malformed request"
        }
    ],
    faultDetail: ""
};

var referralIdentifierTypeCode = {
    value: {
        fixed: ["urn:ihe:iti:xds:2013:referral"]
    }
};

var workflowIdentifierTypeCode = {
    value: {
        fixed: ["urn:ihe:iti:xdw:2013:workflowId"]
    }
};

var homeCommunityId = {
    discovery: {
        type: "jsonpath",
        expression: "$..ExtrinsicObject._home",
        returnType: "single"
    }
};

var assigninAuthority = {
    value: {
        fixed: [""]
    }
};

var empty = {
    value: {
        fixed: [""]
    }
};

var nosologicalIdentifier = {
    discovery: {
        type: "jsonpath",
        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:52a28615-ed55-4fd9-a3a7-fccffc8d4fd3')]._value",
        returnType: "single"
    }
};

var nosologicalIdentifierTypeCode = {
    value: {
        fixed: ["urn:eu:dedalus:x1v1:2016:nosological"]
    }
};

var emergencyIdentifier = {
    discovery: {
        type: "jsonpath",
        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:04600241-d830-423c-9c4f-9be4e7a33aa1')]._value",
        returnType: "single"
    }
};

var emergencyIdentifierTypeCode = {
    value: {
        fixed: ["urn:eu:dedalus:x1v1:2016:emergency"]
    }
};

var orderIdentifier = {
    discovery: {
        type: "jsonpath",
        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:6ea70be1-b85e-45f8-91e8-741cc296ec12')]._value",
        returnType: "single"
    }
};

var orderIdentifierTypeCode = {
    value: {
        fixed: ["urn:ihe:iti:xds:2013:order"]
    }
};

var nosological = {
    whenExists: {
        discovery: {
            type: "jsonpath",
            expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:52a28615-ed55-4fd9-a3a7-fccffc8d4fd3')]._value",
            returnType: "single"
        }
    },
    then: [nosologicalIdentifier, empty, empty, assigninAuthority, nosologicalIdentifierTypeCode],
    separator: "^"
};

var emergency = {
    whenExists: {
        discovery: {
            type: "jsonpath",
            expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:04600241-d830-423c-9c4f-9be4e7a33aa1')]._value",
            returnType: "single"
        }
    },
    then: [emergencyIdentifier, empty, empty, assigninAuthority, emergencyIdentifierTypeCode],
    separator: "^"
};

var order = {
    whenExists: {
        discovery: {
            type: "jsonpath",
            expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:6ea70be1-b85e-45f8-91e8-741cc296ec12')]._value",
            returnType: "single"
        }
    },
    then: [orderIdentifier, empty, empty, assigninAuthority, orderIdentifierTypeCode],
    separator: "^"
};

var typeCodeCondition = {
    value: {
        when: "$..Classification[?(@._classificationScheme == 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983')]._nodeRepresentation",
        postProcessing: "if( ['consent002'].indexOf($out) >= 0 ) { $out = 'true'}",
        then: "true",
        otherwise: "false"
    }
};

var notTypeCodeConsent = {
    value: {
        // restituisce true se non è un documento di consenso ma un documento clinico
        when: "$..Classification[?(@._classificationScheme == 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983')]._nodeRepresentation",
        postProcessing: "if( [ '59284-0', '57016-8', 'consent002', 'consent003' ].indexOf($out) < 0 ) { $out = 'true'}",
        then: "true",
        otherwise: "false"
    }
}

var rimNamespace = {
    prefix: "",
    uri: "urn:oasis:names:tc:ebxml-regrep:xsd:rim:3.0"
};

var referenceIdListSlotName = "urn:ihe:iti:xds:2013:referenceIdList";


var atnaXuaUsername_IN = {
    id: "atnaXuaUsername_IN",
    discovery: {
        type: "mc",
        key: "eu.dedalus.xvalue.policyengine.common.xua.username"
    }
};

var atnaBeanSubjectNameAnonymous = {
    id: "atnaBeanSubjectNameAnonymous",
    value: {
        fixed: ["Anonymous"]
    }
};

var atnaBeanSubjectNameNameID = {
    id: "atnaBeanSubjectNameNameID",
    discovery: {
        type: "mc",
        key: "eu.dedalus.xvalue.policyengine.common.subject",
        whenNoResult: atnaBeanSubjectNameAnonymous
    }
};

var atnaBeanSubjectNameCF = {
    id: "atnaBeanSubjectNameCF",
    discovery: {
        type: "mc",
        key: "eu.dedalus.xvalue.policyengine.common.subjectFiscalCode",
        whenNoResult: atnaBeanSubjectNameNameID
    },
    required: true,
    faultValue: _202
};

var addressingToAnonymous = {
    id: "addressingToAnonymous",
    value: {
        fixed: ["http://www.w3.org/2005/08/addressing/anonymous"]
    }
};

var addressingTo = {
    id: "addressingTo",
    discovery: {
        type: "jsonpath",
        expression: "$..Header.To.#text",
        returnType: "single",
        whenNoResult: addressingToAnonymous
    }
};

var storedQueryId = {
    id: "storedQueryId",
    discovery: {
        type: "jsonpath",
        expression: "$..AdhocQuery._id",
        returnType: "single"
    }
};

var getDocumentIdFromRetrieveDocumentSetRequest = {
    "id": "documentId",
    "discovery": {
        "type": "jsonpath",
        "expression": "$..DocumentUniqueId.#text",
        "returnType": "multiple",
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){ret.push($out[i]);} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
    }
};

var storedQueryPatientId = {
    id: "storedQueryPatientId",
    discovery: {
        type: "jsonpath",
        expression: "$..AdhocQuery.Slot[?(@._name == '$XDSDocumentEntryPatientId')].ValueList.Value.#text",
        returnType: "single",
        postProcessing: "if ( $out.startsWith(\"'\") ) { $out = $out.substring(1, $out.lastIndexOf(\"\'\")); } else { $out = $out; }"
    }
};

var submissionSetUniqueId = {
    id: "submissionSetUniqueId",
    discovery: {
        type: "jsonpath",
        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
        returnType: "single"
    }
};

var submissionSetPatientId = {
    id: "submissionSetPatientId",
    discovery: {
        type: "jsonpath",
        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
        returnType: "single"
    }
};

var documentUniqueId = {
    id: "documentUniqueId",
    discovery: {
        type: "jsonpath",
        expression: "$..DocumentUniqueId.#text",
        returnType: "single"
    }
};

var repositoryUniqueId = {
    id: "repositoryUniqueId",
    discovery: {
        type: "jsonpath",
        expression: "$..RepositoryUniqueId.#text",
        returnType: "single"
    }
};

var fromEndpoint = {
    id: "fromEndpoint",
    discovery: {
        type: "mc",
        key: "eu.dedalus.xvalue.policyengine.common.fromEndpoint"
    }
};

var toEndpoint = {
    id: "toEndpoint",
    discovery: {
        type: "mc",
        key: "eu.dedalus.xvalue.policyengine.common.toEndpoint"
    }
};

var xvalueGatewayEvent = {
    id: "xvalueGatewayEvent",
    value: {
        fixed: ["XValueGateway"]
    }
};

var metadataTypeCode = {
    id: "metadataTypeCode",
    value: {
        fixed: ["metadata"]
    }
};

var metadataTypeDisplay = {
    id: "metadataTypeDisplay",
    value: {
        fixed: ["Document Metadata"]
    }
};

var documentTypeCode = {
    id: "documentTypeCode",
    value: {
        fixed: ["document"]
    }
};

var documentTypeDisplay = {
    id: "documentTypeDisplay",
    value: {
        fixed: ["Clinical Document"]
    }
};

var searchSubType = {
    id: "searchSubType",
    value: {
        fixed: ["search"]
    }
};

var readSubType = {
    id: "readSubType",
    value: {
        fixed: ["read"]
    }
};

var updateSubType = {
    id: "updateSubType",
    value: {
        fixed: ["update"]
    }
};

var deleteSubType = {
    id: "deleteSubType",
    value: {
        fixed: ["delete"]
    }
};

var createReplaceSubType = {
    id: "createReplaceSubType",
    value: {
        when: "$..Association[?(@._type == 'urn:oasis:names:tc:ebxml-regrep:AssociationType:RPLC')]._type",
        then: "replace",
        otherwise: "create"
    }
};

var organizationTypeCodeHA = {
    id: "organizationTypeCodeHA",
    value: {
        fixed: ["HA"]
    }
};

var organizationIdDiscovery = {
    type: "jsonpath",
    expression: "$..Classification[?(@._classificationScheme == 'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d')].Slot[?(@._name == 'authorInstitution')].ValueList.Value.#text",
    returnType: "single",
    postProcessing: "$out = (($out.indexOf('^') > 0) && ($out.indexOf('^') < $out.length - 1)) ? $out.substring($out.lastIndexOf('^') + 1) : $out"
};

var organizationId = {
    id: "organizationId",
    discovery: organizationIdDiscovery
};

var organizationName = {
    id: "organizationName",
    discovery: organizationIdDiscovery
};

var purposeOfUseDiscovery = {
    type: "mc",
    key: "urn:oasis:names:tc:xspa:1.0:subject:purposeofuse"
}

var purposeOfUseCode = {
    id: "purposeOfUseCode",
    discovery: purposeOfUseDiscovery
};

var purposeOfUseDisplay = {
    id: "purposeOfUseDisplay",
    discovery: purposeOfUseDiscovery
};

var participantObjDocumentEntryIds_IN = {
    id: "groupedDocumentIds",
    phase: "IN",
    discovery: {
        type: "jsonpath",
        expression: "$..RemoveObjectsRequest.ObjectRefList.ObjectRef[*]._id",
        "returnType": "multiple"
    }
};

var participantObjDocumentsIds_IN = {
    id: "groupedDocumentIds",
    phase: "IN",
    "discovery": {
        "type": "xpath",
        "groupingValueExpression": "//DocumentUniqueId",
        "detailingValueExpression": "//DocumentRequest[DocumentUniqueId/.='{RETRIEVED_VALUE}']/RepositoryUniqueId",
        "groupedResultingExpression": "{RETRIEVED_VALUE}|{DETAILING_VALUE}",
        "detailingValueAsBase64": true,
        "expression": "//DocumentUniqueId[.='{GROUPING_VALUE}']",
        "returnType": "multiple"
    }
};

var participantObjDocumentIdsForRetrieve_IN = {
    "id": "groupedDocumentIds",
    "phase": "IN",
    "discovery": {
        "type": "xpath",
        "groupingValueExpression": "//DocumentUniqueId",
        "detailingValueExpression": "//DocumentRequest[DocumentUniqueId/.='{RETRIEVED_VALUE}']/RepositoryUniqueId",
        "groupedResultingExpression": "{RETRIEVED_VALUE}|{DETAILING_VALUE}",
        "detailingValueAsBase64": true,
        "expression": "//DocumentUniqueId[.='{GROUPING_VALUE}']",
        "returnType": "multiple"
    }
};

var participantObjDocumentIds_IN = {
    id: "groupedDocumentIds",
    phase: "IN",
    discovery: {
        type: "xpath",
        groupingValueExpression: "//ExternalIdentifier[@identificationScheme='urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427']/@value",
        detailingValueExpression: "//ExtrinsicObject[ExternalIdentifier/@value='{RETRIEVED_VALUE}' and ExternalIdentifier/@identificationScheme='urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427']/Slot[@name='repositoryUniqueId']//Value",
        expression: "//ExtrinsicObject[ExternalIdentifier/@value='{GROUPING_VALUE}' and ExternalIdentifier/@identificationScheme='urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427']/ExternalIdentifier[@identificationScheme='urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab']/@value",
        "returnType": "multiple"
    }
};

var participantObjSubmissionIds_IN = {
    id: "groupedSubmissionIds",
    phase: "IN",
    discovery: {
        type: "xpath",
        groupingValueExpression: "//ExternalIdentifier[@identificationScheme='urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446']/@value",
        expression: "//RegistryPackage[ExternalIdentifier/@value='{GROUPING_VALUE}' and ExternalIdentifier/@identificationScheme='urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446']/ExternalIdentifier[@identificationScheme='urn:uuid:96fdda7c-d067-4183-912e-bf5ee74998a8']/@value",
        returnType: "multiple"
    }
};

var participantObjPatientIds_IN = {
    "id": "storedQueryPatientId",
    "discovery": {
        "type": "jsonpath",
        "expression": "$..AdhocQuery.Slot[?(@._name == '$XDSDocumentEntryPatientId')].ValueList.Value.#text",
        "returnType": "multiple",
        "postProcessing": "if ( $out.startsWith(\"'\") ) { $out = $out.substring(1, $out.lastIndexOf(\"'\")); } else { $out = $out; }"
    }
};

var participantObjDocumentIds_OUT = {
    id: "groupedDocumentIds",
    phase: "OUT",
    discovery: {
        type: "xpath",
		detailingValueAsBase64: true,
        groupingValueExpression: "//ExternalIdentifier[@identificationScheme='urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427']/@value",
        detailingValueExpression: "//ExtrinsicObject[ExternalIdentifier/@value='{RETRIEVED_VALUE}' and ExternalIdentifier/@identificationScheme='urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427']/Slot[@name='repositoryUniqueId']//Value",
        expression: "//ExtrinsicObject[ExternalIdentifier/@value='{GROUPING_VALUE}' and ExternalIdentifier/@identificationScheme='urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427']/ExternalIdentifier[@identificationScheme='urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab']/@value",
        "returnType": "multiple"
    }
};

var participantObjSubmissionIds_OUT = {
    id: "groupedSubmissionIds",
    phase: "OUT",
    discovery: {
        type: "xpath",
        groupingValueExpression: "//ExternalIdentifier[@identificationScheme='urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446']/@value",
        expression: "//RegistryPackage[ExternalIdentifier/@value='{GROUPING_VALUE}' and ExternalIdentifier/@identificationScheme='urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446']/ExternalIdentifier[@identificationScheme='urn:uuid:96fdda7c-d067-4183-912e-bf5ee74998a8']/@value",
        returnType: "multiple"
    }
};

var participantObjPatientIds_OUT = {
    id: "participantObjPatientIds",
    phase: "OUT",
    discovery: {
        type: "xpath",
        expression: "//ExternalIdentifier[@identificationScheme='urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446' or @identificationScheme='urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427']/@value",
        returnType: "multiple"
    }
};

var documentPatientIdDiscovery = {
    type: "jsonpath",
    expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
    returnType: "single"
};

var xdsPatientIdDiscovery = {
    type: "jsonpath",
    expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
    returnType: "single",
    postProcessing: "$out = $out.substring(0, $out.indexOf('^'))"
}

var documentEvenIdDiscovery = {
    type: "jsonpath",
    expression: "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
    returnType: "single"
};

var isConsentA1OnceGivenOnPatientDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }
    ],
    config: headA1OnPatientConfig,
    returnpath: "$.[*]",
    postProcessing: "if($out == 'true') {$out = 'A1';} else {$out = ''};",
    returnType: "single",
    cache: true
};

var isConsentA1OnceGivenDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: documentEvenIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }
    ],
    config: headA1OnEventConfig,
    returnpath: "$.[*]",
    postProcessing: "if($out == 'true') {$out = 'A1';} else {$out = ''};",
    returnType: "single",
    cache: true,
    whenNoResult: {
        discovery: isConsentA1OnceGivenOnPatientDiscovery
    }
};

var consentA1RemovedDateOnPatientDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }
    ],
    config: getHistoricalA1ActiveOnPatientConfig,
    returnpath: "$.[0].period.end",
    returnType: "single",
    cache: true
};

var consentA1RemovedDateOnEventDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: documentEvenIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }
    ],
    config: getHistoricalA1ActiveOnEventConfig,
    returnpath: "$.[0].insertdate",
    returnType: "single",
    cache: true,
    whenNoResult: {
        discovery: consentA1RemovedDateOnPatientDiscovery
    }
};

var consentA1EndDateOnPatientDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }
    ],
    config: getA1ActiveOnPatientConfig,
    returnpath: "$..consents[*].period.end",
    returnType: "single",
    cache: true,
    whenNoResult: {
        discovery: consentA1RemovedDateOnPatientDiscovery
    }
};

var consentA1EndDateFromEventOnPatientDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }
    ],
    config: getA1ActiveOnPatientConfig,
    returnpath: "$..consents[*].period.end",
    returnType: "single",
    cache: true,
    whenNoResult: {
        discovery: consentA1RemovedDateOnEventDiscovery
    }
};

var consentA1EndDateOnEventDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: documentEvenIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }
    ],
    config: getA1ActiveOnEventConfig,
    returnpath: "$..consents[*].period.end",
    returnType: "single",
    cache: true,
    whenNoResult: {
        discovery: consentA1EndDateFromEventOnPatientDiscovery
    }
};

var consentA1StartDateOnPatientDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }
    ],
    config: getA1ActiveOnPatientConfig,
    returnpath: "$..consents[*].period.start",
    returnType: "single",
    cache: true
};

var consentA1StartDateOnEventDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: documentEvenIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }
    ],
    config: getA1ActiveOnEventConfig,
    returnpath: "$..consents[*].period.start",
    returnType: "single",
    whenNoResult: {
        discovery: consentA1StartDateOnPatientDiscovery
    },
    cache: true
};

var consentP1StartDateOnPatientDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["P1"]
            }
        }
    ],
    config: getP1ActiveOnPatientConfig,
    returnpath: "$..consents[*].period.start",
    returnType: "single",
    whenNoResult: {
        discovery: consentA1StartDateOnPatientDiscovery
    },
    cache: true
};

var consentP1StartDateOnEventDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: documentPatientIdDiscovery
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: documentEvenIdDiscovery
        }, {
            id: "consentcode",
            value: {
                fixed: ["P1"]
            }
        }
    ],
    config: getP1ActiveOnEventConfig,
    returnpath: "$..consents[*].period.start",
    returnType: "single",
    whenNoResult: {
        discovery: consentP1StartDateOnPatientDiscovery
    },
    cache: true
};

var documentCreationDateDiscovery = {
    type: "jsonpath",
    expression: "$..Slot[?(@._name=='creationTime')].ValueList.Value.#text",
    postProcessing: "var year = $out.substring(0,4); " +
    "var month = $out.substring(4,6); " +
    "var day = $out.substring(6,8); " +
    "var hours = $out.substring(8,10); " +
    "var minutes = $out.substring(10,12); " +
    "var seconds = $out.substring(12,14); " +
    "$out = year+'-'+month+'-'+day",
    returnType: "single"
};

var lhaHealthCareProviderDiscovery = {
    type: "sql",
    input: [{
            id: "patientidCF",
            discovery: xdsPatientIdDiscovery
        }, {
            id: "patientAssigningAuthority",
            discovery: {
                type: "jsonpath",
                expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                postProcessing: "$out = $out.substring($out.indexOf('&') + 1, $out.lastIndexOf('&'))",
                returnType: "single"
            }
        }
    ],
    expression: "select id_healthprovider from mpi_code where id_patient = :patientidCF and namespace = :patientAssigningAuthority",
    ref: "LHA_DATASOURCE",
    cache: true,
    returnType: "single"
};

var taxCodeDiscovery = {
    type: "mc",
    key: "eu.dedalus.xvalue.policyengine.common.subjectFiscalCode",
    postProcessing: "if ($out !== null && $out !== '' && $out.indexOf('^') > 0) { $out = $out.substring(0, $out.indexOf('^')) } else { $out = $out }"
};

var xdsUniqueIdDiscovery = {
    type: "jsonpath",
    expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
    returnType: "single"
};

var xdsAuthorPersonDiscovery = {
    type: "jsonpath",
    expression: "$..Classification[?(@._classificationScheme == 'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d')].Slot[?(@._name == 'authorPerson')].ValueList.Value.#text",
    returnType: "single",
    postProcessing: "$out = $out.substring(0, $out.indexOf('^'))"
};

var samlSubjectDiscovery = {
    type: "mc",
    key: "eu.dedalus.xvalue.policyengine.common.subject"
};

var tutorDiscovery = {
    type: "rest",
    input: [{
            id: "patientid",
            discovery: documentPatientIdDiscovery
        }
    ],
    config: {
        method: "GET",
        url: "http://@consent@@domain.internal.xds@/consent-engine/tutor/{patientid}",
        headers: [{
                key: "accept",
                value: "application/json"
            }
        ]
    },
    returnpath: "$..tutors[*].tutorid",
    postProcessing: "$out = $out.substring(0, $out.indexOf('^'))",
    returnType: "multiple",
    cache: true
};

var trueFakeDiscovery = {
    type: "jsonpath",
    expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
    returnType: "multiple",
    postProcessing: "$out = 'true'"
};

var dateDischargeDiscovery = {
    type: "mongo",
    input: [{
            id: "patientid",
            discovery: xdsPatientIdDiscovery
        }, {
            id: "structureid",
            discovery: {
                type: "mc",
                key: "eu.dedalus.xvalue.policyengine.pep.handler.subject.healthcare.structure"
            }
        }
    ],
    expression: "{'PID' : '{patientid}', 'CODICE_STRUTTURA' : '{structureid}'}",
    projection: "{'_id' : 0, 'DATA_FINE_RICOVERO' : 1}",
    returnpath: "DATA_FINE_RICOVERO",
    returndatatype: "date",
    ref: "ADT_DATASOURCE",
    database: "xvalue_adt",
    collection: "ADT_ENTRY",
    postProcessing: "if($out !== null && $out.length > 0){ for(var index = 0; index < $out.length; index++) { if($out[index] !== null && $out[index] !== ''){ var offset = new Date().getTime()-(1*24*60*60*1000); if($out[index] >= offset) { $out='true'; break; }} else { $out='true'; break; }} if ($out != 'true') { $out = 'false'; }} else { $out='false'; }",
    postProcessingAsUniqueValue: true,
    cache: true,
    returnType: "multiple"
};

var subjectIdWithPostProcessing = {
    "id": "urn:xacml:3.0:subject:subject-id",
    "category": "urn:oasis:names:tc:xacml:1.0:subject-category:subject",
    "description": "Retrieve the subject-id from the message-context and convert it to the VALUE ^^^ & SYSTEM & ISO format.",
    "discovery": {
	  "type": "mc",
	  "key": "eu.dedalus.xvalue.policyengine.common.subject",
	  "returnType": "single",
	  "postProcessingAsUniqueValue": "true",
	  "postProcessing": "if ($out.length > 0) { var identifier = $out[0]; if (identifier.length > 0) { var splitted = identifier.split('^^^'); var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); if (splitted[1]) { var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); $out = value + '^^^&' + system + '&ISO'; } else { $out = value; } } }"
    },
    "includeInResult": false,
    "required": true,
      "faultValue": {
        "faultCode": "subjectIdNotFound",
        "faultMessage": [
          {
            "lang": "it",
            "message": "Id utente non trovato."
          },
          {
            "lang": "en",
            "message": "User id not found."
          }
        ],
        "faultDetail": ""
      }
    };

var subjectRoleWithPostProcessingForAllRoles = {
    "id": "urn:xacml:3.0:subject:subject-role",
    "category": "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    "description": "Retrieves the subject-roles (s) from the message-context and, if at least one of the values is mappable with the configured lists, returns the corresponding value (mapping lists: X1V1_ASSISTITO, X1V1_TUTOR, X1V1_MEDICO, X1V1_MMG, X1V1_AMMINISTRATIVO).",
    "discovery": {
        "type": "mc",
        "key": "eu.dedalus.xvalue.policyengine.common.subjectRole",
        "returnType": "single",
        "postProcessingAsUniqueValue": "true",
        "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var role = $out[i].split('@'); if (role[role.length - 1]) { ret.push(role[role.length - 1]); } } } $out = ret;",
        "postProcessingAsMappedValues": [{
                "source": {
                    "storedListKey": "X1V1_ASSISTITO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_ASSISTITO"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_TUTORE_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_TUTORE"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_MEDICO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_MEDICO"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_MMG_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_MMG"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_AMMINISTRATIVO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_AMMINISTRATIVO"
                    ]
                }
            }
        ]
    },
    "includeInResult": false,
    "required": true,
    "faultValue": _subjectRoleNotFound
};

var subjectRoleWithPostProcessingForAdministrativeRoles = {
    "id": "urn:xacml:3.0:subject:subject-role",
    "category": "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    "description": "Retrieves the subject-roles (s) from the message-context and, if at least one of the values is mappable with the configured lists, returns the corresponding value (mapping lists: X1V1_AMMINISTRATIVO).",
    "discovery": {
        "type": "mc",
        "key": "eu.dedalus.xvalue.policyengine.common.subjectRole",
        "returnType": "single",
        "postProcessingAsUniqueValue": "true",
        "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var role = $out[i].split('@'); if (role[role.length - 1]) { ret.push(role[role.length - 1]); } } } $out = ret;",
        "postProcessingAsMappedValues": [{
                "source": {
                    "storedListKey": "X1V1_AMMINISTRATIVO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_AMMINISTRATIVO"
                    ]
                }
            }
        ]
    },
    "includeInResult": false,
    "required": true,
    "faultValue": _subjectRoleNotFound
};

var discoverAdministrativeRoles = {
    "discovery": {
        "type": "mc",
        "key": "eu.dedalus.xvalue.policyengine.common.subjectRole",
        "returnType": "single",
        "postProcessingAsUniqueValue": "true",
        "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var role = $out[i].split('@'); if (role[role.length - 1]) { ret.push(role[role.length - 1]); } } } $out = ret;",
        "postProcessingAsMappedValues": [{
                "source": {
                    "storedListKey": "X1V1_AMMINISTRATIVO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_AMMINISTRATIVO"
                    ]
                }
            }
        ]
    },
    "required": false
};

var checkStoreQueryId = {
    "id": "urn:xacml:3.0:system:check-query",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:system",
    "includeInResult": true,
    "required": true,
    "discovery": {
        "type": "jsonpath",
        "expression": "$..AdhocQuery._id",
        "returnType": "single"
    },
    "domain": {
        "value": {
            "fixed": [
                "urn:uuid:14d4debf-8f97-4251-9a74-a90016b0af0d",
                "urn:uuid:5c4f972b-d56b-40ac-a5fc-c8ca9b40b9d4",
                "urn:uuid:12941a89-e02e-4be5-967c-ce4bfc8fe492"
            ]
        }
    },
    "faultValue": _unsupportedStoredQuery
};

var getGroupByForAdhocQueryResponse = {
    "id": "extrinsicObjectOrRegistryPackage",
    "discovery": {
        "type": "jsonpath",
        "expressions": [
            "$..ExtrinsicObject",
            "$..RegistryPackage"
        ],
        "returnType": "multiple"
    }
};

var checkUniqueIdInExtrinsicObject = {
    "discovery": {
        "type": "jsonpath",
        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
        "returnType": "single"
    }
};

var getUniqueIdInExtrinsicObjectWithPostProcessing = {
    "includeInResult": true,
    "required": true,
    "discovery": {
        "type": "jsonpath",
        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
        "returnType": "single",
        "postProcessing": "if($out.length>0){$out = 'EO_'+$out};"
    }
};

var checkUniqueIdInSumbissionSet = {
    "discovery": {
        "type": "jsonpath",
        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:96fdda7c-d067-4183-912e-bf5ee74998a8')]._value",
        "returnType": "single"
    }
};

var getUniqueIdInSumbissionSetWithPostProcessing = {
    "includeInResult": true,
    "required": true,
    "discovery": {
        "type": "jsonpath",
        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:96fdda7c-d067-4183-912e-bf5ee74998a8')]._value",
        "returnType": "single",
        "postProcessing": "if($out.length>0){$out = 'SS_'+$out};"
    }
};

var getUniqueIdInFolderWithPostProcessing = {
    "includeInResult": true,
    "required": true,
    "discovery": {
        "type": "jsonpath",
        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:75df8f67-9973-4fbe-a900-df66cefecc5a')]._value",
        "returnType": "single",
        "postProcessing": "if($out.length>0){$out = 'FO_'+$out};"
    }
};

var getUniqueIdForAdhocQueryResponse = {
    "id": "urn:xacml:3.0:environment:uniqueId",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInResult": true,
    "required": true,
    "when": checkUniqueIdInExtrinsicObject,
    "then": getUniqueIdInExtrinsicObjectWithPostProcessing,
    "otherwise": {
        "when": checkUniqueIdInSumbissionSet,
        "then": getUniqueIdInSumbissionSetWithPostProcessing,
        "otherwise": getUniqueIdInFolderWithPostProcessing
    },
    "faultValue": _missingResourceId
};

var getWardForAdhocQueryResponse = {
    "id": "urn:xacml:3.0:environment:ward",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "array": true,
    "includeInResult": false,
    "required": false,
    "when": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d')].Slot[?(@._name == 'authorInstitution')].ValueList.Value.#text",
            "returnType": "single"
        }
    },
    "then": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d')].Slot[?(@._name == 'authorInstitution')].ValueList.Value.#text",
            "returnType": "multiple",
            "postProcessingAsUniqueValue": true,
            "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^');if(splitted[9]){var value=splitted[9].replaceAll('urn:oid:','').replaceAll('urn:uuid:','');ret.push(value);}else{ret.push(identifier)}}}$out=ret;"
        }
    },
    "otherwise": {
        "when": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:a7058bb9-b4e4-4307-ba5b-e3f0ab85e12d')].Slot[?(@._name == 'authorInstitution')].ValueList.Value.#text",
                "returnType": "single"
            }
        },
        "then": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:a7058bb9-b4e4-4307-ba5b-e3f0ab85e12d')].Slot[?(@._name == 'authorInstitution')].ValueList.Value.#text",
                "returnType": "multiple",
                "postProcessingAsUniqueValue": true,
                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^');if(splitted[9]){var value=splitted[9].replaceAll('urn:oid:','').replaceAll('urn:uuid:','');ret.push(value)}else{ret.push(identifier)}}}$out=ret;",
                "whenNoResult": {
                    "value": {
                        "fixed": [
                            "NO_RESOURCE_WARD"
                        ]
                    }
                }
            }
        },
        "otherwise": {
            "value": {
                "fixed": [
                    "NO_RESOURCE_WARD"
                ]
            }
        }
    }
};

var getAuthorForAdhocQueryResponse = {
    "id": "urn:xacml:3.0:environment:authorId",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "array": true,
    "includeInResult": false,
    "required": false,
    "when": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d')].Slot[?(@._name == 'authorPerson')].ValueList.Value.#text",
            "returnType": "single"
        }
    },
    "then": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d')].Slot[?(@._name == 'authorPerson')].ValueList.Value.#text",
            "returnType": "multiple",
            "postProcessingAsUniqueValue": true,
            "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^');if(splitted[0]&&splitted[8]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:','');var system=splitted[8].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO');ret.push(value)}else{ret.push(identifier)}}}$out=ret;"
        }
    },
    "otherwise": {
        "when": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:a7058bb9-b4e4-4307-ba5b-e3f0ab85e12d')].Slot[?(@._name == 'authorPerson')].ValueList.Value.#text",
                "returnType": "single"
            }
        },
        "then": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:a7058bb9-b4e4-4307-ba5b-e3f0ab85e12d')].Slot[?(@._name == 'authorPerson')].ValueList.Value.#text",
                "returnType": "multiple",
                "postProcessingAsUniqueValue": true,
                "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^');if(splitted[0]&&splitted[8]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:','');var system=splitted[8].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO');ret.push(value)}else{ret.push(identifier)}}}$out=ret;",
                "whenNoResult": {
                    "value": {
                        "fixed": [
                            "NO_RESOURCE_AUTHOR"
                        ]
                    }
                }
            }
        },
        "otherwise": {
            "value": {
                "fixed": [
                    "NO_RESOURCE_AUTHOR"
                ]
            }
        }
    }
};

var getCreationDateForAdhocQueryResponse = {
    "id": "urn:xacml:3.0:environment:creation-date",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "type": "integer",
    "when": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..Slot[?(@._name=='creationTime')].ValueList.Value.#text",
            "returnType": "single"
        }
    },
    "then": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..Slot[?(@._name=='creationTime')].ValueList.Value.#text",
            "returnType": "single"
        }
    },
    "otherwise": {
        "when": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..Slot[?(@._name=='submissionTime')].ValueList.Value.#text",
                "returnType": "single"
            }
        },
        "then": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..Slot[?(@._name=='submissionTime')].ValueList.Value.#text",
                "returnType": "single",
                "whenNoResult": {
                    "value": {
                        "fixed": [
                            "0"
                        ]
                    }
                }
            }
        },
        "otherwise": {
            "value": {
                "fixed": [
                    "0"
                ]
            }
        }
    },
    "includeInResult": false,
    "required": true
};

var getCreationPerformedForAdhocQueryResponse = {
    "id": "urn:xacml:3.0:environment:creation-performed",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "when": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..Slot[?(@._name=='creationTime')].ValueList.Value.#text",
            "returnType": "single"
        }
    },
    "then": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..Slot[?(@._name=='creationTime')].ValueList.Value.#text",
            "postProcessing": "var year = $out.substring(0,4); var month = $out.substring(4,6); var day = $out.substring(6,8); var hours = $out.substring(8,10); var minutes = $out.substring(10,12); var seconds = $out.substring(12,14); var time = year+'-'+month+'-'+day+'T'+hours+':'+minutes+':'+seconds; var value = new Date(time).getTime(); var offset = new Date().getTime()-(45*24*60*60*1000); if(value >= offset) { $out='NEXT_LAST_45_DAYS'; } else { $out='PREV_LAST_45_DAYS'; }",
            "returnType": "single"
        }
    },
    "otherwise": {
        "when": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..Slot[?(@._name=='submissionTime')].ValueList.Value.#text",
                "returnType": "single"
            }
        },
        "then": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..Slot[?(@._name=='submissionTime')].ValueList.Value.#text",
                "returnType": "single",
                "postProcessing": "var year = $out.substring(0,4); var month = $out.substring(4,6); var day = $out.substring(6,8); var hours = $out.substring(8,10); var minutes = $out.substring(10,12); var seconds = $out.substring(12,14); var time = year+'-'+month+'-'+day+'T'+hours+':'+minutes+':'+seconds; var value = new Date(time).getTime(); var offset = new Date().getTime()-(45*24*60*60*1000); if(value >= offset) { $out='NEXT_LAST_45_DAYS'; } else { $out='PREV_LAST_45_DAYS'; }",
                "whenNoResult": {
                    "value": {
                        "fixed": [
                            "PREV_LAST_45_DAYS"
                        ]
                    }
                }
            }
        },
        "otherwise": {
            "value": {
                "fixed": [
                    "PREV_LAST_45_DAYS"
                ]
            }
        }
    },
    "includeInResult": false
};

var getConfidentialityCodeForAdhocQueryResponse = {
    "id": "urn:xacml:3.0:environment:confidentialityCode",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInResult": false,
    "required": false,
    "discovery": {
        "type": "jsonpath",
        "expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f')]._nodeRepresentation",
        "returnType": "multiple",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_CONFIDENTIALITY"
                ]
            }
        }
    }
};

var getTypeCodeForAdhocQueryResponse = {
    "id": "urn:xacml:3.0:environment:typeCode",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInResult": false,
    "required": false,
    "discovery": {        
        "type": "jsonpath",
        "expressions": [
            "$..Classification[?(@._classificationScheme == 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983')].Slot.ValueList.Value.#text",
            "$..Classification[?(@._classificationScheme == 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983')]._nodeRepresentation"
        ],
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var joinedResult = ''; if ($out.length > 0) { if ($out.length > 1) { joinedResult = $out[0]+'|'+$out[1]; } else { joinedResult = '|'+$out[0]; } } $out = joinedResult;",
        "returnType": "multiple",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_TYPECODE"
                ]
            }
        }
    }
};

var getCurrentTimeForMongoDiscovery = {
    "id": "currentTime",
    "value": {
        "fixed": [
            "NOW"
        ],
        "postProcessing": "var d = new Date(); $out = d.getTime() + '';"
    }
};

var patientIdDiscoveryFromAdhocQueryRequestForMongo = {
    "id": "patientIdentifier",
    "discovery": {
        "type": "jsonpath",
        "expressions": [
            "$..Slot[?(@._name == '$XDSDocumentEntryPatientId')].ValueList.Value.#text",
            "$..Slot[?(@._name == '$XDSSubmissionSetPatientId')].ValueList.Value.#text",
            "$..Slot[?(@._name == '$XDSFolderPatientId')].ValueList.Value.#text",
            "$..Slot[?(@._name == '$patientId')].ValueList.Value.#text"
        ],
        "returnType": "multiple",
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0].replaceAll('\\'',''); var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); } else { ret.push(identifier); } } var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult +=  \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
    }
};

var patientIdDiscoveryFromAdhocQueryRequest = {
    "discovery": {
        "type": "jsonpath",
        "expressions": [
            "$..Slot[?(@._name == '$XDSDocumentEntryPatientId')].ValueList.Value.#text",
            "$..Slot[?(@._name == '$XDSSubmissionSetPatientId')].ValueList.Value.#text",
            "$..Slot[?(@._name == '$XDSFolderPatientId')].ValueList.Value.#text",
            "$..Slot[?(@._name == '$patientId')].ValueList.Value.#text"
        ],
        "returnType": "single"
    }
};

var getP2DiscoveryFromAdhocQueryRequest = {
    "discovery": {
        "type": "mongo",
        "input": [
            patientIdDiscoveryFromAdhocQueryRequestForMongo,
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'code': '@policy.authConsultation.code@', $or: [ {'status': 'active'}, {'status': 'rejected'}], $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1}",
        "returnpath": "code",
        "returnType": "single"
    }
};

var getP1DiscoveryFromAdhocQueryRequest = {
    "discovery": {
        "type": "mongo",
        "input": [
            patientIdDiscoveryFromAdhocQueryRequestForMongo,
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'code': '@policy.authCollect.code@', $or: [ {'status': 'active'}, {'status': 'rejected'}], $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1}",
        "returnpath": "code",
        "returnType": "single"
    }
};

var fakeObjectToThrowMissingConsentFault = {
    "includeInResult": false,
    "required": true,
    "discovery": {
        "type": "jsonpath",
        "expression": "$..FakeObjectToThrowMissingConsentFault",
        "returnType": "single"
    },
    "faultValue": _missingConsent
};

var fakeObjectToThrowEmptyConsentsFault = {
    "includeInResult": false,
    "required": true,
    "discovery": {
        "type": "jsonpath",
        "expression": "$..FakeObjectToThrowFault",
        "returnType": "single"
    },
    "faultValue": _emptyConsent
};

var fixedP2Checked = {
    "includeInResult": true,
    "required": true,
    "value": {
        "fixed": [
            "P2_CHECKED"
        ]
    }
};

var fixedP1P2SkippedByRole = {
    "includeInResult": true,
    "required": true,
    "value": {
        "fixed": [
            "P1_P2_CHECK_SKIPPED_BY_ROLE"
        ]
    }
};

var fixedP1P2SkippedByPurposeOfUse = {
    "includeInResult": true,
    "required": true,
    "value": {
        "fixed": [
            "P1_P2_CHECK_SKIPPED_BY_PURPOSE"
        ]
    }
};

var fixedUncheckableConsents = {
    "includeInResult": true,
    "required": true,
    "value": {
        "fixed": [
            "NO_OBJECT_FOR_CONSENTS"
        ]
    }
};

var emptyValueAttributes = {
    value: {
        fixed: []
    }
};

var getConsentsForAdhocQueryResponse = {
    "id": "urn:xacml:3.0:environment:consents",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "array": true,
    "includeInResult": false,
    "required": false,
    "discovery": {
        "type": "mongo",
        "input": [{
                "id": "patientIdentifier",
                "when": {
                    "discovery": {
                        "type": "jsonpath",
                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        "returnType": "single"
                    }
                },
                "then": {
                    "discovery": {
                        "type": "jsonpath",
                        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        "returnType": "multiple",
                        "postProcessingAsUniqueValue": true,
                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                    }
                },
                "otherwise": {
                    "when": {
                        "discovery": {
                            "type": "jsonpath",
                            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446')]._value",
                            "returnType": "single"
                        }
                    },
                    "then": {
                        "discovery": {
                            "type": "jsonpath",
                            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446')]._value",
                            "returnType": "multiple",
                            "postProcessingAsUniqueValue": true,
                            "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                        }
                    },
                    "otherwise": {
                        "discovery": {
                            "type": "jsonpath",
                            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:f64ffdf0-4b97-4e06-b79f-a52b38ec2f8a')]._value",
                            "returnType": "multiple",
                            "postProcessingAsUniqueValue": true,
                            "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                        }
                    }
                }
            }, {
                "id": "eventIdentifier",
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                    "returnType": "multiple",
                    "postProcessingAsUniqueValue": true,
                    "whenNoResult": {
                        "value": {
                            "fixed": [
                                ""
                            ]
                        }
                    },
                    "postProcessing": "if($out&&$out.length>0){for(var ret=\"\",k=0;k<$out.length;k++){var identifier=$out[k],splittedWithoutSystem=identifier.split(\"^^^^\");if(splittedWithoutSystem[0]&&splittedWithoutSystem[1])ret+='\"'+identifier+'\"',ret+=$out.length-k>1?\",\":\"\";else{var splitted=identifier.split(\"^^^\");if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll(\"urn:oid:\",\"\"),splittedSystemAndType=splitted[1].split(\"^\"),systemAndType=\"\";splittedSystemAndType.length>1&&splittedSystemAndType[0]&&splittedSystemAndType[1]?(systemAndType=splittedSystemAndType[0].replaceAll(\"urn:oid:\",\"\")+\"^\"+splittedSystemAndType[1],splittedSystemAndType[2]&&(systemAndType+=\"^\"+splittedSystemAndType[2])):systemAndType=splitted[0].replaceAll(\"urn:oid:\",\"\"),splittedSystemAndType[0].startsWith(\"&\")?ret+='\"'+value+\"^^^\"+systemAndType+'\",\"'+value+\"^^^&urn:oid:\"+systemAndType.replace(\"&\",\"\")+'\"':ret+='\"'+value+\"^^^\"+systemAndType+'\",\"'+value+\"^^^urn:oid:\"+systemAndType+'\"',ret+=$out.length-k>1?\",\":\"\"}else ret+='\"'+identifier+'\"',ret+=$out.length-k>1?\",\":\"\"}}$out=' \"eventid\": { $in: [ '+ret+\" ] } \"}else $out=\"  $expr: { $eq: [0,1] } \";"
                }
            }, {
                "id": "documentId",
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
                    "returnType": "single",
                    "postProcessingAsUniqueValue": true,
                    "whenNoResult": {
                        "value": {
                            "fixed": [
                                ""
                            ]
                        }
                    },
                    "postProcessing": "if($out && $out.length > 0){ $out = \"'documentid': { $in: [ '\" + $out[0] + \"', 'urn:oid:\" + $out[0] + \"', 'urn:uuid:\" + $out[0] + \"' ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                }
            },
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'status': 'active',  $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ], $or: [  { 'code': '@policy.authConsultation.code@' }, { 'code': '@policy.authConsultationPrevious.code@' }, { 'code': '@policy.obscuring.patient.code@' }, { $and: [ {'code': '@policy.authConsultationLast45Days.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.forTutor.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.forTutorAndPatient.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.event.code@'}, {{eventIdentifier}} ] } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1, status: 1}",
        "returnpath": "{code}_{status}",
        "returnType": "multiple",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_CONSENTS"
                ]
            }
        }
    }
};

var getConsentsForDSUB = {
    "id": "urn:xacml:3.0:environment:consents",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "array": true,
    "includeInResult": false,
    "required": false,
    "discovery": {
        "type": "mongo",
        "input": [
				{
					id: "patientIdentifier",
					source: "all",
					discovery: {
						type: "jsonpath",
						expression: "$..pid",
                        returnType: "multiple",
                        postProcessingAsUniqueValue: true,
                        postProcessing: "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
					}
				}, {
					id: "eventIdentifier",
					discovery: {
						type: "jsonpath",
						expression: "$..referenceIdList[*]",
						returnType: "multiple",
						postProcessingAsUniqueValue: true,
						whenNoResult: {
							"value": {
								"fixed": [
									""
								]
							}
						},
						postProcessing: "if($out && $out.length > 0) { var ret = \"\";  for(var k = 0;k < $out.length; k++) {ret += \"'\" + $out[k] + \"'\"; ret += ($out.length - k > 1) ? \",\" : \"\";} $out = \" 'eventid': { $in: [ \" + ret + \" ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
					}
				}, {
					id: "documentId",
					discovery: {
						type: "jsonpath",
						expression: "$..uId",
						returnType: "single",
						postProcessingAsUniqueValue: true,
						whenNoResult: {
							"value": {
								"fixed": [
									""
								]
							}
						},
						postProcessing: "if($out && $out.length > 0){ $out = \"'documentid': { $in: [ '\" + $out[0] + \"', 'urn:oid:\" + $out[0] + \"', 'urn:uuid:\" + $out[0] + \"' ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
					}
				},
				getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'status': 'active',  $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ], $or: [  { 'code': '@policy.authConsultation.code@' }, { 'code': '@policy.authConsultationPrevious.code@' }, { 'code': '@policy.obscuring.patient.code@' }, { $and: [ {'code': '@policy.authConsultationLast45Days.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.forTutor.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.forTutorAndPatient.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.event.code@'}, {{eventIdentifier}} ] } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1, status: 1}",
        "returnpath": "{code}_{status}",
        "returnType": "multiple",
        "unionResult": {
			"discovery" : {
				"type" : "jsonpath",
				"expression" : "$..consents[*]",
				"returnType" : "multiple"
			}
		},
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_DB_CONSENTS"
                ]
            }
        }
    }
};

var getPatientIdFromMessageContext = {
    "discovery": {
        "type": "mc",
        "key": "eu.dedalus.xvalue.policyengine.PatientQueryId",
        "returnType": "single"
    }
};

var getPatientIdentifierFromMessageContextWithPostProcessing = {
    "discovery": {
        "type": "mc",
        "key": "eu.dedalus.xvalue.policyengine.PatientQueryId",
        "returnType": "multiple",
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0]; var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); } else { ret.push(identifier); } } var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult +=  \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
    }
};

var getPatientIdFromMessageContextWithPostProcessing = {
    "discovery": {
        "type": "mc",
        "key": "eu.dedalus.xvalue.policyengine.PatientQueryId",
        "returnType": "multiple",
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0]; var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); ret.push(value);} else { ret.push(identifier); } } $out = ret;"
    }
};

var getPatientIdFromExtrinsicOrSubmissionOrFolder = {
    "when": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
            "returnType": "single"
        }
    },
    "then": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
            "returnType": "multiple",
            "postProcessingAsUniqueValue": true,
            "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0]; var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); ret.push(value);} else { ret.push(identifier); } } $out = ret;"
        }
    },
    "otherwise": {
        "when": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446')]._value",
                "returnType": "single"
            }
        },
        "then": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446')]._value",
                "returnType": "multiple",
                "postProcessingAsUniqueValue": true,
                "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0]; var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); ret.push(value);} else { ret.push(identifier); } } $out = ret;"
            }
        },
        "otherwise": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:f64ffdf0-4b97-4e06-b79f-a52b38ec2f8a')]._value",
                "returnType": "multiple",
                "postProcessingAsUniqueValue": true,
                "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0]; var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); ret.push(value);} else { ret.push(identifier); } } $out = ret;"
            }
        }
    }
};

var getPatientIdForAdhocQueryResponse = {
    "id": "urn:xacml:3.0:environment:patientId",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInGroupedBag": true,
    "array": true,
    "includeInResult": false,
    "required": true,
    "when": {
        "discovery": {
            "type": "jsonpath",
            "expressions": [
                "$..ExtrinsicObject[0]._id",
                "$..ExtrinsicObject._id",
                "$..RegistryPackage[0]._id",
                "$..RegistryPackage._id"
            ],
            "returnType": "multiple"
        }
    },
    "otherwise": {
        "includeInResult": true,
        "required": true,
        "value": {
            "fixed": [
                "NO_OBJECT_FOR_PATIENTID"
            ]
        }
    },
    "then": {
        "when": getPatientIdFromMessageContext,
        "then": getPatientIdFromMessageContextWithPostProcessing,
        "otherwise": getPatientIdFromExtrinsicOrSubmissionOrFolder,
        "faultValue": _missingPatientId
    }
};

var getPatientIdentifierFromExtrinsicOrSubmissionOrFolder = {
    "id": "patientIdentifier",
    "when": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
            "returnType": "single"
        }
    },
    "then": {
        "discovery": {
            "type": "jsonpath",
            "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
            "returnType": "multiple",
            "postProcessingAsUniqueValue": true,
            "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0]; var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); } else { ret.push(identifier); } } var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult +=  \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
        }
    },
    "otherwise": {
        "when": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446')]._value",
                "returnType": "single"
            }
        },
        "then": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446')]._value",
                "returnType": "multiple",
                "postProcessingAsUniqueValue": true,
                "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0]; var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); } else { ret.push(identifier); } } var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult +=  \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
            }
        },
        "otherwise": {
            "discovery": {
                "type": "jsonpath",
                "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:f64ffdf0-4b97-4e06-b79f-a52b38ec2f8a')]._value",
                "returnType": "multiple",
                "postProcessingAsUniqueValue": true,
                "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0]; var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); } else { ret.push(identifier); } } var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult +=  \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
            }
        }
    }
};

var getP2FromAdhocQueryResponse = {
    "discovery": {
        "type": "mongo",
        "input": [
            getPatientIdentifierFromExtrinsicOrSubmissionOrFolder,
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'code': '@policy.authConsultation.code@', $or: [ {'status': 'active'}, {'status': 'rejected'}], $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1}",
        "returnpath": "code",
        "returnType": "single"
    }
};

var getP1FromAdhocQueryResponse = {
    "discovery": {
        "type": "mongo",
        "input": [
            getPatientIdentifierFromExtrinsicOrSubmissionOrFolder,
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'code': '@policy.authCollect.code@', $or: [ {'status': 'active'}, {'status': 'rejected'}], $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1}",
        "returnpath": "code",
        "returnType": "single"
    }
};

var getPolicyBySubjectRole = {
    "id": "urn:xacml:3.0:policy:policyId",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInResult": true,
    "includeInGroupedBag": true,
    "required": false,
    "discovery": {
        "type": "mc",
        "key": "eu.dedalus.xvalue.policyengine.common.subjectRole",
        "returnType": "single",
        "postProcessingAsUniqueValue": "true",
        "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var role = $out[i].split('@'); if (role[role.length - 1]) { ret.push(role[role.length - 1]); } } } $out = ret;",
        "postProcessingAsMappedValues": [{
                "source": {
                    "storedListKey": "X1V1_ASSISTITO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_ASSISTITO"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_TUTORE_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_TUTORE"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_MMG_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_MMG"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_MEDICO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_MEDICO"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_AMMINISTRATIVO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_AMMINISTRATIVO"
                    ]
                }
            }
        ]
    }
};

var patientIdDiscoveryFromRetrieveDocumentSetResponseForMongoDiscovery = {
    "id": "patientIdentifier",
    "discovery": {
        "type": "mongo",
        "input": [
            getDocumentIdFromRetrieveDocumentSetRequest
        ],
        "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:[{documentId}]},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier'},{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier.identificationScheme':'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427'}},{'$group':{'_id':'$_id','value':{'$first':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier.value'}}}]",
        "ref": "ARRIETTY_DATASOURCE",
        "database": "@arrietty.mongodb.name@",
        "collection": "submission",
        "returnpath": "value",
        "returnType": "multiple",
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
    }
};

var getP1DiscoveryFromRetrieveDocumentSetResponse = {
    "discovery": {
        "type": "mongo",
        "input": [
            patientIdDiscoveryFromRetrieveDocumentSetResponseForMongoDiscovery,
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'code': '@policy.authCollect.code@', $or: [ {'status': 'active'}, {'status': 'rejected'}], $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1}",
        "returnpath": "code",
        "returnType": "single"
    }
};

var getP2DiscoveryFromRetrieveDocumentSetResponse = {
    "discovery": {
        "type": "mongo",
        "input": [
            patientIdDiscoveryFromRetrieveDocumentSetResponseForMongoDiscovery,
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'code': '@policy.authConsultation.code@', $or: [ {'status': 'active'}, {'status': 'rejected'}], $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1}",
        "returnpath": "code",
        "returnType": "single"
    }
};

var getConsentsFromRetrieveDocumentSetResponse = {
    "id": "urn:xacml:3.0:environment:consents",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "array": true,
    "includeInResult": false,
    "required": false,
    "discovery": {
        "type": "mongo",
        "input": [{
                "id": "patientIdentifier",
                "discovery": {
                    "type": "mongo",
                    "input": [
                        getDocumentIdFromRetrieveDocumentSetRequest
                    ],
                    "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:[{documentId}]},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier'},{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier.identificationScheme':'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427'}},{'$group':{'_id':'$_id','value':{'$first':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier.value'}}}]",
                    "ref": "ARRIETTY_DATASOURCE",
                    "database": "@arrietty.mongodb.name@",
                    "collection": "submission",
                    "returnpath": "value",
                    "returnType": "multiple",
                    "postProcessingAsUniqueValue": true,
                    "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO')}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                }
            }, {
                "id": "eventIdentifier",
                "discovery": {
                    "type": "mongo",
                    "input": [
                        getDocumentIdFromRetrieveDocumentSetRequest
                    ],
                    "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:[{documentId}]},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Slot'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Slot.ValueList.Value'},{'$match':{'RegistryObjectList.ExtrinsicObject.Slot.name':'urn:ihe:iti:xds:2013:referenceIdList',}},{'$group':{'_id':'$RegistryObjectList.ExtrinsicObject.Slot.ValueList.Value.content',values:{$first:'$RegistryObjectList.ExtrinsicObject.Slot.ValueList.Value.content'}}}]",
                    "ref": "ARRIETTY_DATASOURCE",
                    "database": "@arrietty.mongodb.name@",
                    "collection": "submission",
                    "returnpath": "values",
                    "returnType": "multiple",
                    "postProcessingAsUniqueValue": true,
                    "postProcessing": "if($out&&$out.length>0){for(var ret=\"\",k=0;k<$out.length;k++){var identifier=$out[k],splittedWithoutSystem=identifier.split(\"^^^^\");if(splittedWithoutSystem[0]&&splittedWithoutSystem[1])ret+='\"'+identifier+'\"',ret+=$out.length-k>1?\",\":\"\";else{var splitted=identifier.split(\"^^^\");if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll(\"urn:oid:\",\"\"),splittedSystemAndType=splitted[1].split(\"^\"),systemAndType=\"\";splittedSystemAndType.length>1&&splittedSystemAndType[0]&&splittedSystemAndType[1]?(systemAndType=splittedSystemAndType[0].replaceAll(\"urn:oid:\",\"\")+\"^\"+splittedSystemAndType[1],splittedSystemAndType[2]&&(systemAndType+=\"^\"+splittedSystemAndType[2])):systemAndType=splitted[0].replaceAll(\"urn:oid:\",\"\"),splittedSystemAndType[0].startsWith(\"&\")?ret+='\"'+value+\"^^^\"+systemAndType+'\",\"'+value+\"^^^&urn:oid:\"+systemAndType.replace(\"&\",\"\")+'\"':ret+='\"'+value+\"^^^\"+systemAndType+'\",\"'+value+\"^^^urn:oid:\"+systemAndType+'\"',ret+=$out.length-k>1?\",\":\"\"}else ret+='\"'+identifier+'\"',ret+=$out.length-k>1?\",\":\"\"}}$out=' \"eventid\": { $in: [ '+ret+\" ] } \"}else $out=\"  $expr: { $eq: [0,1] } \";",
                    "whenNoResult": {
                        "value": {
                            "fixed": [
                                ""
                            ]
                        }
                    }
                }
            }, {
                "id": "documentId",
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..DocumentUniqueId.#text",
                    "returnType": "single",
                    "postProcessingAsUniqueValue": true,
                    "whenNoResult": {
                        "value": {
                            "fixed": [
                                ""
                            ]
                        }
                    },
                    "postProcessing": "if($out && $out.length > 0){ $out = \"'documentid': { $in: [ '\" + $out[0] + \"', 'urn:oid:\" + $out[0] + \"', 'urn:uuid:\" + $out[0] + \"' ] } \"}  else { $out = \"  $expr: { $eq: [0,1] } \"};"
                }
            },
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'status': 'active',  $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ], $or: [  { 'code': '@policy.authConsultation.code@' }, { 'code': '@policy.authConsultationPrevious.code@' }, { 'code': '@policy.obscuring.patient.code@' }, { $and: [ {'code': '@policy.authConsultationLast45Days.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.forTutor.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.forTutorAndPatient.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.document.code@'}, {{documentId}} ] }, { $and: [ {'code': '@policy.obscuring.event.code@'}, {{eventIdentifier}} ] } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1, status: 1}",
        "returnpath": "{code}_{status}",
        "returnType": "multiple",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_CONSENTS"
                ]
            }
        }
    }
};

var getCreationPerformedFromRetrieveDocumentSetResponse = {
    "id": "urn:xacml:3.0:environment:creation-performed",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "discovery": {
        "type": "mongo",
        "input": [
            getDocumentIdFromRetrieveDocumentSetRequest
        ],
        "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:[{documentId}]},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Slot'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Slot.ValueList.Value'},{'$match':{'RegistryObjectList.ExtrinsicObject.Slot.name':'creationTime',}},{'$group':{'_id':'$_id',value:{$first:'$RegistryObjectList.ExtrinsicObject.Slot.ValueList.Value.content'}}}]",
        "ref": "ARRIETTY_DATASOURCE",
        "database": "@arrietty.mongodb.name@",
        "collection": "submission",
        "returnpath": "value",
        "postProcessing": "var year = $out.substring(0,4); var month = $out.substring(4,6); var day = $out.substring(6,8); var hours = $out.substring(8,10); var minutes = $out.substring(10,12); var seconds = $out.substring(12,14); var time = year+'-'+month+'-'+day+'T'+hours+':'+minutes+':'+seconds; var value = new Date(time).getTime(); var offset = new Date().getTime()-(45*24*60*60*1000); if(value >= offset) { $out='NEXT_LAST_45_DAYS'; } else { $out='PREV_LAST_45_DAYS'; }",
        "returnType": "single",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "PREV_LAST_45_DAYS"
                ]
            }
        }
    },
    "includeInResult": false
};

var getTypeCodeForRetrieveDocumentSetResponse = {
    "id": "urn:xacml:3.0:environment:typeCode",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInResult": false,
    "required": false,
    "discovery": {
        "type": "mongo",
        "input": [{
                "id": "documentId",
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..DocumentUniqueId.#text",
                    "returnType": "multiple",
                    "postProcessingAsUniqueValue": true,
                    "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){ret.push($out[i]);} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                }
            }
        ],
        "aggregation": "[{'$match': {'RegistryObjectList.ExtrinsicObject.ExternalIdentifier': {$elemMatch: {value: {$in: [{documentId}]},identificationScheme: 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}}, {'$unwind': '$RegistryObjectList.ExtrinsicObject'}, {'$unwind': '$RegistryObjectList.ExtrinsicObject.Classification'}, {'$match': {'RegistryObjectList.ExtrinsicObject.Classification.classificationScheme': 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983',}}, {'$group': {'_id': '$_id',value: {$first: '$RegistryObjectList.ExtrinsicObject.Classification.nodeRepresentation'}, scheme: { $first: '$RegistryObjectList.ExtrinsicObject.Classification.nodeRepresentation.Slot.ValueList.Value.content'}}}]",
        "ref": "ARRIETTY_DATASOURCE",
        "database": "@arrietty.mongodb.name@",
        "collection": "submission",
        "returnpath": "{system}|{value}",
        "returnType": "single",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_TYPECODE"
                ]
            }
        }
    }
};

var getConfidentialityCodeForRetrieveDocumentSetResponse = {
    "id": "urn:xacml:3.0:environment:confidentialityCode",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInResult": false,
    "required": false,
    "discovery": {
        "type": "mongo",
        "input": [{
                "id": "documentId",
                "discovery": {
                    "type": "jsonpath",
                    "expression": "$..DocumentUniqueId.#text",
                    "returnType": "multiple",
                    "postProcessingAsUniqueValue": true,
                    "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){ret.push($out[i]);} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                }
            }
        ],
        "aggregation": "[{'$match': {'RegistryObjectList.ExtrinsicObject.ExternalIdentifier': {$elemMatch: {value: {$in: [{documentId}]},identificationScheme: 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}}, {'$unwind': '$RegistryObjectList.ExtrinsicObject'}, {'$unwind': '$RegistryObjectList.ExtrinsicObject.Classification'}, {'$match': {'RegistryObjectList.ExtrinsicObject.Classification.classificationScheme': 'urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f',}}, {'$group': {'_id': '$_id',value: {$first: '$RegistryObjectList.ExtrinsicObject.Classification.nodeRepresentation'}}}]",
        "ref": "ARRIETTY_DATASOURCE",
        "database": "@arrietty.mongodb.name@",
        "collection": "submission",
        "returnpath": "value",
        "returnType": "multiple",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_CONFIDENTIALITY"
                ]
            }
        }
    }
};

var getCreationDateFromRetrieveDocumentSetResponse = {
    "id": "urn:xacml:3.0:environment:creation-date",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "type": "integer",
    "discovery": {
        "type": "mongo",
        "input": [
            getDocumentIdFromRetrieveDocumentSetRequest
        ],
        "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:[{documentId}]},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Slot'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Slot.ValueList.Value'},{'$match':{'RegistryObjectList.ExtrinsicObject.Slot.name':'creationTime',}},{'$group':{'_id':'$_id',value:{$first:'$RegistryObjectList.ExtrinsicObject.Slot.ValueList.Value.content'}}}]",
        "ref": "ARRIETTY_DATASOURCE",
        "database": "@arrietty.mongodb.name@",
        "collection": "submission",
        "returnpath": "value",
        "returnType": "single",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "0"
                ]
            }
        }
    },
    "includeInResult": false,
    "required": true
};

var getPatientTutorsFromRetrieveDocumentSetResponse = {
    "id": "urn:xacml:3.0:environment:patientTutors",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInGroupedBag": true,
    "array": true,
    "includeInResult": false,
    "required": false,
    "when": {
        "discovery": {
            "type": "jsonpath",
            "expressions": [
                "$..DocumentUniqueId[0].#text",
                "$..DocumentUniqueId.#text"
            ],
            "returnType": "multiple"
        }
    },
    "otherwise": {
        "includeInResult": true,
        "required": true,
        "value": {
            "fixed": [
                "NO_OBJECT_FOR_PATIENTTUTORS"
            ]
        }
    },
    "then": {
        "discovery": {
            "type": "mongo",
            "input": [{
                    "id": "patientIdentifier",
                    "discovery": {
                        "type": "mongo",
                        "input": [
                            getDocumentIdFromRetrieveDocumentSetRequest
                        ],
                        "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:[{documentId}]},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier'},{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier.identificationScheme':'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427'}},{'$group':{'_id':'$_id','value':{'$first':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier.value'}}}]",
                        "ref": "ARRIETTY_DATASOURCE",
                        "database": "@arrietty.mongodb.name@",
                        "collection": "submission",
                        "returnpath": "value",
                        "returnType": "multiple",
                        "postProcessingAsUniqueValue": true,
                        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO');ret.push(value)}else{ret.push(identifier)}} $out=ret}var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult += \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
                    }
                }
            ],
            "expression": "{'patientid': { $in: [{patientIdentifier}] }}",
            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
            "database": "@consent.engine.mongodb.name@",
            "collection": "tutor",
            "returnpath": "tutorid",
            "returnType": "multiple",
            "postProcessingAsUniqueValue": true,
            "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var identifier = $out[i]; var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); ret.push(value); } else { ret.push(identifier); } } $out = ret; }",
            "whenNoResult": {
                "value": {
                    "fixed": [
                        "NO_PATIENT_TUTORS"
                    ]
                }
            }
        }
    }
};

var getAuthorFromRetrieveDocumentSetResponse = {
    "id": "urn:xacml:3.0:environment:authorId",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "array": true,
    "includeInResult": false,
    "required": false,
    "discovery": {
        "type": "mongo",
        "input": [
            getDocumentIdFromRetrieveDocumentSetRequest
        ],
        "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:['2.16.840.1.113883.2.9.3.12.1000.1.1.1605889260915.2','2.16.840.1.113883.2.9.3.12.1000.1.1.1605889544738.2']},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Classification'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Classification.Slot'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Classification.Slot.ValueList.Value'},{'$match':{'RegistryObjectList.ExtrinsicObject.Classification.classificationScheme':'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d','RegistryObjectList.ExtrinsicObject.Classification.Slot.name':'authorPerson',}},{'$group':{'_id':'$_id','value':{'$first':'$RegistryObjectList.ExtrinsicObject.Classification.Slot.ValueList.Value.content'}}}]",
        "ref": "ARRIETTY_DATASOURCE",
        "database": "@arrietty.mongodb.name@",
        "collection": "submission",
        "returnpath": "value",
        "returnType": "multiple",
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^');if(splitted[0]&&splitted[8]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:','');var system=splitted[8].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO');ret.push(value)}else{ret.push(identifier)}}}$out=ret;",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_RESOURCE_AUTHOR"
                ]
            }
        }
    }
};

var getWardFromRetrieveDocumentSetResponse = {
    "id": "urn:xacml:3.0:environment:ward",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "array": true,
    "includeInResult": false,
    "required": false,
    "discovery": {
        "type": "mongo",
        "input": [
            getDocumentIdFromRetrieveDocumentSetRequest
        ],
        "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:['2.16.840.1.113883.2.9.3.12.1000.1.1.1605889260915.2','2.16.840.1.113883.2.9.3.12.1000.1.1.1605889544738.2']},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Classification'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Classification.Slot'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.Classification.Slot.ValueList.Value'},{'$match':{'RegistryObjectList.ExtrinsicObject.Classification.classificationScheme':'urn:uuid:93606bcf-9494-43ec-9b4e-a7748d1a838d','RegistryObjectList.ExtrinsicObject.Classification.Slot.name':'authorInstitution',}},{'$group':{'_id':'$_id','value':{'$first':'$RegistryObjectList.ExtrinsicObject.Classification.Slot.ValueList.Value.content'}}}]",
        "ref": "ARRIETTY_DATASOURCE",
        "database": "@arrietty.mongodb.name@",
        "collection": "submission",
        "returnpath": "value",
        "returnType": "multiple",
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^');if(splitted[9]){var value=splitted[9].replaceAll('urn:oid:','').replaceAll('urn:uuid:','');ret.push(value)}else{ret.push(identifier)}}}$out=ret;",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_RESOURCE_WARD"
                ]
            }
        }
    }
};

var getPatientIdFromRetrieveDocumentSetResponse = {
    "id": "urn:xacml:3.0:environment:patientId",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInGroupedBag": true,
    "array": true,
    "includeInResult": true,
    "required": true,
    "when": {
        "discovery": {
            "type": "jsonpath",
            "expressions": [
                "$..DocumentUniqueId[0].#text",
                "$..DocumentUniqueId.#text"
            ],
            "returnType": "multiple"
        }
    },
    "otherwise": {
        "includeInResult": true,
        "required": true,
        "value": {
            "fixed": [
                "NO_OBJECT_FOR_PATIENTID"
            ]
        }
    },
    "then": {
        "discovery": {
            "type": "mongo",
            "input": [
                getDocumentIdFromRetrieveDocumentSetRequest
            ],
            "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:[{documentId}]},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier'},{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier.identificationScheme':'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427'}},{'$group':{'_id':'$_id','value':{'$first':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier.value'}}}]",
            "ref": "ARRIETTY_DATASOURCE",
            "database": "@arrietty.mongodb.name@",
            "collection": "submission",
            "returnpath": "value",
            "returnType": "multiple",
            "postProcessingAsUniqueValue": true,
            "postProcessing": "var ret=[];if($out.length>0){for(var i=0;i<$out.length;i++){var identifier=$out[i];var splitted=identifier.split('^^^');if(splitted[0]&&splitted[1]){var value=splitted[0].replaceAll('urn:oid:','').replaceAll('urn:uuid:',''); var system=splitted[1].replaceAll('urn:oid:','').replaceAll('urn:uuid:','').replaceAll('&','').replaceAll('ISO','');ret.push(value+'^^^&'+system+'&ISO');ret.push(value+'^^^&urn:oid:'+system+'&ISO');ret.push(value)}else{ret.push(identifier)}} $out=ret}"
        },
        "faultValue": _missingPatientId
    }
};

var getUniqueIdFromRetrieveDocumentSetResponse = {
    "id": "urn:xacml:3.0:environment:uniqueId",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "discovery": {
        "type": "jsonpath",
        "expression": "$..DocumentUniqueId.#text",
        "returnType": "single"
    },
    "includeInResult": true
};

var verifyRoleAsX1V1Medico = {
    "discovery": {
        "type": "mc",
        "key": "eu.dedalus.xvalue.policyengine.common.subjectRole",
        "returnType": "single",
        "postProcessingAsUniqueValue": "true",
        "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var role = $out[i].split('@'); if (role[role.length - 1]) { ret.push(role[role.length - 1]); } } } $out = ret;",
        "postProcessingAsMappedValues": [{
                "source": {
                    "storedListKey": "X1V1_MEDICO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_MEDICO"
                    ]
                }
            }
        ]
    }
};

var groupByForRetrieveDocumentSetResponse = {
    "id": "extrinsicObject",
    "discovery": {
        "type": "jsonpath",
        "expression": "$..DocumentResponse",
        "returnType": "multiple"
    }
};

var patientIdDiscoveryFromProvideAndRegisterDocumentSetRequestForMongoDiscovery = {
    "id": "patientIdentifier",
    "discovery": {
        "type": "jsonpath",
        "expression": "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:6b5aea1a-874d-4603-a4bc-96a0a7b38446')]._value",
        "returnType": "multiple",
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0].replaceAll('\\'',''); var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); } else { ret.push(identifier); } } var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult +=  \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
    }
};

var getP1DiscoveryFromProvideAndRegisterDocumentSetRequest = {
    "discovery": {
        "type": "mongo",
        "input": [
            patientIdDiscoveryFromProvideAndRegisterDocumentSetRequestForMongoDiscovery,
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'code': '@policy.authCollect.code@', $or: [ {'status': 'active'} ], $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1}",
        "returnpath": "code",
        "returnType": "single"
    }
};

var patientIdDiscoveryFromRetrieveDocumentSetRequestForMongoDiscovery = {
    "id": "patientIdentifier",
    "discovery": {
        "type": "mongo",
        "input": [
            getDocumentIdFromRetrieveDocumentSetRequest
        ],
        "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:[{documentId}]},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier'},{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier.identificationScheme':'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427'}},{'$group':{'_id':'$_id','value':{'$first':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier.value'}}}]",
        "ref": "ARRIETTY_DATASOURCE",
        "database": "@arrietty.mongodb.name@",
        "collection": "submission",
        "returnpath": "value",
        "returnType": "multiple",
        "postProcessingAsUniqueValue": true,
        "postProcessing": "var ret = []; if ($out.length > 0) { var identifier = $out[0].replaceAll('\\'',''); var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); } else { ret.push(identifier); } } var joinedResult = ''; for (var k = 0; k < ret.length; k++) { joinedResult +=  \"'\" + ret[k] + \"'\"; joinedResult += (ret.length - k > 1) ? ',' : ''; } $out = joinedResult;"
    }
};

var getP1DiscoveryFromRetrieveDocumentSetRequest = {
    "discovery": {
        "type": "mongo",
        "input": [
            patientIdDiscoveryFromRetrieveDocumentSetRequestForMongoDiscovery,
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'code': '@policy.authCollect.code@', $or: [ {'status': 'active'}, {'status': 'rejected'}], $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1}",
        "returnpath": "code",
        "returnType": "single"
    }
};

var getP2DiscoveryFromRetrieveDocumentSetRequest = {
    "discovery": {
        "type": "mongo",
        "input": [
            patientIdDiscoveryFromRetrieveDocumentSetRequestForMongoDiscovery,
            getCurrentTimeForMongoDiscovery
        ],
        "expression": "{'patientid': { $in: [{patientIdentifier}] }, 'code': '@policy.authConsultation.code@', $or: [ {'status': 'active'}, {'status': 'rejected'}], $or: [ { 'period.end': { $exists: false} }, { 'period.end': { $gte: {$date: {currentTime}}}  } ]}",
        "ref": "PM_CONSENT_ENGINE_DATASOURCE",
        "database": "@consent.engine.mongodb.name@",
        "collection": "consent",
        "projection": "{code : 1}",
        "returnpath": "code",
        "returnType": "single"
    }
};

var patientIdDiscoveryFromRetrieveDocumentSetRequest = {
    "id": "patientIdentifier",
    "discovery": {
        "type": "mongo",
        "input": [
            getDocumentIdFromRetrieveDocumentSetRequest
        ],
        "aggregation": "[{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier':{$elemMatch:{value:{$in:[{documentId}]},identificationScheme:'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab'}}}},{'$unwind':'$RegistryObjectList.ExtrinsicObject'},{'$unwind':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier'},{'$match':{'RegistryObjectList.ExtrinsicObject.ExternalIdentifier.identificationScheme':'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427'}},{'$group':{'_id':'$_id','value':{'$first':'$RegistryObjectList.ExtrinsicObject.ExternalIdentifier.value'}}}]",
        "ref": "ARRIETTY_DATASOURCE",
        "database": "@arrietty.mongodb.name@",
        "collection": "submission",
        "returnpath": "value",
        "returnType": "single"
    }
};

var subjectPurposeOfUse = {
	"id": "urn:xacml:3.0:subject:subject-purpose",
	"category": "urn:oasis:names:tc:xacml:1.0:subject-category:purpose-subject",
	"includeInResult": false,
	"required": false,
	"discovery": {
		"type": "mc",
		"key": "jwtPurposeOfUse",
		"returnType": "multiple",
		"whenNoResult": {
			"value": {
				"fixed": [
					"NO_PURPOSEOFUSE"
				]
			}
		},
		"postProcessing": "var ret = []; if ($out !== null && $out !== '') {  var splitted=$out.split(' '); for (var k = 0; k < splitted.length; k++) { ret.push(splitted[k]); }  } else { ret.push('NO_PURPOSEOFUSE');} $out = ret;"
	}
}

var purposeOfUseAsEmergency = {
    "discovery": {
        "type": "mc",
        "key": "urn:oasis:names:tc:xspa:1.0:subject:purposeofuse",
        "returnType": "single",
        "postProcessingAsUniqueValue": "true",
        "postProcessing": "if ($out.length > 0) { var value = $out[0]; if (value == 'EMERGENCY') { $out = value; } else { $out = []; } } else { $out = []; }"
    }
}

var fixedConsentsNotChecked = {
    "includeInResult": false,
    "required": false,
    "value": {
        "fixed": [
            "NOT_CHECKED"
        ]
    }
};

var subjectWardWithPostProcessing = {
    "id": "urn:xacml:3.0:subject:subject-ward",
    "category": "urn:oasis:names:tc:xacml:3.0:subject-category:ward-subject",
    "includeInResult": false,
    "required": false,
    "discovery": {
        "type": "mc",
        "key": "eu.dedalus.xvalue.policyengine.common.subjectRole",
        "returnType": "single",
        "postProcessingAsUniqueValue": "true",
        "postProcessingInput": [{
                "name": "X1V1_ASSISTITO_Roles",
                "storedListKey": "X1V1_ASSISTITO_Roles"
            }, {
                "name": "X1V1_TUTORE_Roles",
                "storedListKey": "X1V1_TUTORE_Roles"
            }, {
                "name": "X1V1_MEDICO_Roles",
                "storedListKey": "X1V1_MEDICO_Roles"
            }, {
                "name": "X1V1_MMG_Roles",
                "storedListKey": "X1V1_MMG_Roles"
            }, {
                "name": "X1V1_AMMINISTRATIVO_Roles",
                "storedListKey": "X1V1_AMMINISTRATIVO_Roles"
            }
        ],
        "postProcessing": "var X1V1_ASSISTITO_Roles=[{X1V1_ASSISTITO_Roles}];var X1V1_TUTORE_Roles=[{X1V1_TUTORE_Roles}];var X1V1_MEDICO_Roles=[{X1V1_MEDICO_Roles}];var X1V1_MMG_Roles=[{X1V1_MMG_Roles}];var X1V1_AMMINISTRATIVO_Roles=[{X1V1_AMMINISTRATIVO_Roles}];var rolesToSplit=$out;$out='NO_SUBJECT_WARD';if(rolesToSplit.length>0){for(var i=0;i<rolesToSplit.length;i++){var role=rolesToSplit[i].split('@');if(role.length>1){var roleValue=role[role.length-1];var facilityValue=role[role.length-2];for(var j=0;j<X1V1_ASSISTITO_Roles.length;j++){if(roleValue==X1V1_ASSISTITO_Roles[j]){$out=facilityValue}}for(var j=0;j<X1V1_TUTORE_Roles.length;j++){if(roleValue==X1V1_TUTORE_Roles[j]){$out=facilityValue}}for(var j=0;j<X1V1_MEDICO_Roles.length;j++){if(roleValue==X1V1_MEDICO_Roles[j]){$out=facilityValue}}for(var j=0;j<X1V1_MMG_Roles.length;j++){if(roleValue==X1V1_MMG_Roles[j]){$out=facilityValue}}for(var j=0;j<X1V1_AMMINISTRATIVO_Roles.length;j++){if(roleValue==X1V1_AMMINISTRATIVO_Roles[j]){$out=facilityValue}}}}}",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_SUBJECT_WARD"
                ]
            }
        }
    }
};

var getPatientTutorsForAdhocQueryResponse = {
    "id": "urn:xacml:3.0:environment:patientTutors",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInGroupedBag": true,
    "array": true,
    "includeInResult": false,
    "required": false,
    "when": {
        "discovery": {
            "type": "jsonpath",
            "expressions": [
                "$..ExtrinsicObject[0]._id",
                "$..ExtrinsicObject._id",
                "$..RegistryPackage[0]._id",
                "$..RegistryPackage._id"
            ],
            "returnType": "multiple"
        }
    },
    "otherwise": {
        "includeInResult": true,
        "required": true,
        "value": {
            "fixed": [
                "NO_OBJECT_FOR_PATIENTTUTORS"
            ]
        }
    },
    "then": {
        "discovery": {
            "type": "mongo",
            "input": [{
                    "id": "patientIdentifier",
                    "when": getPatientIdFromMessageContext,
                    "then": getPatientIdentifierFromMessageContextWithPostProcessing,
                    "otherwise": getPatientIdentifierFromExtrinsicOrSubmissionOrFolder
                }
            ],
            "expression": "{'patientid': { $in: [{patientIdentifier}] }}",
            "ref": "PM_CONSENT_ENGINE_DATASOURCE",
            "database": "@consent.engine.mongodb.name@",
            "collection": "tutor",
            "returnpath": "tutorid",
            "returnType": "multiple",
            "postProcessingAsUniqueValue": true,
            "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var identifier = $out[i]; var splitted = identifier.split('^^^'); if (splitted[0] && splitted[1]) { var value = splitted[0].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', ''); var system = splitted[1].replaceAll('urn:oid:', '').replaceAll('urn:uuid:', '').replaceAll('&', '').replaceAll('ISO', ''); ret.push(value + '^^^&' + system + '&ISO'); ret.push(value + '^^^&urn:oid:' + system + '&ISO'); ret.push(value); } else { ret.push(identifier); } } $out = ret; }",
            "whenNoResult": {
                "value": {
                    "fixed": [
                        "NO_PATIENT_TUTORS"
                    ]
                }
            }
        }
    }
};

var documentCreationDate = {
    id: XACML_PREFIX + "xacml:3.0:environment:creation-date",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    type: "date",
    discovery: documentCreationDateDiscovery,
    includeInResult: false
};

var consentEndDate = {
    id: XACML_PREFIX + "xacml:3.0:environment:consent:enddate",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    type: "date",
    when: {
        when: {
            discovery: documentEvenIdDiscovery
        },
        then: {
            discovery: isConsentA1OnceGivenDiscovery
        },
        otherwise: {
            discovery: isConsentA1OnceGivenOnPatientDiscovery
        }
    },
    then: {
        when: {
            discovery: documentEvenIdDiscovery
        },
        then: {
            discovery: consentA1EndDateOnEventDiscovery
        },
        otherwise: {
            discovery: consentA1EndDateOnPatientDiscovery
        }
    },
    otherwise: emptyValueAttributes,
    includeInResult: false
};

var consentStartDate = {
    id: XACML_PREFIX + "xacml:3.0:environment:consent:startdate",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    type: "date",
    when: {
        when: {
            discovery: documentEvenIdDiscovery
        },
        then: {
            discovery: isConsentA1OnceGivenDiscovery
        },
        otherwise: {
            discovery: isConsentA1OnceGivenOnPatientDiscovery
        }
    },
    then: {
        // rename P1 -> P3 and A1 -> P1
        when: {
            discovery: documentEvenIdDiscovery
        },
        then: {
            discovery: consentP1StartDateOnEventDiscovery
        },
        otherwise: {
            discovery: consentP1StartDateOnPatientDiscovery
        }
    },
    otherwise: emptyValueAttributes,
    includeInResult: false
};

var role = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-role",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    discovery: {
        type: "mc",
        key: "eu.dedalus.xvalue.policyengine.common.subjectRole",
        postProcessingAsUniqueValue: "true",
        "postProcessing": "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var role = $out[i].split('@'); if (role[role.length - 1]) { ret.push(role[role.length - 1]); } } } $out = ret;",
        "postProcessingAsMappedValues": [{
                "source": {
                    "storedListKey": "X1V1_ASSISTITO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_ASSISTITO"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_TUTORE_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_TUTORE"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_MEDICO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_MEDICO"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_MMG_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_MMG"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_AMMINISTRATIVO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_AMMINISTRATIVO"
                    ]
                }
            }
        ]
    },
    domain: {
        value: {
            storedListKey: "ALL_MAPPED_Roles"
        }
    },
    includeInResult: true,
    required: true,
    faultValue: _202
};

var actionCreate = {
    id: "urn:oasis:names:tc:xacml:1.0:action:action-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:action",
    value: {
        fixed: ["C"]
    },
    includeInResult: false,
    required: true,
    faultValue: _102
};

var actionRead = {
    id: "urn:oasis:names:tc:xacml:1.0:action:action-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:action",
    value: {
        fixed: ["R"]
    },
    includeInResult: false,
    required: true
};

var actionUpdate = {
    id: "urn:oasis:names:tc:xacml:1.0:action:action-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:action",
    value: {
        fixed: ["U"]
    },
    includeInResult: false,
    required: true,
    faultValue: _102
};

var actionDelete = {
    id: "urn:oasis:names:tc:xacml:1.0:action:action-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:action",
    value: {
        fixed: ["D"]
    },
    includeInResult: false,
    required: true,
    faultValue: _102
};

var actionCreateUpdate = {
    id: "urn:oasis:names:tc:xacml:1.0:action:action-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:action",
    value: {
        when: "$..Association[?(@._type == 'urn:oasis:names:tc:ebxml-regrep:AssociationType:RPLC')]._type",
        then: "U",
        otherwise: "C"
    },
    includeInResult: false,
    required: true,
    faultValue: _102
};

var actionNotify = {
    id: "urn:oasis:names:tc:xacml:1.0:action:action-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:action",
    value: {
        fixed: ["N"]
    },
    includeInResult: false,
    required: true
};

var typeCode = {
    id: XACML_PREFIX + "xacml:3.0:environment:type-code",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "jsonpath",
        expression: "$..Classification[?(@._classificationScheme == 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983')]._nodeRepresentation",
        returnType: "single"
    },
    domain: {
        discovery: {
            type: "jsonpath",
            source: "ad",
            expression: "$..CodeType[?(@._classScheme == 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983')].Code[*]._code",
            returnType: "multiple"
        }
    },
    includeInResult: true,
    required: true,
    faultValue: _101
};

var confidentiality = {
    id: XACML_PREFIX + "xacml:3.0:environment:confidentiality",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "jsonpath",
        expression: "$..Classification[?(@._classificationScheme == 'urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f')]._nodeRepresentation",
        returnType: "single"
    },
    domain: {
        discovery: {
            type: "jsonpath",
            source: "ad",
            expression: "$..CodeType[?(@._classScheme == 'urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f')].Code[*]._code",
            returnType: "multiple"
        }
    },
    includeInResult: true,
    required: true,
    faultValue: _203
};

var uniqueId = {
    id: XACML_PREFIX + "xacml:3.0:environment:uniqueId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "jsonpath",
        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
        returnType: "single"
    },
    includeInResult: true
};

var extrinsicObject = {
    id: "extrinsicObject",
    discovery: {
        type: "jsonpath",
        expression: "$..ExtrinsicObject",
        returnType: "multiple"
    }
};

var documentConsentRemoveCondition = {
    id: "documentConsentRemoveCondition",
    value: {
        when: "$..Classification[?(@._nodeRepresentation == '2.16.840.1.113883.2.9.2.100.RAMO_OID_CODIFICHE_PRIVACY.98' || (@._classificationScheme == 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983' && (@._nodeRepresentation == '57016-8' || @._nodeRepresentation == '59284-0' || @._nodeRepresentation == 'consent002' || @._nodeRepresentation == 'consent003')))]._nodeRepresentation",
        postProcessing: "if($out.length > 0) { $out = 'true'}",
        then: "true",
        otherwise: "false"
    }
};

var documentConsentTutorRemoveCondition = {
    id: "documentConsentTutorRemoveCondition",
    value: {
        when: "$..Classification[?(@._nodeRepresentation == '2.16.840.1.113883.2.9.2.100.RAMO_OID_CODIFICHE_PRIVACY.97' || (@._classificationScheme == 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983' && (@._nodeRepresentation == '57016-8' || @._nodeRepresentation == '59284-0' || @._nodeRepresentation == 'consent002' || @._nodeRepresentation == 'consent003')))]._nodeRepresentation",
        postProcessing: "if($out.length > 0) { $out = 'true'}",
        then: "true",
        otherwise: "false"
    }
};

var structure = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-structure",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:structure-subject",
    discovery: {
        type: "mc",
        key: "eu.dedalus.xvalue.policyengine.pep.handler.subject.healthcare.structure"
    },
    includeInResult: true,
    required: true,
    faultValue: _203
};

var documentPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    includeInResult: true,
    discovery: {
        type: "jsonpath",
        expression: "$..Classification[?(@._classificationScheme == 'urn:uuid:2c6b8cb7-8b2a-4051-b291-b1ae6a575ef4')]._nodeRepresentation",
        returnType: "multiple"
    },
    required: true,
    faultValue: missingConsent
};

var bppcPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["alimentazione_consenso"]
    },
    includeInResult: true
};

var codiceAutenticazione = {
    id: XACML_PREFIX + "xacml:3.0:environment:codice-autenticazione",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..Slot[?(@._name == 'codiceAutenticazione')]._name",
            returnType: "single"
        }
    },
    then: {
        value: {
            fixed: ["EVALUATED"]
        }
    },
    otherwise: {
        value: {
            fixed: [""]
        }
    },
    includeInResult: false
};

//policyIdAdhoc
var genericPolicyIdAdhoc = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "rest",
        input: [{
                id: "patientid",
                discovery: {
                    type: "jsonpath",
                    expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                    returnType: "single"
                }
            }
        ],
        config: {
            method: "GET",
            url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?status=active",
            headers: [{
                    key: "accept",
                    value: "application/json"
                }
            ]
        },
        returnpath: "$..consents[*].code",
        cache: true
    }
};

var eventPolicyIdAdhoc = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
            returnType: "multiple"
        }
    },
    then: {
        discovery: {
            type: "rest",
            input: [{
                    id: "patientid",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        returnType: "single"
                    }
                }, {
                    id: "eventid",
                    source: "groupBy",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                        returnType: "single"
                    }
                }
            ],
            config: {
                method: "GET",
                url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?eventid={eventid}&status=active",
                headers: [{
                        key: "accept",
                        value: "application/json"
                    }
                ]
            },
            returnpath: "$..consents[*].code",
            whenNoResult: genericPolicyIdAdhoc,
            cache: true
        }
    },
    otherwise: genericPolicyIdAdhoc
};

var policyIdAdhoc = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    includeInResult: true,
    when: {
        discovery: {
            type: "rest",
            input: [{
                    id: "patientid",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        returnType: "single"
                    }
                }, {
                    id: "documentid",
                    source: "groupBy",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
                        returnType: "single"
                    }
                }
            ],
            config: {
                method: "GET",
                url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?documentid={documentid}&status=active&consentcode=P80",
                headers: [{
                        key: "accept",
                        value: "application/json"
                    }
                ]
            },
            returnpath: "$..consents[*].code",
            cache: true
        }
    },
    then: {
        discovery: {
            type: "rest",
            input: [{
                    id: "patientid",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        returnType: "single"
                    }
                }, {
                    id: "documentid",
                    source: "groupBy",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
                        returnType: "single"
                    }
                }
            ],
            config: {
                method: "GET",
                url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?documentid={documentid}&status=active",
                headers: [{
                        key: "accept",
                        value: "application/json"
                    }
                ]
            },
            returnpath: "$..consents[*].code",
            unionResult: eventPolicyIdAdhoc,
            cache: true
        }
    },
    otherwise: {
        discovery: {
            type: "rest",
            input: [{
                    id: "patientid",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        returnType: "single"
                    }
                }, {
                    id: "documentid",
                    source: "groupBy",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
                        returnType: "single"
                    }
                }
            ],
            config: {
                method: "GET",
                url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?documentid={documentid}&status=active",
                headers: [{
                        key: "accept",
                        value: "application/json"
                    }
                ]
            },
            returnpath: "$..consents[*].code",
            whenNoResult: eventPolicyIdAdhoc,
            cache: true
        }
    },
    required: true,
    faultValue: missingConsent
};
// end policyIdAdhoc

//genericPolicyId
var policyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "jsonpath",
        expression: "$..Classification[?(@._classificationScheme == 'urn:uuid:2c6b8cb7-8b2a-4051-b291-b1ae6a575ef4')]._nodeRepresentation",
        returnType: "multiple"
    }
};

var eventPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
            returnType: "multiple"
        }
    },
    then: {
        discovery: {
            type: "rest",
            input: [{
                    id: "patientid",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        returnType: "single"
                    }
                }, {
                    id: "eventid",
                    source: "groupBy",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                        returnType: "single"
                    }
                }
            ],
            config: {
                method: "GET",
                url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?eventid={eventid}&status=active",
                headers: [{
                        key: "accept",
                        value: "application/json"
                    }
                ]
            },
            returnpath: "$..consents[*].code",
            whenNoResult: policyId,
            cache: true
        }
    },
    otherwise: policyId
};

var genericPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    includeInResult: true,
    discovery: {
        type: "rest",
        input: [{
                id: "patientid",
                discovery: {
                    type: "jsonpath",
                    expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                    returnType: "single"
                }
            }
        ],
        config: {
            method: "GET",
            url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?status=active",
            headers: [{
                    key: "accept",
                    value: "application/json"
                }
            ]
        },
        returnpath: "$..consents[*].code",
        whenNoResult: eventPolicyId,
        cache: true
    },
    required: true,
    faultValue: missingConsent
};

var policyIdDSUB = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["DSUB"]
    },
    includeInResult: false,
    required: true
};

var typeCodeConsent = {
    id: XACML_PREFIX + "xacml:3.0:environment:type-code",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "jsonpath",
        expression: "$..tc",
        returnType: "single"
    },
    includeInResult: true,
    required: true,
    faultValue: customClientFault
};

var roleDSUB = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-role",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    discovery: {
        type: "jsonpath",
        expression: "$..['roles'][*]",
        returnType: "multiple",
        postProcessingAsUniqueValue: "true",
        postProcessing: "var ret = []; if ($out.length > 0) { for (var i = 0; i < $out.length; i++) { var role = $out[i].split('@'); if (role[role.length - 1]) { ret.push(role[role.length - 1]); } } } $out = ret;",
        postProcessingAsMappedValues: [{
                "source": {
                    "storedListKey": "X1V1_MEDICO_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_MEDICO"
                    ]
                }
            }, {
                "source": {
                    "storedListKey": "X1V1_MMG_Roles"
                },
                "target": {
                    "fixed": [
                        "X1V1_MMG"
                    ]
                }
            }
        ]
    },
    domain: {
        value: {
            storedListKey: "ALL_MAPPED_Notify_Roles"
        }
    },
    includeInResult: true,
    required: true,
    faultValue: _subjectRoleNotFound
};

var roleConsent = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-role",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    discovery: {
        type: "jsonpath",
        expression: "$..['roles'][0]",
        returnType: "single"
    },
    includeInResult: true,
    required: true,
    faultValue: customClientFault
};

var uniqueIdConsent = {
    id: XACML_PREFIX + "xacml:3.0:environment:uniqueId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "jsonpath",
        expression: "$..uId",
        returnType: "single"
    },
    includeInResult: true
};

var singleRequestConsent = {
    id: "singleRequest",
    discovery: {
        type: "jsonpath",
        expression: "$..['documents']",
        returnType: "multiple"
    }
};

var document = {
    id: "document",
    discovery: {
        type: "jsonpath",
        expression: "$.*",
        returnType: "multiple"
    }
};

var contextPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["context_policy"]
    },
    includeInResult: false,
    required: true,
    faultValue: _203
};

var registryPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["registry_policy"]
    },
    includeInResult: false,
    required: true,
    faultValue: _203
};

var fakeUniqueId = {
    id: XACML_PREFIX + "xacml:3.0:environment:uniqueId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["fake_uniqueid"]
    },
    includeInResult: true
};

var bundleObject = {
    id: "bundleObject",
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..bundle",
            returnType: "multiple"
        }
    },
    then: {
        discovery: {
            type: "jsonpath",
            expression: "$..bundle",
            returnType: "multiple"
        }
    },
    otherwise: {
        when: {
            discovery: {
                type: "jsonpath",
                expression: "$..entry",
                returnType: "multiple"
            }
        },
        then: {
            discovery: {
                type: "jsonpath",
                expression: "$..entry",
                returnType: "multiple"
            }
        },
        otherwise: {
            discovery: {
                type: "jsonpath",
                expression: "$..resource",
                returnType: "multiple"
            }
        }
    }
};

var codeCoding = {
    id: XACML_PREFIX + "xacml:3.0:environment:code-coding",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..code.coding.code._value",
            returnType: "single"
        }
    },
    then: {
        discovery: {
            type: "jsonpath",
            expression: "$..code.coding.code._value",
            postProcessing: "if($out.startsWith('R') && $out != 'RFANN') { $out = 'ESITO' } else if ($out == 'RFANN') { $out = 'TO_EXCLUDE' } else { $out = 'DIFFERENT_FROM_ESITO' }",
            returnType: "single"
        }
    },
    otherwise: {
        discovery: {
            type: "jsonpath",
            expression: "$..code.coding[*].code",
            postProcessing: "if($out.startsWith('R') && $out != 'RFANN') { $out = 'ESITO' } else if ($out == 'RFANN') { $out = 'TO_EXCLUDE' } else { $out = 'DIFFERENT_FROM_ESITO' }",
            returnType: "single"
        }
    },
    includeInResult: false,
    required: true,
    faultValue: _101
};

var outcome = {
    id: XACML_PREFIX + "xacml:3.0:environment:outcome-coding",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..outcome._value",
            returnType: "single"
        }
    },
    then: {
        discovery: {
            type: "jsonpath",
            expression: "$..outcome._value",
            postProcessing: "if($out == '1') { $out = 'NEGATIVE' } else { $out = 'POSITIVE' }",
            returnType: "single"
        }
    },
    otherwise: {
        discovery: {
            type: "jsonpath",
            expression: "$..outcome",
            postProcessing: "if($out == '1') { $out = 'NEGATIVE' } else { $out = 'POSITIVE' }",
            returnType: "single"
        }
    },
    includeInResult: false
};

var notEvaluated = {
    value: {
        fixed: ["NOT_EVALUATED"]
    }
};

var encounterConsent = {
    id: XACML_PREFIX + "xacml:3.0:environment:encounter-display",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..encounter.display",
            source: "groupBy",
            returnType: "single"
        }
    },
    then: {
        discovery: {
            type: "rest",
            input: [{
                    id: "patientid",
                    source: "groupBy",
                    when: {
                        discovery: {
                            type: "jsonpath",
                            source: "groupBy",
                            expression: "$..subject.reference._value",
                            returnType: "single"
                        }
                    },
                    then: {
                        discovery: {
                            type: "jsonpath",
                            source: "groupBy",
                            expression: "$..subject.reference._value",
                            returnType: "single",
                            postProcessing: "$out = $out.substring($out.indexOf('/') + 1)"
                        }
                    },
                    otherwise: {
                        discovery: {
                            type: "jsonpath",
                            source: "groupBy",
                            expression: "$..subject.reference",
                            returnType: "single",
                            postProcessing: "$out = $out.substring($out.indexOf('/') + 1)"
                        }
                    }
                }, {
                    id: "eventid",
                    source: "groupBy",
                    when: {
                        discovery: {
                            type: "jsonpath",
                            source: "groupBy",
                            expression: "$..encounter.display._value",
                            returnType: "single"
                        }
                    },
                    then: {
                        discovery: {
                            type: "jsonpath",
                            source: "groupBy",
                            expression: "$..encounter.display._value",
                            returnType: "single"
                        }
                    },
                    otherwise: {
                        when: {
                            discovery: {
                                type: "jsonpath",
                                source: "groupBy",
                                expression: "$..encounter.display",
                                returnType: "single"
                            }
                        },
                        then: {
                            discovery: {
                                type: "jsonpath",
                                source: "groupBy",
                                expression: "$..encounter.display",
                                returnType: "single"
                            }
                        }
                    }
                }
            ],
            config: {
                method: "GET",
                url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?eventid={eventid}&status=active",
                headers: [{
                        key: "accept",
                        value: "application/json"
                    }
                ]
            },
            returnpath: "$..consents[*].code",
            postProcessingAsUniqueValue: true,
            postProcessing: "if ($out.length > 1) {for(var index in $out) { if($out[index] == 'P21') {$out = 'P21'; break;}}} if($out != 'P21') { $out = 'NO_P21_CONSENT' };",
            whenNoResult: notEvaluated
        }
    },
    otherwise: notEvaluated,
    includeInResult: false
};

var encounterPerform = {
    id: XACML_PREFIX + "xacml:3.0:environment:encounter-performed",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..performedDateTime._value",
            returnType: "single"
        }
    },
    then: {
        discovery: {
            type: "jsonpath",
            expression: "$..performedDateTime._value",
            postProcessing: "var value = new Date($out).getTime(); var offset = new Date().getTime()-(45*24*60*60*1000); if(value >= offset) { $out='BEFORE_45_DAYS'; } else { $out='AFTER_45_DAYS'; }",
            returnType: "single"
        }
    },
    otherwise: {
        discovery: {
            type: "jsonpath",
            expression: "$..performedDateTime",
            postProcessing: "var value = new Date($out).getTime(); var offset = new Date().getTime()-(45*24*60*60*1000); if(value >= offset) { $out='BEFORE_45_DAYS'; } else { $out='AFTER_45_DAYS'; }",
            returnType: "single"
        }
    },
    includeInResult: false,
    required: true,
    faultValue: _206
};

var procedurePolicy = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["procedure"]
    }
};

var resourceId = {
    id: XACML_PREFIX + "xacml:3.0:environment:uniqueId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..id._value",
            returnType: "single"
        }
    },
    then: {
        discovery: {
            type: "jsonpath",
            expression: "$..id._value",
            returnType: "single"
        }
    },
    otherwise: {
        when: {
            discovery: {
                type: "jsonpath",
                expression: "$..content.id",
                returnType: "single"
            }
        },
        then: {
            discovery: {
                type: "jsonpath",
                expression: "$..content.id",
                returnType: "single"
            }
        },
        otherwise: {
            discovery: {
                type: "jsonpath",
                expression: "$..id",
                returnType: "single"
            }
        }
    },
    includeInResult: true,
    required: true,
    faultValue: _208
};

var creationPerform = {
    id: XACML_PREFIX + "xacml:3.0:environment:creation-performed",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "jsonpath",
        expression: "$..Slot[?(@._name=='creationTime')].ValueList.Value.#text",
        postProcessing: "var year = $out.substring(0,4); " +
        "var month = $out.substring(4,6); " +
        "var day = $out.substring(6,8); " +
        "var hours = $out.substring(8,10); " +
        "var minutes = $out.substring(10,12); " +
        "var seconds = $out.substring(12,14); " +
        "var time = year+'-'+month+'-'+day+'T'+hours+':'+minutes+':'+seconds; " +
        "var value = new Date(time).getTime(); " +
        "var offset = new Date().getTime()-(45*24*60*60*1000); " +
        "if(value >= offset) { $out='BEFORE_45_DAYS'; } else { $out='AFTER_45_DAYS'; }",
        returnType: "single"
    },
    includeInResult: false
};

var mdmRole = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-role",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    value: {
        fixed: ["MDM"]
    }
};

var tutorAttributes = {
    when: {
        discovery: documentPatientIdDiscovery
    },
    then: {
        discovery: tutorDiscovery
    }
};

var lhaHealthCareProviderAttributes = {
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
            returnType: "single"
        }
    },
    then: {
        discovery: lhaHealthCareProviderDiscovery
    }
};

var purposeOfUseDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.purposeOfUse",
    returnType: "single",
    cache: true
};

var actionDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.action",
    returnType: "single",
    cache: true
};

var userIdDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.userId",
    returnType: "single",
    cache: true
};

var userIdTaxCodeDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.userId",
    postProcessing: "if ($out !== null && $out !== '') { $out = $out.substring(0, $out.indexOf('^')) } else { $out = $out }",
    returnType: "single",
    cache: true
};

var userRoleDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.userRole",
    returnType: "single",
    whenNoResult: {
        discovery: samlSubjectDiscovery
    },
    cache: true
};

var userHospitalDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.userHospital",
    returnType: "single",
    cache: true
};

var userFacilityDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.userFacility",
    returnType: "single",
    cache: true
};

var userWardDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.userWard",
    returnType: "single",
    cache: true
};

var currentHospitalDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.currentHospital",
    returnType: "single",
    cache: true
};

var currentFacilityDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.currentFacility",
    returnType: "single",
    cache: true
};

var currentWardDiscoveryDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.currentWard",
    returnType: "single",
    cache: true
};

var bundleResourcesDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.bundle",
    returnType: "multiple",
    cache: true
};

var objectIdDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.objectId",
    returnType: "single"
};

var objectCreationDatetimeDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.objectDate",
    returnType: "single"
};

var patientIdDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$..patientId",
    returnType: "single"
};

var patientIdTaxCodeDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$..patientId",
    postProcessing: "if ($out !== null && $out !== '') { $out = $out.substring(0, $out.indexOf('^')) } else { $out = $out }",
    returnType: "single"
};

var lhaHealthCareProviderDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$..patientInfo.lhaHealthCareProviderId",
    returnType: "single"
};

var lhaHealthCareProviderTaxCodeDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$..patientInfo.lhaHealthCareProviderId",
    postProcessing: "if ($out !== null && $out !== '') { $out = $out.substring(0, $out.indexOf('^')) } else { $out = $out }",
    returnType: "single"
};

//tutorsIdDiscovery
var tutorsIdConsentEngineDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }
    ],
    config: getTutorByPatientConfig,
    returnpath: "$..tutors[*].tutorid",
    postProcessing: "$out = $out.substring(0, $out.indexOf('^'))",
    returnType: "multiple",
    cache: true
};

var tutorsIdDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$..patientInfo.tutorsId[*]",
    returnType: "multiple",
    whenNoResult: {
        discovery: tutorsIdConsentEngineDiscoveryPMAS
    }
};
//tutorsIdDiscovery

var tutorsIdTaxCodeDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$..patientInfo.tutorsId[*]",
    postProcessing: "if ($out !== null && $out !== '') { $out = $out.substring(0, $out.indexOf('^')) } else { $out = $out }",
    returnType: "multiple"
};

var hospitalizationCurrentlyDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.patientInfo.hospitalizationInfo.currentlyHospitalized",
    returnType: "single"
};

var hospitalizationPeriodStartDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.patientInfo.hospitalizationInfo.hospitalizationPeriod.startDate",
    returnType: "single"
};

var hospitalizationPeriodEndDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.patientInfo.hospitalizationInfo.hospitalizationPeriod.endDate",
    returnType: "single"
};

var eventIdDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.eventId",
    returnType: "single"
};

var documentIdDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.documentId",
    returnType: "single"
};

var authorIdDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.authorId",
    returnType: "single"
};

var authorIdTaxCodeDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.authorId",
    postProcessing: "if ($out !== null && $out !== '') { $out = $out.substring(0, $out.indexOf('^')) } else { $out = $out }",
    returnType: "single"
};

var objectHospitalDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.objectHospital",
    returnType: "single"
};

var objectFacilityDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.objectFacility",
    returnType: "single"
};

var objectWardDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.objectWard",
    returnType: "single"
};

var consentsDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.consents[*].code",
    returnType: "multiple"
};

//isConsentA1OnceGivenDiscoveryPMAS
var isConsentA1OnceGivenOnPatientDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "active",
            value: {
                fixed: ["false"]
            }
        }
    ],
    config: headConsentsByPatientCodeActiveConfig,
    returnpath: "$..consents[?(@.code=='A1')].code",
    returnType: "single",
    cache: true
};

var isConsentA1OnceGivenOnEventDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: eventIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "active",
            value: {
                fixed: ["false"]
            }
        }
    ],
    config: headConsentsByEventCodeActiveConfig,
    returnpath: "$..consents[?(@.code=='A1')].code",
    returnType: "single",
    cache: true
};

var isConsentA1OnceGivenOnDocumentDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "documentid",
            source: "groupBy",
            discovery: documentIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "active",
            value: {
                fixed: ["false"]
            }
        }
    ],
    config: headConsentsByDocumentCodeActiveConfig,
    returnpath: "$..consents[?(@.code=='A1')].code",
    returnType: "single",
    cache: true
};

var isConsentA1OnceGivenDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$..consents[?(@.code=='A1')].code",
    returnType: "single",
    whenNoResult: {
        when: {
            discovery: documentIdDiscoveryPMAS
        },
        then: {
            discovery: isConsentA1OnceGivenOnDocumentDiscoveryPMAS
        },
        otherwise: {
            when: {
                discovery: eventIdDiscoveryPMAS
            },
            then: {
                discovery: isConsentA1OnceGivenOnEventDiscoveryPMAS
            },
            otherwise: {
                discovery: isConsentA1OnceGivenOnPatientDiscoveryPMAS
            },
        }
    }
};
//isConsentA1OnceGivenDiscoveryPMAS

//startDateConsentDiscoveryPMAS
var consentA1StartOnPatientDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "status",
            value: {
                fixed: ["active"]
            }
        }
    ],
    config: getConsentsByPatientCodeStatusConfig,
    returnpath: "$..consents[?(@.code=='A1')].period.start",
    returnType: "single",
    cache: true
};

var consentA1StartOnEventDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: eventIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "status",
            value: {
                fixed: ["active"]
            }
        }
    ],
    config: getConsentsByEventCodeStatusConfig,
    returnpath: "$..consents[?(@.code=='A1')].period.start",
    returnType: "single",
    cache: true
};

var consentA1StartOnDocumentDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "documentid",
            source: "groupBy",
            discovery: documentIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "status",
            value: {
                fixed: ["active"]
            }
        }
    ],
    config: getConsentsByDocumentCodeStatusConfig,
    returnpath: "$..consents[?(@.code=='A1')].period.start",
    returnType: "single",
    cache: true
};

var consentP1StartOnPatientDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["P1"]
            }
        }, {
            id: "status",
            value: {
                fixed: ["active"]
            }
        }
    ],
    config: getConsentsByPatientCodeStatusConfig,
    returnpath: "$..consents[?(@.code=='P1')].period.start",
    returnType: "single",
    cache: true
};

var consentP1StartOnEventDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: eventIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["P1"]
            }
        }, {
            id: "status",
            value: {
                fixed: ["active"]
            }
        }
    ],
    config: getConsentsByEventCodeStatusConfig,
    returnpath: "$..consents[?(@.code=='P1')].period.start",
    returnType: "single",
    cache: true
};

var consentP1StartOnDocumentDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "documentid",
            source: "groupBy",
            discovery: documentIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["P1"]
            }
        }, {
            id: "statuc",
            value: {
                fixed: ["active"]
            }
        }
    ],
    config: getConsentsByDocumentCodeStatusConfig,
    returnpath: "$..consents[?(@.code=='P1')].period.start",
    returnType: "single",
    cache: true
};

var startDateA1ConsentDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$..consents[?(@.code=='A1')].period.start",
    returnType: "single"
};

var startDateConsentDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$..consents[?(@.code=='P1')].period.start",
    returnType: "single",
    whenNoResult: {
        when: {
            discovery: documentIdDiscoveryPMAS
        },
        then: {
            discovery: consentP1StartOnDocumentDiscoveryPMAS
        },
        otherwise: {
            when: {
                discovery: eventIdDiscoveryPMAS
            },
            then: {
                discovery: consentP1StartOnEventDiscoveryPMAS
            },
            otherwise: {
                when: {
                    discovery: consentP1StartOnPatientDiscoveryPMAS
                },
                then: {
                    discovery: consentP1StartOnPatientDiscoveryPMAS
                },
                otherwise: {
                    when: {
                        discovery: startDateA1ConsentDiscoveryPMAS
                    },
                    then: {
                        discovery: startDateA1ConsentDiscoveryPMAS
                    },
                    otherwise: {
                        when: {
                            discovery: documentIdDiscoveryPMAS
                        },
                        then: {
                            discovery: consentA1StartOnDocumentDiscoveryPMAS
                        },
                        otherwise: {
                            when: {
                                discovery: eventIdDiscoveryPMAS
                            },
                            then: {
                                discovery: consentA1StartOnEventDiscoveryPMAS
                            },
                            otherwise: {
                                discovery: consentA1StartOnPatientDiscoveryPMAS
                            }
                        }
                    }
                }
            }
        }
    }
};
//startDateConsentDiscoveryPMAS

//endDateConsentDiscoveryPMAS
var consentA1EndHistoricalOnPatientDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "active",
            value: {
                fixed: ["true"]
            }
        }, {
            id: "historical",
            value: {
                fixed: ["true"]
            }
        }
    ],
    config: getHistoricalConsentsByPatientCodeActiveConfig,
    returnpath: "$..consents[1].period.end",
    returnType: "single",
    cache: true
};

var consentA1EndHistoricalOnEventDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: eventIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "active",
            value: {
                fixed: ["true"]
            }
        }, {
            id: "historical",
            value: {
                fixed: ["true"]
            }
        }
    ],
    config: getHistoricalConsentsByEventCodeActiveConfig,
    returnpath: "$..consents[1].period.end",
    returnType: "single",
    cache: true
};

var consentA1EndHistoricalOnDocumentDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "documentid",
            source: "groupBy",
            discovery: documentIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "active",
            value: {
                fixed: ["true"]
            }
        }, {
            id: "historical",
            value: {
                fixed: ["true"]
            }
        }
    ],
    config: getHistoricalConsentsByDocumentCodeActiveConfig,
    returnpath: "$..consents[1].period.end",
    returnType: "single",
    cache: true
};

var consentA1EndOnPatientDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "status",
            value: {
                fixed: ["active"]
            }
        }
    ],
    config: getConsentsByPatientCodeStatusConfig,
    returnpath: "$..consents[?(@.code=='A1')].period.end",
    returnType: "single",
    cache: true
};

var consentA1EndOnEventDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: eventIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "status",
            value: {
                fixed: ["active"]
            }
        }
    ],
    config: getConsentsByEventCodeStatusConfig,
    returnpath: "$..consents[?(@.code=='A1')].period.end",
    returnType: "single",
    cache: true
};

var consentA1EndOnDocumentDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "documentid",
            source: "groupBy",
            discovery: documentIdDiscoveryPMAS
        }, {
            id: "consentcode",
            value: {
                fixed: ["A1"]
            }
        }, {
            id: "status",
            value: {
                fixed: ["active"]
            }
        }
    ],
    config: getConsentsByDocumentCodeStatusConfig,
    returnpath: "$..consents[?(@.code=='A1')].period.end",
    returnType: "single",
    cache: true
};

var endDateConsentDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$..consents[?(@.code=='A1')].period.end",
    returnType: "single",
    whenNoResult: {
        when: {
            discovery: documentIdDiscoveryPMAS
        },
        then: {
            discovery: consentA1EndOnDocumentDiscoveryPMAS
        },
        otherwise: {
            when: {
                discovery: eventIdDiscoveryPMAS
            },
            then: {
                discovery: consentA1EndOnEventDiscoveryPMAS
            },
            otherwise: {
                when: {
                    discovery: consentA1EndOnPatientDiscoveryPMAS
                },
                then: {
                    discovery: consentA1EndOnPatientDiscoveryPMAS
                },
                otherwise: {
                    when: {
                        discovery: documentIdDiscoveryPMAS
                    },
                    then: {
                        discovery: consentA1EndHistoricalOnDocumentDiscoveryPMAS
                    },
                    otherwise: {
                        when: {
                            discovery: eventIdDiscoveryPMAS
                        },
                        then: {
                            discovery: consentA1EndHistoricalOnEventDiscoveryPMAS
                        },
                        otherwise: {
                            discovery: consentA1EndHistoricalOnPatientDiscoveryPMAS
                        }
                    }
                }
            }
        }
    }
};
//endDateConsentDiscoveryPMAS

var creationPerformDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.objectDate",
    postProcessing: "if ($out !== null && $out !== '') { " +
    "var year = $out.substring(0,4); " +
    "var month = $out.substring(4,6); " +
    "var day = $out.substring(6,8); " +
    "var hours = $out.substring(8,10); " +
    "var minutes = $out.substring(10,12); " +
    "var seconds = $out.substring(12,14); " +
    "var time = year+'-'+month+'-'+day+'T'+hours+':'+minutes+':'+seconds; " +
    "var value = new Date(time).getTime(); " +
    "var offset = new Date().getTime()-(45*24*60*60*1000); " +
    "if(value >= offset) { $out='BEFORE_45_DAYS'; } else { $out='AFTER_45_DAYS'; } " +
    " } else { $out=''; }",
    returnType: "single"
};

var genericPolicyIdDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }
    ],
    config: getActiveConsentsByPatientConfig,
    returnpath: "$..consents[*].code",
    cache: true
};

var eventPolicyIdDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "eventid",
            source: "groupBy",
            discovery: eventIdDiscoveryPMAS
        }
    ],
    config: getActiveConsentsByEventConfig,
    returnpath: "$..consents[*].code",
    whenNoResult: {
        discovery: genericPolicyIdDiscoveryPMAS
    },
    cache: true
};

var documentPolicyIdDiscoveryPMAS = {
    type: "rest",
    input: [{
            id: "patientid",
            source: "groupBy",
            discovery: patientIdDiscoveryPMAS
        }, {
            id: "documentid",
            source: "groupBy",
            discovery: documentIdDiscoveryPMAS
        }
    ],
    config: getActiveConsentsByDocumentConfig,
    returnpath: "$..consents[*].code",
    whenNoResult: {
        when: {
            discovery: eventIdDiscoveryPMAS
        },
        then: {
            discovery: eventPolicyIdDiscoveryPMAS
        },
        otherwise: {
            discovery: genericPolicyIdDiscoveryPMAS
        },
    },
    cache: true
};

var policyIdDiscoveryPMAS = {
    type: "jsonpath",
    expression: "$.consents[*].code",
    returnType: "multiple",
    whenNoResult: {
        when: {
            discovery: documentIdDiscoveryPMAS
        },
        then: {
            discovery: documentPolicyIdDiscoveryPMAS
        },
        otherwise: {
            when: {
                discovery: eventIdDiscoveryPMAS
            },
            then: {
                discovery: eventPolicyIdDiscoveryPMAS
            },
            otherwise: {
                discovery: genericPolicyIdDiscoveryPMAS
            },
        }
    },
    unionResult: {
        value: {
            fixed: ["Ownership"]
        }
    }
};

var unauthorizedError = {
    faultCode: "unauthorizedError",
    faultMessage: [{
            lang: "it",
            message: "Operazione non permessa"
        }, {
            lang: "en",
            message: "Unauthorized operation"
        }
    ],
    faultDetail: ""
};

var _203_registry = {
    faultCode: "203",
    faultMessage: [{
            lang: "it",
            message: "i ruoli @ROLES@ non hanno permessi per eseguire operazioni anagrafiche"
        }, {
            lang: "en",
            message: "roles @ROLES@ have no permission to execute registry operation"
        }
    ],
    faultDetail: "",
    responseConfig: [{
            placeholder: "@ROLES@",
            attributes: role
        }
    ]
};
var restPolicy = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["rest_policy"]
    },
    includeInResult: false
};

var getHttpMethod = {
    id: "urn:oasis:names:tc:xacml:1.0:method:method-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:httpmethod",
    value: {
        fixed: ["GET"]
    },
    includeInResult: false
};

var postHttpMethod = {
    id: "urn:oasis:names:tc:xacml:1.0:method:method-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:httpmethod",
    value: {
        fixed: ["POST"]
    },
    includeInResult: false
};

var putHttpMethod = {
    id: "urn:oasis:names:tc:xacml:1.0:method:method-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:httpmethod",
    value: {
        fixed: ["PUT"]
    },
    includeInResult: false
};

var deleteHttpMethod = {
    id: "urn:oasis:names:tc:xacml:1.0:method:method-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:httpmethod",
    value: {
        fixed: ["DELETE"]
    },
    includeInResult: false
};

var headHttpMethod = {
    id: "urn:oasis:names:tc:xacml:1.0:method:method-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:httpmethod",
    value: {
        fixed: ["HEAD"]
    },
    includeInResult: false
};

var patchHttpMethod = {
    id: "urn:oasis:names:tc:xacml:1.0:method:method-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:httpmethod",
    value: {
        fixed: ["PATCH"]
    },
    includeInResult: false
};

var fakeDocument = {
    id: "fakeDocument",
    value: {
        fixed: ['{ "fakeDocument": "empty" }']
    }
};

var purposeOfUsePMAS = {
    id: XACML_PREFIX + "xacml:3.0:purposeofuse:purposeofuse-role",
    category: "urn:oasis:names:tc:xacml:1.0:purposeofuse-category:access-purposeofuse",
    discovery: purposeOfUseDiscoveryPMAS,
    source: "document",
    includeInResult: false
};

var actionPMAS = {
    id: "urn:oasis:names:tc:xacml:1.0:action:action-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:action",
    discovery: actionDiscoveryPMAS,
    source: "document",
    includeInResult: false
};

var userIdPMAS = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-id",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:subject",
    discovery: userIdDiscoveryPMAS,
    source: "document",
    includeInResult: false
};

var userIdTaxCodePMAS = {
    id: XACML_PREFIX + "xacml:3.0:subject:subjectTC",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:tc-subject",
    discovery: userIdTaxCodeDiscoveryPMAS,
    source: "document",
    includeInResult: false
};

var userRolePMAS = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-role",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    discovery: userRoleDiscoveryPMAS,
    source: "document",
    includeInResult: false,
    required: true,
    faultValue: _202
};

var userHospitalPMAS = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-hospital",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:hospital-subject",
    discovery: userHospitalDiscoveryPMAS,
    source: "document",
    includeInResult: false
};

var userFacilityPMAS = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-facility",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:facility-subject",
    discovery: userFacilityDiscoveryPMAS,
    source: "document",
    includeInResult: false
};

var userWardPMAS = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-ward",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:ward-subject",
    discovery: userWardDiscoveryPMAS,
    source: "document",
    includeInResult: false
};

var currentHospitalPMAS = {
    id: XACML_PREFIX + "xacml:3.0:application:application-hospital",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:hospital-application",
    discovery: currentHospitalDiscoveryPMAS,
    source: "document",
    includeInResult: false
};

var currentFacilityPMAS = {
    id: XACML_PREFIX + "xacml:3.0:application:application-facility",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:facility-application",
    discovery: currentFacilityDiscoveryPMAS,
    source: "document",
    includeInResult: false
};

var currentWardPMAS = {
    id: XACML_PREFIX + "xacml:3.0:application:application-ward",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:ward-application",
    discovery: currentWardDiscoveryDiscoveryPMAS,
    source: "document",
    includeInResult: false
};

var bundleResourcesPMAS = {
    id: "bundleResourcesPMAS",
    discovery: bundleResourcesDiscoveryPMAS
};

var typeCodePMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:type-code",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["PMAS"]
    }
};

var objectIdPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:uniqueId",
    category: ENVIRONMENT_XACML,
    discovery: objectIdDiscoveryPMAS,
    source: "groupBy",
    includeInResult: true,
    required: true,
    faultValue: _208
};

var objectCreationDatetimePMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:creation-date",
    category: ENVIRONMENT_XACML,
    type: "date",
    discovery: objectCreationDatetimeDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var patientIdPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:patientId",
    category: ENVIRONMENT_XACML,
    discovery: patientIdDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var eventIdPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:eventId",
    category: ENVIRONMENT_XACML,
    discovery: eventIdDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var documentIdPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:documentId",
    category: ENVIRONMENT_XACML,
    discovery: documentIdDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var patientLHAHealthCareProviderIdPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:patientLHAHealthCareProviderId",
    category: ENVIRONMENT_XACML,
    discovery: lhaHealthCareProviderDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var patientTutorsPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:patientTutors",
    category: ENVIRONMENT_XACML,
    discovery: tutorsIdDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var authorIdPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:author",
    category: ENVIRONMENT_XACML,
    discovery: authorIdDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var authorIdTaxCodePMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:authorTC",
    category: ENVIRONMENT_XACML,
    discovery: authorIdTaxCodeDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var objectHospitalPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:hospital",
    category: ENVIRONMENT_XACML,
    discovery: objectHospitalDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var objectFacilityPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:facility",
    category: ENVIRONMENT_XACML,
    discovery: objectFacilityDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var objectWardPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:ward",
    category: ENVIRONMENT_XACML,
    discovery: objectWardDiscoveryPMAS,
    source: "groupBy",
    includeInResult: false
};

var consentStartDatePMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:consent:startdate",
    category: ENVIRONMENT_XACML,
    type: "date",
    when: {
        discovery: isConsentA1OnceGivenDiscoveryPMAS
    },
    then: {
        discovery: startDateConsentDiscoveryPMAS
    },
    otherwise: emptyValueAttributes,
    source: "groupBy",
    includeInResult: false
};

var consentEndDatePMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:consent:enddate",
    category: ENVIRONMENT_XACML,
    type: "date",
    when: {
        discovery: isConsentA1OnceGivenDiscoveryPMAS
    },
    then: {
        discovery: endDateConsentDiscoveryPMAS
    },
    otherwise: emptyValueAttributes,
    source: "groupBy",
    includeInResult: false
};

var creationPerformPMAS = {
    id: XACML_PREFIX + "xacml:3.0:environment:creation-performed",
    category: ENVIRONMENT_XACML,
    when: {
        discovery: objectCreationDatetimeDiscoveryPMAS
    },
    then: {
        discovery: creationPerformDiscoveryPMAS
    },
    otherwise: emptyValueAttributes,
    source: "groupBy",
    includeInResult: false
};

var policyIdPMAS = {
    id: ID_ATTRIBUTO_POLICY,
    category: ENVIRONMENT_XACML,
    discovery: policyIdDiscoveryPMAS,
    source: "groupBy",
    includeInResult: true,
    required: true,
    faultValue: missingConsent
};

var iniRoleAttribute = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-role",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    discovery: {
        type: "mc",
        key: "urn:oasis:names:tc:xacml:2.0:subject:role"
    },
    includeInResult: true,
    required: true,
    faultValue: _203
};

var iniPurposeofuseAttribute = {
    id: XACML_PREFIX + "oasis:names:tc:xspa:1.0:subject:purposeofuse",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:purposeofuse",
    discovery: {
        type: "mc",
        key: "urn:oasis:names:tc:xspa:1.0:subject:purposeofuse"
    },
    includeInResult: true,
    required: true,
    faultValue: _203
};

var iniActionAttribute = {
    id: XACML_PREFIX + "oasis:names:tc:xacml:1.0:action:action-id",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:action",
    discovery: {
        type: "mc",
        key: "urn:oasis:names:tc:xacml:1.0:action:action-id",
        postProcessing: "if($out == 'CREATE') { $out = 'C'} else if($out == 'READ') { $out = 'R'} else if($out == 'UPDATE') { $out = 'U'} else if($out == 'DELETE') { $out = 'D'}"
    },
    includeInResult: true,
    required: true,
    faultValue: _203
};

var iniConsentAttribute = {
    id: XACML_PREFIX + "oasis:names:tc:xspa:1.0:resource:patient:consent",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:consent",
    discovery: {
        type: "mc",
        key: "urn:oasis:names:tc:xspa:1.0:resource:patient:consent",
        whenNoResult: {
            value: {
                fixed: ["false"]
            }
        }
    },
    includeInResult: true,
    required: false,
    faultValue: _203
};

var roleDiscovery = {
    type: "mc",
    key: "eu.dedalus.xvalue.policyengine.common.subjectRole"
};

var role_ini = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-role",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    discovery: roleDiscovery,
    domain: {
        value: {
            fixed: ["AAS", "APR", "PSS", "INF", "FAR", "DSA", "DAM", "OAM", "ASS",
                "TUT", "ING", "GEN", "NOR", "DRS", "RSA", "MRP", "INI", "OGC", "OPI"]
        }
    },
    includeInResult: true,
    required: true,
    faultValue: _202
};

var objectRefId = {
    id: XACML_PREFIX + "xacml:3.0:environment:uniqueId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "jsonpath",
        expression: "$..ObjectRef._id",
        returnType: "single"
    },
    includeInResult: true
};

var objectRef = {
    id: "objectRef",
    discovery: {
        type: "jsonpath",
        expression: "$..ObjectRef",
        returnType: "multiple"
    }
};

var iniDefaultPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["ini_default_policy"]
    },
    includeInResult: false,
    required: true,
    faultValue: _203
};

var iniDeletePolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["cancella_metadati"]
    },
    includeInResult: false,
    required: true,
    faultValue: _203
};

var iniMetadataUpdatePolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["comunica_aggiorna_metadati"]
    },
    includeInResult: false,
    required: true,
    faultValue: _203
};

var iniRetrieveDocPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["recupero_documento"]
    },
    includeInResult: false,
    required: true,
    faultValue: _203
};

var iniRetrieveReferenceDocPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["recupero_riferimento_doc"]
    },
    includeInResult: false,
    required: true,
    faultValue: _203
};

var iniSearchDocumentPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["ricerca_documenti"]
    },
    includeInResult: false,
    required: true,
    faultValue: _203
};

var iniMoveIndexPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: ["trasferimento_indice"]
    },
    includeInResult: false,
    required: true,
    faultValue: _203
};

var actionValidatorDiscovery = {
    id: "actionValidatorDiscovery",
    discovery: {
        type: "jsonpath",
        expression: "$..Header.Action.#text",
        returnType: "single"
    },
    domain: {
        value: {
            fixed: ["urn:ihe:iti:2007:ProvideAndRegisterDocumentSet-b", "urn:ihe:iti:2007:RegistryStoredQuery", "urn:ihe:iti:2007:RetrieveDocumentSet", "urn:ihe:iti:2007:RegisterDocumentSet-b", "urn:ihe:iti:2010:DeleteDocumentSet"]
        }
    },
    includeInResult: false,
    required: true,
    faultValue: _102
};

//policyIdAdhoc_INI
var genericPolicyIdAdhoc_INI = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "rest",
        input: [{
                id: "patientid",
                discovery: {
                    type: "jsonpath",
                    expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                    returnType: "single"
                }
            }
        ],
        config: {
            method: "GET",
            url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?status=active",
            headers: [{
                    key: "accept",
                    value: "application/json"
                }
            ]
        },
        returnpath: "$..consents[*].code",
        unionResult: iniDefaultPolicyId,
        cache: true
    }
};

var eventPolicyIdAdhoc_INI = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    when: {
        discovery: {
            type: "jsonpath",
            expression: "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
            returnType: "multiple"
        }
    },
    then: {
        discovery: {
            type: "rest",
            input: [{
                    id: "patientid",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        returnType: "single"
                    }
                }, {
                    id: "eventid",
                    source: "groupBy",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..Slot[?(@._name == 'urn:ihe:iti:xds:2013:referenceIdList')].ValueList.Value.#text",
                        returnType: "single"
                    }
                }
            ],
            config: {
                method: "GET",
                url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?eventid={eventid}&status=active",
                headers: [{
                        key: "accept",
                        value: "application/json"
                    }
                ]
            },
            returnpath: "$..consents[*].code",
            whenNoResult: genericPolicyIdAdhoc_INI,
            cache: true
        }
    },
    otherwise: genericPolicyIdAdhoc_INI
};

var policyIdAdhoc_INI = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    includeInResult: true,
    when: {
        discovery: {
            type: "rest",
            input: [{
                    id: "patientid",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        returnType: "single"
                    }
                }, {
                    id: "documentid",
                    source: "groupBy",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
                        returnType: "single"
                    }
                }
            ],
            config: {
                method: "GET",
                url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?documentid={documentid}&status=active",
                headers: [{
                        key: "accept",
                        value: "application/json"
                    }
                ]
            },
            returnpath: "$..consents[*].code",
            cache: true
        }
    },
    then: {
        discovery: {
            type: "rest",
            input: [{
                    id: "patientid",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        returnType: "single"
                    }
                }, {
                    id: "documentid",
                    source: "groupBy",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
                        returnType: "single"
                    }
                }
            ],
            config: {
                method: "GET",
                url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?documentid={documentid}&status=active",
                headers: [{
                        key: "accept",
                        value: "application/json"
                    }
                ]
            },
            returnpath: "$..consents[*].code",
            whenNoResult: eventPolicyIdAdhoc_INI,
            cache: true
        }
    },
    otherwise: {
        discovery: {
            type: "rest",
            input: [{
                    id: "patientid",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..*[?(@._identificationScheme == 'urn:uuid:58a6f841-87b3-4a3e-92fd-a8ffeff98427')]._value",
                        returnType: "single"
                    }
                }, {
                    id: "documentid",
                    source: "groupBy",
                    discovery: {
                        type: "jsonpath",
                        expression: "$..ExternalIdentifier[?(@._identificationScheme == 'urn:uuid:2e82c1f6-a085-4c72-9da3-8640a32e42ab')]._value",
                        returnType: "single"
                    }
                }
            ],
            config: {
                method: "GET",
                url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?documentid={documentid}&status=active",
                headers: [{
                        key: "accept",
                        value: "application/json"
                    }
                ]
            },
            returnpath: "$..consents[*].code",
            whenNoResult: eventPolicyIdAdhoc_INI,
            cache: true
        }
    },
    required: true,
    faultValue: missingConsent
};

var userRoles = {
    id: XACML_PREFIX + "xacml:3.0:subject:subject-role",
    category: "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    discovery: {
        type: "jsonpath",
        expression: "$..userRoles",
        returnType: "single",
        whenNoResult: {
            discovery: {
                type: "mc",
                key: "eu.dedalus.xvalue.policyengine.common.subjectRole",
                postProcessing: "var values = $out.split('@'); if (values.length > 1) { var role = values[values.length - 1]; $out = [role]; } else { $out = $out; };"
            }
        }
    },
    required: true,
    faultValue: _202
};

var resourceType = {
    id: XACML_PREFIX + "xacml:3.0:environment:resourceType",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "jsonpath",
        expression: "$..resourceType",
        returnType: "single"
    },
    includeInResult: true,
    required: true,
    faultValue: _101
};

var resourceUniqueId = {
    id: XACML_PREFIX + "xacml:3.0:environment:uniqueId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery: {
        type: "jsonpath",
        expression: "$.id",
        returnType: "single"
    },
    includeInResult: true,
    required: true,
    faultValue: _208
};

var customBundlePolicy = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    includeInResult: true,
    discovery: {
        type: "rest",
        input: [{
                id: "patientid",
                when: {
                    discovery: {
                        type: "jsonpath",
                        expression: "$..patient.reference",
                        returnType: "single"
                    }
                },
                then: {
                    discovery: {
                        type: "jsonpath",
                        expression: "$..patient.reference",
                        postProcessing: "$out.substring($out.indexOf('/', 0) + 1, $out.length)",
                        returnType: "single"
                    }
                },
                otherwise: {
                    when: {
                        discovery: {
                            type: "jsonpath",
                            expression: "$..subject.reference",
                            returnType: "single"
                        }
                    },
                    then: {
                        discovery: {
                            type: "jsonpath",
                            expression: "$..subject.reference",
                            postProcessing: "$out.substring($out.indexOf('/', 0) + 1, $out.length)",
                            returnType: "single"
                        }
                    },
                    otherwise: {
                        when: {
                            discovery: {
                                type: "jsonpath",
                                expression: "$..participant[*].actor[?(@.reference =~ /PATIENT.*/i)].reference",
                                returnType: "single"
                            }
                        },
                        then: {
                            discovery: {
                                type: "jsonpath",
                                expression: "$..participant[*].actor[?(@.reference =~ /PATIENT.*/i)].reference",
                                postProcessing: "$out.substring($out.indexOf('/', 0) + 1, $out.length)",
                                returnType: "single"
                            }
                        },
                        otherwise: {
                            discovery: {
                                type: "jsonpath",
                                expression: "$..patientId",
                                postProcessing: "$out.substring($out.indexOf('/', 0) + 1, $out.length)",
                                returnType: "single"
                            }
                        }
                    }
                }
            }
        ],
        config: {
            method: "GET",
            url: "http://@consent@@domain.internal.xds@/consent-engine/consent/100/{patientid}?status=active",
            headers: [{
                    key: "accept",
                    value: "application/json"
                }
            ]
        },
        returnpath: "$..consents[*].code",
        cache: true
    },
    required: false
};


var agMatrixJSONRole = {
    id : XACML_PREFIX + "xacml:3.0:subject:subject-role",
    category : "urn:oasis:names:tc:xacml:1.0:subject-category:access-subject",
    discovery : {
        type : "jsonpath",
        expression : "$..['roles'][0]",
        returnType : "multiple"
    },
    includeInResult : true,
    required : true,
    faultValue: _202
};


var agMatrixJSONDocument = {
    id : "agMatrixJSONDocument",
    discovery : {
        type : "jsonpath",
        expression : "$..['documents']",
        returnType : "multiple"
    }
};

var agMatrixPolicyId = {
    id: XACML_PREFIX + "xacml:3.0:policy:policyId",
    category: "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    value: {
        fixed: [ "ag_matrix" ]
    },
    includeInResult: false,
    required: true,
    faultValue: _203
};

var agMatrixJSONUniqueId = {
    id : XACML_PREFIX + "xacml:3.0:environment:uniqueId",
    category : "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery : {
        type : "jsonpath",
        expression : "$..uId",
        returnType : "single"
    },
    includeInResult : true
};

var agMatrixJSONTypeCode = {
    id : XACML_PREFIX + "xacml:3.0:environment:type-code",
    category : "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery : {
        type : "jsonpath",
        expression : "$..tc",
        returnType : "single"
    },
    domain: {
        discovery: {
            type: "jsonpath",
            source: "ad",
            expression: "$..CodeType[?(@._classScheme == 'urn:uuid:f0306f51-975f-434e-a61c-c59651d33983')].Code[*]._code",
            returnType: "multiple"
        }
    },
    includeInResult : true,
    required : true,
    faultValue : _101
};

var agMatrixJSONConfidentiality = {
    id : XACML_PREFIX + "xacml:3.0:environment:confidentiality",
    category : "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    discovery : {
        type : "jsonpath",
        expression : "$..c",
        returnType : "single"
    },
    domain: {
        discovery: {
            type: "jsonpath",
            source: "ad",
            expression: "$..CodeType[?(@._classScheme == 'urn:uuid:f4f85eac-e6cb-4883-b524-f2705394840f')].Code[*]._code",
            returnType: "multiple"
        }
    },
    includeInResult : true,
    required : true,
    faultValue : _203
};


var multitenancyCheckUserIntegrity = {
    "id": "urn:xacml:3.0:environment:multitenancyCheckUserIntegrity",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInResult": false,
    "required": false,
    "discovery": {
        "type": "jsonpath",
        "expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:61b7d1b2-0a95-11ee-be56-0242ac120001')]._nodeRepresentation",
        "returnType": "multiple",
		"messageContextCacheKey": "eu.dedalus.xvalue.policyengine.common.MultitenancySubmission",
        "whenNoResult": {
            "value": {
                "fixed": [
                    "NO_MULTITENANCYORGANISATIONCODES"
                ]
            }
        }
    },
    "domain": {
        "discovery": {
            "type": "mc",
			"key": "eu.dedalus.xvalue.policyengine.common.multitenancy.organisationCodes",
            "returnType": "multiple"
        }
    },
    "faultValue" : {
		"faultCode": "multitenancyUserIntegrityError",
		"faultMessage": [{
				"lang": "en",
				"message": "Unable to process the request: multitenancyUserIntegrityError"
			}
		],
		"faultDetail": ""
	}
};

var checkMultitenancyRequestIntegritySource = {
    "id": "urn:xacml:3.0:environment:checkMultitenancyRequestIntegritySource",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInResult": true,
    "required": true,
    "when": checkUniqueIdInExtrinsicObject,
    "then": {
		"includeInResult": false,
		"required": false,
		"discovery": {
			"type": "jsonpath",
			"expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:61b7d1b2-0a95-11ee-be56-0242ac120002')]._nodeRepresentation",
			"returnType": "multiple",
			"whenNoResult": {
				"value": {
					"fixed": [
						"NO_MULTITENANCYORGANISATIONCODES"
					]
				}
			}
		},
		"domain": {
			"discovery": {
				"type": "mc",
				"key": "eu.dedalus.xvalue.policyengine.common.MultitenancySubmission",
				"returnType": "multiple"
			}
		},
		"faultValue" : {
			"faultCode": "multitenancyRequestIntegrityError",
			"faultMessage": [{
					"lang": "en",
					"message": "Unable to process the request: multitenancyRequestIntegrityError Source ExtrinsicObject Organisations"
				}
			],
			"faultDetail": ""
		}
	},
    "otherwise": {
        "when": checkUniqueIdInSumbissionSet,
        "then": {
			"value": {
                "fixed": ["SUBMISSION_ALREADY_CHECKED"]
            },
            "includeInResult": false,
            "required": false
		},
        "otherwise": {
			"includeInResult": false,
			"required": false,
			"discovery": {
				"type": "jsonpath",
				"expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:61b7d1b2-0a95-11ee-be56-0242ac120003')]._nodeRepresentation",
				"returnType": "multiple",
				"whenNoResult": {
					"value": {
						"fixed": [
							"NO_MULTITENANCYORGANISATIONCODES"
						]
					}
				}
			},
			"domain": {
				"discovery": {
					"type": "mc",
					"key": "eu.dedalus.xvalue.policyengine.common.MultitenancySubmission",
					"returnType": "multiple"
				}
			},
			"faultValue" : {
				"faultCode": "multitenancyRequestIntegrityError",
				"faultMessage": [{
						"lang": "en",
						"message": "Unable to process the request: multitenancyRequestIntegrityError Source Folder Organisations"
					}
				],
				"faultDetail": ""
			}
		}
	},
    "faultValue" : {
		"faultCode": "multitenancyRequestIntegrityError",
		"faultMessage": [{
				"lang": "en",
				"message": "Unable to process the request: multitenancyRequestIntegrityError Source"
			}
		],
		"faultDetail": ""
	}
};

var checkMultitenancyRequestIntegrityTarget = {
    "id": "urn:xacml:3.0:environment:checkMultitenancyRequestIntegrityTarget",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInResult": true,
    "required": true,
    "when": checkUniqueIdInExtrinsicObject,
    "then": {
		"includeInResult": false,
		"required": false,
		"discovery": {
			"type": "mc",
			"key": "eu.dedalus.xvalue.policyengine.common.MultitenancySubmission",
			"returnType": "multiple",
			"whenNoResult": {
				"value": {
					"fixed": [
						"NO_MULTITENANCYORGANISATIONCODES"
					]
				}
			}
		},
		"domain": {
			"discovery": {
				"type": "jsonpath",
				"expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:61b7d1b2-0a95-11ee-be56-0242ac120002')]._nodeRepresentation",
				"returnType": "multiple"
			}
		},
		"faultValue" : {
			"faultCode": "multitenancyRequestIntegrityError",
			"faultMessage": [{
					"lang": "en",
					"message": "Unable to process the request: multitenancyRequestIntegrityError Target ExtrinsicObject Organisations"
				}
			],
			"faultDetail": ""
		}
	},
    "otherwise": {
        "when": checkUniqueIdInSumbissionSet,
        "then": {
			"value": {
                "fixed": ["SUBMISSION_ALREADY_CHECKED"]
            },
            "includeInResult": false,
            "required": false
		},
        "otherwise": {
			"includeInResult": false,
			"required": false,
			"discovery": {
				"type": "mc",
				"key": "eu.dedalus.xvalue.policyengine.common.MultitenancySubmission",
				"returnType": "multiple",
				"whenNoResult": {
					"value": {
						"fixed": [
							"NO_MULTITENANCYORGANISATIONCODES"
						]
					}
				}
			},
			"domain": {
				"discovery": {
					"type": "jsonpath",
					"expression": "$..Classification[?(@._classificationScheme == 'urn:uuid:61b7d1b2-0a95-11ee-be56-0242ac120003')]._nodeRepresentation",
					"returnType": "multiple"
				}
			},
			"faultValue" : {
				"faultCode": "multitenancyRequestIntegrityError",
				"faultMessage": [{
						"lang": "en",
						"message": "Unable to process the request: multitenancyRequestIntegrityError Target Folder Organisations"
					}
				],
				"faultDetail": ""
			}
		}
	},
    "faultValue" : {
		"faultCode": "multitenancyRequestIntegrityError",
		"faultMessage": [{
				"lang": "en",
				"message": "Unable to process the request: multitenancyRequestIntegrityError Target"
			}
		],
		"faultDetail": ""
	}
};

var multitenancyCheckCustomSlotIntegrity = {
    "id": "urn:xacml:3.0:environment:multitenancyCheckCustomSlotIntegrity",
    "category": "urn:oasis:names:tc:xacml:3.0:attribute-category:environment",
    "includeInResult": true,
    "required": true,
    "when": {		
		"discovery": {
			"type": "jsonpath",
			"expression": "$..Slot[?(@._name == '$XDSDocumentEntryOrganization')].ValueList.Value.#text",
			"returnType": "multiple"
		}
	},
    "then": {
		"includeInResult": false,
		"required": false,	
		"discovery": {
			"type": "jsonpath",
			"expression": "$..Slot[?(@._name == '$XDSDocumentEntryOrganization')].ValueList.Value.#text",
			"returnType": "multiple",
			"postProcessing": "var ret=[]; if($out.length>0){ for(var i=0;i<$out.length;i++){ var cleanedValue = $out[i].replaceAll('\\)','').replaceAll('\\(','').replaceAll('\\'','').replaceAll('\"',''); var splittedValues = cleanedValue.split(','); for(var j=0;j<splittedValues.length;j++){ var splittedValue = splittedValues[j]; if (splittedValue.indexOf('^') > 0) { splittedValue = splittedValue.substring(0, splittedValue.indexOf('^')); } ret.push(splittedValue); } } $out=ret }"
		},
		"domain": {
			"discovery": {
				"type": "mc",
				"key": "eu.dedalus.xvalue.policyengine.common.multitenancy.organisationCodes",
				"returnType": "multiple"
			}
		},
		"faultValue" : {
			"faultCode": "multitenancyCheckCustomSlotIntegrity",
			"faultMessage": [{
					"lang": "en",
					"message": "Unable to process the request: multitenancyCheckCustomSlotIntegrity ExtrinsicObject Organisations"
				}
			],
			"faultDetail": ""
		}
	},
    "otherwise": {
        "when": {		
			"discovery": {
				"type": "jsonpath",
				"expression": "$..Slot[?(@._name == '$XDSSubmissionSetOrganization')].ValueList.Value.#text",
				"returnType": "multiple"
			}
		},
		"then": {
			"includeInResult": false,
			"required": false,	
			"discovery": {
				"type": "jsonpath",
				"expression": "$..Slot[?(@._name == '$XDSSubmissionSetOrganization')].ValueList.Value.#text",
				"returnType": "multiple",
				"postProcessing": "var ret=[]; if($out.length>0){ for(var i=0;i<$out.length;i++){ var cleanedValue = $out[i].replaceAll('\\)','').replaceAll('\\(','').replaceAll('\\'','').replaceAll('\"',''); var splittedValues = cleanedValue.split(','); for(var j=0;j<splittedValues.length;j++){ var splittedValue = splittedValues[j]; if (splittedValue.indexOf('^') > 0) { splittedValue = splittedValue.substring(0, splittedValue.indexOf('^')); } ret.push(splittedValue); } } $out=ret }"
			},
			"domain": {
				"discovery": {
					"type": "mc",
					"key": "eu.dedalus.xvalue.policyengine.common.multitenancy.organisationCodes",
					"returnType": "multiple"
				}
			},
			"faultValue" : {
				"faultCode": "multitenancyCheckCustomSlotIntegrity",
				"faultMessage": [{
						"lang": "en",
						"message": "Unable to process the request: multitenancyCheckCustomSlotIntegrity SubmissionSet Organisations"
					}
				],
				"faultDetail": ""
			}
		},
        "otherwise": {
			"when": {		
				"discovery": {
					"type": "jsonpath",
					"expression": "$..Slot[?(@._name == '$XDSFolderOrganization')].ValueList.Value.#text",
					"returnType": "multiple"
				}
			},
			"then": {
				"includeInResult": false,
				"required": false,	
				"discovery": {
					"type": "jsonpath",
					"expression": "$..Slot[?(@._name == '$XDSFolderOrganization')].ValueList.Value.#text",
					"returnType": "multiple",
					"postProcessing": "var ret=[]; if($out.length>0){ for(var i=0;i<$out.length;i++){ var cleanedValue = $out[i].replaceAll('\\)','').replaceAll('\\(','').replaceAll('\\'','').replaceAll('\"',''); var splittedValues = cleanedValue.split(','); for(var j=0;j<splittedValues.length;j++){ var splittedValue = splittedValues[j]; if (splittedValue.indexOf('^') > 0) { splittedValue = splittedValue.substring(0, splittedValue.indexOf('^')); } ret.push(splittedValue); } } $out=ret }"
				},
				"domain": {
					"discovery": {
						"type": "mc",
						"key": "eu.dedalus.xvalue.policyengine.common.multitenancy.organisationCodes",
						"returnType": "multiple"
					}
				},
				"faultValue" : {
					"faultCode": "multitenancyCheckCustomSlotIntegrity",
					"faultMessage": [{
							"lang": "en",
							"message": "Unable to process the request: multitenancyCheckCustomSlotIntegrity Folder Organisations"
						}
					],
					"faultDetail": ""
				}
			},
			"otherwise": {
				"value": {
					"fixed": [
						"NO_MULTITENANCYCUSTOMSLOTS"
					]
				}
			}
		}
	},
    "faultValue" : {
		"faultCode": "multitenancyCheckCustomSlotIntegrity",
		"faultMessage": [{
				"lang": "en",
				"message": "Unable to process the request: multitenancyCheckCustomSlotIntegrity"
			}
		],
		"faultDetail": ""
	}
};