var NEW_AdhocQueryRequest_ResponseHandler = {
    "when": "AdhocQueryRequest",
    faultValue: _205,
    "implementationClazzes": [
        "eu.dedalus.xvalue.policyengine.pep.handler.AdhocQueryRequestDefaultResponseHandler"
    ]
};

var NEW_AdhocQueryResponse_ResponseHandler = {
    "when": "AdhocQueryResponse",
    faultValue: _205,
    "implementationClazzes": [
        "eu.dedalus.xvalue.policyengine.pep.handler.AdhocQueryResponseDefaultResponseHandler",
        "eu.dedalus.xvalue.policyengine.pep.handler.ReferenceIdListHandler"
    ]
};

var NEW_RetrieveDocumentSetResponse_ResponseHandler = {
    "when": "RetrieveDocumentSetResponse",
    faultValue: _205,
    "implementationClazzes": [
        "eu.dedalus.xvalue.policyengine.pep.handler.RetrieveDocumentSetResponseDefaultResponseHandler"
    ]
};

var ProxyTestParamHandler_ResponseHandler = {
    when: "/policy-engine-web/proxy/test/paramHandler",
    faultValue: _205,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.ProxyTestParam"]
};

var DSUB_AgMatrix_ResponseHandler = {
    when: "agmatrix_dsub",
    faultValue: _203,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.web.pep.responsehandler.AgMatrixResponseHandler"]
};

var DSUB_Consent_ResponseHandler = {
    when: "consent_dsub",
    faultValue: _203,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.web.pep.responsehandler.ConsentResponseHandler"]
};

var CONSENT_BASE_1_ResponseHandler = {
    when: "*://*/proxy/ce_base/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_BASE_2_ResponseHandler = {
    when: "*://*/proxy/ce_base/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_BASE_3_ResponseHandler = {
    when: "*://*/proxy/ce_base/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_BASE_4_ResponseHandler = {
    when: "*://*/proxy/ce_base/*/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_BASE_5_ResponseHandler = {
    when: "*://*/proxy/ce_base/*/*/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_BASE_6_ResponseHandler = {
    when: "*://*/proxy/ce_base/*/*/*/*/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_000_PATIENT_DOCUMNET_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_000_PATIENT_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_100_APP_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/*/100",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_100_APP_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/*/100/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_100_APP_TWO_PARAMS_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/*/100/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_100_APP_RESET_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/*/100/reset",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_100_APP_RESET_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/*/100/reset/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_100_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/100",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_100_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/100/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_100_TWO_PARAMS_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/100/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_100_RESET_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/100/reset",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_100_PARAM_RESET_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/100/reset/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_BUNDLE_ResponseHandler = {
    when: "*://*/proxy/pmce_consents/100/bundle/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_BUNDLECONSENT_ResponseHandler = {
    when: "*://*/proxy/pmce_bundleconsent/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var PDF_BUNDLE_ResponseHandler = {
    when: "*://*/proxy/pmce_bundlepdf",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var PDF_BUNDLE_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_bundlepdf/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var TUTOR_ROLLBACK_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_tutors_rollback/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var TUTOR_ROLLBACK_ResponseHandler = {
    when: "*://*/proxy/pmce_tutors_rollback",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var TUTOR_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_tutors/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var TUTOR_ResponseHandler = {
    when: "*://*/proxy/pmce_tutors",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var TUTOR_TWO_PARAMS_ResponseHandler = {
    when: "*://*/proxy/pmce_tutors/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var PATIENT_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_patients/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var PATIENT_ResponseHandler = {
    when: "*://*/proxy/pmce_patients",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MESSAGE_PATIENT_ResponseHandler = {
    when: "*://*/proxy/pmce_messagepatients",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MESSAGE_PATIENT_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_messagepatients/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MESSAGE_PATIENT_TWO_PARAMS_ResponseHandler = {
    when: "*://*/proxy/pmce_messagepatients/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MESSAGE_PATIENT_ANY_PARAMS_ResponseHandler = {
    when: "*://*/proxy/pmce_messagepatients/any/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MESSAGE_ResponseHandler = {
    when: "*://*/proxy/pmce_messages",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MESSAGE_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_messages/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MESSAGE_PATIENT_PATIENT_CODE_ResponseHandler = {
    when: "*://*/proxy/pmce_messages/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENTCOLLECTOR_ResponseHandler = {
    when: "*://*/proxy/pmce_consentcollector",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENTCOLLECTOR_HISTORY_ResponseHandler = {
    when: "*://*/proxy/pmce_consentcollector/history/100",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENTCOLLECTOR_HISTORY_COUNT_ResponseHandler = {
    when: "*://*/proxy/pmce_consentcollector/history/100/count",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MODEL_REGISTRY_ResponseHandler = {
    when: "*://*/proxy/pmce_registrymodel/",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MODEL_REGISTRY_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_registrymodel/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var INFORMATION_REGISTRY_ResponseHandler = {
    when: "*://*/proxy/pmce_registryinformation/",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var INFORMATION_REGISTRY_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_registryinformation/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_REGISTRY_ResponseHandler = {
    when: "*://*/proxy/pmce_registryconsent/",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENT_REGISTRY_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_registryconsent/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var GRAPHOMETRIC_ResponseHandler = {
    when: "*://*/proxy/pmce_graphometric/",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var GRAPHOMETRIC_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_graphometric/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var CONFIGURATIONBYKEY_ResponseHandler = {
    when: "*://*/proxy/pmce_configurationbykey/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENTCOLLECTOR_STANDALONE_ResponseHandler = {
    when: "*://*/proxy/pmce_consentcollector_standalone",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENTCOLLECTOR_PATIENTS_BUNDLES_ResponseHandler = {
    when: "*://*/proxy/pmce_consentcollector_patients_bundles",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var TUTORONLY_PARAM_ResponseHandler = {
    when: "*://*/proxy/pmce_tutors_onlytutor",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var CONSENTCOLLECTOR_EXTERNALCONSENTMANAGER_ResponseHandler = {
    when: "*://*/proxy/pmce_consentcollector_externalconsentmanager",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var FHIR_CLINICAL_RESOURCE_1_ResponseHandler = {
    when: "*://*/*/fhir_clinical/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var FHIR_CLINICAL_RESOURCE_2_ResponseHandler = {
    when: "*://*/*/fhir_clinical/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var FHIR_CLINICAL_RESOURCE_3_ResponseHandler = {
    when: "*://*/*/fhir_clinical/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MCI_SERVICE_ResponseHandler = {
    when: "*://*/*/mci_service/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var FHIR_1_6_0_CLINICAL_ResponseHandler = {
    when: "*://*/*/fhir_clinical_1_6_0/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var FHIR_1_6_0_CLINICAL_RESOURCE_ResponseHandler = {
    when: "*://*/*/fhir_clinical_1_6_0/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MCI_1_6_0_SERVICE_ResponseHandler = {
    when: "*://*/*/mci_service_1_6_0/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var PEOPLE_FHIR_RESOURCE_1_ResponseHandler = {
    when: "*://*/*/people_fhir/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var PEOPLE_FHIR_RESOURCE_2_ResponseHandler = {
    when: "*://*/*/people_fhir/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var PEOPLE_FHIR_RESOURCE_3_ResponseHandler = {
    when: "*://*/*/people_fhir/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var PEOPLE_FHIR_RESOURCE_4_ResponseHandler = {
    when: "*://*/*/people_fhir/*/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var PWP_BACKEND_1_ResponseHandler = {
    when: "*://*/*/pwp_backend/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var PWP_BACKEND_2_ResponseHandler = {
    when: "*://*/*/pwp_backend/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var PWP_BACKEND_3_ResponseHandler = {
    when: "*://*/*/pwp_backend/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};


var ARR_FHIR_2_ResponseHandler = {
    when: "*://*/*/arr_fhir/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var ARR_FHIR_3_ResponseHandler = {
    when: "*://*/*/arr_fhir/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var ARR_FHIR_4_ResponseHandler = {
    when: "*://*/*/arr_fhir/*/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var MHD_0_ResponseHandler = {
    when: "*://*/*/x1v1_mhd/",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var MHD_1_ResponseHandler = {
    when: "*://*/*/x1v1_mhd/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var MHD_2_ResponseHandler = {
    when: "*://*/*/x1v1_mhd/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var MHD_3_ResponseHandler = {
    when: "*://*/*/x1v1_mhd/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var XVALUE_PATSYN_1_ResponseHandler = {
    when: "*://*/*/xvalue_patsyn/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var XVALUE_PATSYN_2_ResponseHandler = {
    when: "*://*/*/xvalue_patsyn/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var XVALUE_PATSYN_3_ResponseHandler = {
    when: "*://*/*/xvalue_patsyn/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};

var X1V1_CONFIGURATOR_1_ResponseHandler = {
    when: "*://*/*/x1v1_configurator/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var X1V1_CONFIGURATOR_2_ResponseHandler = {
    when: "*://*/*/x1v1_configurator/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var X1V1_CONFIGURATOR_3_ResponseHandler = {
    when: "*://*/*/x1v1_configurator/*/*/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var REST_ResponseHandler = {
    when: "*://*/*/rest/*",
    faultValue: unauthorizedError,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.rest.RESTResponseHandler"]
};
var IIA_ServiceSearch = {
    when: "serviceSearch",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var IIA_ServiceSearchFull = {
    when: "serviceSearchFull",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var IIA_ServiceInsert = {
    when: "serviceInsert",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var IIA_ServiceUpdate = {
    when: "serviceUpdate",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var IIA_ServiceUpdates = {
    when: "serviceUpdates",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var IIA_ServiceMerge = {
    when: "serviceMerge",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var PRPA_QUQI = {
    when: "QUQI_IN000003UV01",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var PRPA_PRPA = {
    when: "PRPA_IN201305UV02",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var PRPA_PRPA_302 = {
    when: "PRPA_IN201302UV02",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var PRPA_PRPA_301 = {
    when: "PRPA_IN201301UV02",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var PRPA_PRPA_303 = {
    when: "PRPA_IN201303UV02",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var PRPA_PRPA_304 = {
    when: "PRPA_IN201304UV02",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var PRPA_MCCI_004 = {
    when: "MCCI_IN100004UV01",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var PRPA_MCCI_001 = {
    when: "MCCI_IN100001UV01",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var SND_MSG_S = {
    when: "sendMessageS",
    faultValue: _203_registry,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.PermitOrFaultResponseHandler"]
};

var NEW_FHIRRESOURCE_ResponseHandler = {
    when: "fhirResourceRead",
    faultValue: _205,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.FHIRResourceReadResponseHandler"]
};

var FHIRRESOURCE_ResponseHandler = {
    when: "fhirResource",
    faultValue: _205,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.fhir.FHIRFilterResponseHandler"]
};

var FHIRRESOURCE_ResponseHandlerNoAuth = {
    when: "fhirResourceNoAuth",
    faultValue: _205,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.fhir.FHIRFilterResponseHandler"]
};

var FHIR_PATIENTRESOURCE_ResponseHandler = {
    when: "fhirPatientResourceNoAuth",
    faultValue: _205,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.CustomFHIRFilterResponseHandler"]
};

var FHIR_ResponseHandler = {
    when: "*://*/*/fhir/*",
    faultValue: _205,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.fhir.FHIRFilterResponseHandler"]
};

var NOTIFIER_PUBLISH_ResponseHandler = {
    when: "notifierPublish",
    faultValue: _205,
    implementationClazzes: ["eu.dedalus.xvalue.policyengine.pep.handler.FHIRResourceReadResponseHandler"]
};