db.mongodb_datasource.createIndex({ alias : 1 });

db.mongodb_datasource.insertOne(ADT_DATASOURCE);
db.mongodb_datasource.insertOne(ARRIETTY_DATASOURCE);
db.mongodb_datasource.insertOne(PM_CONSENT_ENGINE_DATASOURCE);