var _203 = {
    faultCode: "203",
    faultMessage: [{
            lang: "it",
            message: "i ruoli @ROLES@ non hanno permessi per il document type @DOCUMENT_TYPE@"
        }, {
            lang: "en",
            message: "roles @ROLES@ have no permission on document of type @DOCUMENT_TYPE@"
        }
    ],
    faultDetail: "",
    responseConfig: [{
            placeholder: "@ROLES@",
            attributes: role
        }, {
            placeholder: "@DOCUMENT_TYPE@",
            attributes: typeCode
        }
    ]
};

var _202 = {
    faultCode: "202",
    faultMessage: [{
            lang: "it",
            message: "Ruolo utente non trovato"
        }, {
            lang: "en",
            message: "Role or operation not found"
        }
    ],
    faultDetail: ""
};

var _204 = {
    faultCode: "204",
    faultMessage: [{
            lang: "it",
            message: "Repository non trovato"
        }, {
            lang: "en",
            message: "Repository not found"
        }
    ],
    faultDetail: ""
};

var _205 = {
    faultCode: "205",
    faultMessage: [{
            lang: "it",
            message: "Errore generico filtraggio risultati"
        }, {
            lang: "en",
            message: "Generic error filtering results"
        }
    ],
    faultDetail: ""
};

var _101 = {
    faultCode: "101",
    faultMessage: [{
            lang: "it",
            message: "Non è possibile determinare la tipologia del documento"
        }, {
            lang: "en",
            message: "Impossible to find the document type"
        }
    ],
    faultDetail: ""
};

var _102 = {
    faultCode: "102",
    faultMessage: [{
            lang: "it",
            message: "Non è possibile determinare la tipologia di operazione"
        }, {
            lang: "en",
            message: "Impossible to find operation type"
        }
    ],
    faultDetail: ""
};

var _105 = {
    faultCode: "105",
    faultMessage: [{
            lang: "it",
            message: "Non è possibile estrarre il CF dell'MMG"
        }, {
            lang: "en",
            message: "Impossible to read MMG's CF"
        }
    ],
    faultDetail: ""
};

var _106 = {
    faultCode: "106",
    faultMessage: [{
            lang: "it",
            message: "Non è possibile estrarre il type code dai metadati"
        }, {
            lang: "en",
            message: "Impossible to read document type code"
        }
    ],
    faultDetail: ""
};

var _108 = {
    faultCode: "108",
    faultMessage: [{
            lang: "it",
            message: "Errore generico access gateway"
        }, {
            lang: "en",
            message: "Generic error access gateway"
        }
    ],
    faultDetail: ""
};

var samlException = {
    faultCode: "samlException",
    faultMessage: [{
            lang: "it",
            message: "Errore generico sulla SAML"
        }, {
            lang: "en",
            message: "Generic error on SAML"
        }
    ],
    faultDetail: ""
};

var samlExpired = {
    faultCode: "samlExpired",
    faultMessage: [{
            lang: "it",
            message: "SAML scaduta"
        }, {
            lang: "en",
            message: "SAML expired"
        }
    ],
    faultDetail: ""
};

var missingSamlSubject = {
    faultCode: "missingSamlSubject",
    faultMessage: [{
            lang: "it",
            message: "Soggetto nella SAML mancante"
        }, {
            lang: "en",
            message: "Missing SAML subject"
        }
    ],
    faultDetail: ""
};

var subjectNotEqual = {
    faultCode: "subjectNotEqual",
    faultMessage: [{
            lang: "it",
            message: "Soggetto diverso"
        }, {
            lang: "en",
            message: "Subject not equal"
        }
    ],
    faultDetail: ""
};

var missingSamlToken = {
    faultCode: "missingSamlToken",
    faultMessage: [{
            lang: "it",
            message: "Token SAML mancante"
        }, {
            lang: "en",
            message: "Missing SAML token"
        }
    ],
    faultDetail: ""
};

var wrongNumberOfSamlToken = {
    faultCode: "wrongNumberOfSamlToken",
    faultMessage: [{
            lang: "it",
            message: "Numero di Token SAML errato"
        }, {
            lang: "en",
            message: "Wrong number of SAML token"
        }
    ],
    faultDetail: ""
};

var repeatedIssuerSamlToken = {
    faultCode: "repeatedIssuerSamlToken",
    faultMessage: [{
            lang: "it",
            message: "Issuer Token SAML ripetuto"
        }, {
            lang: "en",
            message: "Repeated Issuer SAML token"
        }
    ],
    faultDetail: ""
};

var samluntrustedIssuer = {
    faultCode: "samlUntrustedIssuer",
    faultMessage: [{
            lang: "it",
            message: "Issuer del token saml sconosciuto"
        }, {
            lang: "en",
            message: "Untrusted saml token issuer"
        }
    ],
    faultDetail: ""
};

var missingConsent = {
    faultCode: "missingConsent",
    faultMessage: [{
            lang: "it",
            message: "Il paziente non ha espresso consensi"
        }, {
            lang: "en",
            message: "The patient doesn't release consents"
        }
    ],
    faultDetail: ""
};

var illegalConsentInsert = {
    faultCode: "illegalConsentInsert",
    faultMessage: [{
            lang: "it",
            message: "Non è possibile inserire il documento con la configurazione di consensi usata"
        }, {
            lang: "en",
            message: "Impossible to insert the document with selected consents"
        }
    ],
    faultDetail: ""
};

var jwtExpired = {
    faultCode: "jwtExpired",
    faultMessage: [{
            lang: "it",
            message: "jwt scaduto"
        }, {
            lang: "en",
            message: "jwt expired"
        }
    ],
    faultDetail: ""
};

var invalidJwt = {
    faultCode: "invalidJwt",
    faultMessage: [{
            lang: "it",
            message: "jwt non valido"
        }, {
            lang: "en",
            message: "jwt invalid"
        }
    ],
    faultDetail: ""
};

var missingAuthorizationHeader = {
    faultCode: "missingAuthorizationHeader",
    faultMessage: [{
            lang: "it",
            message: "request header Authorization mancante"
        }, {
            lang: "en",
            message: "missing Authorization header "
        }
    ],
    faultDetail: ""
};

var mispelledAuthorizationHeader = {
    faultCode: "mispelledAuthorizationHeader",
    faultMessage: [{
            lang: "it",
            message: "request header Authorization errato"
        }, {
            lang: "en",
            message: "mispelled Authorization header "
        }
    ],
    faultDetail: ""
};

var internalServerError = {
    faultCode: "internalServerError",
    faultMessage: [{
            lang: "it",
            message: "Errore interno del server"
        }, {
            lang: "en",
            message: "internal Server Error"
        }
    ],
    faultDetail: ""
};