var healtCareProviderDiscovery_iti41 = {
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB",
    id: "healtCareProviderDiscovery",
    source: {
        discovery: taxCodeDiscovery
    },
    target: lhaHealthCareProviderAttributes
};

var healtCareProviderDiscovery_iti18 = {
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery",
    id: "healtCareProviderDiscovery",
    source: {
        discovery: taxCodeDiscovery
    },
    target: lhaHealthCareProviderAttributes
};

var documentsPatientIdDiscovery_iti41 = {
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB",
    id: "documentsPatientIdDiscovery",
    target: {
        discovery: xdsPatientIdDiscovery
    }
};

var documentsPatientIdDiscovery_iti18 = {
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery",
    id: "documentsPatientIdDiscovery",
    target: {
        discovery: xdsPatientIdDiscovery
    }
};

var documentUniqueIdDiscovery_iti18 = {
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery",
    id: "documentUniqueIdDiscovery",
    target: {
        discovery: xdsUniqueIdDiscovery
    }
};

var documentUniqueIdDiscovery_iti41 = {
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB",
    id: "documentUniqueIdDiscovery",
    target: {
        discovery: xdsUniqueIdDiscovery
    }
};

var documentAuthorPersonDiscovery_iti41 = {
    id: "documentAuthorPersonDiscovery",
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB",
    source: {
        discovery: samlSubjectDiscovery
    },
    target: {
        discovery: xdsAuthorPersonDiscovery
    }
};

var documentAuthorPersonDiscovery_iti18 = {
    id: "documentAuthorPersonDiscovery",
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery",
    source: {
        discovery: samlSubjectDiscovery
    },
    target: {
        discovery: xdsAuthorPersonDiscovery
    }
};

var userOwnershipDiscovery_iti41 = {
    id: "userOwnershipDiscovery",
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB",
    source: {
        discovery: taxCodeDiscovery
    },
    target: {
        discovery: xdsPatientIdDiscovery
    }
};

var userOwnershipDiscovery_iti18 = {
    id: "userOwnershipDiscovery",
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery",
    source: {
        discovery: taxCodeDiscovery
    },
    target: {
        discovery: xdsPatientIdDiscovery
    }
};

var tutorDiscovery_iti41 = {
    id: "tutorshipDiscovery",
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB",
    source: {
        discovery: samlSubjectDiscovery
    },
    target: tutorAttributes
};

var tutorDiscovery_iti18 = {
    id: "tutorshipDiscovery",
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery",
    source: {
        discovery: samlSubjectDiscovery
    },
    target: tutorAttributes
};

var healtCareProviderDiscovery_agmatrix = {
    id: "healtCareProviderDiscovery",
    when: "agmatrix",
    endpoint: "agmatrix",
    source: {
        discovery: taxCodeDiscovery
    },
    target: lhaHealthCareProviderAttributes
};

var healtCareProviderDiscovery_consent = {
    id: "healtCareProviderDiscovery",
    when: "consent",
    endpoint: "consent",
    source: {
        discovery: taxCodeDiscovery
    },
    target: lhaHealthCareProviderAttributes
};

var documentConsentRemoveConditionDiscovery = {
    id: "documentConsentRemoveConditionDiscovery",
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery",
    source: documentConsentRemoveCondition,
    target: {
        discovery: trueFakeDiscovery
    }
};

var documentConsentTutorRemoveConditionDiscovery = {
    id: "documentConsentTutorRemoveConditionDiscovery",
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery",
    source: documentConsentTutorRemoveCondition,
    target: {
        discovery: trueFakeDiscovery
    }
};

//TO DEPRECATE
var healtCareProviderDiscovery_PMASRES = {
    id: "healtCareProviderDiscovery",
    when: "pmasres",
    endpoint: "pmasres",
    source: {
        discovery: userIdDiscoveryPMAS
    },
    target: {
        discovery: lhaHealthCareProviderDiscoveryPMAS
    }
};

var userOwnershipDiscovery_PMASRES = {
    id: "userOwnershipDiscovery",
    when: "pmasres",
    endpoint: "pmasres",
    source: {
        discovery: userIdDiscoveryPMAS
    },
    target: {
        discovery: patientIdDiscoveryPMAS
    }
};

var tutorDiscovery_PMASRES = {
    id: "tutorshipDiscovery",
    when: "pmasres",
    endpoint: "pmasres",
    source: {
        discovery: userIdDiscoveryPMAS
    },
    target: {
        discovery: tutorsIdDiscoveryPMAS
    }
};

var documentAuthorPersonDiscovery_PMASRES = {
    id: "documentAuthorPersonDiscovery",
    when: "pmasres",
    endpoint: "pmasres",
    source: {
        discovery: userIdTaxCodeDiscoveryPMAS
    },
    target: {
        discovery: authorIdTaxCodeDiscoveryPMAS
    }
};

var hospitalAuthorshipDiscovery_PMASRES = {
    id: "hospitalAuthorshipDiscovery",
    when: "pmasres",
    endpoint: "pmasres",
    source: {
        discovery: userHospitalDiscoveryPMAS
    },
    target: {
        discovery: objectHospitalDiscoveryPMAS
    }
};

var facilityAuthorshipDiscovery_PMASRES = {
    id: "facilityAuthorshipDiscovery",
    when: "pmasres",
    endpoint: "pmasres",
    source: {
        discovery: userFacilityDiscoveryPMAS
    },
    target: {
        discovery: objectFacilityDiscoveryPMAS
    }
};

var wardAuthorshipDiscovery_PMASRES = {
    id: "wardAuthorshipDiscovery",
    when: "pmasres",
    endpoint: "pmasres",
    source: {
        discovery: userWardDiscoveryPMAS
    },
    target: {
        discovery: objectWardDiscoveryPMAS
    }
};

var hospitalExternalAuthorshipDiscovery_PMASRES = {
    id: "hospitalExternalAuthorshipDiscovery",
    when: "pmasres",
    endpoint: "pmasres",
    source: {
        discovery: currentHospitalDiscoveryPMAS
    },
    target: {
        discovery: objectHospitalDiscoveryPMAS
    }
};

var facilityExternalAuthorshipDiscovery_PMASRES = {
    id: "facilityExternalAuthorshipDiscovery",
    when: "pmasres",
    endpoint: "pmasres",
    source: {
        discovery: currentFacilityDiscoveryPMAS
    },
    target: {
        discovery: objectFacilityDiscoveryPMAS
    }
};

var wardExternalAuthorshipDiscovery_PMASRES = {
    id: "wardExternalAuthorshipDiscovery",
    when: "pmasres",
    endpoint: "pmasres",
    source: {
        discovery: currentWardDiscoveryDiscoveryPMAS
    },
    target: {
        discovery: objectWardDiscoveryPMAS
    }
};

//TO DEPRECATE
var healtCareProviderDiscovery_PMAS = {
    id: "healtCareProviderDiscovery",
    when: "pmas",
    endpoint: "pmas",
    source: {
        discovery: userIdDiscoveryPMAS
    },
    target: {
        discovery: lhaHealthCareProviderDiscoveryPMAS
    }
};

var userOwnershipDiscovery_PMAS = {
    id: "userOwnershipDiscovery",
    when: "pmas",
    endpoint: "pmas",
    source: {
        discovery: userIdDiscoveryPMAS
    },
    target: {
        discovery: patientIdDiscoveryPMAS
    }
};

var tutorDiscovery_PMAS = {
    id: "tutorshipDiscovery",
    when: "pmas",
    endpoint: "pmas",
    source: {
        discovery: userIdDiscoveryPMAS
    },
    target: {
        discovery: tutorsIdDiscoveryPMAS
    }
};

var documentAuthorPersonDiscovery_PMAS = {
    id: "documentAuthorPersonDiscovery",
    when: "pmas",
    endpoint: "pmas",
    source: {
        discovery: userIdTaxCodeDiscoveryPMAS
    },
    target: {
        discovery: authorIdTaxCodeDiscoveryPMAS
    }
};

var hospitalAuthorshipDiscovery_PMAS = {
    id: "hospitalAuthorshipDiscovery",
    when: "pmas",
    endpoint: "pmas",
    source: {
        discovery: userHospitalDiscoveryPMAS
    },
    target: {
        discovery: objectHospitalDiscoveryPMAS
    }
};

var facilityAuthorshipDiscovery_PMAS = {
    id: "facilityAuthorshipDiscovery",
    when: "pmas",
    endpoint: "pmas",
    source: {
        discovery: userFacilityDiscoveryPMAS
    },
    target: {
        discovery: objectFacilityDiscoveryPMAS
    }
};

var wardAuthorshipDiscovery_PMAS = {
    id: "wardAuthorshipDiscovery",
    when: "pmas",
    endpoint: "pmas",
    source: {
        discovery: userWardDiscoveryPMAS
    },
    target: {
        discovery: objectWardDiscoveryPMAS
    }
};

var hospitalExternalAuthorshipDiscovery_PMAS = {
    id: "hospitalExternalAuthorshipDiscovery",
    when: "pmas",
    endpoint: "pmas",
    source: {
        discovery: currentHospitalDiscoveryPMAS
    },
    target: {
        discovery: objectHospitalDiscoveryPMAS
    }
};

var facilityExternalAuthorshipDiscovery_PMAS = {
    id: "facilityExternalAuthorshipDiscovery",
    when: "pmas",
    endpoint: "pmas",
    source: {
        discovery: currentFacilityDiscoveryPMAS
    },
    target: {
        discovery: objectFacilityDiscoveryPMAS
    }
};

var wardExternalAuthorshipDiscovery_PMAS = {
    id: "wardExternalAuthorshipDiscovery",
    when: "pmas",
    endpoint: "pmas",
    source: {
        discovery: currentWardDiscoveryDiscoveryPMAS
    },
    target: {
        discovery: objectWardDiscoveryPMAS
    }
};
