db.response_handler.createIndex({ when : 1 });

db.response_handler.insertOne(NEW_AdhocQueryRequest_ResponseHandler);
db.response_handler.insertOne(NEW_AdhocQueryResponse_ResponseHandler);
db.response_handler.insertOne(NEW_RetrieveDocumentSetResponse_ResponseHandler);

db.response_handler.insertOne(ProxyTestParamHandler_ResponseHandler);

db.response_handler.insertOne(CONSENT_BASE_1_ResponseHandler);
db.response_handler.insertOne(CONSENT_BASE_2_ResponseHandler);
db.response_handler.insertOne(CONSENT_BASE_3_ResponseHandler);
db.response_handler.insertOne(CONSENT_BASE_4_ResponseHandler);
db.response_handler.insertOne(CONSENT_BASE_5_ResponseHandler);
db.response_handler.insertOne(CONSENT_BASE_6_ResponseHandler);

db.response_handler.insertOne(FHIR_CLINICAL_RESOURCE_1_ResponseHandler);
db.response_handler.insertOne(FHIR_CLINICAL_RESOURCE_2_ResponseHandler);
db.response_handler.insertOne(FHIR_CLINICAL_RESOURCE_3_ResponseHandler);

db.response_handler.insertOne(MCI_SERVICE_ResponseHandler);

db.response_handler.insertOne(PEOPLE_FHIR_RESOURCE_1_ResponseHandler);
db.response_handler.insertOne(PEOPLE_FHIR_RESOURCE_2_ResponseHandler);
db.response_handler.insertOne(PEOPLE_FHIR_RESOURCE_3_ResponseHandler);
db.response_handler.insertOne(PEOPLE_FHIR_RESOURCE_4_ResponseHandler);

db.response_handler.insertOne(PWP_BACKEND_1_ResponseHandler);
db.response_handler.insertOne(PWP_BACKEND_2_ResponseHandler);
db.response_handler.insertOne(PWP_BACKEND_3_ResponseHandler);

db.response_handler.insertOne(MHD_0_ResponseHandler);
db.response_handler.insertOne(MHD_1_ResponseHandler);
db.response_handler.insertOne(MHD_2_ResponseHandler);
db.response_handler.insertOne(MHD_3_ResponseHandler);

db.response_handler.insertOne(XVALUE_PATSYN_1_ResponseHandler);
db.response_handler.insertOne(XVALUE_PATSYN_2_ResponseHandler);
db.response_handler.insertOne(XVALUE_PATSYN_3_ResponseHandler);

db.response_handler.insertOne(X1V1_CONFIGURATOR_1_ResponseHandler);
db.response_handler.insertOne(X1V1_CONFIGURATOR_2_ResponseHandler);
db.response_handler.insertOne(X1V1_CONFIGURATOR_3_ResponseHandler);

db.response_handler.insertOne(REST_ResponseHandler);

db.response_handler.insertOne(NEW_FHIRRESOURCE_ResponseHandler);

db.response_handler.insertOne(DSUB_AgMatrix_ResponseHandler);
db.response_handler.insertOne(DSUB_Consent_ResponseHandler);