load("util/definition/def_include_all.js");

load("util/1.1.0-mongodb_datasource.js");
load("util/1.1.0-datasources.js");
load("util/1.1.0-attribute_discovery.js");
load("util/1.1.0-atna_bean_configuration.js");