db.configuration.deleteOne({property: "saml.config"});
db.configuration.insertOne(samlConfig);