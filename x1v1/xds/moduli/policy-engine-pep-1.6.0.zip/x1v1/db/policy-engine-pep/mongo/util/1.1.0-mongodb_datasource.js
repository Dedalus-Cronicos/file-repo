db.mongodb_datasource.deleteOne({alias: "ADT_DATASOURCE"});
db.mongodb_datasource.deleteOne({alias: "ARRIETTY_DATASOURCE"});
db.mongodb_datasource.deleteOne({alias: "PM_CONSENT_ENGINE_DATASOURCE"});

db.mongodb_datasource.insertOne(ADT_DATASOURCE);
db.mongodb_datasource.insertOne(ARRIETTY_DATASOURCE);
db.mongodb_datasource.insertOne(PM_CONSENT_ENGINE_DATASOURCE);