db.attribute_discovery.deleteOne({"when": "ProvideAndRegisterDocumentSetRequest", "endpoint": "DocumentRepository_ProvideAndRegisterDocumentSetB_Multitenancy"});
db.attribute_discovery.insertOne(IN_DocumentRepository_ProvideAndRegisterDocumentSetB_Multitenancy);

db.attribute_discovery.deleteOne({"when": "AdhocQueryRequest", "endpoint": "RegistryStoredQuery_Multitenancy"});
db.attribute_discovery.insertOne(IN_RegistryStoredQuery_Multitenancy);