db.referenceid_discovery.createIndex({ when : 1, endpoint : 1, phase : 1 });

db.referenceid_discovery.insertOne(ProvideAndRegisterDocumentSetRequest_Default_ReferenceIdDiscovery);
db.referenceid_discovery.insertOne(AdhocQueryResponse_Default_ReferenceIdDiscovery);
db.referenceid_discovery.insertOne(RegistryResponseBPPC_ReferenceIdDiscovery);
db.referenceid_discovery.insertOne(ProvideAndRegisterDocumentSetRequestBPPC_ReferenceIdDiscovery);