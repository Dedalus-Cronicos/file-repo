db.response_handler.deleteOne({when: "notifierPublish"});
db.response_handler.insertOne(NOTIFIER_PUBLISH_ResponseHandler);