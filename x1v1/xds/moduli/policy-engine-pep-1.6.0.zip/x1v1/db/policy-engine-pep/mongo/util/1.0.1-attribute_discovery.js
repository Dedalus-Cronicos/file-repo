db.attribute_discovery.deleteOne({when: "fhirResourceRead"});
db.attribute_discovery.insertOne(IN_NEW_READ_FHIRRESOURCE);

db.attribute_discovery.deleteOne({when: "*://*/*/arr/*"});

db.attribute_discovery.insertOne(IN_ARR_FHIR_GET_4);
db.attribute_discovery.insertOne(IN_ARR_FHIR_POST_4);
db.attribute_discovery.insertOne(OUT_ARR_FHIR_RESOURCE_4);