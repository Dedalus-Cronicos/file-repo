db.attributes.createIndex({ id : 1 });

db.attributes.insertOne(documentUniqueIdDiscovery);
db.attributes.insertOne(documentConsentInsertInvalidCondition);
db.attributes.insertOne(healtCareProviderRoleDiscovery);
db.attributes.insertOne(delegatedPatientRoleDiscovery);
db.attributes.insertOne(documentPatientId);
db.attributes.insertOne(userIdDiscovery);
db.attributes.insertOne(userHealthcareStructureDiscovery);
db.attributes.insertOne(patientQueryIdDiscovery);
db.attributes.insertOne(documentResponseUniqueIdDiscovery);
db.attributes.insertOne(folderUniqueIdDiscovery);
db.attributes.insertOne(submissionUniqueIdDiscovery);
db.attributes.insertOne(adhocQueryIdDiscovery);
db.attributes.insertOne(documentResponseLidDiscovery);
db.attributes.insertOne(actionValidatorDiscovery);