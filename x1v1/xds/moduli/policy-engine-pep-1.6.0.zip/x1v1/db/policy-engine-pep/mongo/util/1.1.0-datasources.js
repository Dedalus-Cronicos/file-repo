db.datasources.deleteOne({alias: "LHA_DATASOURCE"});

db.datasources.insertOne(LHA_DATASOURCE);