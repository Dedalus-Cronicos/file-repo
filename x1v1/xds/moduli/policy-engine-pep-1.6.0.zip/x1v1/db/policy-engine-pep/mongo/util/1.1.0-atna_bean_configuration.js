db.atna_bean_configuration.deleteOne({when: "ITI_18"});
db.atna_bean_configuration.insertOne(atnaBean_ITI18);