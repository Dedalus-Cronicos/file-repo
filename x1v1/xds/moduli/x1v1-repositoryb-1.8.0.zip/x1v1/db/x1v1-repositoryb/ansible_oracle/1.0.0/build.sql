-- &1 USER
-- &2 TABLES' TABLESPACE
-- &3 INDEXES' TABLESPACE
-- &4 LOBS' TABLESPACE

spool build.log

-- TABLES
@tables/documents.sql &1 &2 &3 &4;

-- SEQUENCES
--@sequences/sequence_nome.sql &1 &2 &3 &4;


-- CONSTRAINTS (NO FOREIGN KEY)
@constraints/documents.sql &1 &2 &3 &4;


-- INDEXES
@indexes/documents_idx.sql &1 &2 &3 &4;


spool off

QUIT
