#!/usr/bin/env bash
#
set -o errexit
# set -o pipefail
# set -o nounset
# set -o xtrace

# mongo --quiet localhost:27017/admin -u admin -p x1v1mdb --authenticationDatabase admin <<EOF
mongo ${CONTAINER:+--quiet} "mongodb://${ADMIN_MONGODB_USER}:${ADMIN_MONGODB_PASSWORD}@${MONGODB_CONN_STRING:-${MONGODB_SERVICE_HOST}:${MONGODB_SERVICE_PORT}}/${ADMIN_MONGODB_NAME}${MONGODB_CONN_OPTS}" <<EOF
db = db.getSiblingDB("${X1V1_REPOSITORYB_MONGODB_USER}");
user = db.getUser("${X1V1_REPOSITORYB_MONGODB_NAME}");
if (!user) {
        db.createUser({ user: "${X1V1_REPOSITORYB_MONGODB_NAME}",
          pwd: "${X1V1_REPOSITORYB_MONGODB_PASSWORD}",
          roles: [
            { role: "readWrite", db: "${X1V1_REPOSITORYB_MONGODB_USER}"}
          ]
        });
}
EOF
