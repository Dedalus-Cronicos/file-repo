//COLLECTION
db.createCollection('documents');


//INDICI
db.documents.createIndex( { "uniqueid": 1 }, { unique: true } )



db.createCollection("schema_version");

db.getCollection("schema_version").insert(
    {
        "major" : "1",
        "minor" : "5",
        "patch" : "0",
        "tag" : "x1v1-repositoryb",
        "revision" : 0,
        "last_change" : ISODate("2020-10-09T16:53:27.604+02:00"),
        "description" : ""
    }
);
