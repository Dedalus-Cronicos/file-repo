//mongo admin -u admin -p x1v1mdb --authenticationDatabase admin;

db = db.getSiblingDB("@repositoryb.mongodb.name@");
db.createUser({ user: "@repositoryb.mongodb.user@",
  pwd: "@repositoryb.mongodb.password@",
  roles: [
    { role: "readWrite", db: "@repositoryb.mongodb.name@"}
  ]
});
