CREATE TABLE documents
(
  uniqueid character varying(128) NOT NULL,
  uuid character varying(60),
  contenttype character varying(64) NOT NULL,
  insertdate timestamp without time zone NOT NULL,
  lastupdate timestamp without time zone NOT NULL,
  sourceoid character varying(128),
  content bytea,
  CONSTRAINT pk_documents PRIMARY KEY (uniqueid)
)
WITH (
  OIDS=FALSE
);
ALTER TABLE documents
  OWNER TO &1;
/
