CREATE UNIQUE INDEX docinsert_idx ON documents (insertdate);
/

CREATE UNIQUE INDEX doclastupd_idx ON documents (lastupdate);
/

