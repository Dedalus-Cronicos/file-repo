db.subscriber.update(
   {'name':'ITI_18'},
   { $set: { "value" : ITI_18_file}}
);

db.subscriber.update(
   {'name':'ITI_41'},
   { $set: { "value" : ITI_41_file}}
);

db.subscriber.update(
   {'name':'ITI_42'},
   { $set: { "value" : ITI_42_file}}
);

db.subscriber.update(
   {'name':'ITI_43'},
   { $set: { "value" : ITI_43_file}}
);

db.subscriber.update(
   {'name':'ITI_57'},
   { $set: { "value" : ITI_57_file}}
);

db.subscriber.update(
   {'name':'ITI_62'},
   { $set: { "value" : ITI_62_file}}
);

