db.x1v1_configuration.remove({key : "PatientSynoptic"});
db.x1v1_configuration.insert(PatientSynoptic);
db.x1v1_configuration.insert(S4HClinicalPortal);
db.x1v1_configuration.insert(S4HResourcePathTest);

