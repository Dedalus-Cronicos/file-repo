db.script_version.drop();

load("util/definition/def-deprecated.js");
load("util/definition/def-x1v1_configuration.js");
load("util/definition/def-subscriber.js");
load("util/definition/def-configuration.js");
load("util/1.3.0-x1v1_configuration.js");
load("util/1.3.0-subscriber.js");
load("util/1.3.0-configuration.js");
