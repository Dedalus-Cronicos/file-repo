db.subscriber.remove({ name: "consentPeople" });
db.subscriber.remove({ name: "consentSTU3" });
db.subscriber.remove({ name: "consentAudit" });
db.subscriber.remove({ name: "sharingContextAudit" });
db.subscriber.remove({ name: "AuditEventSTU3" });
db.subscriber.remove({ name: "ITI_18" });
db.subscriber.remove({ name: "ITI_41" });
db.subscriber.remove({ name: "ITI_42" });
db.subscriber.remove({ name: "ITI_43" });
db.subscriber.remove({ name: "ITI_57" });
db.subscriber.remove({ name: "ITI_62" });

db.subscriber.insert(consentPeople);
db.subscriber.insert(consentSTU3);
db.subscriber.insert(consentAudit);
db.subscriber.insert(sharingContextAudit);
db.subscriber.insert(auditEventSTU3);
db.subscriber.insert(ITI_18);
db.subscriber.insert(ITI_41);
db.subscriber.insert(ITI_42);
db.subscriber.insert(ITI_43);
db.subscriber.insert(ITI_57);
db.subscriber.insert(ITI_62);
  