load("util/definition/def_include_all.js");

load("util/1.2.0-datasources.js");
load("util/1.2.0-attribute_discovery.js");
load("util/1.2.0-response_handler.js");