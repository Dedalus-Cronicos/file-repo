var ProvideAndRegisterDocumentSetRequest_Default_ReferenceIdDiscovery = {
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB_Default",
    phase: "IN",
    extrinsicObject: extrinsicObject,
    referenceIds: [nosological, emergency, order],
    namespace: rimNamespace,
    slotName: referenceIdListSlotName
};

var AdhocQueryResponse_Default_ReferenceIdDiscovery = {
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery_Default",
    phase: "OUT",
    condition: notTypeCodeConsent,
    extrinsicObject: extrinsicObject,
    referenceIds: [nosological, emergency, order],
    namespace: rimNamespace,
    slotName: referenceIdListSlotName
};

var ProvideAndRegisterDocumentSetRequest_ReferenceIdDiscovery = {
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB",
    phase: "IN",
    extrinsicObject: extrinsicObject,
    referenceIds: [nosological, emergency, order],
    namespace: rimNamespace,
    slotName: referenceIdListSlotName
};

var ProvideAndRegisterDocumentSetRequestBPPC_ReferenceIdDiscovery = {
    when: "ProvideAndRegisterDocumentSetRequest",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetBBPPC",
    phase: "IN",
    condition: typeCodeCondition,
    extrinsicObject: extrinsicObject,
    referenceIds: [nosological, emergency, order],
    namespace: rimNamespace,
    slotName: referenceIdListSlotName
};

var RegistryResponse_ReferenceIdDiscovery = {
    when: "RegistryResponse",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetB",
    phase: "OUT",
    skipEvaluationProcess: true
};

var RegistryResponseBPPC_ReferenceIdDiscovery = {
    when: "RegistryResponse",
    endpoint: "DocumentRepository_ProvideAndRegisterDocumentSetBBPPC",
    phase: "OUT",
    skipEvaluationProcess: true
};

var RetrieveDocumentSetRequest_ReferenceIdDiscovery = {
    when: "RetrieveDocumentSetRequest",
    endpoint: "DocumentRepository_RetrieveDocumentSet",
    phase: "IN",
    skipEvaluationProcess: true
};

var RetrieveDocumentSetResponse_ReferenceIdDiscovery = {
    when: "RetrieveDocumentSetResponse",
    endpoint: "DocumentRepository_RetrieveDocumentSet",
    phase: "OUT",
    skipEvaluationProcess: true
};

var AdhocQueryRequest_ReferenceIdDiscovery = {
    when: "AdhocQueryRequest",
    endpoint: "RegistryStoredQuery",
    phase: "IN",
    skipEvaluationProcess: true
};

var AdhocQueryResponse_ReferenceIdDiscovery = {
    when: "AdhocQueryResponse",
    endpoint: "RegistryStoredQuery",
    phase: "OUT",
    condition: notTypeCodeConsent,
    extrinsicObject: extrinsicObject,
    referenceIds: [nosological, emergency, order],
    namespace: rimNamespace,
    slotName: referenceIdListSlotName
};