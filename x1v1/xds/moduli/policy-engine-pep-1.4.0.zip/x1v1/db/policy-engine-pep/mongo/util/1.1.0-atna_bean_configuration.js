db.atna_bean_configuration.remove({when: "ITI_18"});
db.atna_bean_configuration.insert(atnaBean_ITI18);