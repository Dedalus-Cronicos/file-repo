db.response_handler.insert(ARR_FHIR_2_ResponseHandler);
db.response_handler.insert(ARR_FHIR_3_ResponseHandler);
db.response_handler.insert(ARR_FHIR_4_ResponseHandler);