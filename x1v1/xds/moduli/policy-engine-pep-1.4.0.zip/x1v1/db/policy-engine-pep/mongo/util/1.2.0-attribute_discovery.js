db.attribute_discovery.remove({when: "fhirResourceRead", endpoint: "fhirResourceRead"});
db.attribute_discovery.remove({when: "AdhocQueryResponse", endpoint: "RegistryStoredQuery"});
db.attribute_discovery.remove({when: "RetrieveDocumentSetResponse", endpoint: "DocumentRepository_RetrieveDocumentSet_Default"});
db.attribute_discovery.remove({when: "AdhocQueryResponse", endpoint: "RegistryStoredQuery_Default"});
db.attribute_discovery.remove({when: "*://*/*/xvalue_patsyn/*/*/*/*"});
db.attribute_discovery.remove({when: "notifierPublish"});

db.attribute_discovery.insert(IN_NEW_READ_FHIRRESOURCE);
db.attribute_discovery.insert(OUT_AdhocQueryResponse);
db.attribute_discovery.insert(OUT_DocumentRepository_RetrieveDocumentSet_Default);
db.attribute_discovery.insert(OUT_RegistryStoredQuery_Default);
db.attribute_discovery.insert(IN_XVALUE_PATSYN_GET_4);
db.attribute_discovery.insert(OUT_XVALUE_PATSYN_4);
db.attribute_discovery.insert(IN_NOTIFIER_PUBLISH);