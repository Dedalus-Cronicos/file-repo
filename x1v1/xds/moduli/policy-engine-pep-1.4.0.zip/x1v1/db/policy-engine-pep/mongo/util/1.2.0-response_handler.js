db.response_handler.remove({when: "notifierPublish"});
db.response_handler.insert(NOTIFIER_PUBLISH_ResponseHandler);