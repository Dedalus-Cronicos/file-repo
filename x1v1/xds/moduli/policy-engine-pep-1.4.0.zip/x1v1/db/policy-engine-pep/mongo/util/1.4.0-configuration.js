db.configuration.remove({property: "language"});
db.configuration.insert(language);
db.configuration.remove({property: "jwtAdditionalJPathAttributes"});
db.configuration.insert(jwtAdditionalJPathAttributes);
db.configuration.remove({property: "saml.config"});
db.configuration.insert(samlConfig);