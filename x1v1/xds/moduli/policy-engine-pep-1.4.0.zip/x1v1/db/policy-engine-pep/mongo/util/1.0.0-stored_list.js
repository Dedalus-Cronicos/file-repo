db.stored_list.ensureIndex({ key: 1 });

db.stored_list.insert(X1V1_AMMINISTRATIVO_Roles);
db.stored_list.insert(X1V1_MEDICO_Roles);
db.stored_list.insert(X1V1_TUTORE_Roles);
db.stored_list.insert(X1V1_ASSISTITO_Roles);
db.stored_list.insert(X1V1_MMG_Roles);
db.stored_list.insert(ALL_MAPPED_Roles);
db.stored_list.insert(ALL_MAPPED_Notify_Roles);