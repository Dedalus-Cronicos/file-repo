db.attribute_discovery.remove({when: "fhirResourceRead"});
db.attribute_discovery.insert(IN_NEW_READ_FHIRRESOURCE);

db.attribute_discovery.remove({when: "*://*/*/arr/*"});

db.attribute_discovery.insert(IN_ARR_FHIR_GET_4);
db.attribute_discovery.insert(IN_ARR_FHIR_POST_4);
db.attribute_discovery.insert(OUT_ARR_FHIR_RESOURCE_4);