db.datasources.ensureIndex({ alias : 1 });

db.datasources.insert(LHA_DATASOURCE);