db.referenceid_discovery.ensureIndex({ when : 1, endpoint : 1, phase : 1 });

db.referenceid_discovery.insert(ProvideAndRegisterDocumentSetRequest_Default_ReferenceIdDiscovery);
db.referenceid_discovery.insert(AdhocQueryResponse_Default_ReferenceIdDiscovery);
db.referenceid_discovery.insert(RegistryResponseBPPC_ReferenceIdDiscovery);
db.referenceid_discovery.insert(ProvideAndRegisterDocumentSetRequestBPPC_ReferenceIdDiscovery);