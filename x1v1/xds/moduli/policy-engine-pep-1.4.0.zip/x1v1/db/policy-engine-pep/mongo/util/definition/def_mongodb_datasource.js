var ADT_DATASOURCE = {
    alias: "ADT_DATASOURCE",
    useConnectionUri: true,
    host: "@mongodb.conn.string@",
    port: "",
    options: "@mongodb.conn.opts@",
    database: "xvalue_adt",
    user: "xvalue_adt",
    password: "xvalue_adt"
};

var ARRIETTY_DATASOURCE = {
    alias: "ARRIETTY_DATASOURCE",
    useConnectionUri: true,
    host: "@mongodb.conn.string@",
    port: "",
    options: "@mongodb.conn.opts@",
    database: "@arrietty.mongodb.name@",
    user: "@arrietty.mongodb.user@",
    password: "@arrietty.mongodb.password@"
};

var PM_CONSENT_ENGINE_DATASOURCE = {
    alias: "PM_CONSENT_ENGINE_DATASOURCE",
    useConnectionUri: true,
    host: "@mongodb.conn.string@",
    port: "",
    options: "@mongodb.conn.opts@",
    database: "@consent.engine.mongodb.name@",
    user: "@consent.engine.mongodb.user@",
    password: "@consent.engine.mongodb.password@"
};