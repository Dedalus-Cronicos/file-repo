db.atna_bean_configuration.insert(atnaBean_ITI18);
db.atna_bean_configuration.insert(atnaBean_ITI41);
db.atna_bean_configuration.insert(atnaBean_ITI42);
db.atna_bean_configuration.insert(atnaBean_ITI43);
db.atna_bean_configuration.insert(atnaBean_ITI57);
db.atna_bean_configuration.insert(atnaBean_ITI62);
db.atna_bean_configuration.insert(atnaBean_ITI86);