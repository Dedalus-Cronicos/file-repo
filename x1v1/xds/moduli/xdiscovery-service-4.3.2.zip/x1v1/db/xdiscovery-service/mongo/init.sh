#!/usr/bin/env bash
#
set -o errexit
# set -o pipefail
# set -o nounset
# set -o xtrace

# mongo --quiet localhost:27017/admin -u admin -p x1v1mdb --authenticationDatabase admin <<EOF
mongosh ${CONTAINER:+--quiet} "${MONGODB_CONN_PROTOCOL}://${ADMIN_MONGODB_USER}:${ADMIN_MONGODB_PASSWORD}@${MONGODB_CONN_STRING:-${MONGODB_SERVICE_HOST}:${MONGODB_SERVICE_PORT}}/${ADMIN_MONGODB_NAME}${MONGODB_CONN_OPTS}" <<EOF
db = db.getSiblingDB("${XDISCOVERY_API_MONGODB_NAME}");
user = db.getUser("${XDISCOVERY_API_MONGODB_USER}");
if (!user) {
        db.createUser({ user: "${XDISCOVERY_API_MONGODB_USER}",
          pwd: "${XDISCOVERY_API_MONGODB_PASSWORD}",
          roles: [
            { role: "readWrite", db: "${XDISCOVERY_API_MONGODB_NAME}"}
          ]
        });
}
EOF

