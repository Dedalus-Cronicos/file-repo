db.configuration.ensureIndex({ key: 1 });

db.configuration.remove({key : "notifyPersistenceConfig"});
db.configuration.insert(notifyPersistenceConfig);

db.configuration.remove({key : "jmsConfig"});
db.configuration.insert(jmsConfig);