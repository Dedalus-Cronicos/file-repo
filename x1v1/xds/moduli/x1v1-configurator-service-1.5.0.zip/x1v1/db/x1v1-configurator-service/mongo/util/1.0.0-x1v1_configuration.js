db.x1v1_configuration.insert(xvalue_task_manager);
db.x1v1_configuration.insert(ConsentCollector);
  