db.x1v1_configuration.remove({key : "ConsentCollector"});
db.x1v1_configuration.insert(ConsentCollector);
db.x1v1_configuration.remove({key : "PatientSynoptic"});
db.x1v1_configuration.insert(S4HFormModel);


