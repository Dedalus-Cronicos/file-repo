load("util/definition/commons.js");

load("util/definition/def_api_mapping.js");
load("util/definition/def_applications.js");
load("util/definition/def_configuration.js");