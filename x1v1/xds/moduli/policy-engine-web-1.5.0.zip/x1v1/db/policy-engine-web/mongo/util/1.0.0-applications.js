db.applications.remove({_id : "test"});
db.applications.insert(test);

db.applications.remove({_id : "dsub"});
db.applications.insert(dsub);

db.applications.remove({_id : "mci_service"});
db.applications.insert(mci_service);

db.applications.remove({_id : "fhir_clinical"});
db.applications.insert(fhir_clinical);

db.applications.remove({_id : "ce_base"});
db.applications.insert(ce_base);

db.applications.remove({_id : "people_fhir"});
db.applications.insert(people_fhir);

db.applications.remove({_id : "x1v1_mhd"});
db.applications.insert(x1v1_mhd);

db.applications.remove({_id : "xvalue_patsyn"});
db.applications.insert(xvalue_patsyn);

db.applications.remove({_id : "x1v1_configurator"});
db.applications.insert(x1v1_configurator);

db.applications.remove({_id : "arr_fhir"});
db.applications.insert(arr_fhir);

db.applications.remove({_id : "fhir_terminology"});
db.applications.insert(fhir_terminology);

db.applications.remove({_id : "pwp_backend"});
db.applications.insert(pwp_backend);