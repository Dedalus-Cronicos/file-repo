//db.createCollection("subscriptions");
//db.createCollection("subscriptionTopics");
//db.createCollection('fhir_sequence');
//db.createCollection('bundles');
//db.createCollection('payloads_mail');
//db.createCollection('payloads_ntf_002');

//db.createCollection('fhir_search_modifier');

db.getCollection('fhir_search_modifier').insertOne(
	{
		"name": "fhirSearchModifiers",
		"modifiers": [
			{
				"code": "=",
				"queryStringModifier": "="

			},
			{
				"code": "eq",
				"queryStringModifier": "=eq"
			},
			{
				"code": "ne",
				"queryStringModifier": "=ne"
			},
			{
				"code": "gt",
				"queryStringModifier": "=gt"
			},
			{
				"code": "ge",
				"queryStringModifier": "=ge"
			},
			{
				"code": "le",
				"queryStringModifier": "=le"
			},
			{
				"code": "lt",
				"queryStringModifier": "=lt"
			},
			{
				"code": "sa",
				"queryStringModifier": "=sa"
			},
			{
				"code": "eb",
				"queryStringModifier": "=eb"
			},
			{
				"code": "ap",
				"queryStringModifier": "=ap"
			},
			{
				"code": "above",
				"queryStringModifier": ":above="
			},
			{
				"code": "below",
				"queryStringModifier": ":below="
			},
			{
				"code": "in",
				"queryStringModifier": ":in="
			},
			{
				"code": "not-in",
				"queryStringModifier": ":not-in="
			},
			{
				"code": "of-type",
				"queryStringModifier": ":of-type="
			},
			{
				"code": "not",
				"queryStringModifier": ":not="
			},
			{
				"code": "contains",
				"queryStringModifier": ":contains="
			},
			{
				"code": "exact",
				"queryStringModifier": ":exact="
			},
			{
				"code": "text",
				"queryStringModifier": ":text="
			}

		]
	}
);

db.getCollection('subscriptionTopics').createIndex({"content.url":1, "versionId" : 1},{unique:true});


//db.createCollection('profiles');
//db.createCollection('fhir_loadProfiles');
db.fhir_loadProfiles.createIndex( { "type": 1, "hosts": 1}, { unique: false , name: "fhir_loadProfilesIndex"} );



//SUBSCRIPTION

var subscriptionFiles;
try {
subscriptionFiles=fs.readdirSync('DefaultSubscription',{ withFileTypes: true });
} catch (error) {
	subscriptionFiles= listFiles('DefaultSubscription');
}
var seq, id, tot;
var insertDateString;
var dateString;
var longDateString;
var currentUrl, currentVersion;
for (var index = 0; index < subscriptionFiles.length; index++) {
	var subscription;
	try{
		var nameFile= 'DefaultSubscription/'+subscriptionFiles[index].name;		
		subscription= fs.readFileSync(nameFile,'utf8');
	}catch(e){
		subscription= cat(subscriptionFiles[index].name);
	}
	printjson('subscription: ' + subscription);
	var subscriptionJson = JSON.parse(subscription)
	currentVersion = subscriptionJson.fhirVersion
	printjson('currentVersion: ' + currentVersion);

	tot = db.fhir_sequence.find({ '_id': 'Subscription' }).count();
	printjson('sequence tot: ' + tot);
	if (tot == 0) {
		db.fhir_sequence.insertOne({ '_id': 'Subscription', 'seq': NumberInt(1) });
	}

	seq = db.fhir_sequence.findAndModify({ query: { '_id': 'Subscription' }, update: { $inc: { seq:  NumberInt(1)  } } });
	printjson('sequence: ' + seq.seq );
	id = 'Subscription/' + seq.seq;
	subscriptionJson._id = id;
	subscriptionJson.id = id;
	subscriptionJson.content.id = '' + seq.seq;

	var currentDate = new Date();
	print(currentDate);
	var month = currentDate.getMonth() + 1;
	var monthString = month.toString();
	if (monthString.length == 1) {
		monthString = '0' + monthString;
	}

	var day = currentDate.getDate();
	var dayString = day.toString();
	if (dayString.length == 1) {
		dayString = '0' + dayString;
	}

	var hour = currentDate.getHours();
	var hourString = hour.toString();
	if (hourString.length == 1) {
		hourString = '0' + hourString;
	}

	var minutes = currentDate.getMinutes();
	var minutesString = minutes.toString();
	if (minutesString.length == 1) {
		minutesString = '0' + minutesString;
	}

	var seconds = currentDate.getSeconds();
	var secondsString = seconds.toString();
	if (secondsString.length == 1) {
		secondsString = '0' + secondsString;
	}

	insertDateString = currentDate.getFullYear() + monthString + dayString + hourString + minutesString + secondsString;
	print('insertDateString: ' + insertDateString);
	longDateString = currentDate.getFullYear() + '' + monthString + dayString + '000000';
	print('longDateString: ' + longDateString);
	dateString = currentDate.getFullYear() + '-' + monthString + '-' + dayString;
	print('dateString: ' + dateString);
	subscriptionJson.dateLong = parseInt(longDateString);
	subscriptionJson.insertDate = parseInt(insertDateString);

	subscriptionJson.fhirVersion = 'R5';
	db.subscriptions.insertOne(subscriptionJson)
}




//SUBSCRIPTION_TOPIC
var subscriptionTopicFiles;
try{
subscriptionTopicFiles=fs.readdirSync('DefaultSubscriptionTopic',{ withFileTypes: true } )
}catch (error){
	subscriptionTopicFiles= listFiles('DefaultSubscriptionTopic');
}

var seq, id, tot;
var insertDateString;
var dateString;
var longDateString;
var currentUrl, currentVersion;
for (var index = 0; index < subscriptionTopicFiles.length; index++) {
	var subscriptionTopic;
	try{
		var nameFileT= 'DefaultSubscriptionTopic/'+subscriptionTopicFiles[index].name;
		subscriptionTopic= fs.readFileSync(nameFileT,'utf8');
		
	}catch(e){
		subscriptionTopic= cat(subscriptionTopicFiles[index].name);
	}
	printjson('subscriptionTopic: ' + subscriptionTopic);
	var subscriptionTopicJson = JSON.parse(subscriptionTopic)
	currentVersion = subscriptionTopicJson.fhirVersion
	printjson('currentVersion: ' + currentVersion);

	currentUrl = subscriptionTopicJson.content.url;
	printjson('currentUrl: ' + currentUrl);

	tot = db.fhir_sequence.find({ '_id': 'SubscriptionTopic' }).count();
	printjson('sequence tot: ' + tot);
	if (tot == 0) {
		db.fhir_sequence.insertOne({ '_id': 'SubscriptionTopic', 'seq': NumberInt(1) });
	}

	seq = db.fhir_sequence.findAndModify({ query: { '_id': 'SubscriptionTopic' }, update: { $inc: { seq:  NumberInt(1)  } } });
	printjson('sequence: ' + seq.seq );
	id = 'SubscriptionTopic/' + seq.seq;
	subscriptionTopicJson._id = id;
	subscriptionTopicJson.id = id;
	subscriptionTopicJson.content.id = '' + seq.seq;

	var currentDate = new Date();
	print(currentDate);
	var month = currentDate.getMonth() + 1;
	var monthString = month.toString();
	if (monthString.length == 1) {
		monthString = '0' + monthString;
	}

	var day = currentDate.getDate();
	var dayString = day.toString();
	if (dayString.length == 1) {
		dayString = '0' + dayString;
	}

	var hour = currentDate.getHours();
	var hourString = hour.toString();
	if (hourString.length == 1) {
		hourString = '0' + hourString;
	}

	var minutes = currentDate.getMinutes();
	var minutesString = minutes.toString();
	if (minutesString.length == 1) {
		minutesString = '0' + minutesString;
	}

	var seconds = currentDate.getSeconds();
	var secondsString = seconds.toString();
	if (secondsString.length == 1) {
		secondsString = '0' + secondsString;
	}

	insertDateString = currentDate.getFullYear() + monthString + dayString + hourString + minutesString + secondsString;
	print('insertDateString: ' + insertDateString);
	longDateString = currentDate.getFullYear() + '' + monthString + dayString + '000000';
	print('longDateString: ' + longDateString);
	dateString = currentDate.getFullYear() + '-' + monthString + '-' + dayString;
	print('dateString: ' + dateString);
	subscriptionTopicJson.dateLong = parseInt(longDateString);
	subscriptionTopicJson.insertDate = parseInt(insertDateString);
	subscriptionTopicJson.fhirVersion = 'R5';
	db.subscriptionTopics.insertOne(subscriptionTopicJson)
}

//db.createCollection("pull_point_subscriptions");
//creazione della collection che avrà SubscriptionUUID, status, insertDate, insertDateLong 
//db.getCollection('pull_point_subscriptions').insert(...
db.getCollection('pull_point_subscriptions').createIndex({"subscriptionUUID":1, "status" : 1},{unique:true});

db.subscriptionTopics.createIndex( { 'status' : 1, 'content.resourceTrigger.resource': 1 } , { sparse: true, name: 'topicResourceIndex'});
db.subscriptionTopics.createIndex( { 'status' : 1, 'content.resourceTrigger.resource': 1, 'content.status': 1 } , { sparse: true, name: 'topicResAndStatusIndex'});


db.subscriptions.createIndex( { 'status' : 1, 'content.topic': 1} ,{ sparse: true, name: 'subTopicIndex'});
db.subscriptions.createIndex( { 'status' : 1, 'content.topic': 1, 'content.status': 1},{ sparse: true, name: 'subTopicAndStatusIndex'});
db.subscriptions.createIndex( { 'status' : 1, 'content.filterBy.resourceType': 1, 'content.filterBy.searchParamName': 1, 'content.filterBy.value': 1},{ sparse: true, name: 'subFilterByIndex'});



