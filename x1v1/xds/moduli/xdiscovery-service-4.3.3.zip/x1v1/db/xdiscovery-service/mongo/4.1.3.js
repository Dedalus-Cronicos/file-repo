
db.getCollection("schema_version").insertOne(
    {
        "major" : "4",
        "minor" : "1",
        "patch" : "3",
        "tag" : "xdiscovery-service",
        "revision" : 0,
        "last_change" : ISODate("2022-10-22T12:24:27.604+02:00"),
        "description" : ""
    }
);

db.getCollection('DS_RegisteredClient').insertOne(
    {
         "clientId" : "qPSaOguUdMybiM86",
         "nameIdentifier" : "Document-central",
         "secret" : "ho9qLInTO8T2ccnT",
         "userRoleProvisioningURL" : "https://localdomain:8080/dc4h/hpdx/api/auth/Profile",
         "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
         "serverLocationUri" : "https://localdomain",
         "queryBy" : "username",
         "subjectAA" : "urn:oid:2.16.840.1.113883.2.9.3.12.4.2"
    }
);
