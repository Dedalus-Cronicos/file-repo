
db.createCollection("schema_version");

db.getCollection("schema_version").insert(
    {
        "major" : "4",
        "minor" : "1",
        "patch" : "1",
        "tag" : "xdiscovery-service",
        "revision" : 0,
        "last_change" : ISODate("2022-03-16T16:53:27.604+02:00"),
        "description" : ""
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "RVE1DAUTHENTICATEANDGETASSERTION",
          "secret" : "kppi7WZiycOxd4Ip",
          "serverLocationUri" : "https://localhost",
          "owner" : "RVE1D AUTHENTICATE_AND_GET_ASSERTION",
          "nameIdentifier" : "RVE1D AUTHENTICATE_AND_GET_ASSERTION",
          "userRoleProvisioningURL" : "https://servername:serverport/people-auth/rest/Profile",
          "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
          "queryBy" : "username",
          "subjectAA" : "urn:oid:2.16.840.1.113883.2.9.4.3.2"
    }
);

db.getCollection('DS_RegisteredClient').insert(
    {
          "clientId" : "amGjnx2kqSB3X6LR",
          "secret" : "elCuxdT0sCP2Fb4L",
          "serverLocationUri" : "http://audit-8080-tcp-cronicos-desa-helm.apps.lab.okd4.local",
          "owner" : "Audit",
          "nameIdentifier" : "Audit",
          "userRoleProvisioningURL" : "http://hpdx-8080-tcp-cronicos-desa.apps.lab.okd4.local/hpdx/api/auth/Profile",
          "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
          "queryBy" : "username",
          "subjectAA" : "Subject"
    }
);