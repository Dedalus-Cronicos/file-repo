db.subscriber.remove({ name: "AuditEventSTU3" });
db.subscriber.remove({ name: "auth-003" });
db.subscriber.remove({ name: "auth-005" });
db.subscriber.remove({ name: "auth-006" });
db.subscriber.remove({ name: "ds_login_password_expired" });
db.subscriber.remove({ name: "ds_login_user_unknown" });
db.subscriber.remove({ name: "ds_login_wrong_password" });
db.subscriber.remove({ name: "ds_login" });
db.subscriber.remove({ name: "ds_logout" });

db.subscriber.insert(auditEventSTU3);
db.subscriber.insert(auth_003);
db.subscriber.insert(auth_005);
db.subscriber.insert(auth_006);
db.subscriber.insert(ds_login_password_expired);
db.subscriber.insert(ds_login_user_unknown);
db.subscriber.insert(ds_login_wrong_password);
db.subscriber.insert(ds_login);
db.subscriber.insert(ds_logout);
