db.x1v1_configuration.remove({key : "ConsentCollector"});
db.x1v1_configuration.remove({key : "xvalue-task-manager"});
db.x1v1_configuration.insert(ConsentCollector);
db.x1v1_configuration.insert(xvalue_task_manager);
  