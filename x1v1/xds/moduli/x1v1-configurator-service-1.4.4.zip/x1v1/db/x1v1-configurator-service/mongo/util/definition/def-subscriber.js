var consentPeople_file = cat('util/ftl/consentPeople.ftl');
var consentSTU3_file = cat('util/ftl/consentSTU3.ftl');
var consentAudit_file = cat('util/ftl/consentAudit.ftl');
var sharingContextAudit_file = cat('util/ftl/sharingContextAudit.ftl');
var auditEventSTU3_file = cat('util/ftl/auditEventSTU3.ftl');
var ITI_18_file = cat('util/ftl/AuditEvent-ITI_18.ftl');
var ITI_41_file = cat('util/ftl/AuditEvent-ITI_41.ftl');
var ITI_42_file = cat('util/ftl/AuditEvent-ITI_42.ftl');
var ITI_43_file = cat('util/ftl/AuditEvent-ITI_43.ftl');
var ITI_57_file = cat('util/ftl/AuditEvent-ITI_57.ftl');
var ITI_62_file = cat('util/ftl/AuditEvent-ITI_62.ftl');


var auth_003_file = cat('util/ftl/auth-003.ftl');
var auth_005_file = cat('util/ftl/auth-005.ftl');
var auth_006_file = cat('util/ftl/auth-006.ftl');
var ds_login_password_expired_file = cat('util/ftl/ds_login_password_expired.ftl');
var ds_login_user_unknown_file = cat('util/ftl/ds_login_user_unknown.ftl');
var ds_login_wrong_password_file = cat('util/ftl/ds_login_wrong_password.ftl');
var ds_login_file = cat('util/ftl/ds_login.ftl');
var ds_logout_file = cat('util/ftl/ds_logout.ftl');





var consentPeople = {
    "name": "consentPeople",
    "contentType": "application/json",
    "url": "http://@mpi@@domain.internal.mpi@@mpi.context@/Consent",
    "status": true,
    "value": consentPeople_file
};

var consentSTU3 = {
    "name": "consentSTU3",
    "contentType": "application/json",
    "url": "http://@fhir@@domain.internal.xds@/x1v1-fhir-clinical/fhir/Consent",
    "status": true,
    "value": consentSTU3_file
};

var consentAudit = {
    "name": "consentAudit",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": consentAudit_file
};

var auditEventSTU3 = {
    "name": "AuditEventSTU3",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": auditEventSTU3_file
};

var sharingContextAudit = {
    "name": "sharingContextAudit",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": sharingContextAudit_file
};

var ITI_18 = {
    "name": "ITI_18",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_18_file
};

var ITI_41 = {
    "name": "ITI_41",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_41_file
};

var ITI_42 = {
    "name": "ITI_42",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_42_file
};

var ITI_43 = {
    "name": "ITI_43",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_43_file
};

var ITI_57 = {
    "name": "ITI_57",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_57_file
};

var ITI_62 = {
    "name": "ITI_62",
    "contentType": "application/xml",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ITI_62_file
};

var auth_003 = {
    "name": "auth-003",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": auth_003_file
};

var auth_005 = {
    "name": "auth-005",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": auth_005_file
};

var auth_006 = {
    "name": "auth-006",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": auth_006_file
};

var ds_login_password_expired = {
    "name": "ds_login_password_expired",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ds_login_password_expired_file
};

var ds_login_user_unknown = {
    "name": "ds_login_user_unknown",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ds_login_user_unknown_file
};

var ds_login_wrong_password = {
    "name": "ds_login_wrong_password",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ds_login_wrong_password_file
};

var ds_login = {
    "name": "ds_login",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ds_login_file
};

var ds_logout = {
    "name": "ds_logout",
    "contentType": "application/json",
    "url": "http://@audit@@domain.internal.xds@/x1v1-arr-service/arr-fhir/AuditEvent",
    "status": true,
    "value": ds_logout_file
};



