var notifyPersistenceConfig = { 
    "key" : "notifyPersistenceConfig", 
    "data" : {
        "active" : true, 
        "startDelay" : NumberInt(3000), 
        "repeatInterval" : NumberInt(30000), 
        "redeliveryInterval" : NumberInt(600000), 
        "maxRedeliveries" : NumberInt(5)
    }
};

var jmsConfig = {
    "key" : "jmsConfig",
    "data" : {
        "JMSSessionCacheSize" : "10",
        "JMSBrokerURL" : "@activemq.broker.url@",
        "destinations" : "notifyQueue",
        "jmsEnabled" : true,
        "enableAuth" : "@activemq.broker.enableAuth@",
        "username" : "@activemq.broker.username@",
        "password" : "@activemq.broker.password@"
    }
};