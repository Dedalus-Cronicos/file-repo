db.subscriber.remove({ name: "AuditEventSTU3" });


db.subscriber.insert(auditEventSTU3);

