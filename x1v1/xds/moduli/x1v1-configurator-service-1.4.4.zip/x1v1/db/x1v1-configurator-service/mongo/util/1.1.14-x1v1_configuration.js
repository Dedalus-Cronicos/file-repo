db.x1v1_configuration.remove({key : "PatientSynoptic"});
db.x1v1_configuration.insert(PatientSynoptic);