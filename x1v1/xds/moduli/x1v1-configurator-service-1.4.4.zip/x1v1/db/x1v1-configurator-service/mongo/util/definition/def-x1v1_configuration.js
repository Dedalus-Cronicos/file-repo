var xvalue_task_manager = {
		"key" : "xvalue-task-manager",
		"type" : "taskManager",
		"data" : {
			"langs" : [
				"en-GB",
				"it-IT"
			],
			"defaultLang" : "it-IT",
			"storage" : "session",
			"customPropertiesGroups" : [
				{
					"groupKey" : "processingHandler",
					"properties" : {
						"enabled" : false,
						"implementationClasses" : true
					}
				}
			],
			"environmentLinks" : {
				"serverURL" : "@domain.public.protocol@://@fhir@@domain.public@",
				"clinicalEndPoint" : "/x1v1-fhir-clinical/fhir",
				"terminologyEndPoint" : "/x1v1-fhir-terminology/fhir",
				"activityDefinitionEndPoint" : "/ActivityDefinition",
				"planDefinitionEndPoint" : "/PlanDefinition",
				"structureDefinitionEndPoint" : "/StructureDefinition",
				"codeSystemEndPoint" : "/CodeSystem"
			},
			"auth" : {
				"method" : "dev",
				"url" : "@domain.public.protocol@://@ds@@domain.public@/xdiscovery-service"
			},
			"languageSettings" : {
				"defaultLanguage" : "it-IT",
				"availableLanguages" : [
					"en-GB",
					"it-IT",
					"de-DE"
				]
			},
			"containers" :  [
            {
                "searchType" : "codeSystem", 
                "active" : true, 
                "searchUrl" : "fhir", 
                "detailsUrl" : "", 
                "backgroundColor" : "rgb(211, 225, 243)", 
                "styleColor" : "rgb(92, 144, 184)", 
                "iconClass" : "fa fa-h-square fa-lg", 
                "title" : "Code System", 
                "settings" : {
                    "attr" : {
                        "class" : "table-hero"
                    }, 
                    "columns" : {
                        "resource_id" : {
                            "title" : "identifier", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.id"
                            }, 
                            "bundleKey" : "resource.id"
                        }, 
                        "resource_name" : {
                            "title" : "Title", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.name"
                            }, 
                            "bundleKey" : "resource.name"
                        }, 
                        "resource_status" : {
                            "title" : "Status", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.status"
                            }, 
                            "bundleKey" : "resource.status"
                        }, 
                        "resource_date" : {
                            "title" : "Date", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.date"
                            }, 
                            "bundleKey" : "resource.date"
                        }, 
                        "resource_publisher" : {
                            "title" : "Publisher", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.publisher"
                            }, 
                            "bundleKey" : "resource.publisher"
                        }
                    }, 
                    "hideFilter" : true, 
                    "hideFooter" : false, 
                    "actions" : {
                        "add" : false, 
                        "edit" : false, 
                        "delete" : false
                    }
                }, 
                "searchForm" : [
                    [
                        {
                            "value" : "", 
                            "key" : "notDateFrom", 
                            "label" : "From", 
                            "required" : false, 
                            "order" : NumberInt(1), 
                            "controlType" : "date", 
                            "checkValues" : [

                            ], 
                            "queryString" : "date=ge?"
                        }, 
                        {
                            "value" : "", 
                            "key" : "notDateTo", 
                            "label" : "To", 
                            "required" : false, 
                            "order" : NumberInt(2), 
                            "controlType" : "date", 
                            "checkValues" : [

                            ], 
                            "queryString" : "date=le?"
                        }
                    ], 
                    [
                        {
                            "value" : "", 
                            "key" : "codeName", 
                            "label" : "Name", 
                            "required" : false, 
                            "order" : NumberInt(3), 
                            "controlType" : "text", 
                            "checkValues" : [

                            ], 
                            "queryString" : "name:contains=?"
                        }, 
                        {
                            "value" : "", 
                            "key" : "status", 
                            "label" : "Status", 
                            "required" : false, 
                            "order" : NumberInt(2), 
                            "controlType" : "selectWithDisplay", 
                            "checkValues" : [
                                {
                                    "code" : "draft", 
                                    "display" : "Draft"
                                }, 
                                {
                                    "code" : "active", 
                                    "display" : "Active"
                                }, 
                                {
                                    "code" : "retired", 
                                    "display" : "Retired"
                                }, 
                                {
                                    "code" : "unknown", 
                                    "display" : "Unknown"
                                }
                            ], 
                            "queryString" : "status=?"
                        }
                    ]
                ], 
                "url" : "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-terminology/fhir/CodeSystem?_format=application/json", 
                "urlDetailRouting" : "/codeSystemDetail", 
                "urlNewRouting" : "/codeSystemDetail"
            }, 
            {
                "searchType" : "planDef", 
                "active" : true, 
                "searchUrl" : "fhir", 
                "detailsUrl" : "", 
                "backgroundColor" : "rgb(221, 221, 221)", 
                "styleColor" : "rgb(128, 126, 109)", 
                "iconClass" : "fa fa-file-text-o fa-lg", 
                "title" : "Plan definition", 
                "settings" : {
                    "attr" : {
                        "class" : "table-hero"
                    }, 
                    "columns" : {
                        "resource_id" : {
                            "title" : "identifier", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.id"
                            }, 
                            "bundleKey" : "resource.id"
                        }, 
                        "resource_name" : {
                            "title" : "Title", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.name"
                            }, 
                            "bundleKey" : "resource.name"
                        }, 
                        "resource_status" : {
                            "title" : "Status", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.status"
                            }, 
                            "bundleKey" : "resource.status"
                        }, 
                        "resource_date" : {
                            "title" : "Date", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.date"
                            }, 
                            "bundleKey" : "resource.date"
                        }, 
                        "resource_publisher" : {
                            "title" : "Publisher", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.publisher"
                            }, 
                            "bundleKey" : "resource.publisher"
                        }
                    }, 
                    "hideFilter" : true, 
                    "hideFooter" : false, 
                    "actions" : {
                        "add" : true, 
                        "edit" : false, 
                        "delete" : false
                    }
                }, 
                "searchForm" : [
                    [
                        {
                            "value" : "", 
                            "key" : "source", 
                            "label" : "Code System", 
                            "required" : false, 
                            "order" : NumberInt(1), 
                            "controlType" : "selectWithDisplay", 
                            "datasource" : {
                                "url" : "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-terminology/fhir/CodeSystem?_format=application/json&_count=100", 
                                "code" : "$.entry[*].resource.id", 
                                "display" : "$.entry[*].resource.name"
                            }, 
                            "checkValues" : [

                            ], 
                            "queryString" : "codeSystem=?"
                        }, 
                        {
                            "value" : "", 
                            "key" : "codeName", 
                            "label" : "Name", 
                            "required" : false, 
                            "order" : NumberInt(3), 
                            "controlType" : "text", 
                            "checkValues" : [

                            ], 
                            "queryString" : "name:contains=?"
                        }
                    ], 
                    [
                        {
                            "value" : "", 
                            "key" : "status", 
                            "label" : "Status", 
                            "required" : false, 
                            "order" : NumberInt(2), 
                            "controlType" : "selectWithDisplay", 
                            "checkValues" : [
                                {
                                    "code" : "draft", 
                                    "display" : "Draft"
                                }, 
                                {
                                    "code" : "active", 
                                    "display" : "Active"
                                }, 
                                {
                                    "code" : "retired", 
                                    "display" : "Retired"
                                }, 
                                {
                                    "code" : "unknown", 
                                    "display" : "Unknown"
                                }
                            ], 
                            "queryString" : "status=?"
                        }
                    ]
                ], 
                "url" : "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/PlanDefinition?_format=application/json", 
                "urlDetailRouting" : "/planDefDetail", 
                "urlNewRouting" : "/planDefDetail"
            }, 
            {
                "searchType" : "activityDef", 
                "active" : true, 
                "searchUrl" : "notifiche", 
                "detailsUrl" : "serieViewer", 
                "backgroundColor" : "rgb(255, 204, 212)", 
                "styleColor" : "rgb(255, 0, 38)", 
                "iconClass" : "fa fa-hospital-o fa-lg", 
                "title" : "Activity definition", 
                "settings" : {
                    "attr" : {
                        "class" : "table-hero"
                    }, 
                    "columns" : {
                        "resource_id" : {
                            "title" : "identifier", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.id"
                            }, 
                            "bundleKey" : "resource.id"
                        }, 
                        "resource_name" : {
                            "title" : "Title", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.name"
                            }, 
                            "bundleKey" : "resource.name"
                        }, 
                        "resource_status" : {
                            "title" : "Status", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.status"
                            }, 
                            "bundleKey" : "resource.status"
                        }, 
                        "resource_date" : {
                            "title" : "Date", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.date"
                            }, 
                            "bundleKey" : "resource.date"
                        }, 
                        "resource_publisher" : {
                            "title" : "Publisher", 
                            "editable" : false, 
                            "sort" : false, 
                            "labelFunction" : "readByDataJsonPath", 
                            "data" : {
                                "jsonPath" : "resource.publisher"
                            }, 
                            "bundleKey" : "resource.publisher"
                        }
                    }, 
                    "hideFilter" : true, 
                    "hideFooter" : false, 
                    "actions" : {
                        "add" : false, 
                        "edit" : false, 
                        "delete" : false
                    }
                }, 
                "searchForm" : [
                    [
                        {
                            "value" : "", 
                            "key" : "codeSystem", 
                            "label" : "Code System", 
                            "required" : false, 
                            "order" : NumberInt(1), 
                            "controlType" : "selectWithDisplay", 
                            "datasource" : {
                                "url" : "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-terminology/fhir/CodeSystem?_format=application/json&_count=100", 
                                "code" : "$.entry[*].resource.id", 
                                "display" : "$.entry[*].resource.name"
                            }, 
                            "checkValues" : [

                            ], 
                            "queryString" : "codeSystem=?"
                        }, 
                        {
                            "value" : "", 
                            "key" : "planDefinition", 
                            "label" : "Plan Definition", 
                            "required" : false, 
                            "order" : NumberInt(1), 
                            "controlType" : "selectWithDisplay", 
                            "datasource" : {
                                "url" : "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/PlanDefinition?_format=application/json&_count=100", 
                                "code" : "$.entry[*].resource.id", 
                                "display" : "$.entry[*].resource.name"
                            }, 
                            "checkValues" : [

                            ], 
                            "queryString" : "planDefinitionId=?"
                        }
                    ], 
                    [
                        {
                            "value" : "", 
                            "key" : "codeName", 
                            "label" : "Name", 
                            "required" : false, 
                            "order" : NumberInt(3), 
                            "controlType" : "text", 
                            "checkValues" : [

                            ], 
                            "queryString" : "name:contains=?"
                        }, 
                        {
                            "value" : "", 
                            "key" : "status", 
                            "label" : "Status", 
                            "required" : false, 
                            "order" : NumberInt(1), 
                            "controlType" : "selectWithDisplay", 
                            "checkValues" : [
                                {
                                    "code" : "draft", 
                                    "display" : "Draft"
                                }, 
                                {
                                    "code" : "active", 
                                    "display" : "Active"
                                }, 
                                {
                                    "code" : "retired", 
                                    "display" : "Retired"
                                }, 
                                {
                                    "code" : "unknown", 
                                    "display" : "Unknown"
                                }
                            ], 
                            "queryString" : "status=?"
                        }
                    ]
                ], 
                "url" : "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/ActivityDefinition?_format=application/json", 
                "urlDetails" : "", 
                "urlDetailRouting" : "/activityDefDetail", 
                "urlNewRouting" : "/activityDefDetail"
            }
        ]
		}
	};

var ConsentCollector ={
        "key": "ConsentCollector",
        "data": {
            "langs": [
                "en-GB",
                "it-IT",
                "de-DE"
            ],
            "defaultLang": "it-IT",
            "storage": "session",
            "customPropertiesGroups": [],
            "environmentLinks": {
                "backUrl": "",
                "profile": "",
                "civicNetwork": "",
                "logoutRedirectUrl": ""
            },
            "contextPath": "consent-collector",
            "debug": true,
            "logoutMode": "event",
            "auth": {
                "method": "ds",
                "url": "/xdiscovery-service",
                "client_id": "ODufuxmcA5ECdcMF",
                "client_secret": "9$APrIT04w8GtZM7",
                "scope": {
                    "profile": true
                },
                "store": true
            },
            "tutorVisibilityFlag": "true",
            "guardianVisibilityFlag": "true",
            "showHistory": "true",
            "showHistorySearch": "false",
            "hidedHistoricalConsents": "",
            "showPrintBundle": "true",
            "toolbarPosition": "bottom",
            "periodEndDate": "2099-12-31",
            "graphometricIntegration": false,
            "clientPollingInterval": NumberInt(6000),
            "consent100Public": "@domain.public.protocol@://@consent@@domain.public@/consent-engine",
            "consent100SubPath": "/consent/100",
            "mode": "standalone",
            "allergyFhirServiceUrl": "/x1v1-fhir-clinical/fhir/AllergyIntolerance?_format=application/json",
            "allergyAvailable": true,
            "patientLayout": "banner",
            "taxcodeSystemCodeExternalSystem": "TAX",
            "taxcodeSystemCode": "2.16.840.1.113883.2.9.4.3.2",
            "identifierSystemCode": "2.16.840.1.113883.2.9.3.12.4.1",
            "birthplaceSystemCode": "http://hl7.org/fhir/structuredefinition/birthplace",
            "addressCitySystemCode": "http://xvalue.dedalus.eu/dm/Address#city-code",
            "telecomSystemCode": "phone",
            "patientPhotoUrl": null,
            "downloadFile": true,
            "fhirPatientService": "/patientFhir",
            "dictionary": "/configurationbykey/",
            "guardianRolesKey": "enumGuardianRole",
            "consentOpenedOnInit": false,
            "containers": [
                {
                    "key": "search-patient",
                    "navType": "piechart",
                    "values": [
                        {
                            "searchType": "searchPatient",
                            "active": true,
                            "searchUrl": "fhir",
                            "detailsUrl": "",
                            "backgroundColor": "rgb(211, 225, 243)",
                            "styleColor": "rgb(92, 144, 184)",
                            "iconClass": "fa fa-h-square fa-lg",
                            "title": "Ricerca Paziente",
                            "settings": {
                                "attr": {
                                    "class": "table-hero"
                                },
                                "columns": {
                                    "resource_id": {
                                        "title": "Identifier",
                                        "editable": false,
                                        "sort": false,
                                        "labelFunction": "readByDataJsonPath",
                                        "data": {
                                            "jsonPath": "resource.id"
                                        },
                                        "bundleKey": "Identifier"
                                    },
                                    "resource_surname": {
                                        "title": "Surname",
                                        "editable": false,
                                        "sort": false,
                                        "labelFunction": "readByDataJsonPath",
                                        "data": {
                                            "jsonPath": "resource.name[0].family"
                                        },
                                        "bundleKey": "Surname"
                                    },
                                    "resource_name": {
                                        "title": "Name",
                                        "editable": false,
                                        "sort": false,
                                        "labelFunction": "readByDataJsonPath",
                                        "data": {
                                            "jsonPath": "resource.name[0].given"
                                        },
                                        "bundleKey": "Name"
                                    },
                                    "resource_birth_date": {
                                        "title": "Birth Date",
                                        "editable": false,
                                        "sort": false,
                                        "labelFunction": "readByDataJsonPath",
                                        "data": {
                                            "jsonPath": "resource.birthDate"
                                        },
                                        "bundleKey": "Birthdate"
                                    },
                                    "resource_taxcode": {
                                        "title": "Taxcode",
                                        "editable": false,
                                        "sort": false,
                                        "labelFunction": "readByDataJsonPath",
                                        "data": {
                                            "jsonPath": "resource.identifier[?(@.system=='2.16.840.1.113883.2.9.4.3.2')].value"
                                        },
                                        "bundleKey": "Taxcode"
                                    }
                                },
                                "hideFilter": true,
                                "hideFooter": false,
                                "actions": {
                                    "add": false,
                                    "edit": false,
                                    "delete": false
                                }
                            },
                            "searchForm": [
                                [
                                    {
                                        "value": "",
                                        "key": "surname",
                                        "label": "Surname",
                                        "required": true,
                                        "order": NumberInt(1),
                                        "controlType": "text",
                                        "checkValues": [],
                                        "queryString": "family=?"
                                    },
                                    {
                                        "value": "",
                                        "key": "name",
                                        "label": "Name",
                                        "required": true,
                                        "order": NumberInt(2),
                                        "controlType": "text",
                                        "checkValues": [],
                                        "queryString": "given=?"
                                    },
                                    {
                                        "value": "",
                                        "key": "taxcode",
                                        "label": "Taxcode",
                                        "required": false,
                                        "order": NumberInt(3),
                                        "controlType": "text",
                                        "checkValues": [],
                                        "queryString": "identifier=?"
                                    }
                                ],
                                [
                                    {
                                        "value": "",
                                        "key": "gender",
                                        "label": "Gender",
                                        "required": false,
                                        "order": NumberInt(2),
                                        "controlType": "selectWithDisplay",
                                        "checkValues": [
                                            {
                                                "code": "female",
                                                "display": "Female"
                                            },
                                            {
                                                "code": "male",
                                                "display": "Male"
                                            }
                                        ],
                                        "queryString": "gender=?"
                                    },
                                    {
                                        "value": "",
                                        "key": "birthdate",
                                        "label": "Birthdate",
                                        "required": false,
                                        "order": NumberInt(1),
                                        "controlType": "date",
                                        "checkValues": [],
                                        "queryString": "birthdate=?"
                                    }
                                ]
                            ],
                            "url": "@mpi.context@/Patient?_format=application/json&_count=10",
                            "urlDetailRouting": "/search-patient-bundle"
                        }
                    ]
                },
                {
                    "key": "search-patient-bundle",
                    "navType": "tab",
                    "values": [
                        {
                            "searchType": "patientBundles",
                            "active": true,
                            "searchUrl": "ConsentEngine",
                            "detailsUrl": "",
                            "backgroundColor": "rgb(211, 225, 243)",
                            "styleColor": "rgb(92, 144, 184)",
                            "iconClass": "fa fa-h-square fa-lg",
                            "title": "Raccolta consensi paziente",
                            "settings": {
                                "attr": {
                                    "class": "table-hero"
                                },
                                "columns": {
                                    "resource_bundles": {
                                        "title": "bundles",
                                        "editable": false,
                                        "sort": false,
                                        "labelFunction": "readByDataJsonPath",
                                        "data": {
                                            "jsonPath": "display"
                                        },
                                        "bundleKey": "bundles_table"
                                    },
                                    "resource_status": {
                                        "title": "status",
                                        "editable": false,
                                        "sort": false,
                                        "type": "custom",
                                        "labelFunction": "readByDataJsonPath",
                                        "data": {
                                            "jsonPath": "itemsConsent[*]"
                                        },
                                        "bundleKey": "status_table",
                                        "renderComponent": "ConsentStatusRenderComponent"
                                    }
                                },
                                "hideFilter": true,
                                "hideFooter": false,
                                "actions": {
                                    "add": false,
                                    "edit": false,
                                    "delete": false
                                }
                            },
                            "searchForm": [
                                [
                                    {
                                        "value": "",
                                        "key": "patientId",
                                        "label": "Identifier",
                                        "required": false,
                                        "order": NumberInt(1),
                                        "controlType": "text",
                                        "checkValues": [],
                                        "queryString": "patientid=?"
                                    }
                                ]
                            ],
                            "url": "/consentCollector/patients/bundles?language=it-IT",
                            "urlDetailRouting": "/home/model",
                            "searchVisible": false,
                            "autoSearch": true
                        }
                    ]
                }
            ]
        }
    
}

var PatientSynoptic = {
        "key": "PatientSynoptic",
        "data": {
            "langs": [
                "en-GB",
                "it-IT",
                "fr-FR",
                "zh-CN"
            ],
            "debug": true,
            "silent": true,
            "contextEnabled": true,
            "contextPath": "patient-synoptic",
            "auth": {
                "method": "ds",
                "url": "@domain.public.protocol@://@ds@@domain.public@/xdiscovery-service",
                "client_id": "",
                "client_secret": "",
                "scope": {
                    "profile": true
                },
                "store": true
            },
            "i18n": [
                "core",
                "forms",
                "feedback",
                "admin",
                "theme",
                "s4h-dashboard",
                "s4h-core",
                "s4h-timeline"
            ],
            "formDefs": "@domain.public.protocol@://@config@@domain.public@/configuration/S4HFormModel/",
            "patientUrl": "@domain.public.protocol@://@mpi@@domain.public@@mpi.context@",
            "serverFhirUrl": "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/",
            "clinicalPortalConfigUrl": "@domain.public.protocol@://@config@@domain.public@/configuration/",
            "clinicalPortalConfigUrlDefault": "@domain.public.protocol@://@config@@domain.public@/configuration/S4HClinicalPortal/",
            "widgetResourceConfigUrl": "@domain.public.protocol@://@config@@domain.public@/configuration/S4HResourcePathTest/",
            "patient-banner-configuration": {
                "patientUrl": "@domain.public.protocol@://@mpi@@domain.public@@mpi.context@",
                "serverFhirUrl": "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/",
                "allergyIntolleranceUrl": "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/AllergyIntolerance?_format=application/json&_count=10",
                "procedureUrl": "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/Procedure?_format=application/json&_count=10"
            },
            "diagnostic-report": {
                "table_configuration": "@domain.public.protocol@://@config@@domain.public@/configuration/S4HDiagnosticReportListConfiguration",
                "current": {
                    "endpoint": "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/DiagnosticReport",
                    "diagnosticReportEndpoint": "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/DiagnosticReport",
                    "mediaEndpoint": "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/Media/",
                    "mhdResourceEndpoint": "@domain.public.protocol@://@xds@@domain.public@/x1v1-mhd-fhir/$retrieveDocumentByMasterIdentifier",
                    "encounterEndpoint": "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-clinical/fhir/Encounter",
                    "uploadEndpoint": "@domain.public.protocol@://@patsyn@@domain.public@/xvalue-patsyn/upload",
                    "deleteResourceEndpoint": "@domain.public.protocol@://@patsyn@@domain.public@/xvalue-patsyn/DiagnosticReport/[ID]/$removeRelatedContent",
                    "o3Endpoint": "@o3.viewer.url@",
                    "tagEndpoint": "@domain.public.protocol@://@fhir@@domain.public@/x1v1-fhir-terminology/fhir/CodeSystem?url=xvalue://dedalus.eu/CodeSystem/TagIdentifiers&_format=application/json+fhir",
                    "noContentPage": "@domain.public.protocol@://@patsyn@@domain.public@/xvalue-patsyn/nocontent.html",
                    "documentViewerEndpoint": "@domain.public.protocol@://@patsyn@@domain.public@/xvalue-patsyn/document/view"
                      
                }
              
            }
        }

}

var S4HClinicalPortal = {
        "key": "S4HClinicalPortal",
        "data": {
            "resourceType": "configuration",
            "id": "S4HClinicalPortal",
            "version": "0001",
            "identifier": [
                {
                    "use": "official",
                    "system": "http://www.bmc.nl/portal/configuration",
                    "value": "12345689"
                }
            ],
            "status": "active",
            "display": {
                "it-IT": "Informazioni cliniche",
                "en-GB": "Clinical view"
            },
            "authoredOn": "2019-01-15",
            "author": "Dott. XXX XXX",
            "Condition": [
                {
                    "use": "official",
                    "system": "http://www.bmc.nl/portal/condition",
                    "value": "12345689"
                }
            ],
            "Action": [
                {
                    "use": "official",
                    "system": "http://www.bmc.nl/portal/action",
                    "value": "12345689"
                }
            ],
            "entry": [
                {
                    "id": "Problematiche",
                    "presentation": {
                        "displayModes": [
                            "table"
                        ],
                        "title": {
                            "it-IT": "Problematiche",
                            "en-GB": "Conditions"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "Condition",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "all": true
                            }
                        ]
                    }
                },
                {
                    "id": "Patologie_autoimmuni",
                    "presentation": {
                        "displayModes": [
                            "table"
                        ],
                        "title": {
                            "it-IT": "Patologie autoimmuni",
                            "en-GB": "Autoimmune diseases"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "Condition",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "all": true,
                                "code": "xxx"
                            }
                        ]
                    }
                },
                {
                    "id": "Passate_infezioni",
                    "presentation": {
                        "displayModes": [
                            "table"
                        ],
                        "title": {
                            "it-IT": "Passate infezioni",
                            "en-GB": "Infections"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "Condition",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "all": true,
                                "code": "xxx"
                            }
                        ]
                    }
                },
                {
                    "id": "Immunization",
                    "presentation": {
                        "displayModes": [
                            "table"
                        ],
                        "title": {
                            "it-IT": "Vaccinazioni",
                            "en-GB": "Immunizations"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "Immunization",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date"
                            }
                        ]
                    }
                },
                {
                    "id": "Leucociti",
                    "presentation": {
                        "displayModes": [
                            "line",
                            "bar"
                        ],
                        "title": {
                            "it-IT": "EMO-Leucociti (WBC) | Sangue intero EDTA",
                            "en-GB": "EMO-Leukocyte (WBC)"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "Observation",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "category": "laboratory",
                                "code": "1013"
                            }
                        ]
                    }
                },
                {
                    "id": "ObservationA",
                    "presentation": {
                        "displayModes": [
                            "line",
                            "table"
                        ],
                        "title": {
                            "it-IT": "S-Glucosio | Siero",
                            "en-GB": "S-Glucose"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "Observation",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "category": "laboratory",
                                "code": "1011"
                            }
                        ]
                    }
                },
                {
                    "id": "ObservationB",
                    "presentation": {
                        "displayModes": [
                            "line",
                            "bar"
                        ],
                        "title": {
                            "it-IT": "S-Creatinina | Siero",
                            "en-GB": "S-Creatinine"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "Observation",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "category": "laboratory",
                                "code": "1012"
                            }
                        ]
                    }
                },
                {
                    "id": "pressione",
                    "presentation": {
                        "displayModes": [
                            "line",
                            "table"
                        ],
                        "title": {
                            "it-IT": "Pressione del Sangue",
                            "en-GB": "Blood Pressure Measurement"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "Observation",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "intervalDay": {
                                    "value": -500,
                                    "field": "date"
                                },
                                "all": true,
                                "code": "85354-9",
                                "category": "vital-signs"
                            }
                        ]
                    }
                },
                {
                    "id": "peso",
                    "presentation": {
                        "displayModes": [
                            "line",
                            "table",
                            "bar"
                        ],
                        "title": {
                            "it-IT": "Peso",
                            "en-GB": "Weight"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "Observation",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "intervalDay": {
                                    "value": -1000,
                                    "field": "date"
                                },
                                "all": true,
                                "code": "29463-7",
                                "category": "vital-signs"
                            }
                        ]
                    }
                },
                {
                    "id": "Observation3",
                    "presentation": {
                        "displayModes": [
                            "table"
                        ],
                        "title": {
                            "it-IT": "Ultimi risultati",
                            "en-GB": "Last observations"
                        },
                        "size": "large"
                    },
                    "data": {
                        "target": "Observation",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "date": "ge2019-07-27T21:00:00+01:00",
                                "category": "laboratory",
                                "code": "1002"
                            },
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "date": "ge2019-07-27T21:00:00+01:00",
                                "category": "laboratory",
                                "code": "1003"
                            },
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "date": "ge2019-07-27T21:00:00+01:00",
                                "category": "laboratory",
                                "code": "1004"
                            },
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "date": "ge2019-07-27T21:00:00+01:00",
                                "category": "laboratory",
                                "code": "1005"
                            }
                        ]
                    }
                },
                {
                    "id": "Observation11",
                    "presentation": {
                        "displayModes": [
                            "table"
                        ],
                        "title": {
                            "it-IT": "Risultati Precedenti",
                            "en-GB": "Prior observations"
                        },
                        "size": "large"
                    },
                    "data": {
                        "target": "Observation",
                        "filter": [
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "date": "lt2019-07-27T21:00:00+01:00",
                                "category": "laboratory",
                                "code": "1000"
                            },
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "date": "lt2019-07-27T21:00:00+01:00",
                                "category": "laboratory",
                                "code": "1001"
                            },
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "date": "lt2019-07-27T21:00:00+01:00",
                                "category": "laboratory",
                                "code": "1011"
                            },
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "date": "lt2019-07-27T21:00:00+01:00",
                                "category": "laboratory",
                                "code": "1012"
                            },
                            {
                                "lastNValue": 15,
                                "all": true,
                                "_sort": "date",
                                "date": "lt2019-07-27T21:00:00+01:00",
                                "category": "laboratory",
                                "code": "1013"
                            }
                        ]
                    }
                },
                {
                    "id": "Encounter1",
                    "presentation": {
                        "displayModes": [
                            "timeline"
                        ],
                        "title": {
                            "it-IT": "Encounter 1",
                            "en-GB": "Encounter 1"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "Encounter",
                        "filter": [
                            {
                                "lastNValue": 5,
                                "intervalDay": {
                                    "value": -500,
                                    "field": "date"
                                },
                                "all": true
                            }
                        ]
                    }
                },
                {
                    "id": "EpisodeOfCare1",
                    "presentation": {
                        "displayModes": [
                            "timeline"
                        ],
                        "title": {
                            "it-IT": "Episodio 1",
                            "en-GB": "Episode of care 1"
                        },
                        "size": "small"
                    },
                    "data": {
                        "target": "EpisodeOfCare",
                        "filter": [
                            {
                                "lastNValue": 5,
                                "intervalDay": {
                                    "value": -500,
                                    "field": "date"
                                },
                                "all": true
                            }
                        ]
                    }
                }
            ],
            "note": [
                {
                    "text": "bla bla bla"
                }
            ]
        }
    }

var S4HResourcePathTest = {
        "key": "S4HResourcePathTest",
        "data": {
            "displayModesSupported": [
                "table",
                "bar",
                "line",
                "pie",
                "tagcloud",
                "narrative"
            ],
            "fhirResources": {
                "Task": [
                    {
                        "displayModes": [
                            "table"
                        ],
                        "configuration": {
                            "values": [
                                {
                                    "field": "task",
                                    "jsonPath": "$.resource.code.text",
                                    "header": "Task",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Task",
                                        "en-GB": "Task"
                                    }
                                },
                                {
                                    "field": "status",
                                    "jsonPath": "$.resource.status",
                                    "header": "Status",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Stato",
                                        "en-GB": "Status"
                                    }
                                },
                                {
                                    "field": "businessStatus",
                                    "jsonPath": "$.resource.businessStatus.text",
                                    "header": "Business status",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Stato Business",
                                        "en-GB": "Business status"
                                    }
                                },
                                {
                                    "field": "priority",
                                    "jsonPath": "$.resource.priority",
                                    "header": "Priority",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Priorità",
                                        "en-GB": "Priority"
                                    }
                                },
                                {
                                    "field": "start",
                                    "jsonPath": "$.resource.executionPeriod.start",
                                    "header": "Start",
                                    "type": "datetime",
                                    "title": {
                                        "it-IT": "Inizio",
                                        "en-GB": "Start"
                                    }
                                },
                                {
                                    "field": "end",
                                    "jsonPath": "$.resource.executionPeriod.end",
                                    "header": "End",
                                    "type": "datetime",
                                    "title": {
                                        "it-IT": "Fine",
                                        "en-GB": "End"
                                    }
                                }
                            ]
                        }
                    },
                    {
                        "displayModes": [
                            "pie",
                            "tagcloud"
                        ],
                        "configuration": {
                            "values": [
                                {
                                    "jsonPath": "$.resource.code.text"
                                }
                            ]
                        }
                    }
                ],
                "MedicationRequest": [
                    {
                        "displayModes": [
                            "tagcloud",
                            "pie"
                        ],
                        "configuration": {
                            "values": [
                                {
                                    "jsonPath": "$.resource.medicationCodeableConcept.coding[0].display"
                                }
                            ]
                        }
                    }
                ],
                "Observation": [
                    {
                        "displayModes": [
                            "line",
                            "bar"
                        ],
                        "configuration": {
                            "values": [
                                {
                                    "field": "datetime",
                                    "jsonPath": "$.resource.effectiveDateTime",
                                    "header": "Datetime",
                                    "type": "date",
                                    "title": {
                                        "it-IT": "Data",
                                        "en-GB": "Datetime",
                                        "fr-FR": "Date"
                                    }
                                },
                                {
                                    "field": "simpleLabel",
                                    "jsonPath": "$.resource.code.coding[0].display",
                                    "header": "Label",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Codice",
                                        "en-GB": "Code",
                                        "fr-FR": "Codage"
                                    }
                                },
                                {
                                    "field": "simpleValue",
                                    "jsonPath": "$.resource.valueQuantity.value",
                                    "header": "Value",
                                    "type": "number",
                                    "title": {
                                        "it-IT": "Valore",
                                        "en-GB": "Value",
                                        "fr-FR": "Valeur"
                                    }
                                },
                                {
                                    "field": "simpleValueUnit",
                                    "jsonPath": "$.resource.valueQuantity.unit",
                                    "header": "ValueUnit",
                                    "type": "number",
                                    "title": {
                                        "it-IT": "Unita",
                                        "en-GB": "Unit",
                                        "fr-FR": "Unité de mesure"
                                    }
                                },
                                {
                                    "field": "composedLabel",
                                    "jsonPath": "$.resource.component.*.code.coding[0].display",
                                    "header": "Label",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Codice",
                                        "en-GB": "Code",
                                        "fr-FR": "Codage"
                                    }
                                },
                                {
                                    "field": "composedValue",
                                    "jsonPath": "$.resource.component.*.valueQuantity.value",
                                    "header": "Value",
                                    "type": "number",
                                    "title": {
                                        "it-IT": "Valore",
                                        "en-GB": "Value"
                                    }
                                },
                                {
                                    "field": "composedValueUnit",
                                    "jsonPath": "$.resource.component.*.valueQuantity.unit",
                                    "header": "Unit",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Unita",
                                        "en-GB": "Unit"
                                    }
                                },
                                {
                                    "field": "referenceRangeText",
                                    "jsonPath": "$.resource.referenceRange[0].text",
                                    "header": "Range",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Intervallo",
                                        "en-GB": "Range",
                                        "fr-FR": "Échelle"
                                    }
                                },
                                {
                                    "field": "referenceRangeMin",
                                    "jsonPath": "$.resource.referenceRange[0].low.value",
                                    "header": "RangeMin",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Intervallo Minimo",
                                        "en-GB": "Range min",
                                        "fr-FR": "Échelle minimum"
                                    }
                                },
                                {
                                    "field": "referenceRangeMax",
                                    "jsonPath": "$.resource.referenceRange[0].high.value",
                                    "header": "RangeMax",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Intervallo Massimo",
                                        "en-GB": "Range max",
                                        "fr-FR": "Échelle maximun"
                                    }
                                },
                                {
                                    "field": "interpretation",
                                    "jsonPath": "$.resource.interpretation.coding[0].display",
                                    "header": "Interpretation",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Interpretazione",
                                        "en-GB": "Interpretation",
                                        "fr-FR": "Interprétation"
                                    }
                                }
                            ]
                        }
                    }
                ],
                "Procedure": [
                    {
                        "displayModes": [
                            "table"
                        ],
                        "configuration": {
                            "values": [
                                {
                                    "field": "procedure",
                                    "jsonPath": "$.resource.code.text",
                                    "header": "Task",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Task",
                                        "en-GB": "Task"
                                    }
                                },
                                {
                                    "field": "status",
                                    "jsonPath": "$.resource.status",
                                    "header": "Status",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Stato",
                                        "en-GB": "Status"
                                    }
                                },
                                {
                                    "field": "start",
                                    "jsonPath": "$.resource.performedPeriod.start",
                                    "header": "Start",
                                    "type": "datetime",
                                    "title": {
                                        "it-IT": "Inizio",
                                        "en-GB": "Start"
                                    }
                                },
                                {
                                    "field": "end",
                                    "jsonPath": "$.resource.performedPeriod.end",
                                    "header": "End",
                                    "type": "datetime",
                                    "title": {
                                        "it-IT": "Fine",
                                        "en-GB": "End"
                                    }
                                }
                            ]
                        }
                    }
                ],
                "Immunization": [
                    {
                        "displayModes": [
                            "table"
                        ],
                        "configuration": {
                            "values": [
                                {
                                    "field": "code",
                                    "jsonPath": "$.resource.vaccineCode.text",
                                    "header": "Vaccino",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Vaccino",
                                        "en-GB": "Vaccine",
                                        "fr-FR": "Vaccin"
                                    }
                                },
                                {
                                    "field": "date",
                                    "jsonPath": "$.resource.date",
                                    "header": "Data",
                                    "type": "date",
                                    "title": {
                                        "it-IT": "Data",
                                        "en-GB": "Date",
                                        "fr-FR": "Date"
                                    }
                                }
                            ]
                        }
                    }
                ],
                "Condition": [
                    {
                        "displayModes": [
                            "table"
                        ],
                        "configuration": {
                            "values": [
                                {
                                    "field": "procedure",
                                    "jsonPath": "$.resource.code.text",
                                    "header": "Condition",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Condizione",
                                        "en-GB": "Condition",
                                        "fr-FR": "Antécédent"
                                    }
                                },
                                {
                                    "field": "status",
                                    "jsonPath": "$.resource.clinicalStatus",
                                    "header": "Status",
                                    "type": "text",
                                    "title": {
                                        "it-IT": "Stato",
                                        "en-GB": "Status",
                                        "fr-FR": "État"
                                    }
                                },
                                {
                                    "field": "start",
                                    "jsonPath": "$.resource.onsetDateTime",
                                    "header": "Insert date",
                                    "type": "date",
                                    "title": {
                                        "it-IT": "Data inserimento",
                                        "en-GB": "Insert date",
                                        "fr-FR": "Date d'enregistrement"
                                    }
                                }
                            ]
                        }
                    }
                ],
                "DiagnosticReport": [
                    {
                        "displayModes": [
                            "narrative"
                        ],
                        "configuration": {
                            "values": [
                                {
                                    "field": "text",
                                    "jsonPath": "$.resource.text.div",
                                    "type": "html"
                                }
                            ]
                        }
                    }
                ]
            }
        },
        "displayModesSupported": [
            "table",
            "bar",
            "line",
            "pie",
            "tagcloud"
        ]
    }

var S4HFormModel = {
        "key":"S4HFormModel",
        "data":{ 
           "patientForm":{ 
              "model":{ 
                 "submit":"s4h.advanced-search.search",
                 "rows":[ 
                    [ 
                       { 
                          "type":"text",
                          "name":"family",
                          "label":"s4h.advanced-search.family"
                       },
                       { 
                          "type":"text",
                          "name":"given",
                          "label":"s4h.advanced-search.given"
                       }
                    ],
                    [ 
                       { 
                          "type":"date",
                          "name":"birthdate",
                          "enableMask":true,
                          "label":"s4h.patient-search.birthdate"
                       },
                       { 
                          "type":"select",
                          "name":"gender",
                          "multiple":false,
                          "label":"s4h.patient-search.gender",
                          "options":[ 
                             { 
                                "label":"s4h.advanced-search.select",
                                "value":null
                             },
                             { 
                                "label":"s4h.patient-banner.male",
                                "value":"male"
                             },
                             { 
                                "label":"s4h.patient-banner.female",
                                "value":"female"
                             },
                             { 
                                "label":"s4h.patient-banner.other",
                                "value":"other"
                             }
                          ]
                       }
                    ],
                    [ 
                       { 
                          "type":"text",
                          "name":"id",
                          "label":"s4h.patient-banner.Identifier"
                       },
                       { 
                          "type":"select",
                          "multiple":false,
                          "name":"authority",
                          "label":"s4h.patient-search.authority",
                          "options":[ 
                             { 
                                "label":"s4h.advanced-search.select",
                                "value":null
                             },
                             { 
                                "value":"http://xvalue.dedalus.eu/dm/person/master_key",
                                "label":"s4h.patient-search.mpi"
                             },
                             { 
                                "value":"2.16.840.1.113883.2.9.3.12.4.1",
                                "label":"s4h.patient-search.pi"
                             },
                             { 
                                "value":"urn:oid:2.16.840.1.113883.2.9.4.3.2",
                                "label":"s4h.patient-search.taxcode"
                             }
                          ]
                       }
                    ]
                 ]
              },
              "conditions":"(data.given != null && data.given != '') || (data.family != null && data.family != '') || (data.birthdate != null && data.birthdate != '') || (data.id != null && data.id != '')"
           },
           "documentForm":{ 
              "model":{ 
                 "header":"Registration form",
                 "submit":"s4h.advanced-search.search",
                 "rows":[ 
                    [ 
                       { 
                          "type":"date",
                          "name":"rangeDates",
                          "enableMask":true,
                          "selectionMode":"range",
                          "label":"s4h.advanced-search.select_time"
                       },
                       { 
                          "type":"text",
                          "name":"event",
                          "label":"s4h.advanced-search.event"
                       },
                       { 
                          "type":"select",
                          "multiple":false,
                          "name":"eventIdentifier",
                          "label":"s4h.advanced-search.event_type",
                          "options":[ 
                             { 
                                "value":null,
                                "label":"s4h.advanced-search.select"
                             },
                             { 
                                "value":"urn:eu:dedalus:x1v1:2015:nosological",
                                "label":"s4h.timeline.urn:eu:dedalus:x1v1:2015:nosological"
                             },
                             { 
                                "value":"urn:eu:dedalus:x1v1:2015:encounterId",
                                "label":"s4h.timeline.urn:eu:dedalus:x1v1:2015:encounterId"
                             },
                             { 
                                "value":"urn:ihe:iti:xds:2013:uniqueId",
                                "label":"s4h.advanced-search.urn:ihe:iti:xds:2013:uniqueId"
                             },
                             { 
                                "value":"urn:ihe:iti:xdw:2013:workflowId",
                                "label":"s4h.advanced-search.urn:ihe:iti:xdw:2013:workflowId"
                             },
                             { 
                                "value":"urn:ihe:iti:xds:2013:order",
                                "label":"s4h.advanced-search.urn:ihe:iti:xds:2013:order"
                             },
                             { 
                                "value":"urn:ihe:iti:xds:2013:accession",
                                "label":"s4h.advanced-search.urn:ihe:iti:xds:2013:accession"
                             },
                             { 
                                "value":"urn:ihe:iti:xds:2013:referral",
                                "label":"s4h.advanced-search.urn:ihe:iti:xds:2013:referral"
                             }
                          ]
                       }
                    ],
                    [ 
                       { 
                          "type":"select",
                          "multiple":false,
                          "name":"speciality",
                          "label":"s4h.advanced-search.specialization",
                          "options":[ 
                             { 
                                "value":null,
                                "label":"s4h.advanced-search.selectspeciality"
                             },
                             { 
                                "label":"s4h.advanced-search.anatomy",
                                "value":"PAT"
                             },
                             { 
                                "label":"s4h.advanced-search.radiology",
                                "value":"RAD"
                             },
                             { 
                                "label":"s4h.advanced-search.laboratory",
                                "value":"LAB"
                             }
                          ]
                       },
                       { 
                          "type":"text",
                          "multiple":false,
                          "name":"diagnosis",
                          "label":"s4h.advanced-search.diagnosis"
                       }
                    ]
                 ]
              },
              "conditions":"(data.rangeDates != null && data.rangeDates.length > 0) || (data.diagnosis != null && data.diagnosis != '') || ((data.event != null && data.event != '') && (data.eventIdentifier != null && data.eventIdentifier.length > 0)) || (data.speciality  != null && data.speciality.length > 0)"
           }
        }
     };

var codeSystem =  {
        "key": "CodeSystem",
        "data": {
            "valueSets": [
                {
                    "system": "http://d4solutions.dedalus.eu/fhir/CodeSystem/SwabResultCodes-COVID19",
                    "concept": {
                        "en-GB": {
                            "POS": "Positive",
                            "NEG": "Negative",
                            "NA": "Unavailable",
                            "UNC": "Uncertain"
                        },
                        "en-US": {
                            "POS": "Positive",
                            "NEG": "Negative",
                            "NA": "Unavailable",
                            "UNC": "Uncertain"
                        },
                        "it-IT": {
                            "POS": "Positivo",
                            "NEG": "Negativo",
                            "NA": "Non disponibile",
                            "UNC": "Incerto"
                        },
                        "fr-FR": {
                            "POS": "Positif",
                            "NEG": "Negatif",
                            "NA": "Indisponible",
                            "UNC": "Incertain"
                        },
                        "zh-CN": {
                            "POS": "Positive",
                            "NEG": "Negative",
                            "NA": "Unavailable",
                            "UNC": "Uncertain"
                        }
                    }
                },
                {
                    "system": "http://d4solutions.dedalus.eu/fhir/CodeSystem/ClinicalAssessmentOutcomes-COVID19",
                    "concept": {
                        "en-GB": {
                            "SEND-TO-NON-INTENSIVE-CARE": "Send to low intensity department",
                            "SEND-TO-INTENSIVE-CARE": "Send to Intensive Care Unit",
                            "MONITORED-QUARANTINE": "Home isolation monitoring",
                            "DECEASED": "Deceased",
                            "HEALED": "Healed"
                        },
                        "en-US": {
                            "SEND-TO-NON-INTENSIVE-CARE": "Send to low intensity department",
                            "SEND-TO-INTENSIVE-CARE": "Send to Intensive Care Unit",
                            "MONITORED-QUARANTINE": "Home isolation monitoring",
                            "DECEASED": "Deceased",
                            "HEALED": "Healed"
                        },
                        "it-IT": {
                            "SEND-TO-NON-INTENSIVE-CARE": "Inviare a reparto bassa intensità",
                            "SEND-TO-INTENSIVE-CARE": "Inviare a Unità di Terapia Intensiva",
                            "MONITORED-QUARANTINE": "Monitoraggio in isolamento domiciliare",
                            "DECEASED": "Deceduto",
                            "HEALED": "Guarigione"
                        },
                        "fr-FR": {
                            "SEND-TO-NON-INTENSIVE-CARE": "Envoyer au service de faible intensité",
                            "SEND-TO-INTENSIVE-CARE": "Envoyer à l'unité de soins intensifs",
                            "MONITORED-QUARANTINE": "Surveillance de l'isolement à domicile",
                            "DECEASED": "Décédé",
                            "HEALED": "Guérison"
                        },
                        "zh-CN": {
                            "SEND-TO-NON-INTENSIVE-CARE": "Send to low intensity department",
                            "SEND-TO-INTENSIVE-CARE": "Send to Intensive Care Unit",
                            "MONITORED-QUARANTINE": "Home isolation monitoring",
                            "DECEASED": "Deceased",
                            "HEALED": "Healed"
                        }
                    }
                }
            ]
        }
    };

var codeSystemReasonAccess =  {
        "key": "treatmentReason",
        "data": {
            "valueSets": [
                {
                    "system": "http://d4solutions.dedalus.eu/fhir/CodeSystem/ReasonAccess",
                    "concept": {
                        "en-GB": {
                           "IMP": "PRESA IN CARICO REGIME DI RICOVERO",
                            "TER": "PRESA IN CARICO ASSISTENZA TERRITORIALE",
                            "AMB": "CONSULENZA IN REGIME DI VISITA AMBULATORIALE",
                            "DID": "DIDATTICA",
                            "RIC": "RICERCA",
                            "AMM": "VERIFICHE AMMINISTRATIVE",
                            "TEC": "VERIFICHE TECNICHE",
                            "LIB": "CONSULENZA IN REGIME DI LIBERA PROFESSIONE"
                        },
                        "en-US": {
                            "IMP": "PRESA IN CARICO REGIME DI RICOVERO",
                            "TER": "PRESA IN CARICO ASSISTENZA TERRITORIALE",
                            "AMB": "CONSULENZA IN REGIME DI VISITA AMBULATORIALE",
                            "DID": "DIDATTICA",
                            "RIC": "RICERCA",
                            "AMM": "VERIFICHE AMMINISTRATIVE",
                            "TEC": "VERIFICHE TECNICHE",
                            "LIB": "CONSULENZA IN REGIME DI LIBERA PROFESSIONE"
                        },
                        "it-IT": {
                            "IMP": "PRESA IN CARICO REGIME DI RICOVERO",
                            "TER": "PRESA IN CARICO ASSISTENZA TERRITORIALE",
                            "AMB": "CONSULENZA IN REGIME DI VISITA AMBULATORIALE",
                            "DID": "DIDATTICA",
                            "RIC": "RICERCA",
                            "AMM": "VERIFICHE AMMINISTRATIVE",
                            "TEC": "VERIFICHE TECNICHE",
                            "LIB": "CONSULENZA IN REGIME DI LIBERA PROFESSIONE"
                        },
                        "fr-FR": {
                            "IMP": "PRESA IN CARICO REGIME DI RICOVERO",
                            "TER": "PRESA IN CARICO ASSISTENZA TERRITORIALE",
                            "AMB": "CONSULENZA IN REGIME DI VISITA AMBULATORIALE",
                            "DID": "DIDATTICA",
                            "RIC": "RICERCA",
                            "AMM": "VERIFICHE AMMINISTRATIVE",
                            "TEC": "VERIFICHE TECNICHE",
                            "LIB": "CONSULENZA IN REGIME DI LIBERA PROFESSIONE"
                        },
                        "zh-CN": {
                            "IMP": "PRESA IN CARICO REGIME DI RICOVERO",
                            "TER": "PRESA IN CARICO ASSISTENZA TERRITORIALE",
                            "AMB": "CONSULENZA IN REGIME DI VISITA AMBULATORIALE",
                            "DID": "DIDATTICA",
                            "RIC": "RICERCA",
                            "AMM": "VERIFICHE AMMINISTRATIVE",
                            "TEC": "VERIFICHE TECNICHE",
                            "LIB": "CONSULENZA IN REGIME DI LIBERA PROFESSIONE"
                        }
                    }
                }
              ]
        }
};