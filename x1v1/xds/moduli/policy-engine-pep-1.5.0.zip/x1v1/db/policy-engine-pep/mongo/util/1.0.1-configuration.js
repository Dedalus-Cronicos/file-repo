db.configuration.remove({property: "jwtAdditionalJPathAttributes"});
db.configuration.insert(jwtAdditionalJPathAttributes);