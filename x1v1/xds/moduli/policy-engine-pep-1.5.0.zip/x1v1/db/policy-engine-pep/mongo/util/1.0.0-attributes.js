db.attributes.ensureIndex({ id : 1 });

db.attributes.insert(documentUniqueIdDiscovery);
db.attributes.insert(documentConsentInsertInvalidCondition);
db.attributes.insert(healtCareProviderRoleDiscovery);
db.attributes.insert(delegatedPatientRoleDiscovery);
db.attributes.insert(documentPatientId);
db.attributes.insert(userIdDiscovery);
db.attributes.insert(userHealthcareStructureDiscovery);
db.attributes.insert(patientQueryIdDiscovery);
db.attributes.insert(documentResponseUniqueIdDiscovery);
db.attributes.insert(folderUniqueIdDiscovery);
db.attributes.insert(submissionUniqueIdDiscovery);
db.attributes.insert(adhocQueryIdDiscovery);
db.attributes.insert(documentResponseLidDiscovery);
db.attributes.insert(actionValidatorDiscovery);