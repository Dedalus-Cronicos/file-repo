var X1V1_AMMINISTRATIVO_Roles = {
    "key": "X1V1_AMMINISTRATIVO_Roles",
    "values": [
        "X1V1_PERSONALE_TECNICO",
        "X1V1_AMMINISTRATIVO",
        "supervisor"
    ]
};

var X1V1_MEDICO_Roles = {
    "key": "X1V1_MEDICO_Roles",
    "values": [
        "X1V1_MEDICO",
        "DOCTOR",
        "doctor"
    ]
};

var X1V1_TUTORE_Roles = {
    "key": "X1V1_TUTORE_Roles",
    "values": [
        "X1V1_TUTORE",
        "X1V1_TUTOR",
        "TUTOR"
    ]
};

var X1V1_ASSISTITO_Roles = {
    "key": "X1V1_ASSISTITO_Roles",
    "values": [
        "X1V1_ASSISTITO",
        "PATIENT"
    ]
};

var X1V1_MMG_Roles = {
    "key": "X1V1_MMG_Roles",
    "values": [
        "X1V1_MMG",
        "ME"
    ]
};

var ALL_MAPPED_Roles = {
    "key": "ALL_MAPPED_Roles",
    "values": [
        "X1V1_MEDICO",
        "X1V1_ASSISTITO",
        "X1V1_TUTORE",
        "X1V1_MMG",
        "X1V1_AMMINISTRATIVO"
    ]
};

var ALL_MAPPED_Notify_Roles = {
    "key": "ALL_MAPPED_Notify_Roles",
    "values": [
        "X1V1_MEDICO",
        "X1V1_MMG"
    ]
};