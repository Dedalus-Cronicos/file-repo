db.attribute_discovery.ensureIndex({ when : 1, endpoint : 1, phase : 1 });


db.attribute_discovery.insert(IN_DeleteDocumentSet_Default);
db.attribute_discovery.insert(IN_UpdateDocumentSet_Default);
db.attribute_discovery.insert(IN_DocumentRepository_RemoveDocumentsResponse_Default);
db.attribute_discovery.insert(IN_DocumentRepository_RetrieveDocumentSet_Default);
db.attribute_discovery.insert(IN_DocumentRepository_ProvideAndRegisterDocumentSetB_Default);
db.attribute_discovery.insert(IN_RegistryStoredQuery_Default);
db.attribute_discovery.insert(OUT_UpdateDocumentSet_Default);
db.attribute_discovery.insert(OUT_DeleteDocumentSet_Default);
db.attribute_discovery.insert(OUT_DocumentRepository_RemoveDocumentsResponse_Default);
db.attribute_discovery.insert(OUT_DocumentRepository_ProvideAndRegisterDocumentSetB_Default);
db.attribute_discovery.insert(OUT_DocumentRepository_RetrieveDocumentSet_Default);
db.attribute_discovery.insert(OUT_RegistryStoredQuery_Default);
db.attribute_discovery.insert(IN_ProvideAndRegisterDocumentSetRequestBPPC);
db.attribute_discovery.insert(OUT_RegistryResponseBPPC);


db.attribute_discovery.insert(IN_ProxyTestParam);
db.attribute_discovery.insert(OUT_ProxyTestParam);


db.attribute_discovery.insert(IN_NEW_READ_FHIRRESOURCE);


db.attribute_discovery.insert(IN_ARR_GET_1);
db.attribute_discovery.insert(IN_ARR_POST_1);
db.attribute_discovery.insert(IN_ARR_PUT_1);
db.attribute_discovery.insert(IN_ARR_HEAD_1);
db.attribute_discovery.insert(IN_ARR_DELETE_1);
db.attribute_discovery.insert(OUT_ARR_1);


db.attribute_discovery.insert(IN_REST_GET_1);
db.attribute_discovery.insert(IN_REST_POST_1);
db.attribute_discovery.insert(IN_REST_PUT_1);
db.attribute_discovery.insert(IN_REST_HEAD_1);
db.attribute_discovery.insert(IN_REST_DELETE_1);
db.attribute_discovery.insert(OUT_REST_1);


db.attribute_discovery.insert(IN_ARR_FHIR_GET_2);
db.attribute_discovery.insert(IN_ARR_FHIR_POST_2);
db.attribute_discovery.insert(IN_ARR_FHIR_PUT_2);
db.attribute_discovery.insert(IN_ARR_FHIR_DELETE_2);
db.attribute_discovery.insert(IN_ARR_FHIR_GET_3);
db.attribute_discovery.insert(OUT_ARR_FHIR_RESOURCE_2);
db.attribute_discovery.insert(OUT_ARR_FHIR_RESOURCE_3);


db.attribute_discovery.insert(IN_FHIR_TERMINOLOGY_GET_1);
db.attribute_discovery.insert(IN_FHIR_TERMINOLOGY_GET_2);
db.attribute_discovery.insert(IN_FHIR_TERMINOLOGY_GET_3);
db.attribute_discovery.insert(IN_FHIR_TERMINOLOGY_POST_1);
db.attribute_discovery.insert(IN_FHIR_TERMINOLOGY_POST_2);
db.attribute_discovery.insert(IN_FHIR_TERMINOLOGY_POST_3);
db.attribute_discovery.insert(IN_FHIR_TERMINOLOGY_PUT_1);
db.attribute_discovery.insert(IN_FHIR_TERMINOLOGY_PUT_2);
db.attribute_discovery.insert(IN_FHIR_TERMINOLOGY_PUT_3);
db.attribute_discovery.insert(OUT_FHIR_TERMINOLOGY_RESOURCE_1);
db.attribute_discovery.insert(OUT_FHIR_TERMINOLOGY_RESOURCE_2);
db.attribute_discovery.insert(OUT_FHIR_TERMINOLOGY_RESOURCE_3);


db.attribute_discovery.insert(IN_FHIR_CLINICAL_GET_1);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_GET_2);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_GET_3);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_POST_1);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_POST_2);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_PUT_2);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_PUT_3);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_HEAD_1);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_HEAD_2);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_DELETE_1);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_DELETE_2);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_DELETE_3);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_PATCH_1);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_PATCH_2);
db.attribute_discovery.insert(IN_FHIR_CLINICAL_PATCH_3);
db.attribute_discovery.insert(OUT_FHIR_CLINICAL_RESOURCE_1);
db.attribute_discovery.insert(OUT_FHIR_CLINICAL_RESOURCE_2);
db.attribute_discovery.insert(OUT_FHIR_CLINICAL_RESOURCE_3);


db.attribute_discovery.insert(IN_MCI_SERVICE_GET_3);
db.attribute_discovery.insert(IN_MCI_SERVICE_POST_3);
db.attribute_discovery.insert(OUT_MCI_SERVICE_3);


db.attribute_discovery.insert(IN_PEOPLE_FHIR_GET_1);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_GET_2);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_GET_3);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_GET_4);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_POST_1);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_POST_2);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_POST_3);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_PUT_1);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_PUT_2);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_PUT_3);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_DELETE_1);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_DELETE_2);
db.attribute_discovery.insert(IN_PEOPLE_FHIR_DELETE_3);
db.attribute_discovery.insert(OUT_PEOPLE_FHIR_1);
db.attribute_discovery.insert(OUT_PEOPLE_FHIR_2);
db.attribute_discovery.insert(OUT_PEOPLE_FHIR_3);
db.attribute_discovery.insert(OUT_PEOPLE_FHIR_4);


db.attribute_discovery.insert(IN_PWP_BACKEND_GET_1);
db.attribute_discovery.insert(IN_PWP_BACKEND_GET_2);
db.attribute_discovery.insert(IN_PWP_BACKEND_GET_3);
db.attribute_discovery.insert(IN_PWP_BACKEND_POST_1);
db.attribute_discovery.insert(IN_PWP_BACKEND_POST_2);
db.attribute_discovery.insert(IN_PWP_BACKEND_POST_3);
db.attribute_discovery.insert(IN_PWP_BACKEND_PUT_1);
db.attribute_discovery.insert(IN_PWP_BACKEND_PUT_2);
db.attribute_discovery.insert(IN_PWP_BACKEND_PUT_3);
db.attribute_discovery.insert(OUT_PWP_BACKEND_1);
db.attribute_discovery.insert(OUT_PWP_BACKEND_2);
db.attribute_discovery.insert(OUT_PWP_BACKEND_3);


db.attribute_discovery.insert(IN_MHD_FHIR_GET_0);
db.attribute_discovery.insert(IN_MHD_FHIR_GET_1);
db.attribute_discovery.insert(IN_MHD_FHIR_GET_2);
db.attribute_discovery.insert(IN_MHD_FHIR_GET_3);
db.attribute_discovery.insert(IN_MHD_FHIR_POST_0);
db.attribute_discovery.insert(IN_MHD_FHIR_POST_1);
db.attribute_discovery.insert(IN_MHD_FHIR_POST_2);
db.attribute_discovery.insert(IN_MHD_FHIR_POST_3);
db.attribute_discovery.insert(OUT_MHD_FHIR_0);
db.attribute_discovery.insert(OUT_MHD_FHIR_1);
db.attribute_discovery.insert(OUT_MHD_FHIR_2);
db.attribute_discovery.insert(OUT_MHD_FHIR_3);


db.attribute_discovery.insert(IN_XVALUE_PATSYN_GET_1);
db.attribute_discovery.insert(IN_XVALUE_PATSYN_GET_2);
db.attribute_discovery.insert(IN_XVALUE_PATSYN_GET_3);
db.attribute_discovery.insert(IN_XVALUE_PATSYN_POST_1);
db.attribute_discovery.insert(IN_XVALUE_PATSYN_POST_2);
db.attribute_discovery.insert(IN_XVALUE_PATSYN_POST_3);
db.attribute_discovery.insert(OUT_XVALUE_PATSYN_1);
db.attribute_discovery.insert(OUT_XVALUE_PATSYN_2);
db.attribute_discovery.insert(OUT_XVALUE_PATSYN_3);


db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_GET_1);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_GET_2);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_GET_3);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_POST_1);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_POST_2);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_POST_3);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_HEAD_1);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_HEAD_2);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_HEAD_3);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_DELETE_1);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_DELETE_2);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_DELETE_3);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_PUT_1);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_PUT_2);
db.attribute_discovery.insert(IN_X1V1_CONFIGURATOR_PUT_3);
db.attribute_discovery.insert(OUT_X1V1_CONFIGURATOR_1);
db.attribute_discovery.insert(OUT_X1V1_CONFIGURATOR_2);
db.attribute_discovery.insert(OUT_X1V1_CONFIGURATOR_3);


db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_GET_1);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_GET_2);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_GET_3);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_GET_4);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_GET_5);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_GET_6);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_HEAD_1);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_HEAD_2);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_HEAD_3);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_HEAD_4);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_HEAD_5);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_HEAD_6);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_POST_1);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_POST_2);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_POST_3);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_POST_4);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_POST_5);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_POST_6);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_DELETE_1);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_DELETE_2);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_DELETE_3);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_DELETE_4);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_DELETE_5);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_DELETE_6);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_PUT_1);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_PUT_2);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_PUT_3);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_PUT_4);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_PUT_5);
db.attribute_discovery.insert(IN_CONSENTENGINE_CONSENT_BASE_PUT_6);
db.attribute_discovery.insert(OUT_CONSENTENGINE_CONSENT_BASE_1);
db.attribute_discovery.insert(OUT_CONSENTENGINE_CONSENT_BASE_2);
db.attribute_discovery.insert(OUT_CONSENTENGINE_CONSENT_BASE_3);
db.attribute_discovery.insert(OUT_CONSENTENGINE_CONSENT_BASE_4);
db.attribute_discovery.insert(OUT_CONSENTENGINE_CONSENT_BASE_5);
db.attribute_discovery.insert(OUT_CONSENTENGINE_CONSENT_BASE_6);


db.attribute_discovery.insert(IN_DSUB_API_GET_1);
db.attribute_discovery.insert(IN_DSUB_API_GET_2);
db.attribute_discovery.insert(IN_DSUB_API_GET_3);
db.attribute_discovery.insert(IN_DSUB_API_POST_1);
db.attribute_discovery.insert(IN_DSUB_API_POST_2);
db.attribute_discovery.insert(IN_DSUB_API_POST_3);
db.attribute_discovery.insert(IN_DSUB_CreatePullPoint);
db.attribute_discovery.insert(IN_DSUB_DestroyPullPoint);
db.attribute_discovery.insert(IN_DSUB_GetMessages);
db.attribute_discovery.insert(IN_DSUB_getSubscriptions);
db.attribute_discovery.insert(IN_DSUB_Subscribe);
db.attribute_discovery.insert(IN_DSUB_Unsubscribe);
db.attribute_discovery.insert(IN_DSUB_consent);
db.attribute_discovery.insert(IN_DSUB_agmatrix);
db.attribute_discovery.insert(OUT_DSUB_API_3);
db.attribute_discovery.insert(OUT_DSUB_API_2);
db.attribute_discovery.insert(OUT_DSUB_API_1);
db.attribute_discovery.insert(OUT_DSUB_CreatePullPoint);
db.attribute_discovery.insert(OUT_DSUB_DestroyPullPoint);
db.attribute_discovery.insert(OUT_DSUB_UnableToCreatePullPointFault);
db.attribute_discovery.insert(OUT_DSUB_GetMessage);
db.attribute_discovery.insert(OUT_DSUB_ResourceUnknownFault);
db.attribute_discovery.insert(OUT_DSUB_UnableToGetMessagesFault);
db.attribute_discovery.insert(OUT_DSUB_getSubscriptions);
db.attribute_discovery.insert(OUT_DSUB_Subscribe);
db.attribute_discovery.insert(OUT_DSUB_Unsubscribe);