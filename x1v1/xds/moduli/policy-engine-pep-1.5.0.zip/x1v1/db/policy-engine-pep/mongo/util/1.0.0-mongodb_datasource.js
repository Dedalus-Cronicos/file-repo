db.mongodb_datasource.ensureIndex({ alias : 1 });

db.mongodb_datasource.insert(ADT_DATASOURCE);
db.mongodb_datasource.insert(ARRIETTY_DATASOURCE);
db.mongodb_datasource.insert(PM_CONSENT_ENGINE_DATASOURCE);