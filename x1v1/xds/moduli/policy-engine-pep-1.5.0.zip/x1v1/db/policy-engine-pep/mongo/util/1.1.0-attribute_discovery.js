db.attribute_discovery.remove({when: "AdhocQueryResponse", endpoint: "RegistryStoredQuery_Default"});
db.attribute_discovery.remove({when: "fhirResourceRead", endpoint: "fhirResourceRead"});
db.attribute_discovery.remove({when: "RetrieveDocumentSetResponse", endpoint: "fhirResourceRead"});

db.attribute_discovery.insert(OUT_RegistryStoredQuery_Default);
db.attribute_discovery.insert(OUT_DocumentRepository_RetrieveDocumentSet_Default);
db.attribute_discovery.insert(IN_NEW_READ_FHIRRESOURCE);