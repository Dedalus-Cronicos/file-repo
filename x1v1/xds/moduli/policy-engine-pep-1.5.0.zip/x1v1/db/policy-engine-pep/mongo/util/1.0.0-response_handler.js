db.response_handler.ensureIndex({ when : 1 });

db.response_handler.insert(NEW_AdhocQueryRequest_ResponseHandler);
db.response_handler.insert(NEW_AdhocQueryResponse_ResponseHandler);
db.response_handler.insert(NEW_RetrieveDocumentSetResponse_ResponseHandler);

db.response_handler.insert(ProxyTestParamHandler_ResponseHandler);

db.response_handler.insert(CONSENT_BASE_1_ResponseHandler);
db.response_handler.insert(CONSENT_BASE_2_ResponseHandler);
db.response_handler.insert(CONSENT_BASE_3_ResponseHandler);
db.response_handler.insert(CONSENT_BASE_4_ResponseHandler);
db.response_handler.insert(CONSENT_BASE_5_ResponseHandler);
db.response_handler.insert(CONSENT_BASE_6_ResponseHandler);

db.response_handler.insert(FHIR_CLINICAL_RESOURCE_1_ResponseHandler);
db.response_handler.insert(FHIR_CLINICAL_RESOURCE_2_ResponseHandler);
db.response_handler.insert(FHIR_CLINICAL_RESOURCE_3_ResponseHandler);

db.response_handler.insert(MCI_SERVICE_ResponseHandler);

db.response_handler.insert(PEOPLE_FHIR_RESOURCE_1_ResponseHandler);
db.response_handler.insert(PEOPLE_FHIR_RESOURCE_2_ResponseHandler);
db.response_handler.insert(PEOPLE_FHIR_RESOURCE_3_ResponseHandler);
db.response_handler.insert(PEOPLE_FHIR_RESOURCE_4_ResponseHandler);

db.response_handler.insert(PWP_BACKEND_1_ResponseHandler);
db.response_handler.insert(PWP_BACKEND_2_ResponseHandler);
db.response_handler.insert(PWP_BACKEND_3_ResponseHandler);

db.response_handler.insert(MHD_0_ResponseHandler);
db.response_handler.insert(MHD_1_ResponseHandler);
db.response_handler.insert(MHD_2_ResponseHandler);
db.response_handler.insert(MHD_3_ResponseHandler);

db.response_handler.insert(XVALUE_PATSYN_1_ResponseHandler);
db.response_handler.insert(XVALUE_PATSYN_2_ResponseHandler);
db.response_handler.insert(XVALUE_PATSYN_3_ResponseHandler);

db.response_handler.insert(X1V1_CONFIGURATOR_1_ResponseHandler);
db.response_handler.insert(X1V1_CONFIGURATOR_2_ResponseHandler);
db.response_handler.insert(X1V1_CONFIGURATOR_3_ResponseHandler);

db.response_handler.insert(REST_ResponseHandler);

db.response_handler.insert(NEW_FHIRRESOURCE_ResponseHandler);

db.response_handler.insert(DSUB_AgMatrix_ResponseHandler);
db.response_handler.insert(DSUB_Consent_ResponseHandler);