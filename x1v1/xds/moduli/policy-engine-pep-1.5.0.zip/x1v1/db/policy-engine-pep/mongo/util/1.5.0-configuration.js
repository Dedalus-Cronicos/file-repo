db.configuration.remove({property: "jwt.config"});
db.configuration.insert(jwtConfig);