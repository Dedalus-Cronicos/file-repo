db.getCollection('subscriptionTopics').dropIndex({
    "content.url" : 1.0,
    "versionId" : 1.0
});



db.getCollection('subscriptionTopics').ensureIndex({"content.url":1},{ partialFilterExpression: { status:  "current"}, unique: true, name: 'topicUrlIndex'});

