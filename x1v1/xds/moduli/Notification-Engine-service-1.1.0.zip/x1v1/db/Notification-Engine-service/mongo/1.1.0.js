db.createCollection('payloads_dsub');

db.payloads_mail.createIndex( { 'status.status' : 1, 'status.active': 1, 'attempts': 1},{ sparse: true, name: 'payloadStatusIndex'});
db.payloads_ntf_002.createIndex( { 'status.status' : 1, 'status.active': 1, 'attempts': 1},{ sparse: true, name: 'payloadStatusIndex'});
db.payloads_dsub.createIndex( { 'status.status' : 1, 'status.active': 1, 'attempts': 1, 'sendToPicasso': 1},{ sparse: true, name: 'payloadStatusIndex'});
