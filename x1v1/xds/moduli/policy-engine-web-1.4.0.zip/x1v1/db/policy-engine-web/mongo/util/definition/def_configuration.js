var cacheTimeoutInMillis = {
    property: "cache.timeout.in.millis",
    value: "3600000"
};