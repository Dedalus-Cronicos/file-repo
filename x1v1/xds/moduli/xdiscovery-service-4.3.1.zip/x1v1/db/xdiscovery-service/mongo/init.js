//mongo admin -u admin -p x1v1mdb --authenticationDatabase admin;

db = db.getSiblingDB("@discoveryservice.mongodb.name@");
db.createUser({ user: "@discoveryservice.mongodb.user@",
  pwd: "@discoveryservice.mongodb.password@",
  roles: [
    { role: "readWrite", db: "@discoveryservice.mongodb.name@"}
  ]
});

db = db.getSiblingDB("@discoveryservice.sharetopic.mongodb.name@");
db.createUser({ user: "@discoveryservice.sharetopic.mongodb.user@",
  pwd: "@discoveryservice.sharetopic.mongodb.password@",
  roles: [
    { role: "readWrite", db: "@discoveryservice.sharetopic.mongodb.name@"}
  ]
});
