
db.getCollection("schema_version").insertOne(
    {
        "major" : "4",
        "minor" : "2",
        "patch" : "0",
        "tag" : "xdiscovery-service",
        "revision" : 0,
        "last_change" : ISODate("2023-02-28T16:53:27.604+02:00"),
        "description" : ""
    }
);


db.getCollection('DS_Kid').deleteOne({"kid":"YWFjYjU="});

db.getCollection('DS_Kid').deleteOne({"kid":"N2JjMjg="});

var kidDSPublicCert = db.getCollection('DS_Kid').findOne({alias:'DS-Public-Cert'})
if (kidDSPublicCert == null) {
  // insertOne Discovery Service Public Certificate
  db.getCollection('DS_Kid').insertOne(
    {
        kid : "Dqg8ZmFgeU3R-ubEY7O_Vw==",
        alias : "DS-Public-Cert",
        type : "cert",
        defaultCER: true,
        defaultPK: false,
        demoEntry: false,
        description : "Discovery Service Public Certificate",
        key : BinData (0,"LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSURnekNDQW11Z0F3SUJBZ0lVREpkclU0SXNjMnZoS2FodzhzOHJSL1ZvSW5zd0RRWUpLb1pJaHZjTkFRRUwKQlFBd1d6RVNNQkFHQTFVRUF3d0paR1Z0Ynkxa1l6Um9NUTB3Q3dZRFZRUUxEQVJFUXpSSU1SY3dGUVlEVlFRSwpEQTVFWldSaGJIVnpJRk11Y0M1QkxqRUxNQWtHQTFVRUJoTUNTVlF4RURBT0JnTlZCQWNNQjBacGNtVnVlbVV3CkhoY05Nak13TWpJNE1EazBNRFEwV2hjTk16TXdNakkxTURrME1EUTBXakJmTVFzd0NRWURWUVFHRXdKSlZERVEKTUE0R0ExVUVCd3dIUm1seVpXNTZaVEVYTUJVR0ExVUVDZ3dPUkdWa1lXeDFjeUJUTG5BdVFTNHhEVEFMQmdOVgpCQXNNQkVSRE5FZ3hGakFVQmdOVkJBTU1EV1JqTkdndVpHVnRieTVzWVc0d2dnRWlNQTBHQ1NxR1NJYjNEUUVCCkFRVUFBNElCRHdBd2dnRUtBb0lCQVFEWGphQUJ3ZDlRam9kQ1hSWEhZMnUyZzRWeE5NTjFoM1NBNFVicWcxQXMKT0I1YWkrUDVGZndzL0ZqMVRiNHV0dzFjY3FKVHJDYzBpVkJMRUMyVHJDL0szQTViM01rMUpUR25LdzQvMmh1OQo4TUczSW5ZZW92Wi9vRXdHaGFmSnp4ci93TGpyRFNlWHJGUFNQcFVQS0l6RWxmUzlRWWNMRHV1Lzdhb09Hb3U2CnJRTzk4N0VRU2pmdUJrOWxuOTB5d21INVp4dkVQK09lL3JZaDhCSHVhTlZjMmt0akplaExkYWdxQnNHeHRsV2EKajl0c2NVSWRXNEJqR1lDTVhUNXV3clRjTWZjY3pwTDRBeUhhZXB0WDBHbnNaZEpGREZkVFYyL2NTY0F3dWpTUApGZEVDa2VybWxBZjF0UjN0WWtucTJqUHpGWjcrVjVSd1RtY0FBUzNjSktGaEFnTUJBQUdqT3pBNU1COEdBMVVkCkl3UVlNQmFBRk9KNGNDaGhmVldhcGQ4TWtxTmdvSUxRUm1Nc01Ba0dBMVVkRXdRQ01BQXdDd1lEVlIwUEJBUUQKQWdUd01BMEdDU3FHU0liM0RRRUJDd1VBQTRJQkFRQnFrZHcybGZGbVB6a1NaMTcvbDUrMkNibXFuZloxVXdmSwphdHQwd01NQzFTZk5OWDBDOWFkTU1RQW44Q2R4VkdMeXRjTjFyMFU5YWcvdzB2T2E2M29sS2V6cE1Zd1lWZkhHCjlHeS92eUVuN2pXeUNrdVF2cGdSeDVSbmRIV1F0S1laNlVaZm14UDVXR3JxS0Z6elhpT3hUYmhxenFBbnN0MjcKcE1OUWlvRjZ3enNNQktYaGpFbG1IRFgxbHVrQUNTQ1ZsbmVwa1pXL1YwVjVtNVZWNW54OGtCMkxDenRpUzBOMwpKZS9tZ2tINUpTVUNkMVltbVJ0TzRXQTZoeWQrTEJMQm5iSHI3WHdZZXU4a1kzSi8rRzhoQXVaWS9ybjU2aXArCnk5NnVwSlQ3bDVpdkFGS1pjZ0lYVmlKOVpHaGM1WEN5OVBYS3lHcFJOK0JjYThxMUNzL1YKLS0tLS1FTkQgQ0VSVElGSUNBVEUtLS0tLQo=")
    }
  );
} else {
  //update document adding new fields
  db.getCollection('DS_Kid').updateOne(
    {alias:"DS-Public-Cert", "type":"cert"},
    { $set:{defaultCER:true, defaultPK: false, demoEntry: false}}
  );
}

var kidDSPrivateKey = db.getCollection('DS_Kid').findOne({alias:'DS-Private-Key'})
if (kidDSPublicCert == null){
  // insertOne Discovery Private Key
  db.getCollection('DS_Kid').insertOne(
    {
        kid : "HLXzRu8xZYV4PMQKGw0Epg==",
        alias : "DS-Private-Key",
        type : "private",
        defaultCER: false,
        defaultPK: true,
        demoEntry: false,
        description : "Discovery Service Private Key",
        key : BinData(0, "LS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tCk1JSUV2QUlCQURBTkJna3Foa2lHOXcwQkFRRUZBQVNDQktZd2dnU2lBZ0VBQW9JQkFRRFhqYUFCd2Q5UWpvZEMKWFJYSFkydTJnNFZ4Tk1OMWgzU0E0VWJxZzFBc09CNWFpK1A1RmZ3cy9GajFUYjR1dHcxY2NxSlRyQ2MwaVZCTApFQzJUckMvSzNBNWIzTWsxSlRHbkt3NC8yaHU5OE1HM0luWWVvdlovb0V3R2hhZkp6eHIvd0xqckRTZVhyRlBTClBwVVBLSXpFbGZTOVFZY0xEdXUvN2FvT0dvdTZyUU85ODdFUVNqZnVCazlsbjkweXdtSDVaeHZFUCtPZS9yWWgKOEJIdWFOVmMya3RqSmVoTGRhZ3FCc0d4dGxXYWo5dHNjVUlkVzRCakdZQ01YVDV1d3JUY01mY2N6cEw0QXlIYQplcHRYMEduc1pkSkZERmRUVjIvY1NjQXd1alNQRmRFQ2tlcm1sQWYxdFIzdFlrbnEyalB6Rlo3K1Y1UndUbWNBCkFTM2NKS0ZoQWdNQkFBRUNnZ0VBYStXTGszV2ROL0N3U2dyWVRQODZPcGpwSWZxY1lHZFdiUERYRTZwNVpqa04KRUp2M21JWmx2WXJ2YUpMcXdPMkdOYUY0R2RRUnA5MllJSXJQbFp6YUszd3RmOVFycjN1WHVDcjRMZ1FhWU9Cegp4eHpyN1hmN1ZYVkN1UDBNT1J0L1UwZ0FDRUNFY2dxanhwam0ramg5QmlaZDVLSTVXOUt6TlZaZENrUkZiMElpClVkZW10clJHeUNpQis1d01jeGRoNnRIcDA0RXBWcTN2R0RvSWtpNmczVFpEd2I3cFpYa3plMi96V0FBcGVnNS8Kb2FCK2d1cWNFRk9KbXNqRWtoWGlrVTBOeFJabW5Da29ZMVVERGs5ZGZBeUZadE9FNTZoWS95OVBwUUtydVp4QgpnajJSMGNQb0RrMkNQK0ovNUpOMlNSTVpPbTU5SlhDRXBpbmx6Nkt4OFFLQmdRRHl1Y0R0emZSaWhYdXhkcHhCCjZROHpvZjJNL1k1eGEyNnhlbktKZ1JzMVcwUXluQVIwcGh5UFgrbjVGcDVJUVk3K1VqVTB5NkQrNDBZam9RUVoKUlNnRldidnkvQ3hLUjRnU1RSREFpSTZneG82K2V1Z0trc3hobzhmekhaN09tb1QySGFma3dodVZ1cFUxd1BuSgprenNGNjJ3ZldWYk1JbGJrbGdDcVhvU0ZOUUtCZ1FEalYzTEJwaGNFbUFoUFVZRVM1dGdYcDVDNktWRDJaNnBwCmVnWnJRMDFkL1AwckM5UkJyUVd1L1dzV2FMT2JiWDc5UksrSHFZcmhUa0o4NzNNMjZzUHdSMTNhK0QrZDBNQXkKZUZjbGNRb3RvZmN2bTJmM3VzUTRZMERVTW1lNGJDcFNTMmc5aWNtMUdXQ0lZMDhpSHJUc0JhdE9oQ1RZdVYwaQozRUprZjRTTS9RS0JnQXpNdnQvTGZKZTFjbEJwY05RSTlrUkN4cHdvd3RvNFVCNEwxdjVwVUlYL3loamhJVnNGClozd29FcTZRQXNqTXJEMjlHQkV3cTh6RkwyMnhrQVhGSDljb1pFRHNDMm5mVzgyYlFzYmtiS0VOMTNrMEFnaU0KdFRwdzZKcHBkWFp2cjVOSy9RK1RMT0U0ZGFYZ0Iwd1o5NExZWjFzLzJ0UG8rNndTUFBhL0JUNEJBb0dBYjl5YwppNnBrMHc3WHIrZWp3aUF5SGRtR2ZnTk1ZaUg2R1BKQTdGQnVaaHZRbW5pMGxTaEVqcWtGSXo2YmVaUDBFenpUCnZjWHZueEw1NWkyUUhHcUJ4TjNvMFpDckJNVXRmT2Yzd1dXUW80bDVia1JpY09QR0h4Uy9WbW9DM1J6ajZpQk8KaDFFZ0hlc0JzN3BodXFFdlZwOG5mbmZKQlphWHZFcHlwSzZXRXlVQ2dZQmhlekpaOVloRzFKVVFLdVJWdldhQgo3WFp2UUxjWWtWN3VwWlJHWUVBY1I1L0V2dTdOWHBKNENlN3MwNTVkZmhWSjZIcmovMUVtb3BzelNQVkRBZmhXCmhLYndPcE1aaWVTRThIZkRudUd4YW5KeDlnY0FpNEVENW9tTTY5Wmh0Zit0OE01akt1MFViMzEwVHZOOXBnbCsKZ2JZNUFCZGF1elJxeGtScG1iSUJVZz09Ci0tLS0tRU5EIFBSSVZBVEUgS0VZLS0tLS0K")
    }
  );
} else {
   //update document adding new fields
   db.getCollection('DS_Kid').updateOne(
     {alias:"DS-Private-Key", "type":"private"},
     { $set:{defaultCER:false, defaultPK: true, demoEntry: false}}
   );
}
