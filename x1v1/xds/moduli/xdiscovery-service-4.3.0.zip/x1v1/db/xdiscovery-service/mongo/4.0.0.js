
db.getCollection("schema_version").insertOne(
    {
        "major" : "4",
        "minor" : "0",
        "patch" : "0",
        "tag" : "xdiscovery-service",
        "revision" : 0,
        "last_change" : ISODate("2020-10-09T16:53:27.604+02:00"),
        "description" : ""
    }
);

db.getCollection('DS_RegisteredClient').insertOne(
    {
          "clientId" : "VEGASTS123456789",
          "secret" : "c79touE4t0chrt3W",
          "serverLocationUri" : "https://@mpi@@domain.web@",
          "owner" : "VEGA STS",
          "nameIdentifier" : "VEGA STS",
          "userRoleProvisioningURL" : "https://@mpi@@domain.app@/people-auth/rest/Profile",
          "implementation" : "eu.dedalus.x1v1.jwt.resolver.PeopleProfileAndRoleResolver",
          "queryBy" : "username",
          "subjectAA" : "CF"
    }
);

