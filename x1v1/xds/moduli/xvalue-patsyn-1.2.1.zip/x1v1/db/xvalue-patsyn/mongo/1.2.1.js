//mongo 127.0.0.1:27017/xvalue-patsyn -u xvalue-patsyn -p xvalue-patsyn < 1.2.1.js
load("util/definition/def_configuration.js");
load("util/1.2.1-configuration.js");

db.script_version.remove({ key: "xvalue-patsyn"});
db.script_version.insert({ key: "xvalue-patsyn", version : "1.2.1", date: new Date() });
