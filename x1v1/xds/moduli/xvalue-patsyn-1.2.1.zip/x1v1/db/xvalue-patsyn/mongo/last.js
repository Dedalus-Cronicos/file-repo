//mongo 127.0.0.1:27017/xvalue-patsyn -u xvalue-patsyn -p xvalue-patsyn < last.js
load("1.0.0.js");
load("1.2.0.js");
load("1.2.1.js");