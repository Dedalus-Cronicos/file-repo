//mongo admin -u admin -p x1v1mdb --authenticationDatabase admin < init.js;
db = db.getSiblingDB("@xvaluePatSyn.mongodb.name@");
db.createUser({ user: "@xvaluePatSyn.mongodb.user@",
  pwd: "@xvaluePatSyn.mongodb.password@",
  roles: [
    { role: "readWrite", db: "@xvaluePatSyn.mongodb.name@"}
  ]
});