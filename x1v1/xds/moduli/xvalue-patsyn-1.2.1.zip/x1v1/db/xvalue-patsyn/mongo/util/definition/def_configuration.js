var defaultConfiguration = {
	"key": "default",
	"fhirPeople" : {
		"endpoint" : "http://@app.x1v1@:@app.x1v1.xds.port@/people.fhir/fhir",
		"useAuthToken" : true
	},
	"fhirClinical" : {
		"endpoint" : "http://@app.x1v1@:@app.x1v1.xds.port@/x1v1-fhir-clinical/fhir",
		"useAuthToken" : true
	},
	"fhirMHD" : {
		"endpoint" : "http://@app.x1v1@:@app.x1v1.xds.port@/x1v1-mhd-fhir",
		"useAuthToken" : true
	},
    "extensions": {
        "attachedDocument": "http://apiframework.dedalus.eu/fhir/StructureDefinition/extension-diagnosticReport-attachedDocument",
        "documentReferenceMasterIdentifier": "http://apiframework.dedalus.eu/fhir/StructureDefinition/extension-attachment-documentReferenceMasterIdentifier",
        "documentReferenceContentFormat": "http://apiframework.dedalus.eu/fhir/StructureDefinition/extension-attachment-documentReferenceContentFormat",
        "relatedTo": "http://apiframework.dedalus.eu/fhir/StructureDefinition/extension-attachment-relatedTo",
        "thumbnail": "http://apiframework.dedalus.eu/fhir/StructureDefinition/extension-attachment-thumbnail"
    },
    "codeSystems": {
        "diagnosticReportIdentifierSystems": [
            "urn:oid:2.16.840.1.113883.2.9.3.12.1000",
            "http://www.bmc.nl/zorgportal/identifiers/accessionNumber"
        ],
        "specimenIdentifierSystems": [
            "urn:oid:2.16.840.1.113883.2.9.3.12.1000"
        ],
        "observationIdentifierSystems": [
            "urn:oid:2.16.840.1.113883.2.9.3.12.1000"
        ],
        "attachedDocumentClassIdentifierSystem": "urn:oid:2.16.840.1.113883.2.9.3.12.1000",
        "attachedDocumentClassCode": "0001",
        "imageNoThumbnailClassIdentifierSystem": "urn:oid:2.16.840.1.113883.2.9.3.12.1000",
        "imageNoThumbnailClassCode": "0002",
        "imageClassIdentifierSystem": "urn:oid:2.16.840.1.113883.2.9.3.12.1000",
        "imageClassCode": "0003"
    },
    "thumbnails": {
        "maxWidth": 300,
        "maxHeight": 300
    },
    "templateAssociations": [
		{
			"code" : "COVID19-SELFASSESSMENT-IT",
			"system" : "http://d4solutions.dedalus.eu/fhir/CodeSystem/QuestionnaireCodes-COVID19",
			"language" : "it-IT",
			"filename" : "COVID19-SELFASSESSMENT_it-IT.jrxml"
		},
		{
			"code" : "COVID19-FOLLOWUP-IT",
			"system" : "http://d4solutions.dedalus.eu/fhir/CodeSystem/QuestionnaireCodes-COVID19",
			"language" : "it-IT",
			"filename" : "COVID19-FOLLOWUP_it-IT.jrxml"
		},
		{
			"code" : "COVID19-RAREDESEASES-IT",
			"system" : "http://d4solutions.dedalus.eu/fhir/CodeSystem/QuestionnaireCodes-COVID19",
			"language" : "it-IT",
			"filename" : "COVID19-RAREDESEASES_it-IT.jrxml"
		},{
			"code" : "COVID19-SELFASSESSMENT-IT",
			"system" : "http://d4solutions.dedalus.eu/fhir/CodeSystem/QuestionnaireCodes-COVID19",
			"language" : "en-US",
			"filename" : "COVID19-SELFASSESSMENT_en-US.jrxml"
		},
		{
			"code" : "COVID19-FOLLOWUP-IT",
			"system" : "http://d4solutions.dedalus.eu/fhir/CodeSystem/QuestionnaireCodes-COVID19",
			"language" : "en-US",
			"filename" : "COVID19-FOLLOWUP_en-US.jrxml"
		}
    ]
};