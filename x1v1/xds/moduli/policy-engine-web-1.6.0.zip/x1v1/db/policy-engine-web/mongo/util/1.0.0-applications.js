db.applications.deleteOne({_id : "test"});
db.applications.insertOne(test);

db.applications.deleteOne({_id : "dsub"});
db.applications.insertOne(dsub);

db.applications.deleteOne({_id : "mci_service"});
db.applications.insertOne(mci_service);

db.applications.deleteOne({_id : "fhir_clinical"});
db.applications.insertOne(fhir_clinical);

db.applications.deleteOne({_id : "ce_base"});
db.applications.insertOne(ce_base);

db.applications.deleteOne({_id : "people_fhir"});
db.applications.insertOne(people_fhir);

db.applications.deleteOne({_id : "x1v1_mhd"});
db.applications.insertOne(x1v1_mhd);

db.applications.deleteOne({_id : "xvalue_patsyn"});
db.applications.insertOne(xvalue_patsyn);

db.applications.deleteOne({_id : "x1v1_configurator"});
db.applications.insertOne(x1v1_configurator);

db.applications.deleteOne({_id : "arr_fhir"});
db.applications.insertOne(arr_fhir);

db.applications.deleteOne({_id : "fhir_terminology"});
db.applications.insertOne(fhir_terminology);

db.applications.deleteOne({_id : "pwp_backend"});
db.applications.insertOne(pwp_backend);