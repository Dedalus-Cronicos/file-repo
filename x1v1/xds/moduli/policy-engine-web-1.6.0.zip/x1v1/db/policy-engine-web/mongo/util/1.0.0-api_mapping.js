db.api_mapping.createIndex({ apis : 1 });

db.api_mapping.deleteOne({apis : "agmatrix"});
db.api_mapping.insertOne(agmatrix);

db.api_mapping.deleteOne({apis : "consent"});
db.api_mapping.insertOne(consent);

db.api_mapping.deleteOne({apis : "sampleapi1"});
db.api_mapping.insertOne(sample);