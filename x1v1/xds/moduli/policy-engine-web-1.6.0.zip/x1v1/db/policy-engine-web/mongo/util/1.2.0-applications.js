db.applications.deleteOne({_id : "mci_service"});
db.applications.deleteOne({_id : "fhir_clinical_1_6_0"});
db.applications.deleteOne({_id : "mci_service_1_6_0"});

db.applications.deleteOne({_id : "fhir_clinical"});
db.applications.insertOne(fhir_clinical);

db.applications.deleteOne({_id : "fhir_terminology"});
db.applications.insertOne(fhir_terminology);