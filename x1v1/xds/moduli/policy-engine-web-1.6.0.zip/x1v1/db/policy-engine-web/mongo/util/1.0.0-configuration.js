db.configuration.createIndex({ property : 1 });

db.configuration.deleteOne({property: "cache.timeout.in.millis"});
db.configuration.insertOne(cacheTimeoutInMillis);