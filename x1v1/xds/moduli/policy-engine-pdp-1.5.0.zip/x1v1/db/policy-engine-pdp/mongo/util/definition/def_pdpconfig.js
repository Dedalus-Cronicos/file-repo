var policyUpdaterIntervalMinutes = {
	key: "policy.updater.interval.minutes",
	value: 60,
	type: "number",
	helper: "every X minutes policy are updated from the DB"
};

var xacmlAttributePolicyId = {
	key: "xacml.attribute.policy.id",
	value: XACML_PREFIX + "xacml:3.0:policy:policyId",
	type: "text",
	helper: "this is the attribute that identifiy a policy"
};