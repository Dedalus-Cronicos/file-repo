load("util/definition/commons.js");

load("util/definition/def_pdpconfig.js");
load("util/definition/def_policy.js");