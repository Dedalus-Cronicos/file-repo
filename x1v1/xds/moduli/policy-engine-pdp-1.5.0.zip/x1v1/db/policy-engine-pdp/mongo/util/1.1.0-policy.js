db.policy.remove({
    _id: "X1V1_MEDICO"
});

db.policy.insert({
    _id: "X1V1_MEDICO",
    title: "Abilitazione visibility per X1V1_MEDICO",
    xml: x1v1_medico,
    description: "Abilitazione alla visualizzazione di risorse all'utente con ruolo X1V1_MEDICO.",
    updatable: false
});