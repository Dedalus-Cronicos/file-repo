//mongo 127.0.0.1:27017/xvalue-patsyn -u xvalue-patsyn -p xvalue-patsyn < 1.2.0.js
load("util/definition/def_configuration.js");
load("util/1.2.0-configuration.js");

db.script_version.remove({ key: "xvalue-patsyn"});
db.script_version.insert({ key: "xvalue-patsyn", version : "1.2.0", date: new Date() });
