//mongo admin -u admin -p x1v1mdb --authenticationDatabase admin < init.js
db = db.getSiblingDB("@xvalue.patsyn.mongodb.name@");
db.createUser({ user: "@xvalue.patsyn.mongodb.user@",
  pwd: "@xvalue.patsyn.mongodb.password@",
  roles: [
    { role: "readWrite", db: "@xvalue.patsyn.mongodb.name@"}
  ]
});