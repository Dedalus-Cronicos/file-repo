//mongo 127.0.0.1:27017/xvalue-patsyn -u xvalue-patsyn -p xvalue-patsyn < 1.2.1.js
load("util/definition/def_configuration.js");
load("util/1.3.0-configuration.js");

db.script_version.drop();
