//mongo 127.0.0.1:27017/xvalue-patsyn -u xvalue-patsyn -p xvalue-patsyn < 1.0.0.js
db.createCollection('configuration');
load("util/definition/def_configuration.js");
load("util/1.0.0-configuration.js");

db.script_version.remove({ key: "xvalue-patsyn"});
db.script_version.insert({ key: "xvalue-patsyn", version : "1.0.0", date: new Date() });
