//mongo 127.0.0.1:27017/xvalue-patsyn -u xvalue-patsyn -p xvalue-patsyn < delta.js
var tag = "xvalue-patsyn";

function getInstalledVersion() {
	var installedVersion = db.schema_version.aggregate({$match: {tag: tag}}, {$project: { installedVersion : { $concat : ["$major", ".", "$minor", ".", "$patch"]}}}) || '0.0.0';
	if (installedVersion && installedVersion.hasNext()) {
		installedVersion = installedVersion.next().installedVersion || '0.0.0';
	} else {
		installedVersion = '0.0.0';
	}
	return installedVersion;
}

function compareVersions(v1, v2) {
    var v1parts = v1.split('.'),
        v2parts = v2.split('.');    
    function isValidPart(x) {
        return (/^\d+$/).test(x);
    }
    if (!v1parts.every(isValidPart) || !v2parts.every(isValidPart)) {
        return NaN;
    }
    for (var i = 0; i < v1parts.length; i++) {
    	
        if (Number(v1parts[i]) == Number(v2parts[i])) {
            continue;
        }
        else if (Number(v1parts[i]) > Number(v2parts[i])) {
            return 1;
        }
        else {
            return -1;
        }
    }
    return 0;
}

function executeScript(major, minor, patch, applicationTag) {
	var fileVersionedName = major+"."+minor+"."+patch;
	print("install > " + pwd()+"/"+fileVersionedName+".js");
	load(pwd()+"/"+fileVersionedName+".js");
	db.schema_version.remove({tag: applicationTag});
	db.schema_version.insert({major: major, minor: minor, patch: patch, tag: tag, revision:0, last_change: new Date(), description: ""});
	print("installed > " + pwd()+"/"+fileVersionedName+".js");	
}

var installedVersion = getInstalledVersion();
var files = ls();
if (files) {
	files = files.map(function(fileName, index) {
		return fileName.replace("./","").replace(".js","");
	});
	files = files.filter(function(fileName) {
		return (/^[0-9]+\.[0-9]+\.[0-9]+$/).test(fileName);
	});
	files.sort(function compareFileVersions(v1, v2) {
		return compareVersions(v1, v2);
	});
	print("START UPDATE FROM '"+installedVersion+"' VERSION");
	var _scriptConfigurations = [];
	for (var i = 0; i < files.length; i++) {
		var scriptMajor = files[i].split(".")[0];
		var scriptMinor = files[i].split(".")[1];
		var scriptPatch = files[i].split(".")[2];
		if (compareVersions(files[i], installedVersion) > 0) {
			_scriptConfigurations.push({major: scriptMajor, minor: scriptMinor, patch: scriptPatch, applicationTag: tag});
		}
	}
	for (var j = 0; j < _scriptConfigurations.length; j++) {
		executeScript(_scriptConfigurations[j].major, _scriptConfigurations[j].minor, _scriptConfigurations[j].patch, _scriptConfigurations[j].applicationTag);
	}
	print("END UPDATE FROM '"+installedVersion+"' VERSION");
}