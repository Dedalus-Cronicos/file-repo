db.pdpconfig.ensureIndex({ key : 1 });

db.pdpconfig.insert(policyUpdaterIntervalMinutes);
db.pdpconfig.insert(xacmlAttributePolicyId);