db.createCollection("schema_version");

db.getCollection("schema_version").insert(
    {
        "major" : "1",
        "minor" : "0",
        "patch" : "0",
        "tag" : "ucc",
        "revision" : 0,
        "last_change" : ISODate("2021-09-23T10:00:27.604+02:00"),
        "description" : ""
    }
);
