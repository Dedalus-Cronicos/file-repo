db.applications.remove({_id : "x1v1_mhd"});
db.applications.insert(x1v1_mhd);